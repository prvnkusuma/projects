import * as actionTypes from "actions/actiontypes/BulkReProcessDeclineDialogActionTypes";

const getBulkReProcessDeclineDialog = () => {
  return dispatch => {
    dispatch({
      type: actionTypes.GET_BULK_REDECLINE_DIALOG
    });
  };
};

const addBulkReProcessDeclineDialog = bulkReDeclineSearch => {
  return dispatch => {
    dispatch({
      type: actionTypes.ADD_BULK_REDECLINE_DIALOG,
      payload: bulkReDeclineSearch
    });
  };
};

const delBulkReProcessDeclineDialog = () => {
  return dispatch => {
    dispatch({
      type: actionTypes.DEL_BULK_REDECLINE_DIALOG
    });
  };
};

export {
  getBulkReProcessDeclineDialog,
  addBulkReProcessDeclineDialog,
  delBulkReProcessDeclineDialog
};
