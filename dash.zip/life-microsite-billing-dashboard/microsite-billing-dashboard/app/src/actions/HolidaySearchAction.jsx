import * as actionTypes from "actions/actiontypes/HolidaySearchActionTypes";

const initHolidaySearch = () => {
  return dispatch => {
    dispatch({
      type: actionTypes.INIT_HOLIDAY_SEARCH
    });
  };
};

const getHolidaySearch = () => {
  return dispatch => {
    dispatch({
      type: actionTypes.GET_HOLIDAY_SEARCH
    });
  };
};

const addHolidaySearch = holidaySearch => {
  return dispatch => {
    dispatch({
      type: actionTypes.ADD_HOLIDAY_SEARCH,
      payload: holidaySearch
    });
  };
};

const delHolidaySearch = () => {
  return dispatch => {
    dispatch({
      type: actionTypes.DEL_HOLIDAY_SEARCH
    });
  };
};

export {
  initHolidaySearch,
  getHolidaySearch,
  addHolidaySearch,
  delHolidaySearch
};
