import * as actionTypes from "actions/actiontypes/AWDSearchActionTypes";

const initAWDSearch = () => {
  return dispatch => {
    dispatch({
      type: actionTypes.INIT_AWD_SEARCH
    });
  };
};

const getAWDSearch = () => {
  return dispatch => {
    dispatch({
      type: actionTypes.GET_AWD_SEARCH
    });
  };
};

const addAWDSearch = awdSearch => {
  return dispatch => {
    dispatch({
      type: actionTypes.ADD_AWD_SEARCH,
      payload: awdSearch
    });
  };
};

const delAWDSearch = () => {
  return dispatch => {
    dispatch({
      type: actionTypes.DEL_AWD_SEARCH
    });
  };
};

export { initAWDSearch, getAWDSearch, addAWDSearch, delAWDSearch };
