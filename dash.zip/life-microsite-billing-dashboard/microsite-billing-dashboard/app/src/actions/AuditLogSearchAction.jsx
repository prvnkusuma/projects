import * as actionTypes from "actions/actiontypes/AuditLogSearchActionTypes";

const initAuditLogSearch = () => {
  return dispatch => {
    dispatch({
      type: actionTypes.INIT_AUDITLOG_SEARCH
    });
  };
};

const getAuditLogSearch = () => {
  return dispatch => {
    dispatch({
      type: actionTypes.GET_AUDITLOG_SEARCH
    });
  };
};

const addAuditLogSearch = auditLogSearch => {
  return dispatch => {
    dispatch({
      type: actionTypes.ADD_AUDITLOG_SEARCH,
      payload: auditLogSearch
    });
  };
};

const delAuditLogSearch = () => {
  return dispatch => {
    dispatch({
      type: actionTypes.DEL_AUDITLOG_SEARCH
    });
  };
};

export {
  initAuditLogSearch,
  getAuditLogSearch,
  addAuditLogSearch,
  delAuditLogSearch
};
