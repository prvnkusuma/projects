import * as actionTypes from "actions/actiontypes/BillSearchActionTypes";

const initBillSearch = () => {
  return dispatch => {
    dispatch({
      type: actionTypes.INIT_BILLSEARCH
    });
  };
};

const getBillSearch = () => {
  return dispatch => {
    dispatch({
      type: actionTypes.GET_BILLSEARCH
    });
  };
};

const addBillSearch = billSearch => {
  return dispatch => {
    dispatch({
      type: actionTypes.ADD_BILLSEARCH,
      payload: billSearch
    });
  };
};

const delBillSearch = () => {
  return dispatch => {
    dispatch({
      type: actionTypes.DEL_BILLSEARCH
    });
  };
};

export { initBillSearch, getBillSearch, addBillSearch, delBillSearch };
