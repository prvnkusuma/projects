import * as actionTypes from "actions/actiontypes/BulkReProcessRemitDialogActionTypes";

const getBulkReProcessRemitDialog = () => {
  return dispatch => {
    dispatch({
      type: actionTypes.GET_BULK_REREMIT_DIALOG
    });
  };
};

const addBulkReProcessRemitDialog = bulkReRemitSearch => {
  return dispatch => {
    dispatch({
      type: actionTypes.ADD_BULK_REREMIT_DIALOG,
      payload: bulkReRemitSearch
    });
  };
};

const delBulkReProcessRemitDialog = () => {
  return dispatch => {
    dispatch({
      type: actionTypes.DEL_BULK_REREMIT_DIALOG
    });
  };
};

export {
  getBulkReProcessRemitDialog,
  addBulkReProcessRemitDialog,
  delBulkReProcessRemitDialog
};
