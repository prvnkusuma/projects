import * as actionTypes from "actions/actiontypes/BulkReProcessBillDialogActionTypes";

const getBulkReProcessBillDialog = () => {
  return dispatch => {
    dispatch({
      type: actionTypes.GET_BULK_REBILL_DIALOG
    });
  };
};

const addBulkReProcessBillDialog = bulkRebillSearch => {
  return dispatch => {
    dispatch({
      type: actionTypes.ADD_BULK_REBILL_DIALOG,
      payload: bulkRebillSearch
    });
  };
};

const delBulkReProcessBillDialog = () => {
  return dispatch => {
    dispatch({
      type: actionTypes.DEL_BULK_REBILL_DIALOG
    });
  };
};

export {
  getBulkReProcessBillDialog,
  addBulkReProcessBillDialog,
  delBulkReProcessBillDialog
};
