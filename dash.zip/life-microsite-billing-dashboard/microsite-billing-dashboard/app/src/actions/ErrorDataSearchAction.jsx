import * as actionTypes from "actions/actiontypes/ErrorDataSearchActionTypes";

const initErrorDataSearch = () => {
  return dispatch => {
    dispatch({
      type: actionTypes.INIT_ERRORDATA_SEARCH
    });
  };
};

const getErrorDataSearch = () => {
  return dispatch => {
    dispatch({
      type: actionTypes.GET_ERRORDATA_SEARCH
    });
  };
};

const addErrorDataSearch = errorDataSearch => {
  return dispatch => {
    dispatch({
      type: actionTypes.ADD_ERRORDATA_SEARCH,
      payload: errorDataSearch
    });
  };
};

const delErrorDataSearch = () => {
  return dispatch => {
    dispatch({
      type: actionTypes.DEL_ERRORDATA_SEARCH
    });
  };
};

export {
  initErrorDataSearch,
  getErrorDataSearch,
  addErrorDataSearch,
  delErrorDataSearch
};
