import * as actionTypes from "actions/actiontypes/EFTBankHeaderInquiryActionTypes";

const initBankHeaderInquiry = () => {
  return dispatch => {
    dispatch({
      type: actionTypes.INIT_BANKHEADER_INQUIRY
    });
  };
};

const getBankHeaderInquiry = () => {
  return dispatch => {
    dispatch({
      type: actionTypes.GET_BANKHEADER_INQUIRY
    });
  };
};

const addBankHeaderInquiry = bankHeaderInquiry => {
  return dispatch => {
    dispatch({
      type: actionTypes.ADD_BANKHEADER_INQUIRY,
      payload: bankHeaderInquiry
    });
  };
};

const delBankHeaderInquiry = () => {
  return dispatch => {
    dispatch({
      type: actionTypes.DEL_BANKHEADER_INQUIRY
    });
  };
};

export {
  initBankHeaderInquiry,
  getBankHeaderInquiry,
  addBankHeaderInquiry,
  delBankHeaderInquiry
};
