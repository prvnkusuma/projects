export const INIT_AWD_SEARCH = "INIT_AWD_SEARCH";
export const GET_AWD_SEARCH = "GET_AWD_SEARCH";
export const ADD_AWD_SEARCH = "ADD_AWD_SEARCH";
export const DEL_AWD_SEARCH = "DEL_AWD_SEARCH";
