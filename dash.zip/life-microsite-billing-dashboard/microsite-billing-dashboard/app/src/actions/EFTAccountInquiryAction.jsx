import * as actionTypes from "actions/actiontypes/EFTAccountInquiryActionTypes";

const initAccountInquiry = () => {
  return dispatch => {
    dispatch({
      type: actionTypes.INIT_ACCOUNT_INQUIRY
    });
  };
};

const getAccountInquiry = () => {
  return dispatch => {
    dispatch({
      type: actionTypes.GET_ACCOUNT_INQUIRY
    });
  };
};

const addAccountInquiry = AccountInquiry => {
  return dispatch => {
    dispatch({
      type: actionTypes.ADD_ACCOUNT_INQUIRY,
      payload: AccountInquiry
    });
  };
};

const delAccountInquiry = () => {
  return dispatch => {
    dispatch({
      type: actionTypes.DEL_ACCOUNT_INQUIRY
    });
  };
};

export {
  initAccountInquiry,
  getAccountInquiry,
  addAccountInquiry,
  delAccountInquiry
};
