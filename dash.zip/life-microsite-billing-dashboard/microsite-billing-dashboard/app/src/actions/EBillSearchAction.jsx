import * as actionTypes from "actions/actiontypes/EBillSearchActionTypes";

const initEBillSearch = () => {
  return dispatch => {
    dispatch({
      type: actionTypes.INIT_EBILL_SEARCH
    });
  };
};

const getEBillSearch = () => {
  return dispatch => {
    dispatch({
      type: actionTypes.GET_EBILL_SEARCH
    });
  };
};

const addEBillSearch = correspondenceSearch => {
  return dispatch => {
    dispatch({
      type: actionTypes.ADD_EBILL_SEARCH,
      payload: correspondenceSearch
    });
  };
};

const delEBillSearch = () => {
  return dispatch => {
    dispatch({
      type: actionTypes.DEL_EBILL_SEARCH
    });
  };
};

export { initEBillSearch, getEBillSearch, addEBillSearch, delEBillSearch };
