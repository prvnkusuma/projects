import * as actionTypes from "actions/actiontypes/DeclineSearchActionTypes";

const initDeclineSearch = () => {
  return dispatch => {
    dispatch({
      type: actionTypes.INIT_DECLINE_SEARCH
    });
  };
};

const getDeclineSearch = () => {
  return dispatch => {
    dispatch({
      type: actionTypes.GET_DECLINE_SEARCH
    });
  };
};

const addDeclineSearch = declineSearch => {
  return dispatch => {
    dispatch({
      type: actionTypes.ADD_DECLINE_SEARCH,
      payload: declineSearch
    });
  };
};

const delDeclineSearch = () => {
  return dispatch => {
    dispatch({
      type: actionTypes.DEL_DECLINE_SEARCH
    });
  };
};

export {
  initDeclineSearch,
  getDeclineSearch,
  addDeclineSearch,
  delDeclineSearch
};
