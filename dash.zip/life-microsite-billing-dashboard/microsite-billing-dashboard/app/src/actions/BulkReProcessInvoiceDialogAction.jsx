import * as actionTypes from "actions/actiontypes/BulkReProcessInvoiceDialogActionTypes";

const getBulkReProcessInvoiceDialog = () => {
  return dispatch => {
    dispatch({
      type: actionTypes.GET_BULK_REINVOICE_DIALOG
    });
  };
};

const addBulkReProcessInvoiceDialog = bulkReInvoiceSearch => {
  return dispatch => {
    dispatch({
      type: actionTypes.ADD_BULK_REINVOICE_DIALOG,
      payload: bulkReInvoiceSearch
    });
  };
};

const delBulkReProcessInvoiceDialog = () => {
  return dispatch => {
    dispatch({
      type: actionTypes.DEL_BULK_REINVOICE_DIALOG
    });
  };
};

export {
  getBulkReProcessInvoiceDialog,
  addBulkReProcessInvoiceDialog,
  delBulkReProcessInvoiceDialog
};
