import * as actionTypes from "actions/actiontypes/ManualBillSearchActionTypes";

const initManualBillSearch = () => {
  return dispatch => {
    dispatch({
      type: actionTypes.INIT_MANUALBILL_SEARCH
    });
  };
};

const getManualBillSearch = () => {
  return dispatch => {
    dispatch({
      type: actionTypes.GET_MANUALBILL_SEARCH
    });
  };
};

const addManualBillSearch = manualBillSearch => {
  return dispatch => {
    dispatch({
      type: actionTypes.ADD_MANUALBILL_SEARCH,
      payload: manualBillSearch
    });
  };
};

const delManualBillSearch = () => {
  return dispatch => {
    dispatch({
      type: actionTypes.DEL_MANUALBILL_SEARCH
    });
  };
};

export {
  initManualBillSearch,
  getManualBillSearch,
  addManualBillSearch,
  delManualBillSearch
};
