import * as actionTypes from "actions/actiontypes/CorrespondenceSearchActionTypes";

const initCorrespondenceSearch = () => {
  return dispatch => {
    dispatch({
      type: actionTypes.INIT_CORRESPONDENCE_SEARCH
    });
  };
};

const getCorrespondenceSearch = () => {
  return dispatch => {
    dispatch({
      type: actionTypes.GET_CORRESPONDENCE_SEARCH
    });
  };
};

const addCorrespondenceSearch = correspondenceSearch => {
  return dispatch => {
    dispatch({
      type: actionTypes.ADD_CORRESPONDENCE_SEARCH,
      payload: correspondenceSearch
    });
  };
};

const delCorrespondenceSearch = () => {
  return dispatch => {
    dispatch({
      type: actionTypes.DEL_CORRESPONDENCE_SEARCH
    });
  };
};

export {
  initCorrespondenceSearch,
  getCorrespondenceSearch,
  addCorrespondenceSearch,
  delCorrespondenceSearch
};
