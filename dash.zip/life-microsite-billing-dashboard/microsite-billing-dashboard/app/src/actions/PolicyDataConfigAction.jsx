import * as actionTypes from "actions/actiontypes/PolicyDataConfigActionTypes";

const initPolDataConfig = () => {
  return dispatch => {
    dispatch({
      type: actionTypes.INIT_POLDATA_CONFIG
    });
  };
};

const getPolDataConfig = () => {
  return dispatch => {
    dispatch({
      type: actionTypes.GET_POLDATA_CONFIG
    });
  };
};

const addPolDataConfig = polDataConfig => {
  return dispatch => {
    dispatch({
      type: actionTypes.ADD_POLDATA_CONFIG,
      payload: polDataConfig
    });
  };
};

const delPolDataConfig = () => {
  return dispatch => {
    dispatch({
      type: actionTypes.DEL_POLDATA_CONFIG
    });
  };
};

export {
  initPolDataConfig,
  getPolDataConfig,
  addPolDataConfig,
  delPolDataConfig
};
