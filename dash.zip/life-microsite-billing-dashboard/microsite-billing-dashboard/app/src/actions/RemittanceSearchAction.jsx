import * as actionTypes from "actions/actiontypes/RemittanceSearchActionTypes";

const initRemittanceSearch = () => {
  return dispatch => {
    dispatch({
      type: actionTypes.INIT_REMIT_SEARCH
    });
  };
};

const getRemittanceSearch = () => {
  return dispatch => {
    dispatch({
      type: actionTypes.GET_REMIT_SEARCH
    });
  };
};

const addRemittanceSearch = remittanceSearch => {
  return dispatch => {
    dispatch({
      type: actionTypes.ADD_REMIT_SEARCH,
      payload: remittanceSearch
    });
  };
};

const delRemittanceSearch = () => {
  return dispatch => {
    dispatch({
      type: actionTypes.DEL_REMIT_SEARCH
    });
  };
};

export {
  initRemittanceSearch,
  getRemittanceSearch,
  addRemittanceSearch,
  delRemittanceSearch
};
