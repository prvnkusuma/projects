import * as actionTypes from "actions/actiontypes/PhonePaymentEntryActionTypes";

const initPhonePaymentEntry = () => {
  return dispatch => {
    dispatch({
      type: actionTypes.INIT_PHONEPAYMENT_ENTRY
    });
  };
};

const getPhonePaymentEntry = () => {
  return dispatch => {
    dispatch({
      type: actionTypes.GET_PHONEPAYMENT_ENTRY
    });
  };
};

const addPhonePaymentEntry = phonePaymentEntry => {
  return dispatch => {
    dispatch({
      type: actionTypes.ADD_PHONEPAYMENT_ENTRY,
      payload: phonePaymentEntry
    });
  };
};

const delPhonePaymentEntry = () => {
  return dispatch => {
    dispatch({
      type: actionTypes.DEL_PHONEPAYMENT_ENTRY
    });
  };
};

export {
  initPhonePaymentEntry,
  getPhonePaymentEntry,
  addPhonePaymentEntry,
  delPhonePaymentEntry
};
