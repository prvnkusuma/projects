import * as actionTypes from "actions/actiontypes/BulkReProcessAWDDialogActionTypes";

const getBulkReProcessAWDDialog = () => {
  return dispatch => {
    dispatch({
      type: actionTypes.GET_BULK_REAWD_DIALOG
    });
  };
};

const addBulkReProcessAWDDialog = bulkReAWDSearch => {
  return dispatch => {
    dispatch({
      type: actionTypes.ADD_BULK_REAWD_DIALOG,
      payload: bulkReAWDSearch
    });
  };
};

const delBulkReProcessAWDDialog = () => {
  return dispatch => {
    dispatch({
      type: actionTypes.DEL_BULK_REAWD_DIALOG
    });
  };
};

export {
  getBulkReProcessAWDDialog,
  addBulkReProcessAWDDialog,
  delBulkReProcessAWDDialog
};
