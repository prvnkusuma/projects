import * as actionTypes from "actions/actiontypes/InvoiceSearchActionTypes";

const initInvoiceSearch = () => {
  return dispatch => {
    dispatch({
      type: actionTypes.INIT_INVOICE_SEARCH
    });
  };
};

const getInvoiceSearch = () => {
  return dispatch => {
    dispatch({
      type: actionTypes.GET_INVOICE_SEARCH
    });
  };
};

const addInvoiceSearch = remittanceSearch => {
  return dispatch => {
    dispatch({
      type: actionTypes.ADD_INVOICE_SEARCH,
      payload: remittanceSearch
    });
  };
};

const delInvoiceSearch = () => {
  return dispatch => {
    dispatch({
      type: actionTypes.DEL_INVOICE_SEARCH
    });
  };
};

export {
  initInvoiceSearch,
  getInvoiceSearch,
  addInvoiceSearch,
  delInvoiceSearch
};
