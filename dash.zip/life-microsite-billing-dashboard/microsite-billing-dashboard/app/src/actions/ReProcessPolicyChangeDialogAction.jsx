import * as actionTypes from "actions/actiontypes/ReProcessPolicyChangeDialogActionTypes";

const getReProcessPolicyChangeDialog = () => {
  return dispatch => {
    dispatch({
      type: actionTypes.GET_REPOL_CHANGE_DIALOG
    });
  };
};

const addReProcessPolicyChangeDialog = rebillSearch => {
  return dispatch => {
    dispatch({
      type: actionTypes.ADD_REPOL_CHANGE_DIALOG,
      payload: rebillSearch
    });
  };
};

const delReProcessPolicyChangeDialog = () => {
  return dispatch => {
    dispatch({
      type: actionTypes.DEL_REPOL_CHANGE_DIALOG
    });
  };
};

export {
  getReProcessPolicyChangeDialog,
  addReProcessPolicyChangeDialog,
  delReProcessPolicyChangeDialog
};
