import * as actionTypes from "actions/actiontypes/ReportingSearchActionTypes";

const initReportingSearch = () => {
  return dispatch => {
    dispatch({
      type: actionTypes.INIT_REPORTING_SEARCH
    });
  };
};

const getReportingSearch = () => {
  return dispatch => {
    dispatch({
      type: actionTypes.GET_REPORTING_SEARCH
    });
  };
};

const addReportingSearch = reportingSearch => {
  return dispatch => {
    dispatch({
      type: actionTypes.ADD_REPORTING_SEARCH,
      payload: reportingSearch
    });
  };
};

const delReportingSearch = () => {
  return dispatch => {
    dispatch({
      type: actionTypes.DEL_REPORTING_SEARCH
    });
  };
};

export {
  initReportingSearch,
  getReportingSearch,
  addReportingSearch,
  delReportingSearch
};
