import * as actionTypes from "actions/actiontypes/ReProcessRemitDialogActionTypes";

const getReProcessRemitDialog = () => {
  return dispatch => {
    dispatch({
      type: actionTypes.GET_REMIT_DIALOG
    });
  };
};

const addReProcessRemitDialog = reprocessRemitDialog => {
  return dispatch => {
    dispatch({
      type: actionTypes.ADD_REMIT_DIALOG,
      payload: reprocessRemitDialog
    });
  };
};

const delReProcessRemitDialog = () => {
  return dispatch => {
    dispatch({
      type: actionTypes.DEL_REMIT_DIALOG
    });
  };
};

export {
  getReProcessRemitDialog,
  addReProcessRemitDialog,
  delReProcessRemitDialog
};
