import * as actionTypes from "actions/actiontypes/ReProcessBillDialogActionTypes";

const getReProcessBillDialog = () => {
  return dispatch => {
    dispatch({
      type: actionTypes.GET_REBILL_DIALOG
    });
  };
};

const addReProcessBillDialog = rebillSearch => {
  return dispatch => {
    dispatch({
      type: actionTypes.ADD_REBILL_DIALOG,
      payload: rebillSearch
    });
  };
};

const delReProcessBillDialog = () => {
  return dispatch => {
    dispatch({
      type: actionTypes.DEL_REBILL_DIALOG
    });
  };
};

export {
  getReProcessBillDialog,
  addReProcessBillDialog,
  delReProcessBillDialog
};
