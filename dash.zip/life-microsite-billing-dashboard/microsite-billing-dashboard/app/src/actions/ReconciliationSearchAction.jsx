import * as actionTypes from "actions/actiontypes/ReconciliationSearchActionTypes";

const initReconciliationSearch = () => {
  return dispatch => {
    dispatch({
      type: actionTypes.INIT_RECON_SEARCH
    });
  };
};

const getReconciliationSearch = () => {
  return dispatch => {
    dispatch({
      type: actionTypes.GET_RECON_SEARCH
    });
  };
};

const addReconciliationSearch = reconciliationSearch => {
  return dispatch => {
    dispatch({
      type: actionTypes.ADD_RECON_SEARCH,
      payload: reconciliationSearch
    });
  };
};

const delReconciliationSearch = () => {
  return dispatch => {
    dispatch({
      type: actionTypes.DEL_RECON_SEARCH
    });
  };
};

const delEFTReconciliationSearch = reconciliationSearch => {
  return dispatch => {
    dispatch({
      type: actionTypes.DEL_EFT_RECON_SEARCH,
      payload: reconciliationSearch
    });
  };
};

export {
  initReconciliationSearch,
  getReconciliationSearch,
  addReconciliationSearch,
  delReconciliationSearch,
  delEFTReconciliationSearch
};
