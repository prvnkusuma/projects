import * as actionTypes from "actions/actiontypes/PolicyChangeSearchActionTypes";

const initPolicyChangeSearch = () => {
  return dispatch => {
    dispatch({
      type: actionTypes.INIT_POLCHANGE_SEARCH
    });
  };
};

const getPolicyChangeSearch = () => {
  return dispatch => {
    dispatch({
      type: actionTypes.GET_POLCHANGE_SEARCH
    });
  };
};

const addPolicyChangeSearch = PolicyChangeSearch => {
  return dispatch => {
    dispatch({
      type: actionTypes.ADD_POLCHANGE_SEARCH,
      payload: PolicyChangeSearch
    });
  };
};

const delPolicyChangeSearch = () => {
  return dispatch => {
    dispatch({
      type: actionTypes.DEL_POLCHANGE_SEARCH
    });
  };
};

export {
  initPolicyChangeSearch,
  getPolicyChangeSearch,
  addPolicyChangeSearch,
  delPolicyChangeSearch
};
