import * as actionTypes from "actions/actiontypes/BulkReProcessCorrespondenceDialogActionTypes";

const getBulkReProcessCorrespondenceDialog = () => {
  return dispatch => {
    dispatch({
      type: actionTypes.GET_BULK_RECORRESP_DIALOG
    });
  };
};

const addBulkReProcessCorrespondenceDialog = bulkReCorrespondenceSearch => {
  return dispatch => {
    dispatch({
      type: actionTypes.ADD_BULK_RECORRESP_DIALOG,
      payload: bulkReCorrespondenceSearch
    });
  };
};

const delBulkReProcessCorrespondenceDialog = () => {
  return dispatch => {
    dispatch({
      type: actionTypes.DEL_BULK_RECORRESP_DIALOG
    });
  };
};

export {
  getBulkReProcessCorrespondenceDialog,
  addBulkReProcessCorrespondenceDialog,
  delBulkReProcessCorrespondenceDialog
};
