import * as actionTypes from "actions/actiontypes/BulkReProcessEFTReturnsDialogActionTypes";

const getBulkReProcessEFTReturnsDialog = () => {
  return dispatch => {
    dispatch({
      type: actionTypes.GET_BULK_REEFTRETURNS_DIALOG
    });
  };
};

const addBulkReProcessEFTReturnsDialog = bulkReReportSearch => {
  return dispatch => {
    dispatch({
      type: actionTypes.ADD_BULK_REEFTRETURNS_DIALOG,
      payload: bulkReReportSearch
    });
  };
};

const delBulkReProcessEFTReturnsDialog = () => {
  return dispatch => {
    dispatch({
      type: actionTypes.DEL_BULK_REEFTRETURNS_DIALOG
    });
  };
};

export {
  getBulkReProcessEFTReturnsDialog,
  addBulkReProcessEFTReturnsDialog,
  delBulkReProcessEFTReturnsDialog
};
