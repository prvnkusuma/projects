import * as actionTypes from "actions/actiontypes/EFTReturnsSearchActionTypes";

const initEFTReturnsSearch = () => {
  return dispatch => {
    dispatch({
      type: actionTypes.INIT_EFTRETURNS_SEARCH
    });
  };
};

const getEFTReturnsSearch = () => {
  return dispatch => {
    dispatch({
      type: actionTypes.GET_EFTRETURNS_SEARCH
    });
  };
};

const addEFTReturnsSearch = eftReturnsSearch => {
  return dispatch => {
    dispatch({
      type: actionTypes.ADD_EFTRETURNS_SEARCH,
      payload: eftReturnsSearch
    });
  };
};

const delEFTReturnsSearch = () => {
  return dispatch => {
    dispatch({
      type: actionTypes.DEL_EFTRETURNS_SEARCH
    });
  };
};

export {
  initEFTReturnsSearch,
  getEFTReturnsSearch,
  addEFTReturnsSearch,
  delEFTReturnsSearch
};
