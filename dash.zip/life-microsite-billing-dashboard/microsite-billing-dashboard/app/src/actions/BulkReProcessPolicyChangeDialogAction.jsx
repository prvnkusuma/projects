import * as actionTypes from "actions/actiontypes/BulkReProcessPolicyChangeDialogActionTypes";

const getBulkReProcessPolicyChangeDialog = () => {
  return dispatch => {
    dispatch({
      type: actionTypes.GET_BULK_REPOL_CHG_DIALOG
    });
  };
};

const addBulkReProcessPolicyChangeDialog = bulkRePolChangeSearch => {
  return dispatch => {
    dispatch({
      type: actionTypes.ADD_BULK_REPOL_CHG_DIALOG,
      payload: bulkRePolChangeSearch
    });
  };
};

const delBulkReProcessPolicyChangeDialog = () => {
  return dispatch => {
    dispatch({
      type: actionTypes.DEL_BULK_REPOL_CHG_DIALOG
    });
  };
};

export {
  getBulkReProcessPolicyChangeDialog,
  addBulkReProcessPolicyChangeDialog,
  delBulkReProcessPolicyChangeDialog
};
