import * as actionTypes from "actions/actiontypes/BulkReProcessReportingDialogActionTypes";

const getBulkReProcessReportingDialog = () => {
  return dispatch => {
    dispatch({
      type: actionTypes.GET_BULK_REREPORT_DIALOG
    });
  };
};

const addBulkReProcessReportingDialog = bulkReReportSearch => {
  return dispatch => {
    dispatch({
      type: actionTypes.ADD_BULK_REREPORT_DIALOG,
      payload: bulkReReportSearch
    });
  };
};

const delBulkReProcessReportingDialog = () => {
  return dispatch => {
    dispatch({
      type: actionTypes.DEL_BULK_REREPORT_DIALOG
    });
  };
};

export {
  getBulkReProcessReportingDialog,
  addBulkReProcessReportingDialog,
  delBulkReProcessReportingDialog
};
