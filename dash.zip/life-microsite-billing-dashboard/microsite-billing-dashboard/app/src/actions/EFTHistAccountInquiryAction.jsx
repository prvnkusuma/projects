import * as actionTypes from "actions/actiontypes/EFTHistAccountInquiryActionTypes";

const initHistAccountInquiry = () => {
  return dispatch => {
    dispatch({
      type: actionTypes.INIT_HIST_ACCOUNT_INQUIRY
    });
  };
};

const getHistAccountInquiry = () => {
  return dispatch => {
    dispatch({
      type: actionTypes.GET_HIST_ACCOUNT_INQUIRY
    });
  };
};

const addHistAccountInquiry = HistAccountInquiry => {
  return dispatch => {
    dispatch({
      type: actionTypes.ADD_HIST_ACCOUNT_INQUIRY,
      payload: HistAccountInquiry
    });
  };
};

const delHistAccountInquiry = () => {
  return dispatch => {
    dispatch({
      type: actionTypes.DEL_HIST_ACCOUNT_INQUIRY
    });
  };
};

export {
  initHistAccountInquiry,
  getHistAccountInquiry,
  addHistAccountInquiry,
  delHistAccountInquiry
};
