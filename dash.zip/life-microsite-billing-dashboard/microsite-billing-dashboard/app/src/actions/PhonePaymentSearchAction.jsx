import * as actionTypes from "actions/actiontypes/PhonePaymentSearchActionTypes";

const initPhonePaymentSearch = () => {
  return dispatch => {
    dispatch({
      type: actionTypes.INIT_PHONEPAYMENT_SEARCH
    });
  };
};

const getPhonePaymentSearch = () => {
  return dispatch => {
    dispatch({
      type: actionTypes.GET_PHONEPAYMENT_SEARCH
    });
  };
};

const addPhonePaymentSearch = phonePaymentSearch => {
  return dispatch => {
    dispatch({
      type: actionTypes.ADD_PHONEPAYMENT_SEARCH,
      payload: phonePaymentSearch
    });
  };
};

const delPhonePaymentSearch = () => {
  return dispatch => {
    dispatch({
      type: actionTypes.DEL_PHONEPAYMENT_SEARCH
    });
  };
};

export {
  initPhonePaymentSearch,
  getPhonePaymentSearch,
  addPhonePaymentSearch,
  delPhonePaymentSearch
};
