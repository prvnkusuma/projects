import * as actionTypes from "actions/actiontypes/HolidayConfigAddDialogActionTypes";

const getHolidayConfigAddDialog = () => {
  return dispatch => {
    dispatch({
      type: actionTypes.GET_HOLIDAY_ADD_DIALOG
    });
  };
};

const addHolidayConfigAddDialog = holidayAddDialog => {
  return dispatch => {
    dispatch({
      type: actionTypes.ADD_HOLIDAY_ADD_DIALOG,
      payload: holidayAddDialog
    });
  };
};

const delHolidayConfigAddDialog = () => {
  return dispatch => {
    dispatch({
      type: actionTypes.DEL_HOLIDAY_ADD_DIALOG
    });
  };
};

export {
  getHolidayConfigAddDialog,
  addHolidayConfigAddDialog,
  delHolidayConfigAddDialog
};
