import * as actionTypes from "actions/actiontypes/ErrorFlagConfigAddDialogActionTypes";

const getErrorFlagConfigAddDialog = () => {
  return dispatch => {
    dispatch({
      type: actionTypes.GET_ERROR_CONFIG_ADD_DIALOG
    });
  };
};

const addErrorFlagConfigAddDialog = errorConfigAddDialog => {
  return dispatch => {
    dispatch({
      type: actionTypes.ADD_ERROR_CONFIG_ADD_DIALOG,
      payload: errorConfigAddDialog
    });
  };
};

const delErrorFlagConfigAddDialog = () => {
  return dispatch => {
    dispatch({
      type: actionTypes.DEL_ERROR_CONFIG_ADD_DIALOG
    });
  };
};

export {
  getErrorFlagConfigAddDialog,
  addErrorFlagConfigAddDialog,
  delErrorFlagConfigAddDialog
};
