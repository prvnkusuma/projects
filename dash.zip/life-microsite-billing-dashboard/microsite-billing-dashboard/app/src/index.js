import React from "react";
import ReactDOM from "react-dom";
import { PropTypes } from "prop-types";
import { Provider } from "react-redux";
import { HashRouter, Route } from "react-router-dom";
import IdleTimer from "react-idle-timer";
import { withRouter } from "react-router";
import store from "Store.jsx";

// These are needed for react components to work properly in IE11
import "core-js/es6/number";
import "core-js/es6/array";
import "core-js/es6/map";
import "core-js/es6/set";
import "raf/polyfill";

import App from "App.jsx";

class Index extends React.Component {
  constructor(props) {
    super(props);
    this.idleTimer = null;
    this.onIdle = this._onIdle.bind(this);
  }

  _onIdle() {
    localStorage.removeItem("userProf");
    localStorage.removeItem("user");
    this.props.history.replace("/login");
  }

  render() {
    return (
      <React.Fragment>
        <Provider store={store}>
          <IdleTimer
            ref={ref => {
              this.idleTimer = ref;
            }}
            element={document}
            onIdle={this.onIdle}
            debounce={250}
            timeout={1000 * 60 * 30}
          />
          <App />
        </Provider>
      </React.Fragment>
    );
  }
}

Index.propTypes = {
  history: PropTypes.object
};

export default withRouter(Index);

ReactDOM.render(
  <HashRouter>
    <Route path="/" component={Index} />
  </HashRouter>,
  document.getElementById("root")
);
