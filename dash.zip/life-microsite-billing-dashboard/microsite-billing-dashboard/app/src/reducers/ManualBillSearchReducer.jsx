import moment from "moment";
import { addDays } from "utils/CommonFunctions.jsx";

const initialState = {
  policyNumber: "",
  payorName: "",
  payorAddrLine1: "",
  payorAddrLine2: "",
  payorCity: "",
  payorState: "",
  payorZip: "",
  premiumDueBillDate: addDays(moment(new Date(), "YYYY-MM-DD").toDate(), 1),
  cycleDate: moment(new Date(), "YYYY-MM-DD").toDate(),
  premiumLoanInd: "P",
  billFrequency: "",
  premiumAmnt: "",
  netBilledAmnt: "",
  paymentMethod: "MANUAL",
  carrierCode: ""
};

function manualBillSearchReducer(state = initialState, action) {
  switch (action.type) {
    case "GET_MANUALBILL_SEARCH":
      return { ...state };
    case "INIT_MANUALBILL_SEARCH":
      return { ...initialState };
    case "ADD_MANUALBILL_SEARCH":
      return { ...action.payload };
    case "DEL_MANUALBILL_SEARCH":
      return { ...state, ...initialState };
    default:
      return state;
  }
}

export default manualBillSearchReducer;
