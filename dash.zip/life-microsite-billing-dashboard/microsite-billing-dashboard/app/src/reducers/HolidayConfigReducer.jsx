const initialState = {
  date: "",
  insertUser: "",
  insertTimestamp: "",
  actions: "" // This is used to show action icons only.
};

function HolidayConfigReducer(state = initialState, action) {
  switch (action.type) {
    case "GET_HOLIDAY_SEARCH":
      return { ...state };
    case "INIT_HOLIDAY_SEARCH":
      return { ...initialState };
    case "ADD_HOLIDAY_SEARCH":
      return { ...action.payload };
    case "DEL_HOLIDAY_SEARCH":
      return { ...state, ...initialState };
    default:
      return state;
  }
}

export default HolidayConfigReducer;
