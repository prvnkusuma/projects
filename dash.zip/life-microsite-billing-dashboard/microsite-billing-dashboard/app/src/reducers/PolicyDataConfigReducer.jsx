import moment from "moment";

const initialState = {
  ruleName: "",
  ruleDesc: "",
  startDate: moment(new Date(), "YYYY-MM-DD").toDate(),
  endDate: moment(new Date(), "YYYY-MM-DD").toDate(),
  lastUpdatedBy: "",
  lastUpdatedOn: "",
  isActivated: true
};

function PolicyDataConfigReducer(state = initialState, action) {
  switch (action.type) {
    case "GET_POLDATA_CONFIG":
      return { ...state };
    case "INIT_POLDATA_CONFIG":
      return { ...initialState };
    case "ADD_POLDATA_CONFIG":
      return { ...action.payload };
    case "DEL_POLDATA_CONFIG":
      return { ...state, ...initialState };
    default:
      return state;
  }
}

export default PolicyDataConfigReducer;
