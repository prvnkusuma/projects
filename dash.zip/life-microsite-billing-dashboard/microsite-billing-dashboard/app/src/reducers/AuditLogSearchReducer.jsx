const initialState = {
  userName: "",
  fromCycleDate: "",
  toCycleDate: "",
  auditLogType: "",
  actionType: "",
  paymentMethod: "",
  holdingInquiry: "",
  identifier: "",
  insertTstampFrom: "",
  insertTstampTo: ""
};

function AuditLogSearchReducer(state = initialState, action) {
  switch (action.type) {
    case "GET_AUDITLOG_SEARCH":
      return { ...state };
    case "INIT_AUDITLOG_SEARCH":
      return { ...initialState };
    case "ADD_AUDITLOG_SEARCH":
      return { ...action.payload };
    case "DEL_AUDITLOG_SEARCH":
      return { ...state, ...initialState };
    default:
      return state;
  }
}

export default AuditLogSearchReducer;
