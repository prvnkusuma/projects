import moment from "moment";

const initialState = {
  reprocessType: "allCorrespondences",
  cycleDate: moment(new Date(), "YYYY-MM-DD").toDate(),
  selectedCorrespondenceList: "",
  eventCode: "70001"
};

function BulkReProcessCorrespondenceDialogReducer(
  state = initialState,
  action
) {
  switch (action.type) {
    case "GET_BULK_RECORRESP_DIALOG":
      return { ...state };
    case "ADD_BULK_RECORRESP_DIALOG":
      return { ...action.payload };
    case "DEL_BULK_RECORRESP_DIALOG":
      return { ...state, ...initialState };
    default:
      return state;
  }
}

export default BulkReProcessCorrespondenceDialogReducer;
