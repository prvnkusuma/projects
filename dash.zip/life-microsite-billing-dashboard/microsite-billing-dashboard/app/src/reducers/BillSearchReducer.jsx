import { getLastWorkingDay } from "utils/CommonFunctions.jsx";

const initialState = {
  polCont: "",
  billId: "",
  billDueDate: "",
  paymentMethod: "",
  billCommType: "",
  status: "",
  fromCycleDate: getLastWorkingDay().format("YYYY-MM-DD"),
  toCycleDate: getLastWorkingDay().format("YYYY-MM-DD"),
  transRefGUID: ""
};

function BillSearchReducer(state = initialState, action) {
  switch (action.type) {
    case "GET_BILLSEARCH":
      return { ...state };
    case "INIT_BILLSEARCH":
      return { ...initialState };
    case "ADD_BILLSEARCH":
      return { ...action.payload };
    case "DEL_BILLSEARCH":
      return { ...state, ...initialState };
    default:
      return state;
  }
}

export default BillSearchReducer;
