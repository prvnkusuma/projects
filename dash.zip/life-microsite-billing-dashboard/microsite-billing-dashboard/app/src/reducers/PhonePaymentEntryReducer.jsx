import moment from "moment";

const initialState = {
  name: "",
  mi: "",
  lastName: "",
  addr1: "",
  addr2: "",
  email: "",
  emailIndicator: "",
  suppressCorrespondence: false,
  accountNumber: "",
  accountNumberReenter: "",
  accountType: "CHECKING",
  countryIndicator: "",
  orgIndicator: false,
  country: "US",
  city: "",
  state: "",
  zip: "",
  telephoneNumber: "",
  routingNumber: "",
  draftDate: moment(new Date(), "YYYY-MM-DD").toDate(),
  selectedDraftDate: moment(new Date(), "YYYY-MM-DD").toDate(),
  status: "",
  totalDraftAmt: "",
  enteredBy: "",
  comments: "",
  actions: "" // This is used to show action icons only.
};

function PhonePaymentEntryReducer(state = initialState, action) {
  switch (action.type) {
    case "GET_PHONEPAYMENT_ENTRY":
      return { ...state };
    case "INIT_PHONEPAYMENT_ENTRY":
      return { ...initialState };
    case "ADD_PHONEPAYMENT_ENTRY":
      return { ...action.payload };
    case "DEL_PHONEPAYMENT_ENTRY":
      return { ...state, ...initialState };
    default:
      return state;
  }
}

export default PhonePaymentEntryReducer;
