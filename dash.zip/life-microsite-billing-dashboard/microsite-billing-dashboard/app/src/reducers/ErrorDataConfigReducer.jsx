const initialState = {
  errorCode: "",
  errorSource: "",
  errorDesc: "",
  awdWorkItem: "",
  errorOwner: "",
  reprocessFlag: "",
  awdFlag: "",
  notificationFlag: "",
  status: "",
  actions: "" // This is used to show action icons only.
};

function ErrorDataConfigReducer(state = initialState, action) {
  switch (action.type) {
    case "GET_ERRORDATA_SEARCH":
      return { ...state };
    case "INIT_ERRORDATA_SEARCH":
      return { ...initialState };
    case "ADD_ERRORDATA_SEARCH":
      return { ...action.payload };
    case "DEL_ERRORDATA_SEARCH":
      return { ...state, ...initialState };
    default:
      return state;
  }
}

export default ErrorDataConfigReducer;
