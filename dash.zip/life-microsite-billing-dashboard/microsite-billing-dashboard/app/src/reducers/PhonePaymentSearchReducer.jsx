const initialState = {
  trackingNumber: "",
  policyNumber: "",
  accountName: "",
  enteredBy: "",
  fromDraftDate: "",
  toDraftDate: ""
};

function PhonePaymentSearchReducer(state = initialState, action) {
  switch (action.type) {
    case "GET_PHONEPAYMENT_SEARCH":
      return { ...state };
    case "INIT_PHONEPAYMENT_SEARCH":
      return { ...initialState };
    case "ADD_PHONEPAYMENT_SEARCH":
      return { ...action.payload };
    case "DEL_PHONEPAYMENT_SEARCH":
      return { ...state, ...initialState };
    default:
      return state;
  }
}

export default PhonePaymentSearchReducer;
