import moment from "moment";

const initialState = {
  polCont: "",
  transRefGUID: "",
  remitRecvdDate: "",
  paymentMethod: "",
  companyCode: "",
  paymentType: "",
  amount: "",
  effectiveDate: "",
  paymentSource: "",
  type: "",
  status: "",
  fromCycleDate: moment(new Date()).format("YYYY-MM-DD"),
  toCycleDate: moment(new Date()).format("YYYY-MM-DD")
};

function RemittanceSearchReducer(state = initialState, action) {
  switch (action.type) {
    case "GET_REMIT_SEARCH":
      return { ...state };
    case "INIT_REMIT_SEARCH":
      return { ...initialState };
    case "ADD_REMIT_SEARCH":
      return { ...action.payload };
    case "DEL_REMIT_SEARCH":
      return { ...state, ...initialState };
    default:
      return state;
  }
}

export default RemittanceSearchReducer;
