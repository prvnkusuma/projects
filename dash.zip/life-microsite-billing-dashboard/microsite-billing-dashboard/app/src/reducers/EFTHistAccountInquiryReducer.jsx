const initialState = {
  controlNum: "",
  polCont: "",
  bankAcctNum: "",
  transitNum: "",
  fromCycleDate: "",
  toCycleDate: ""
};

function EFTHistAccountInquiryReducer(state = initialState, action) {
  switch (action.type) {
    case "GET_HIST_ACCOUNT_INQUIRY":
      return { ...state };
    case "INIT_HIST_ACCOUNT_INQUIRY":
      return { ...initialState };
    case "ADD_HIST_ACCOUNT_INQUIRY":
      return { ...action.payload };
    case "DEL_HIST_ACCOUNT_INQUIRY":
      return { ...state, ...initialState };
    default:
      return state;
  }
}

export default EFTHistAccountInquiryReducer;
