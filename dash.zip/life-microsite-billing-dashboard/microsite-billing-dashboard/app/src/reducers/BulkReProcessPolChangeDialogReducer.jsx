import { getLastWorkingDay } from "utils/CommonFunctions.jsx";

const initialState = {
  reprocessType: "allPolicies",
  cycleDate: getLastWorkingDay().format("YYYY-MM-DD"),
  selectedPolicyList: "",
  holdingInquiry: "false"
};

function BulkReProcessPolChangeDialogReducer(state = initialState, action) {
  switch (action.type) {
    case "GET_BULK_REPOL_CHG_DIALOG":
      return { ...state };
    case "ADD_BULK_REPOL_CHG_DIALOG":
      return { ...action.payload };
    case "DEL_BULK_REPOL_CHG_DIALOG":
      return { ...state, ...initialState };
    default:
      return state;
  }
}

export default BulkReProcessPolChangeDialogReducer;
