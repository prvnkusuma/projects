import { getLastWorkingDay } from "utils/CommonFunctions.jsx";

const initialState = {
  billId: "",
  polCont: "",
  amount: "",
  billCommType: "",
  fromCycleDate: getLastWorkingDay().format("YYYY-MM-DD"),
  toCycleDate: getLastWorkingDay().format("YYYY-MM-DD"),
  transRefGUID: "",
  status: "",
  actions: "", // This is used to show action icons only.
  insertDate: ""
};

function InvoiceSearchReducer(state = initialState, action) {
  switch (action.type) {
    case "GET_INVOICE_SEARCH":
      return { ...state };
    case "INIT_INVOICE_SEARCH":
      return { ...initialState };
    case "ADD_INVOICE_SEARCH":
      return { ...action.payload };
    case "DEL_INVOICE_SEARCH":
      return { ...state, ...initialState };
    default:
      return state;
  }
}

export default InvoiceSearchReducer;
