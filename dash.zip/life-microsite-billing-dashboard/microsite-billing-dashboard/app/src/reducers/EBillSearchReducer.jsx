import moment from "moment";

const initialState = {
  polCont: "",
  ebillIndicator: "",
  fromBillIndChangeDate: moment(new Date()).format("YYYY-MM-DD"),
  toBillIndChangeDate: moment(new Date()).format("YYYY-MM-DD"),
  lockBoxNumber: "",
  paymentMethod: ""
};

function eBillSearchReducer(state = initialState, action) {
  switch (action.type) {
    case "GET_EBILL_SEARCH":
      return { ...state };
    case "INIT_EBILL_SEARCH":
      return { ...initialState };
    case "ADD_EBILL_SEARCH":
      return { ...action.payload };
    case "DEL_EBILL_SEARCH":
      return { ...state, ...initialState };
    default:
      return state;
  }
}

export default eBillSearchReducer;
