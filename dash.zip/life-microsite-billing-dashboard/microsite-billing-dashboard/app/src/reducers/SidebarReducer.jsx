import { combineReducers } from "redux";
import BillSearchReducer from "./BillSearchReducer";
import ReProcessBillDialogReducer from "./ReProcessBillDialogReducer";
import RemittanceSearchReducer from "./RemittanceSearchReducer";
import ReProcessRemitDialogReducer from "./ReProcessRemitDialogReducer";
import InvoiceSearchReducer from "./InvoiceSearchReducer";
import BulkReProcessBillDialogReducer from "./BulkReProcessBillDialogReducer";
import ReconciliationSearchReducer from "./ReconciliationSearchReducer";
import DeclineSearchReducer from "./DeclineSearchReducer";
import ReportingSearchReducer from "./ReportingSearchReducer";
import BulkReProcessRemitDialogReducer from "./BulkReProcessRemitDialogReducer";
import BulkReProcessDeclineDialogReducer from "./BulkReProcessDeclineDialogReducer";
import BulkReProcessInvoiceDialogReducer from "./BulkReProcessInvoiceDialogReducer";
import PolicyChangeSearchReducer from "./PolicyChangeSearchReducer";
import ReProcessPolicyChangeDialogReducer from "./ReProcessPolicyChangeDialogReducer";
import BulkReProcessPolChangeDialogReducer from "./BulkReProcessPolChangeDialogReducer";
import AWDSearchReducer from "./AWDSearchReducer";
import BulkReProcessAWDDialogReducer from "./BulkReProcessAWDDialogReducer";
import BulkReProcessReportingDialogReducer from "./BulkReProcessReportingDialogReducer";
import PolicyDataConfigReducer from "./PolicyDataConfigReducer";
import ErrorDataConfigReducer from "./ErrorDataConfigReducer";
import ErrorDataConfigAddDialogReducer from "./ErrorDataConfigAddDialogReducer";
import EFTBankHeaderInquiryReducer from "./EFTBankHeaderInquiryReducer";
import EFTAccountInquiryReducer from "./EFTAccountInquiryReducer";
import EFTHistAccountInquiryReducer from "./EFTHistAccountInquiryReducer";
import EFTReturnsSearchReducer from "./EFTReturnsSearchReducer";
import BulkReProcessEFTReturnsDialogReducer from "./BulkReProcessEFTReturnsDialogReducer";
import CorrespondenceSearchReducer from "./CorrespondenceSearchReducer";
import BulkReProcessCorrespondenceDialogReducer from "./BulkReProcessCorrespondenceDialogReducer";
import AuditLogSearchReducer from "./AuditLogSearchReducer";
import EBillSearchReducer from "./EBillSearchReducer";
import ManualBillSearchReducer from "./ManualBillSearchReducer";
import PhonePaymentSearchReducer from "./PhonePaymentSearchReducer";
import PhonePaymentEntryReducer from "./PhonePaymentEntryReducer";
import HolidayConfigReducer from "./HolidayConfigReducer";
import HolidayConfigAddDialogReducer from "./HolidayConfigAddDialogReducer";

const SideBarReducer = combineReducers({
  billSearch: BillSearchReducer,
  reprocessBillDialog: ReProcessBillDialogReducer,
  bulkReprocessBillDialog: BulkReProcessBillDialogReducer,

  remittanceSearch: RemittanceSearchReducer,
  reprocessRemitDialog: ReProcessRemitDialogReducer,
  bulkReprocessRemitDialog: BulkReProcessRemitDialogReducer,

  invoiceSearch: InvoiceSearchReducer,
  bulkReprocessInvoiceDialog: BulkReProcessInvoiceDialogReducer,

  reconciliationSearch: ReconciliationSearchReducer,

  declineSearch: DeclineSearchReducer,
  bulkReprocessDeclineDialog: BulkReProcessDeclineDialogReducer,

  reportingSearch: ReportingSearchReducer,
  bulkReprocessReportingDialog: BulkReProcessReportingDialogReducer,

  policyChangeSearch: PolicyChangeSearchReducer,
  reprocessPolicyChangeDialog: ReProcessPolicyChangeDialogReducer,
  bulkReprocessPolChangeDialog: BulkReProcessPolChangeDialogReducer,

  awdSearch: AWDSearchReducer,
  bulkReprocessAWDDialog: BulkReProcessAWDDialogReducer,

  policyDataConfig: PolicyDataConfigReducer,
  errorDataConfig: ErrorDataConfigReducer,
  errorDataConfigAdd: ErrorDataConfigAddDialogReducer,

  eftBankHeaderInquiry: EFTBankHeaderInquiryReducer,
  eftAccountInquiry: EFTAccountInquiryReducer,
  eftHistAccountInquiry: EFTHistAccountInquiryReducer,
  eftReturnsSearch: EFTReturnsSearchReducer,
  bulkReprocessEFTReturnsDialog: BulkReProcessEFTReturnsDialogReducer,

  correspondenceSearch: CorrespondenceSearchReducer,
  bulkReprocessCorrespondenceDialog: BulkReProcessCorrespondenceDialogReducer,

  auditLogSearch: AuditLogSearchReducer,

  eBillSearch: EBillSearchReducer,

  manualBillSearch: ManualBillSearchReducer,

  phonePaymentSearch: PhonePaymentSearchReducer,
  phonePaymentEntry: PhonePaymentEntryReducer,

  holidaySearch: HolidayConfigReducer,
  holidayAdd: HolidayConfigAddDialogReducer
});

export default SideBarReducer;
