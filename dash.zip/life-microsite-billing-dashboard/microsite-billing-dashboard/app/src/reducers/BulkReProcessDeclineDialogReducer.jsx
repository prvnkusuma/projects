import moment from "moment";

const initialState = {
  reprocessType: "allDeclines",
  cycleDate: moment(new Date(), "YYYY-MM-DD").toDate(),
  selectedDeclineList: ""
};

function BulkReProcessDeclineDialogReducer(state = initialState, action) {
  switch (action.type) {
    case "GET_BULK_REDECLINE_DIALOG":
      return { ...state };
    case "ADD_BULK_REDECLINE_DIALOG":
      return { ...action.payload };
    case "DEL_BULK_REDECLINE_DIALOG":
      return { ...state, ...initialState };
    default:
      return state;
  }
}

export default BulkReProcessDeclineDialogReducer;
