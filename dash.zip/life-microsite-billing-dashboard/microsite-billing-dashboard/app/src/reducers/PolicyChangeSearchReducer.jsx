import { getLastWorkingDay } from "utils/CommonFunctions.jsx";

const initialState = {
  transRefGUID: "",
  polCont: "",
  status: "",
  fromCycleDate: getLastWorkingDay().format("YYYY-MM-DD"),
  toCycleDate: getLastWorkingDay().format("YYYY-MM-DD")
};

function PolicyChangeSearchReducer(state = initialState, action) {
  switch (action.type) {
    case "GET_POLCHANGE_SEARCH":
      return { ...state };
    case "INIT_POLCHANGE_SEARCH":
      return { ...initialState };
    case "ADD_POLCHANGE_SEARCH":
      return { ...action.payload };
    case "DEL_POLCHANGE_SEARCH":
      return { ...state, ...initialState };
    default:
      return state;
  }
}

export default PolicyChangeSearchReducer;
