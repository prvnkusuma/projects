const initialState = {
  polCont: "",
  remitRecvdDate: "",
  paymentMethod: "",
  amount: "",
  effectiveDate: "",
  errorLog: ""
};

function ReProcessRemitDialogReducer(state = initialState, action) {
  switch (action.type) {
    case "GET_REMIT_DIALOG":
      return { ...state };
    case "ADD_REMIT_DIALOG":
      return { ...action.payload };
    case "DEL_REMIT_DIALOG":
      return { ...state, ...initialState };
    default:
      return state;
  }
}

export default ReProcessRemitDialogReducer;
