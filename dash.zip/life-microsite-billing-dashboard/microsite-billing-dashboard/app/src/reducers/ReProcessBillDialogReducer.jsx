const initialState = {
  billId: "",
  paymentMethod: "",
  billDueDate: "",
  paidDate: "",
  errorLog: "",
  holdingInquiry: "false",
  isBusinessError: "",
  reprocessFlag: ""
};

function ReProcessBillDialogReducer(state = initialState, action) {
  switch (action.type) {
    case "GET_REBILL_DIALOG":
      return { ...state };
    case "ADD_REBILL_DIALOG":
      return { ...action.payload };
    case "DEL_REBILL_DIALOG":
      return { ...state, ...initialState };
    default:
      return state;
  }
}

export default ReProcessBillDialogReducer;
