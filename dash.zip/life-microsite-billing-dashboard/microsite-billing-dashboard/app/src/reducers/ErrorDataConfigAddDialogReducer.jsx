const initialState = {
  errorCode: "",
  errorSource: "",
  errorDesc: "",
  awdWorkItem: "",
  errorOwner: "",
  reprocessFlag: "N",
  awdFlag: "N",
  notificationFlag: "N"
};

function ErrorDataConfigAddDialogReducer(state = initialState, action) {
  switch (action.type) {
    case "GET_ERROR_CONFIG_ADD_DIALOG":
      return { ...state };
    case "ADD_ERROR_CONFIG_ADD_DIALOG":
      return { ...action.payload };
    case "DEL_ERROR_CONFIG_ADD_DIALOG":
      return { ...state, ...initialState };
    default:
      return state;
  }
}

export default ErrorDataConfigAddDialogReducer;
