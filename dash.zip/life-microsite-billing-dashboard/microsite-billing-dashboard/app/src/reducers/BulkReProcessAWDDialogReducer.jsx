import moment from "moment";

const initialState = {
  reprocessType: "allAWDs",
  fromDate: moment(new Date(), "YYYY-MM-DD").toDate(),
  toDate: moment(new Date(), "YYYY-MM-DD").toDate(),
  selectedAWDList: ""
};

function BulkReProcessAWDDialogReducer(state = initialState, action) {
  switch (action.type) {
    case "GET_BULK_REAWD_DIALOG":
      return { ...state };
    case "ADD_BULK_REAWD_DIALOG":
      return { ...action.payload };
    case "DEL_BULK_REAWD_DIALOG":
      return { ...state, ...initialState };
    default:
      return state;
  }
}

export default BulkReProcessAWDDialogReducer;
