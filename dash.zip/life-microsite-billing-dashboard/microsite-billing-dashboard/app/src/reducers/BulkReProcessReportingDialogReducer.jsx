import { getLastWorkingDay } from "utils/CommonFunctions.jsx";

const initialState = {
  reprocessType: "allBills",
  cycleDate: getLastWorkingDay().format("YYYY-MM-DD"),
  billDueDate: "",
  businessErrCode: "",
  paymentMethod: "Credit Card",
  selectedBillList: "",
  holdingInquiry: "false"
};

function BulkReProcessReportingDialogReducer(state = initialState, action) {
  switch (action.type) {
    case "GET_BULK_REREPORT_DIALOG":
      return { ...state };
    case "ADD_BULK_REREPORT_DIALOG":
      return { ...action.payload };
    case "DEL_BULK_REREPORT_DIALOG":
      return { ...state, ...initialState };
    default:
      return state;
  }
}

export default BulkReProcessReportingDialogReducer;
