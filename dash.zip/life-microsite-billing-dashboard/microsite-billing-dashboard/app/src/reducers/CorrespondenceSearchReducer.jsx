import { getLastWorkingDay } from "utils/CommonFunctions.jsx";

const initialState = {
  controlNum: "",
  polCont: "",
  transRefGUID: "",
  trackingNumber: "",
  fromCycleDate: getLastWorkingDay().format("YYYY-MM-DD"),
  toCycleDate: getLastWorkingDay().format("YYYY-MM-DD"),
  eventCode: "",
  status: ""
};

function CorrespondenceSearchReducer(state = initialState, action) {
  switch (action.type) {
    case "GET_CORRESPONDENCE_SEARCH":
      return { ...state };
    case "INIT_CORRESPONDENCE_SEARCH":
      return { ...initialState };
    case "ADD_CORRESPONDENCE_SEARCH":
      return { ...action.payload };
    case "DEL_CORRESPONDENCE_SEARCH":
      return { ...state, ...initialState };
    default:
      return state;
  }
}

export default CorrespondenceSearchReducer;
