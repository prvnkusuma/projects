import { getLastWorkingDay } from "utils/CommonFunctions.jsx";

const initialState = {
  transRefGUID: "",
  polCont: "",
  billId: "",
  fromCycleDate: getLastWorkingDay().format("YYYY-MM-DD"),
  toCycleDate: getLastWorkingDay().format("YYYY-MM-DD"),
  errorDesc: "",
  team: "",
  paymentMethod: ""
};

function ReportingSearchReducer(state = initialState, action) {
  switch (action.type) {
    case "GET_REPORTING_SEARCH":
      return { ...state };
    case "INIT_REPORTING_SEARCH":
      return { ...initialState };
    case "ADD_REPORTING_SEARCH":
      return { ...action.payload };
    case "DEL_REPORTING_SEARCH":
      return { ...state, ...initialState };
    default:
      return state;
  }
}

export default ReportingSearchReducer;
