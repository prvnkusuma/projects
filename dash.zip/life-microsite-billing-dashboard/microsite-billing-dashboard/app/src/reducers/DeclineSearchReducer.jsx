import moment from "moment";

const initialState = {
  polCont: "",
  transRefGUID: "",
  declineDate: "",
  paymentMethod: "",
  effectiveDate: "",
  type: "",
  status: "",
  fromCycleDate: moment(new Date()).format("YYYY-MM-DD"),
  toCycleDate: moment(new Date()).format("YYYY-MM-DD")
};

function DeclineSearchReducer(state = initialState, action) {
  switch (action.type) {
    case "GET_DECLINE_SEARCH":
      return { ...state };
    case "INIT_DECLINE_SEARCH":
      return { ...initialState };
    case "ADD_DECLINE_SEARCH":
      return { ...action.payload };
    case "DEL_DECLINE_SEARCH":
      return { ...state, ...initialState };
    default:
      return state;
  }
}

export default DeclineSearchReducer;
