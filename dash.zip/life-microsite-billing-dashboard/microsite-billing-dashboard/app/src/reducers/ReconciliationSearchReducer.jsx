const initialState = {
  cycleDate: "",
  secondaryCycleDate: "",
  reconType: ""
};

function ReconciliationSearchReducer(state = initialState, action) {
  switch (action.type) {
    case "GET_RECON_SEARCH":
      return { ...state };
    case "INIT_RECON_SEARCH":
      return { ...initialState };
    case "ADD_RECON_SEARCH":
      return { ...action.payload };
    case "DEL_RECON_SEARCH":
      return { ...state, ...initialState };
    case "DEL_EFT_RECON_SEARCH":
      return { ...state, ...action.payload };
    default:
      return state;
  }
}

export default ReconciliationSearchReducer;
