const initialState = {
  payorName: "",
  controlNum: ""
};

function EFTAccountInquiryReducer(state = initialState, action) {
  switch (action.type) {
    case "GET_ACCOUNT_INQUIRY":
      return { ...state };
    case "INIT_ACCOUNT_INQUIRY":
      return { ...initialState };
    case "ADD_ACCOUNT_INQUIRY":
      return { ...action.payload };
    case "DEL_ACCOUNT_INQUIRY":
      return { ...state, ...initialState };
    default:
      return state;
  }
}

export default EFTAccountInquiryReducer;
