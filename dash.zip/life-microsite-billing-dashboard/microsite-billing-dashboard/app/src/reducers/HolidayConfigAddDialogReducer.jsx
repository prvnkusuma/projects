import moment from "moment";

const initialState = {
  date: moment(new Date()).format("YYYY-MM-DD"),
  insertUser: "",
  insertTimestamp: ""
};

function HolidayConfigAddDialogReducer(state = initialState, action) {
  switch (action.type) {
    case "GET_HOLIDAY_ADD_DIALOG":
      return { ...state };
    case "ADD_HOLIDAY_ADD_DIALOG":
      return { ...action.payload };
    case "DEL_HOLIDAY_ADD_DIALOG":
      return { ...state, ...initialState };
    default:
      return state;
  }
}

export default HolidayConfigAddDialogReducer;
