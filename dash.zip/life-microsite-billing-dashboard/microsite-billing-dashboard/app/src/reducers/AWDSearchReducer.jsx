import moment from "moment";

const initialState = {
  billId: "",
  transRefGUID: "",
  polCont: "",
  errorCode: "",
  status: "",
  insertDate: "",
  fromCycleDate: moment(new Date()).format("YYYY-MM-DD"),
  toCycleDate: moment(new Date()).format("YYYY-MM-DD"),
  comment: "",
  transactionType: ""
};

function AWDSearchReducer(state = initialState, action) {
  switch (action.type) {
    case "GET_AWD_SEARCH":
      return { ...state };
    case "INIT_AWD_SEARCH":
      return { ...initialState };
    case "ADD_AWD_SEARCH":
      return { ...action.payload };
    case "DEL_AWD_SEARCH":
      return { ...state, ...initialState };
    default:
      return state;
  }
}

export default AWDSearchReducer;
