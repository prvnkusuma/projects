import { getLastWorkingDay } from "utils/CommonFunctions.jsx";

const initialState = {
  polCont: "",
  controlNum: "",
  eftType: "",
  paymentType: "",
  effDate: "",
  fromCycleDate: getLastWorkingDay().format("YYYY-MM-DD"),
  toCycleDate: getLastWorkingDay().format("YYYY-MM-DD"),
  status: "",
  transCode: "",
  reasonCode: "",
  type: ""
};

function EFTReturnsSearchReducer(state = initialState, action) {
  switch (action.type) {
    case "GET_EFTRETURNS_SEARCH":
      return { ...state };
    case "INIT_EFTRETURNS_SEARCH":
      return { ...initialState };
    case "ADD_EFTRETURNS_SEARCH":
      return { ...action.payload };
    case "DEL_EFTRETURNS_SEARCH":
      return { ...state, ...initialState };
    default:
      return state;
  }
}

export default EFTReturnsSearchReducer;
