const initialState = {
  transitNum: "",
  bankName: ""
};

function EFTBankHeaderInquiryReducer(state = initialState, action) {
  switch (action.type) {
    case "GET_BANKHEADER_INQUIRY":
      return { ...state };
    case "INIT_BANKHEADER_INQUIRY":
      return { ...initialState };
    case "ADD_BANKHEADER_INQUIRY":
      return { ...action.payload };
    case "DEL_BANKHEADER_INQUIRY":
      return { ...state, ...initialState };
    default:
      return state;
  }
}

export default EFTBankHeaderInquiryReducer;
