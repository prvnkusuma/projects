import moment from "moment";

const initialState = {
  reprocessType: "allInvoices",
  cycleDate: moment(new Date(), "YYYY-MM-DD").toDate(),
  selectedInvoiceList: ""
};

function BulkReProcessInvoiceDialogReducer(state = initialState, action) {
  switch (action.type) {
    case "GET_BULK_REINVOICE_DIALOG":
      return { ...state };
    case "ADD_BULK_REINVOICE_DIALOG":
      return { ...action.payload };
    case "DEL_BULK_REINVOICE_DIALOG":
      return { ...state, ...initialState };
    default:
      return state;
  }
}

export default BulkReProcessInvoiceDialogReducer;
