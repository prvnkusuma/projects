const initialState = {
  transRefGUID: "",
  cycleDate: "",
  errorLog: "",
  holdingInquiry: "false"
};

function ReProcessPolicyChangeDialogReducer(state = initialState, action) {
  switch (action.type) {
    case "GET_REPOL_CHANGE_DIALOG":
      return { ...state };
    case "ADD_REPOL_CHANGE_DIALOG":
      return { ...action.payload };
    case "DEL_REPOL_CHANGE_DIALOG":
      return { ...state, ...initialState };
    default:
      return state;
  }
}

export default ReProcessPolicyChangeDialogReducer;
