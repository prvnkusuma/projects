import { getLastWorkingDay } from "utils/CommonFunctions.jsx";

const initialState = {
  reprocessType: "allReturns",
  cycleDate: getLastWorkingDay().format("YYYY-MM-DD"),
  rejectionType: "AWD_ABCRETURN",
  selectedReturnsList: ""
};

function BulkReProcessEFTReturnsDialogReducer(state = initialState, action) {
  switch (action.type) {
    case "GET_BULK_REEFTRETURNS_DIALOG":
      return { ...state };
    case "ADD_BULK_REEFTRETURNS_DIALOG":
      return { ...action.payload };
    case "DEL_BULK_REEFTRETURNS_DIALOG":
      return { ...state, ...initialState };
    default:
      return state;
  }
}

export default BulkReProcessEFTReturnsDialogReducer;
