import React from "react";
import { HashRouter, Route, Switch } from "react-router-dom";

import "assets/css/material-dashboard-react.css?v=1.5.0";
import { createMuiTheme, MuiThemeProvider } from "@material-ui/core/styles";

import indexRoutes from "routes/index.jsx";

const bitsTheme = createMuiTheme({
  overrides: {
    MuiInput: {
      root: {
        height: "1.7em"
      }
    },
    MuiInputLabel: {
      root: {
        fontSize: 13
      }
    }
  }
});

const App = () => (
  <MuiThemeProvider theme={bitsTheme}>
    <HashRouter>
      <Switch>
        {indexRoutes.map((prop, key) => {
          return (
            <Route path={prop.path} component={prop.component} key={key} />
          );
        })}
      </Switch>
    </HashRouter>
  </MuiThemeProvider>
);

export default App;
