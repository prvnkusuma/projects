// @material-ui/icons
import { AccountCircle, SupervisorAccount } from "@material-ui/icons";

// core components/views
import UserProfile from "views/UserProfile/UserProfile.jsx";
import Admin from "views/TableList/Admin.jsx";

const dashboardRoutesSubLinks = [
  {
    path: "/user",
    sidebarName: "User Profile",
    navbarName: "Profile",
    icon: AccountCircle,
    component: UserProfile,
    isExpandable: false,
    parent: "User"
  },
  {
    path: "/admin",
    sidebarName: "Admin",
    navbarName: "Admin",
    icon: SupervisorAccount,
    component: Admin,
    isExpandable: false,
    parent: "User"
  }
];

export default dashboardRoutesSubLinks;
