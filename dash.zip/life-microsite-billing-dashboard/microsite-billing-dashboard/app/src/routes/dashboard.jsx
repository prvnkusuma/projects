// @material-ui/icons
//import Dashboard from "@material-ui/icons/Dashboard";
//import BarChart from "@material-ui/icons/BarChart";
import {
  Person,
  LibraryBooks,
  Money,
  Receipt,
  SwapHoriz,
  MoneyOff,
  Report,
  Description,
  DeviceHub,
  AccountBalanceOutlined,
  Email,
  Assignment,
  DvrOutlined,
  RecentActors,
  PhoneAndroid
} from "@material-ui/icons";

// core components/views
//import DashboardPage from "views/Dashboard/Dashboard.jsx";
//import AnalyticsPage from "views/Dashboard/Analytics.jsx";
import UserProfile from "views/UserProfile/UserProfile.jsx";
import Bill from "views/TableList/Bill.jsx";
import Remittance from "views/TableList/Remittance.jsx";
import Reconciliation from "views/Dashboard/Reconciliation.jsx";
import Invoice from "views/TableList/Invoice.jsx";
import Reporting from "views/TableList/Reporting.jsx";
import Decline from "views/TableList/Decline.jsx";
import LoginPage from "views/Login/LoginPage.jsx";
import ErrorPage from "views/Other/ErrorPage.jsx";
import PolicyChange from "views/TableList/PolicyChange.jsx";
import AWD from "views/TableList/AWD.jsx";
import EFT from "views/TableList/EFT.jsx";
import Correspondence from "views/TableList/Correspondence.jsx";
import AuditLog from "views/TableList/AuditLog.jsx";
import EBill from "views/TableList/EBill.jsx";
import ManualBill from "views/TableList/ManualBill.jsx";
import PhonePayment from "views/TableList/PhonePayment.jsx";

const dashboardRoutes = [
  /*
  {
    path: "/dashboard",
    sidebarName: "Dashboard",
    navbarName: "Dashboard",
    icon: Dashboard,
    component: DashboardPage,
    isExpandable: false
  },
  {
    path: "/analytics",
    sidebarName: "Analytics",
    navbarName: "Analytics",
    icon: BarChart,
    component: AnalyticsPage,
    isExpandable: false
  },*/
  {
    path: "/reconciliation",
    sidebarName: "Reconciliation",
    navbarName: "Reconciliation",
    icon: SwapHoriz,
    component: Reconciliation,
    isExpandable: false
  },
  {
    path: "/bill",
    sidebarName: "Bill",
    navbarName: "Bill",
    icon: LibraryBooks,
    component: Bill,
    isExpandable: false
  },
  {
    path: "/remittance",
    sidebarName: "Remittance",
    navbarName: "Remittance",
    icon: Money,
    component: Remittance,
    isExpandable: false
  },
  {
    path: "/decline",
    sidebarName: "Decline",
    navbarName: "Decline",
    icon: MoneyOff,
    component: Decline,
    isExpandable: false
  },
  {
    path: "/invoice",
    sidebarName: "Invoice",
    navbarName: "Invoice",
    icon: Receipt,
    component: Invoice,
    isExpandable: false
  },
  {
    path: "/businessErrors",
    sidebarName: "Business Errors",
    navbarName: "Business Errors",
    icon: Report,
    component: Reporting,
    isExpandable: false
  },
  {
    path: "/policyChange",
    sidebarName: "Policy Change",
    navbarName: "Policy Change",
    icon: Description,
    component: PolicyChange,
    isExpandable: false
  },
  {
    path: "/awd",
    sidebarName: "AWD",
    navbarName: "AWD",
    icon: DeviceHub,
    component: AWD,
    isExpandable: false
  },
  {
    path: "/eft",
    sidebarName: "EFT",
    navbarName: "EFT",
    icon: AccountBalanceOutlined,
    component: EFT,
    isExpandable: false
  },
  {
    path: "/correspondence",
    sidebarName: "Correspondence",
    navbarName: "Correspondence",
    icon: Email,
    component: Correspondence,
    isExpandable: false
  },
  {
    path: "/ebill",
    sidebarName: "E-Bill",
    navbarName: "E-Bill",
    icon: DvrOutlined,
    component: EBill,
    isExpandable: false
  },
  {
    path: "/manualBill",
    sidebarName: "Manual Bill",
    navbarName: "Manual Bill",
    icon: RecentActors,
    component: ManualBill,
    isExpandable: false
  },
  {
    path: "/phonePayment",
    sidebarName: "Phone Payment",
    navbarName: "Phone Payment",
    icon: PhoneAndroid,
    component: PhonePayment,
    isExpandable: false
  },
  {
    path: "/audit",
    sidebarName: "Audit Log",
    navbarName: "Audit Log",
    icon: Assignment,
    component: AuditLog,
    isExpandable: false
  },
  {
    path: "/userParent",
    sidebarName: "User",
    navbarName: "User",
    icon: Person,
    component: UserProfile,
    isExpandable: true
  },
  {
    path: "/login",
    sidebarName: "none",
    navbarName: "none",
    icon: Person,
    component: LoginPage,
    isExpandable: false
  },
  {
    path: "/error",
    sidebarName: "none",
    navbarName: "none",
    icon: Person,
    component: ErrorPage,
    isExpandable: false
  }
];

export default dashboardRoutes;
