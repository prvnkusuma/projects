import Dashboard from "layouts/Dashboard/Dashboard.jsx";
import { withRouter } from "react-router-dom";

const indexRoutes = [{ path: "/", component: Dashboard }];

export default withRouter(indexRoutes);
