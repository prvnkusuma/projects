/* eslint-disable */
import React from "react";
import PropTypes from "prop-types";
import { Switch, Route, Redirect } from "react-router-dom";
// creates a beautiful scrollbar
import "simplebar";
import "simplebar/dist/simplebar.css";

// @material-ui/core components
import withStyles from "@material-ui/core/styles/withStyles";
// core components
import Header from "components/Header/Header.jsx";
import Footer from "components/Footer/Footer.jsx";
import Sidebar from "components/Sidebar/Sidebar.jsx";

import dashboardRoutes from "routes/dashboard.jsx";
import dashboardSubRoutes from "routes/dashboardSubLinks.jsx";

import dashboardStyle from "assets/jss/material-dashboard-react/layouts/dashboardStyle.jsx";
import requireAuth from "utils/AuthenticatedComponent.jsx";

import image from "assets/img/sidebar-1.jpg";
import logo from "assets/img/aiglogo.gif";

var allRoutes = [...dashboardRoutes, ...dashboardSubRoutes];

const switchRoutes = (
  <Switch>
    {allRoutes.map((prop, key) => {
      return <Route path={prop.path} component={requireAuth(prop.component, "sidebar")} key={key} />;
    })}
    <Redirect from="/" to="/login" key="" />
  </Switch>
);

class App extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      mobileOpen: false,
      sidebarOpen: false
    };
    this.resizeFunction = this.resizeFunction.bind(this);
  }
  handleDrawerToggle = () => {
    this.setState({ mobileOpen: !this.state.mobileOpen });
  };
  handleSidebarToggle = () => {
    this.setState({ sidebarOpen: !this.state.sidebarOpen });
  };
  getRoute() {
    return this.props.location.pathname !== "/maps";
  }
  isLoginRoute() {
    return this.props.location.pathname === "/login";
  }
  resizeFunction() {
    if (window.innerWidth >= 960) {
      this.setState({ mobileOpen: false });
    }
  }
  componentDidMount() {
    window.addEventListener("resize", this.resizeFunction);
  }
  componentDidUpdate(e) {
    if (e.history.location.pathname !== e.location.pathname) {
      this.refs.mainPanel.scrollTop = 0;
      if (this.state.mobileOpen) {
        this.setState({ mobileOpen: false });
      }
    }
  }
  componentWillUnmount() {
    window.removeEventListener("resize", this.resizeFunction);
  }
  render() {
    const { classes, ...rest } = this.props;
    return (
      <div className={classes.wrapper} data-simplebar>
        {!this.isLoginRoute() ? (
          <div>
            <Sidebar
              routes={dashboardRoutes}
              logoText={"BITS"}
              logo={logo}
              image={image}
              handleDrawerToggle={this.handleDrawerToggle}
              handleSidebarToggle={this.handleSidebarToggle}
              open={this.state.mobileOpen}
              sidebarOpen={this.state.sidebarOpen}
              color="blue"
              {...rest}
            />
            <div className={classes.mainPanel} ref="mainPanel">
              <Header
                routes={dashboardRoutes}
                handleDrawerToggle={this.handleDrawerToggle}
                handleSidebarToggle={this.handleSidebarToggle}
                sidebarOpen={this.state.sidebarOpen}
                {...rest}
              />
              {/* On the /maps route we want the map to be on full screen - this is not possible if the content and container classes are present because they have some paddings which would make the map smaller */}
              {this.getRoute() ? (
                <div className={classes.content}>
                  <div className={classes.container}>{switchRoutes}</div>
                </div>
              ) : (
                <div className={classes.map}>{switchRoutes}</div>
              )}
              {this.getRoute() ? <Footer /> : null}
            </div>
          </div>
        ) : (
          <div ref="mainPanel">{switchRoutes}</div>
        )}
      </div>
    );
  }
}

App.propTypes = {
  classes: PropTypes.object.isRequired
};

export default withStyles(dashboardStyle)(App);
