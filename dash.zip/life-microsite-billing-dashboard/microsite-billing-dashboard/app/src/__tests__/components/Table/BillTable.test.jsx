import React from "react";
import Enzyme, { shallow, mount } from "enzyme";
import BillTable from "components/Table/BillTable.jsx";
import Adapter from "enzyme-adapter-react-16";

Enzyme.configure({ adapter: new Adapter() });

describe("BillTable component", () => {
  test("renders", () => {
  	const tableWrapper = shallow(<BillTable />);
  	expect(tableWrapper.exists()).toBe(true);
  })
})