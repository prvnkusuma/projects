import React from "react";

import { PropTypes } from "prop-types";

// @material-ui/core components
import withStyles from "@material-ui/core/styles/withStyles";

// core components
import GridItem from "components/Grid/GridItem.jsx";
import GridContainer from "components/Grid/GridContainer.jsx";
import CustomInput from "components/CustomInput/CustomInput.jsx";
import Card from "components/Card/Card.jsx";
import CardHeader from "components/Card/CardHeader.jsx";
import CardAvatar from "components/Card/CardAvatar.jsx";
import CardBody from "components/Card/CardBody.jsx";
import AccountCircle from "@material-ui/icons/AccountCircle";
import PermIdentityTwoTone from "@material-ui/icons/PermIdentityTwoTone";
import CardIcon from "components/Card/CardIcon.jsx";
import requireAuth from "utils/AuthenticatedComponent.jsx";
import { getFromLocalStorage } from "utils/CommonFunctions.jsx";

const styles = theme => ({
  cardCategory: {
    color: "rgba(97,97,97,.62)",
    margin: "0",
    fontWeight: "700",
    marginTop: "0",
    marginBottom: "0"
  },
  cardTitle: {
    color: "rgba(0,0,0,.62)",
    marginTop: "20px",
    minHeight: "auto",
    fontWeight: "400",
    fontFamily: "'Roboto', 'Helvetica', 'Arial', sans-serif",
    textDecoration: "none"
  },
  cardSubTitle: {
    color: "rgba(97,97,97,.62)",
    marginTop: "20px",
    minHeight: "auto",
    fontWeight: "400",
    fontFamily: "'Roboto', 'Helvetica', 'Arial', sans-serif",
    textDecoration: "none"
  },
  button: {
    margin: theme.spacing.unit
  }
});

class UserProfile extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      userName: getFromLocalStorage("userId").toUpperCase(),
      userEmail: getFromLocalStorage("userEmail"),
      firstName: getFromLocalStorage("firstName"),
      lastName: getFromLocalStorage("lastName"),
      userRole: getFromLocalStorage("userRole")
    };
  }

  render() {
    const { classes } = this.props;
    return (
      <div>
        <GridContainer>
          <GridItem xs={12} sm={12} md={8}>
            <Card>
              <CardHeader color="success" stats icon>
                <CardIcon color="success">
                  <AccountCircle>content_copy</AccountCircle>
                </CardIcon>
              </CardHeader>
              <CardBody>
                <GridContainer>
                  <GridItem xs={12} sm={12} md={6}>
                    <CustomInput
                      labelText="User Name"
                      id="userName"
                      formControlProps={{
                        fullWidth: true
                      }}
                      value={this.state.userName}
                    />
                  </GridItem>
                  <GridItem xs={12} sm={12} md={6}>
                    <CustomInput
                      labelText="Email Address"
                      id="emailAddress"
                      formControlProps={{
                        fullWidth: true
                      }}
                      value={this.state.userEmail}
                    />
                  </GridItem>
                </GridContainer>
                <GridContainer>
                  <GridItem xs={12} sm={12} md={6}>
                    <CustomInput
                      labelText="First Name"
                      id="firstName"
                      formControlProps={{
                        fullWidth: true
                      }}
                      value={this.state.firstName}
                    />
                  </GridItem>
                  <GridItem xs={12} sm={12} md={6}>
                    <CustomInput
                      labelText="Last Name"
                      id="lastName"
                      formControlProps={{
                        fullWidth: true
                      }}
                      value={this.state.lastName}
                    />
                  </GridItem>
                </GridContainer>
                <GridContainer>
                  <GridItem xs={12} sm={12} md={6}>
                    <CustomInput
                      labelText="User Role"
                      id="userRole"
                      formControlProps={{
                        fullWidth: true
                      }}
                      value={this.state.userRole}
                    />
                  </GridItem>
                </GridContainer>
              </CardBody>
            </Card>
          </GridItem>
          <GridItem xs={12} sm={12} md={4}>
            <Card
              profile
              style={{
                marginTop: "60px",
                height: "calc(100% - 60px)"
              }}
            >
              <CardAvatar profile style={{ height: "100%", width: "100%" }}>
                <PermIdentityTwoTone
                  style={{
                    fontSize: 100,
                    color: "#5084C0"
                  }}
                >
                  content_copy
                </PermIdentityTwoTone>
              </CardAvatar>
              <CardBody profile>
                <h4 className={classes.cardCategory}>{this.state.userName}</h4>
                <h4 className={classes.cardTitle}>
                  {this.state.firstName}
                  &nbsp;&nbsp;&nbsp;
                  {this.state.lastName}
                </h4>
                <h4 className={classes.cardSubTitle}>{this.state.userEmail}</h4>
              </CardBody>
            </Card>
          </GridItem>
        </GridContainer>
      </div>
    );
  }
}

UserProfile.propTypes = {
  classes: PropTypes.object.isRequired
};

export default withStyles(styles)(requireAuth(UserProfile, "mainContent"));
