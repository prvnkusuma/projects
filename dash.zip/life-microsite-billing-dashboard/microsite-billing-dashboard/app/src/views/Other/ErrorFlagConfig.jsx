import React from "react";
import { connect } from "react-redux";
import { bindActionCreators } from "redux";

import PropTypes from "prop-types";

// Import React Table
import ReactTable from "react-table";
import { ReactTableDefaults } from "react-table";

import Tooltip from "@material-ui/core/Tooltip";
import TextField from "@material-ui/core/TextField";
import Button from "@material-ui/core/Button";
import InfoOutlined from "@material-ui/icons/InfoOutlined";
import AddCircleOutlineOutlined from "@material-ui/icons/AddCircleOutlineOutlined";
import Checkbox from "@material-ui/core/Checkbox";
import Input from "@material-ui/core/Input";

// Import actions
import {
  initErrorDataSearch,
  getErrorDataSearch,
  addErrorDataSearch,
  delErrorDataSearch
} from "actions/ErrorDataSearchAction.jsx";

import "react-table/react-table.css";
import "assets/css/bits-styles-override.css";
import "assets/css/bits-styles-hrtext.css";

import Snackbar from "components/Snackbar/Snackbar.jsx";
import APIURIs from "properties/APIURIs.jsx";
import ErrorFlagConfigAddDialog from "components/Dialog/ErrorFlagConfigAddDialog.jsx";
import LoadingSpinner from "components/CustomWidgets/LoadingSpinner.jsx";
import {
  postTableData,
  putData,
  getFromLocalStorage
} from "utils/CommonFunctions.jsx";
import requireAuth from "utils/AuthenticatedComponent.jsx";
import Refresh from "components/CustomWidgets/Refresh.jsx";
import Overlay from "components/CustomWidgets/Overlay.jsx";
import CommonEditActions from "views/Other/CommonEditActions.jsx";
import RecordCount from "components/CustomWidgets/RecordCount.jsx";

//Set default values of React Table
Object.assign(ReactTableDefaults, {
  multiSort: false,
  LoadingComponent: LoadingSpinner
});

const classes = theme => ({
  formControl: {
    margin: theme.spacing.unit,
    minWidth: 120,
    display: "flex",
    wrap: "nowrap"
  },
  textField: {
    marginLeft: theme.spacing.unit,
    marginRight: theme.spacing.unit,
    width: 200
  },
  button: {
    margin: theme.spacing.unit
  }
});

function getErrorData(pageSize, page, sorted, filtered, errorDataSearch) {
  return postTableData(
    APIURIs.ADMIN_ERRORDATA_CONFIG_URI,
    APIURIs.ADMIN_ERRORDATA_CONFIG_APIKEY,
    pageSize,
    page,
    sorted,
    filtered,
    errorDataSearch
  );
}

function updateErrorData(
  errorCode,
  awdWorkItem,
  reprocessFlag,
  awdFlag,
  notificationFlag
) {
  return putData(
    APIURIs.ADMIN_ERRORDATA_UPDATE_URI + "/" + errorCode,
    APIURIs.ADMIN_ERRORDATA_UPDATE_APIKEY,
    {
      awdWorkItem: awdWorkItem,
      reprocessFlag: reprocessFlag,
      awdFlag: awdFlag,
      notificationFlag: notificationFlag,
      updateUser: getFromLocalStorage("userId")
    }
  );
}

class ErrorFlagConfig extends React.Component {
  _isMounted = false;
  constructor(props) {
    super(props);

    this.state = {
      data: [],
      pages: null,
      loading: true,
      editMode: false,
      selectedErrorCode: "",
      awdWorkItem: "",
      reprocessFlag: "N",
      awdFlag: "N",
      notificationFlag: "N",
      actionLoading: false,
      successElt: false,
      successMsg: "",
      errorElt: false,
      errorMsg: "",
      openAddNewDialog: false,
      totalRecords: null
    };
    this.props.initErrorDataSearch();
  }

  componentDidMount() {
    this._isMounted = true;
  }

  componentWillUnmount() {
    this._isMounted = false;
    this.props.initErrorDataSearch();
  }

  showAddSuccessNotification() {
    if (this._isMounted) {
      this.setState(
        {
          successMsg: "Successfully created error configuration!"
        },
        function() {
          this.showNotification("successElt");
        }
      );
    }
  }

  showAddErrorNotification() {
    if (this._isMounted) {
      this.setState(
        {
          errorMsg: "Failed to create error configuration!"
        },
        function() {
          this.showNotification("errorElt");
        }
      );
    }
  }

  showNotification(place) {
    var x = [];
    x[place] = true;
    if (this._isMounted) {
      this.setState(x);
    }
    this.alertTimeout = setTimeout(
      function() {
        x[place] = false;
        if (this._isMounted) {
          this.setState(x);
        }
      }.bind(this),
      6000
    );
  }

  setLoading(status) {
    if (this._isMounted) {
      this.setState({ actionLoading: status });
    }
  }

  handleAddNew = () => {
    if (this._isMounted) {
      this.setState({ openAddNewDialog: true });
    }
  };

  handleClose = () => {
    if (this._isMounted) {
      this.setState({ openAddNewDialog: false });
    }
  };

  handleRefresh = event => {
    this.handleSubmit(event);
  };

  handleSubmit = event => {
    event.preventDefault();
    this.selectTable.fireFetchData();
  };

  handleClear = () => {
    this.props.delErrorDataSearch();
  };

  handleAction = (
    action,
    errorCode,
    awdWorkItem,
    reprocessFlag,
    awdFlag,
    notificationFlag
  ) => {
    if (action === "edit") {
      if (this._isMounted) {
        this.setState({
          editMode: true,
          selectedErrorCode: errorCode,
          awdWorkItem: awdWorkItem,
          reprocessFlag: reprocessFlag,
          awdFlag: awdFlag,
          notificationFlag: notificationFlag
        });
      }
      return;
    }
    if (action === "cancel") {
      if (this._isMounted) {
        this.setState({
          editMode: false,
          selectedErrorCode: "",
          reprocessFlag: "",
          awdFlag: "",
          notificationFlag: ""
        });
      }
      return;
    }
    if (action === "save") {
      if (this._isMounted) {
        this.setState({ loading: true });
      }
      updateErrorData(
        this.state.selectedErrorCode,
        this.state.awdWorkItem,
        this.state.reprocessFlag,
        this.state.awdFlag,
        this.state.notificationFlag
      )
        .then(response => {
          if (this._isMounted) {
            this.setState({ loading: false });
          }
          if (response && response.status === 200) {
            this.selectTable.fireFetchData();
            if (this._isMounted) {
              this.setState(
                {
                  successMsg: "Successfully saved error configuration!",
                  editMode: false
                },
                function() {
                  this.showNotification("successElt");
                }
              );
            }
          } else {
            if (this._isMounted) {
              this.setState(
                {
                  errorMsg: "Failed to save error configuration!",
                  editMode: false
                },
                function() {
                  this.showNotification("errorElt");
                }
              );
            }
          }
        })
        .catch(error => {
          console.warn(error);
          if (this._isMounted) {
            this.setState({
              loading: false,
              editMode: false
            });
          }
        });
    }
  };

  handleCheckboxChange = flagType => event => {
    if (event.target.checked == true) {
      if (this._isMounted) {
        this.setState({ [flagType]: "Y" });
      }
    } else {
      if (this._isMounted) {
        this.setState({ [flagType]: "N" });
      }
    }
  };

  handleTextChange = name => event => {
    if (this._isMounted) {
      this.setState({ [name]: event.target.value });
    }
  };

  handleChange = event => {
    let errorSearchTmp = Object.assign({}, this.props.dialogdata);
    errorSearchTmp[event.target.name] = event.target.value;
    this.props.addErrorDataSearch(errorSearchTmp);
  };

  fetchSearchData = () => {
    if (this._isMounted) {
      this.setState({ loading: true });
    }
    getErrorData(10, 0, true, false, this.props.dialogdata)
      .then(res => {
        if (this._isMounted) {
          this.setState({
            data: res.rows,
            pages: res.pages == undefined ? 0 : res.pages,
            loading: false
          });
        }
      })
      .catch(error => {
        console.warn(error);
        if (this._isMounted) {
          this.setState({ loading: false });
        }
      });
  };

  fetchData = state => {
    if (this._isMounted) {
      this.setState({ loading: true });
    }
    getErrorData(
      state.pageSize,
      state.page,
      state.sorted,
      state.filtered,
      this.props.dialogdata
    )
      .then(res => {
        if (this._isMounted) {
          this.setState({
            data: res.rows,
            pages: res.pages == undefined ? 0 : res.pages,
            totalRecords: res.totalRecords,
            loading: false
          });
        }
      })
      .catch(error => {
        console.warn(error);
        if (this._isMounted) {
          this.setState({ loading: false });
        }
      });
  };

  render() {
    const { data, pages, loading } = this.state;
    return (
      <React.Fragment>
        <Overlay active={this.state.actionLoading} marginTop="150px">
          <p />
          <table border="0px" cellPadding="0" cellSpacing="0">
            <tbody>
              <tr>
                <td className="VerticalAlignBottom">
                  <TextField
                    id="errorCode"
                    name="errorCode"
                    label="Error Code"
                    type="search"
                    className={classes.textField}
                    onChange={this.handleChange}
                    value={this.props.dialogdata.errorCode}
                    margin="none"
                  />
                </td>
                <td>&nbsp;</td>
                <td className="VerticalAlignBottom">
                  <TextField
                    id="errorSource"
                    name="errorSource"
                    label="Error Source"
                    type="search"
                    className={classes.textField}
                    onChange={this.handleChange}
                    value={this.props.dialogdata.errorSource}
                    margin="none"
                  />
                </td>
                <td>&nbsp;</td>
                <td className="VerticalAlignBottom">
                  <TextField
                    id="awdWorkItem"
                    name="awdWorkItem"
                    label="AWD Work Item"
                    type="search"
                    className={classes.textField}
                    onChange={this.handleChange}
                    value={this.props.dialogdata.awdWorkItem}
                    margin="none"
                  />
                </td>
                <td>&nbsp;</td>
                <td className="VerticalAlignBottom">
                  <TextField
                    id="errorOwner"
                    name="errorOwner"
                    label="Error Owner"
                    type="search"
                    className={classes.textField}
                    onChange={this.handleChange}
                    value={this.props.dialogdata.errorOwner}
                    margin="none"
                  />
                </td>
              </tr>
            </tbody>
          </table>
          <div className="LeftActionBarStyle">
            <Button
              variant="contained"
              color="primary"
              className={classes.button}
              onClick={this.handleSubmit}
            >
              Search
            </Button>
            &nbsp;
            <Button
              variant="contained"
              color="primary"
              className={classes.button}
              onClick={this.handleClear}
            >
              Clear
            </Button>
            &nbsp;
            <span className="RightActionBarStyle">
              <div
                style={{
                  textAlign: "right",
                  paddingTop: 10,
                  cursor: "pointer",
                  color: "#388e3c"
                }}
              >
                <Tooltip title="Add New">
                  <AddCircleOutlineOutlined onClick={this.handleAddNew} />
                </Tooltip>
              </div>
            </span>
            <span className="RightActionBarStyle">
              <Refresh onClick={this.handleRefresh} />
            </span>
          </div>
          <ReactTable
            ref={reactErrorFlagConfig =>
              (this.selectTable = reactErrorFlagConfig)
            }
            columns={[
              {
                Header: "Error Code",
                accessor: "errorCode",
                headerClassName: "BoldText ColoredText"
              },
              {
                Header: "Error Source",
                accessor: "errorSource",
                headerClassName: "BoldText ColoredText"
              },
              {
                Header: "Error Description",
                accessor: "errorDesc",
                headerClassName: "BoldText ColoredText"
              },
              {
                Header: "AWD Work Item",
                accessor: "awdWorkItem",
                headerClassName: "BoldText ColoredText",
                Cell: ({ row }) => {
                  return (
                    <span style={{ textAlign: "center" }}>
                      {this.state.editMode &&
                      row.errorCode == this.state.selectedErrorCode ? (
                        <Input
                          value={this.state.awdWorkItem}
                          name={row.awdWorkItem}
                          onChange={this.handleTextChange("awdWorkItem")}
                        />
                      ) : (
                        row.awdWorkItem
                      )}
                    </span>
                  );
                }
              },
              {
                Header: "Error Owner",
                accessor: "errorOwner",
                headerClassName: "BoldText ColoredText"
              },
              {
                Header: "Reprocess Flag",
                accessor: "reprocessFlag",
                headerClassName: "BoldText ColoredText",
                className: "Centered",
                sortable: false,
                Cell: ({ row }) => {
                  return (
                    <span style={{ textAlign: "center" }}>
                      {this.state.editMode &&
                      row.errorCode == this.state.selectedErrorCode ? (
                        <Checkbox
                          checked={
                            this.state.reprocessFlag == "Y" ? true : false
                          }
                          style={{ padding: "0px" }}
                          onChange={this.handleCheckboxChange("reprocessFlag")}
                          disabled={false}
                          color="primary"
                        />
                      ) : (
                        <Checkbox
                          style={{ padding: "0px" }}
                          checked={row.reprocessFlag === "Y" ? true : false}
                          disabled={true}
                          color="primary"
                        />
                      )}
                    </span>
                  );
                }
              },
              {
                Header: "AWD Flag",
                accessor: "awdFlag",
                headerClassName: "BoldText ColoredText",
                className: "Centered",
                sortable: false,
                Cell: ({ row }) => {
                  return (
                    <span style={{ textAlign: "center" }}>
                      {this.state.editMode &&
                      row.errorCode == this.state.selectedErrorCode ? (
                        <Checkbox
                          style={{ padding: "0px" }}
                          checked={this.state.awdFlag == "Y" ? true : false}
                          onChange={this.handleCheckboxChange("awdFlag")}
                          disabled={false}
                          color="primary"
                        />
                      ) : (
                        <Checkbox
                          style={{ padding: "0px" }}
                          checked={row.awdFlag === "Y" ? true : false}
                          disabled={true}
                          color="primary"
                        />
                      )}
                    </span>
                  );
                }
              },
              {
                Header: "Notification Flag",
                accessor: "notificationFlag",
                headerClassName: "BoldText ColoredText",
                className: "Centered",
                sortable: false,
                Cell: ({ row }) => {
                  return (
                    <span style={{ textAlign: "center" }}>
                      {this.state.editMode &&
                      row.errorCode == this.state.selectedErrorCode ? (
                        <Checkbox
                          style={{ padding: "0px" }}
                          checked={
                            this.state.notificationFlag == "Y" ? true : false
                          }
                          onChange={this.handleCheckboxChange(
                            "notificationFlag"
                          )}
                          disabled={false}
                          color="primary"
                        />
                      ) : (
                        <Checkbox
                          style={{ padding: "0px" }}
                          checked={row.notificationFlag === "Y" ? true : false}
                          disabled={true}
                          color="primary"
                        />
                      )}
                    </span>
                  );
                }
              },
              {
                Header: "Actions",
                id: "actions",
                accessor: "actions",
                sortable: false,
                className: "Centered",
                headerClassName: "BoldText ColoredText",
                Cell: ({ original }) => {
                  return (
                    <span style={{ textAlign: "center" }}>
                      <CommonEditActions
                        editMode={this.state.editMode}
                        isSelected={
                          original.errorCode == this.state.selectedErrorCode
                        }
                        handleEdit={() =>
                          this.handleAction(
                            "edit",
                            original.errorCode,
                            original.awdWorkItem,
                            original.reprocessFlag,
                            original.awdFlag,
                            original.notificationFlag
                          )
                        }
                        handleSave={() =>
                          this.handleAction(
                            "save",
                            original.errorCode,
                            original.awdWorkItem,
                            original.reprocessFlag,
                            original.awdFlag,
                            original.notificationFlag
                          )
                        }
                        handleCancel={() =>
                          this.handleAction(
                            "cancel",
                            original.errorCode,
                            original.awdWorkItem,
                            original.reprocessFlag,
                            original.awdFlag,
                            original.notificationFlag
                          )
                        }
                      />
                    </span>
                  );
                }
              }
            ]}
            defaultSorted={[
              {
                id: "errorCode",
                desc: true
              }
            ]}
            manual // Forces table not to paginate or sort automatically, so we can handle it server-side
            data={data}
            pages={pages} // Display the total number of pages
            loading={loading} // Display the loading overlay when we need it
            onFetchData={this.fetchData} // Request new data when things change
            defaultPageSize={10}
            className="-striped -highlight"
            getTdProps={() => {
              return {
                style: {
                  padding: 0
                }
              };
            }}
          >
            {(state, makeTable) => {
              return (
                <RecordCount
                  state={state}
                  makeTable={makeTable}
                  totalRecords={this.state.totalRecords}
                />
              );
            }}
          </ReactTable>
          <br />
          {/* Add New Dialog */}
          <ErrorFlagConfigAddDialog
            open={this.state.openAddNewDialog}
            handleClose={this.handleClose}
            title="Add New"
            showSuccessNotification={() => this.showAddSuccessNotification()}
            showErrorNotification={() => this.showAddErrorNotification()}
          />
          <Snackbar
            place="tr"
            color="success"
            icon={InfoOutlined}
            message={this.state.successMsg}
            open={this.state.successElt}
            closeNotification={() => this.setState({ successElt: false })}
            close
          />
          <Snackbar
            place="tr"
            color="danger"
            icon={InfoOutlined}
            message={this.state.errorMsg}
            open={this.state.errorElt}
            closeNotification={() => this.setState({ errorElt: false })}
            close
          />
        </Overlay>
      </React.Fragment>
    );
  }
}

const mapStateToProps = state => ({
  dialogdata: state.sidebar.errorDataConfig
});

const mapDispatchToProps = dispatch =>
  bindActionCreators(
    {
      initErrorDataSearch,
      getErrorDataSearch,
      addErrorDataSearch,
      delErrorDataSearch
    },
    dispatch
  );

ErrorFlagConfig.propTypes = {
  initErrorDataSearch: PropTypes.func,
  addErrorDataSearch: PropTypes.func,
  getErrorDataSearch: PropTypes.func,
  delErrorDataSearch: PropTypes.func,
  className: PropTypes.string,
  sidebar: PropTypes.object,
  stats: PropTypes.bool,
  icon: PropTypes.bool,
  dialogdata: PropTypes.object
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(requireAuth(ErrorFlagConfig, "mainContent"));
