import React from "react";
import { connect } from "react-redux";
import { bindActionCreators } from "redux";

import PropTypes from "prop-types";

// Import React Table
import ReactTable from "react-table";
import { ReactTableDefaults } from "react-table";

import Button from "@material-ui/core/Button";
import Tooltip from "@material-ui/core/Tooltip";
import DeleteTwoTone from "@material-ui/icons/DeleteTwoTone";
import InfoOutlined from "@material-ui/icons/InfoOutlined";
import AddCircleOutlineOutlined from "@material-ui/icons/AddCircleOutlineOutlined";

// Import actions
import {
  initHolidaySearch,
  getHolidaySearch,
  addHolidaySearch,
  delHolidaySearch
} from "actions/HolidaySearchAction.jsx";

import "react-table/react-table.css";
import "assets/css/bits-styles-override.css";
import "assets/css/bits-styles-hrtext.css";

import Snackbar from "components/Snackbar/Snackbar.jsx";
import APIURIs from "properties/APIURIs.jsx";
import HolidayConfigAddDialog from "components/Dialog/HolidayConfigAddDialog.jsx";
import LoadingSpinner from "components/CustomWidgets/LoadingSpinner.jsx";
import { getTableData, requestData } from "utils/CommonFunctions.jsx";
import requireAuth from "utils/AuthenticatedComponent.jsx";
import Refresh from "components/CustomWidgets/Refresh.jsx";
import Overlay from "components/CustomWidgets/Overlay.jsx";
import RecordCount from "components/CustomWidgets/RecordCount.jsx";
import InlineCustomConfirmation from "components/CustomWidgets/InlineCustomConfirmation.jsx";

//Set default values of React Table
Object.assign(ReactTableDefaults, {
  multiSort: false,
  LoadingComponent: LoadingSpinner
});

function getHoliday(pageSize, page, sorted, filtered) {
  return getTableData(
    APIURIs.ADMIN_HOLIDAY_URI + "?",
    APIURIs.ADMIN_HOLIDAY_APIKEY,
    pageSize,
    page,
    sorted,
    filtered,
    {}
  );
}

function deleteHoliday(date) {
  return requestData(
    APIURIs.ADMIN_HOLIDAY_URI + "/" + date,
    APIURIs.ADMIN_HOLIDAY_APIKEY,
    "delete",
    {}
  );
}

class HolidayConfig extends React.Component {
  _isMounted = false;
  constructor(props) {
    super(props);

    this.state = {
      data: [],
      pages: null,
      loading: true,
      editMode: false,
      selectedDate: "",
      date: "",
      insertUser: "",
      insertTimestamp: "",
      actionLoading: false,
      successElt: false,
      successMsg: "",
      errorElt: false,
      errorMsg: "",
      openAddNewDialog: false,
      totalRecords: null
    };
    this.props.initHolidaySearch();
  }

  componentDidMount() {
    this._isMounted = true;
  }

  componentWillUnmount() {
    this._isMounted = false;
    this.props.initHolidaySearch();
  }

  refreshHolidayList() {
    this.selectTable.fireFetchData();
  }

  showAddSuccessNotification() {
    if (this._isMounted) {
      this.setState(
        {
          successMsg: "Successfully created configuration!"
        },
        function() {
          this.showNotification("successElt");
        }
      );
    }
  }

  showAddErrorNotification() {
    if (this._isMounted) {
      this.setState(
        {
          errorMsg: "Failed to create configuration!"
        },
        function() {
          this.showNotification("errorElt");
        }
      );
    }
  }

  showNotification(place) {
    var x = [];
    x[place] = true;
    if (this._isMounted) {
      this.setState(x);
    }
    this.alertTimeout = setTimeout(
      function() {
        x[place] = false;
        if (this._isMounted) {
          this.setState(x);
        }
      }.bind(this),
      6000
    );
  }

  setLoading(status) {
    if (this._isMounted) {
      this.setState({ actionLoading: status });
    }
  }

  handleAddNew = () => {
    if (this._isMounted) {
      this.setState({ openAddNewDialog: true });
    }
  };

  handleAction = (action, date) => {
    if (action === "delete") {
      this.showConfirmDialog(
        "Confirm",
        "Are you sure you want to delete ?"
      ).then(result => {
        if (result) {
          deleteHoliday(date)
            .then(res => {
              if (res) {
                if (this._isMounted) {
                  this.setState(
                    {
                      successMsg: "Successfully deleted configuration!"
                    },
                    function() {
                      this.refreshHolidayList();
                      this.showNotification("successElt");
                    }
                  );
                }
              }
            })
            .catch(error => {
              console.warn(error);
              if (this._isMounted) {
                this.setState(
                  {
                    loading: false,
                    errorMsg: "Failed to delete configuration!"
                  },
                  function() {
                    this.showNotification("errorElt");
                  }
                );
              }
            });
        }
      });
    }
  };

  handleClose = () => {
    if (this._isMounted) {
      this.setState({ openAddNewDialog: false });
    }
  };

  handleRefresh = event => {
    this.handleSubmit(event);
  };

  handleSubmit = event => {
    event.preventDefault();
    this.selectTable.fireFetchData();
  };

  handleClear = () => {
    this.props.delHolidaySearch();
  };

  handleCheckboxChange = flagType => event => {
    if (event.target.checked == true) {
      if (this._isMounted) {
        this.setState({ [flagType]: "Y" });
      }
    } else {
      if (this._isMounted) {
        this.setState({ [flagType]: "N" });
      }
    }
  };

  handleTextChange = name => event => {
    if (this._isMounted) {
      this.setState({ [name]: event.target.value });
    }
  };

  handleChange = event => {
    let errorSearchTmp = Object.assign({}, this.props.dialogdata);
    errorSearchTmp[event.target.name] = event.target.value;
    this.props.addHolidaySearch(errorSearchTmp);
  };

  showConfirmDialog(title, description) {
    return InlineCustomConfirmation.show({
      title: title,
      description: description,
      button1Title: "YES",
      button2Title: "NO"
    });
  }

  fetchSearchData = () => {
    if (this._isMounted) {
      this.setState({ loading: true });
    }
    getHoliday(10, 0, true, false, this.props.dialogdata)
      .then(res => {
        if (this._isMounted) {
          this.setState({
            data: res.rows,
            pages: res.pages == undefined ? 0 : res.pages,
            loading: false
          });
        }
      })
      .catch(error => {
        console.warn(error);
        if (this._isMounted) {
          this.setState({ loading: false });
        }
      });
  };

  fetchData = state => {
    if (this._isMounted) {
      this.setState({ loading: true });
    }
    getHoliday(
      state.pageSize,
      state.page,
      state.sorted,
      state.filtered,
      this.props.dialogdata
    )
      .then(res => {
        if (this._isMounted) {
          this.setState({
            data: res.rows,
            pages: res.pages == undefined ? 0 : res.pages,
            totalRecords: res.totalRecords,
            loading: false
          });
        }
      })
      .catch(error => {
        console.warn(error);
        if (this._isMounted) {
          this.setState({ loading: false });
        }
      });
  };

  render() {
    const { data, pages, loading } = this.state;
    return (
      <React.Fragment>
        <Overlay active={this.state.actionLoading} marginTop="150px">
          <p />
          <div className="LeftActionBarStyle">
            <Button
              variant="contained"
              color="primary"
              style={{ visibility: "hidden" }}
            >
              Clear
            </Button>
            &nbsp;
            <span className="RightActionBarStyle">
              <div
                style={{
                  textAlign: "right",
                  paddingTop: 10,
                  cursor: "pointer",
                  color: "#388e3c"
                }}
              >
                <Tooltip title="Add New">
                  <AddCircleOutlineOutlined onClick={this.handleAddNew} />
                </Tooltip>
              </div>
            </span>
            <span className="RightActionBarStyle">
              <Refresh onClick={this.handleRefresh} />
            </span>
          </div>
          <ReactTable
            ref={reactHolidayConfig => (this.selectTable = reactHolidayConfig)}
            columns={[
              {
                Header: "Date",
                accessor: "date",
                headerClassName: "BoldText ColoredText"
              },
              {
                Header: "Insert User",
                accessor: "insertUser",
                headerClassName: "BoldText ColoredText"
              },
              {
                Header: "Insert Timestamp",
                accessor: "insertTimestamp",
                headerClassName: "BoldText ColoredText"
              },
              {
                Header: "Actions",
                id: "actions",
                accessor: "actions",
                sortable: false,
                className: "Centered",
                headerClassName: "BoldText ColoredText",
                Cell: ({ original }) => {
                  return (
                    <span style={{ textAlign: "center" }}>
                      <Tooltip title="Delete">
                        <a
                          role="button"
                          style={{
                            cursor: "pointer"
                          }}
                          onClick={() =>
                            this.handleAction("delete", original.date)
                          }
                        >
                          <b>
                            <DeleteTwoTone
                              style={{
                                color: "rgba(0, 0, 0, 0.52)",
                                transition: "all .3s ease"
                              }}
                            />
                          </b>
                        </a>
                      </Tooltip>
                    </span>
                  );
                }
              }
            ]}
            defaultSorted={[
              {
                id: "date",
                desc: true
              }
            ]}
            manual // Forces table not to paginate or sort automatically, so we can handle it server-side
            data={data}
            pages={pages} // Display the total number of pages
            loading={loading} // Display the loading overlay when we need it
            onFetchData={this.fetchData} // Request new data when things change
            defaultPageSize={10}
            className="-striped -highlight"
            getTdProps={() => {
              return {
                style: {
                  padding: 0,
                  height: 30
                }
              };
            }}
          >
            {(state, makeTable) => {
              return (
                <RecordCount
                  state={state}
                  makeTable={makeTable}
                  totalRecords={this.state.totalRecords}
                />
              );
            }}
          </ReactTable>
          <br />
          {/* Add New Dialog */}
          <HolidayConfigAddDialog
            open={this.state.openAddNewDialog}
            handleClose={this.handleClose}
            title="Add New"
            refreshHolidayList={() => this.refreshHolidayList()}
            showSuccessNotification={() => this.showAddSuccessNotification()}
            showErrorNotification={() => this.showAddErrorNotification()}
          />
          <Snackbar
            place="tr"
            color="success"
            icon={InfoOutlined}
            message={this.state.successMsg}
            open={this.state.successElt}
            closeNotification={() => this.setState({ successElt: false })}
            close
          />
          <Snackbar
            place="tr"
            color="danger"
            icon={InfoOutlined}
            message={this.state.errorMsg}
            open={this.state.errorElt}
            closeNotification={() => this.setState({ errorElt: false })}
            close
          />
        </Overlay>
      </React.Fragment>
    );
  }
}

const mapStateToProps = state => ({
  dialogdata: state.sidebar.holidaySearch
});

const mapDispatchToProps = dispatch =>
  bindActionCreators(
    {
      initHolidaySearch,
      getHolidaySearch,
      addHolidaySearch,
      delHolidaySearch
    },
    dispatch
  );

HolidayConfig.propTypes = {
  initHolidaySearch: PropTypes.func,
  addHolidaySearch: PropTypes.func,
  getHolidaySearch: PropTypes.func,
  delHolidaySearch: PropTypes.func,
  className: PropTypes.string,
  sidebar: PropTypes.object,
  stats: PropTypes.bool,
  icon: PropTypes.bool,
  dialogdata: PropTypes.object
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(requireAuth(HolidayConfig, "mainContent"));
