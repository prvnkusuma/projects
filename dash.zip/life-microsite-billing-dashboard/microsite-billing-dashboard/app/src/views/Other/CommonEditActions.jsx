import React from "react";
import PropTypes from "prop-types";

import Tooltip from "@material-ui/core/Tooltip";
import EditTwoTone from "@material-ui/icons/EditTwoTone";
import SaveTwoTone from "@material-ui/icons/SaveTwoTone";
import CancelTwoTone from "@material-ui/icons/CancelTwoTone";
import DeleteTwoTone from "@material-ui/icons/DeleteTwoTone";

import requireAuth from "utils/AuthenticatedComponent.jsx";

class CommonEditActions extends React.Component {
  constructor(props) {
    super(props);
  }

  render() {
    const { editMode, isSelected, isDelete, isEnabled } = this.props;
    return (
      <React.Fragment>
        {editMode == false || isSelected == false ? (
          <Tooltip title="Edit">
            <a
              role="button"
              style={{
                cursor: "pointer"
              }}
              onClick={() => {
                if (isEnabled) {
                  this.props.handleEdit();
                }
              }}
            >
              <b>
                <EditTwoTone
                  style={{
                    color: isEnabled ? "#007ac7" : "#CCCCCC",
                    transition: "all .3s ease"
                  }}
                />
              </b>
            </a>
          </Tooltip>
        ) : (
          ""
        )}
        {editMode == true && isSelected == true ? (
          <Tooltip title="Save">
            <a
              role="button"
              style={{
                cursor: "pointer"
              }}
              onClick={() => {
                if (isEnabled) {
                  this.props.handleSave();
                }
              }}
            >
              <b>
                <SaveTwoTone
                  style={{
                    color: isEnabled ? "#00796b" : "#CCCCCC",
                    transition: "all .3s ease"
                  }}
                />
              </b>
            </a>
          </Tooltip>
        ) : (
          ""
        )}
        {editMode == true && isSelected == true ? (
          <Tooltip title="Cancel">
            <a
              role="button"
              style={{
                cursor: "pointer"
              }}
              onClick={() => {
                if (isEnabled) {
                  this.props.handleCancel();
                }
              }}
            >
              <b>
                <CancelTwoTone
                  style={{
                    color: isEnabled ? "#e54747" : "#CCCCCC",
                    transition: "all .3s ease"
                  }}
                />
              </b>
            </a>
          </Tooltip>
        ) : (
          ""
        )}
        {isDelete == true ? (
          <Tooltip title="Delete">
            <a
              role="button"
              style={{
                cursor: "pointer"
              }}
              onClick={() => {
                if (isEnabled) {
                  this.props.handleDelete();
                }
              }}
            >
              <b>
                <DeleteTwoTone
                  style={{
                    color: isEnabled ? "rgba(0, 0, 0, 0.52)" : "#CCCCCC",
                    transition: "all .3s ease"
                  }}
                />
              </b>
            </a>
          </Tooltip>
        ) : (
          ""
        )}
      </React.Fragment>
    );
  }
}

CommonEditActions.defaultProps = {
  isDelete: false,
  isEnabled: true
};

CommonEditActions.propTypes = {
  editMode: PropTypes.any,
  isSelected: PropTypes.any,
  isDelete: PropTypes.any,
  isEnabled: PropTypes.any,
  handleEdit: PropTypes.func,
  handleSave: PropTypes.func,
  handleCancel: PropTypes.func,
  handleDelete: PropTypes.func
};

export default requireAuth(CommonEditActions, "mainContent");
