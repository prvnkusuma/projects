import React from "react";

import { PropTypes } from "prop-types";

// @material-ui/core components
import withStyles from "@material-ui/core/styles/withStyles";

// core components
import requireAuth from "utils/AuthenticatedComponent.jsx";
import { getFromLocalStorage } from "utils/CommonFunctions.jsx";

const styles = theme => ({
  cardCategoryWhite: {
    color: "rgba(255,255,255,.62)",
    margin: "0",
    fontSize: "14px",
    marginTop: "0",
    marginBottom: "0"
  },
  cardTitleWhite: {
    color: "#FFFFFF",
    marginTop: "0px",
    minHeight: "auto",
    fontWeight: "300",
    fontFamily: "'Roboto', 'Helvetica', 'Arial', sans-serif",
    marginBottom: "3px",
    textDecoration: "none"
  },
  button: {
    margin: theme.spacing.unit
  }
});

class ErrorPage extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      loggedinUserId: getFromLocalStorage("userId")
    };
  }

  handleSubmit = () => {
    console.log("In handleSubmit");
  };

  render() {
    //const { classes } = this.props;
    return (
      <div>
        <span>
          Access Denied! You are not authorized to access this screen.
        </span>
      </div>
    );
  }
}

ErrorPage.propTypes = {
  classes: PropTypes.object.isRequired
};

export default withStyles(styles)(requireAuth(ErrorPage, "mainContent"));
