import React from "react";
import { PropTypes } from "prop-types";
import SimpleReactValidator from "simple-react-validator";

import "assets/css/bits-styles-hrtext.css";

// @material-ui/core components
import withStyles from "@material-ui/core/styles/withStyles";
import TextField from "@material-ui/core/TextField";
import Select from "@material-ui/core/Select";
import Button from "@material-ui/core/Button";
import Typography from "@material-ui/core/Typography";
import InputLabel from "@material-ui/core/InputLabel";
import FormControl from "@material-ui/core/FormControl";
import InfoOutlined from "@material-ui/icons/InfoOutlined";
import InputBase from "@material-ui/core/InputBase";
import Chip from "@material-ui/core/Chip";
import WarningOutlined from "@material-ui/icons/WarningOutlined";

import GridItem from "components/Grid/GridItem.jsx";
import Snackbar from "components/Snackbar/Snackbar.jsx";
import APIURIs from "properties/APIURIs.jsx";
import accordTypes from "properties/AccordTypes.jsx";

// core components
import requireAuth from "utils/AuthenticatedComponent.jsx";
import { getData } from "utils/CommonFunctions.jsx";
import Overlay from "components/CustomWidgets/Overlay.jsx";

const classes = theme => ({
  root: {
    ...theme.mixins.gutters(),
    paddingTop: theme.spacing.unit * 2,
    paddingBottom: theme.spacing.unit * 2
  },
  formControl: {
    margin: theme.spacing.unit,
    minWidth: 120,
    display: "flex",
    wrap: "nowrap"
  },
  textField: {
    marginLeft: theme.spacing.unit,
    marginRight: theme.spacing.unit,
    width: 200,
    display: "flex",
    flexWrap: "wrap"
  },
  multilineTextField: {
    root: {
      "& .MuiFilledInput": {
        borderBottom: 0,
        borderRadius: 4
      }
    }
  },
  button: {
    margin: theme.spacing.unit
  },
  InputClasses: {
    fullWidth: true
  }
});

const CustomXMLInput = withStyles(theme => ({
  root: {
    "label + &": {
      marginTop: theme.spacing.unit * 2
    }
  },
  input: {
    borderRadius: 4,
    position: "relative",
    backgroundColor: "rgba(256, 256, 256, 0.14)",
    border: "1px solid #ced4da",
    fontSize: 16,
    color: "#000000",
    width: "650px",
    minHeight: "350px",
    maxHeight: "350px",
    padding: "10px 12px",
    transition: theme.transitions.create(["border-color", "box-shadow"]),
    "&:focus": {
      borderColor: theme.palette.primary.main
    }
  }
}))(InputBase);

function getAccordXMLData(uuid, accordType) {
  return getData(
    APIURIs.ADMIN_ACCORD_XML_URI + accordType + "/ids/" + uuid,
    APIURIs.ADMIN_ACCORD_XML_APIKEY,
    {}
  );
}

const defaultValues = {
  uuid: "",
  accordType: "",
  xml: ""
};

class AccordRequestXML extends React.Component {
  _isMounted = false;
  constructor(props) {
    super(props);
    this.state = {
      ...defaultValues,
      successElt: false,
      errorElt: false,
      loading: false,
      validationError: false,
      validationMsg: ""
    };
    this.validator = new SimpleReactValidator();
  }

  componentDidMount() {
    this._isMounted = true;
  }

  componentWillUnmount() {
    this._isMounted = false;
  }

  showNotification(place) {
    var x = [];
    x[place] = true;
    if (this._isMounted) {
      this.setState(x);
    }
    this.alertTimeout = setTimeout(
      function() {
        x[place] = false;
        if (this._isMounted) {
          this.setState(x);
        }
      }.bind(this),
      6000
    );
  }

  handleAction = actionType => {
    if (actionType == "clear") {
      if (this._isMounted) {
        this.setState({
          ...defaultValues,
          validationError: false
        });
      }
      return;
    } else {
      let isValidationError = false;
      let validationMsg = "";
      if (!this.validator.fieldValid("uuid")) {
        isValidationError = true;
        validationMsg = "Validation Failed. UUID is mandatory!";
      } else if (!this.validator.fieldValid("accordType")) {
        isValidationError = true;
        validationMsg = "Validation Failed. Accord Type is mandatory!";
      }
      if (this._isMounted) {
        this.setState({
          validationError: isValidationError,
          validationMsg: validationMsg
        });
      }
      if (isValidationError) {
        return;
      } else {
        event.preventDefault();
        if (this._isMounted) {
          this.setState({ loading: true });
        }
        getAccordXMLData(this.state.uuid, this.state.accordType)
          .then(res => {
            if (this._isMounted) {
              this.setState({
                loading: false,
                xml: res.data
              });
            }
          })
          .catch(error => {
            console.warn(error);
            if (this._isMounted) {
              this.setState({ loading: false });
            }
          });
      }
    }
  };

  handleChange = event => {
    this.setState({
      [event.target.name]: event.target.value
    });
  };

  render() {
    return (
      <React.Fragment>
        <div style={{ height: "530px", width: "100%" }}>
          <p />
          {this.state.validationError ? (
            <Chip
              icon={<WarningOutlined />}
              label={this.state.validationMsg}
              color="secondary"
            />
          ) : (
            ""
          )}
          <table border="0px" cellPadding="0" cellSpacing="0">
            <tbody>
              <tr>
                <td className="VerticalAlignBottom">
                  <TextField
                    id="uuid"
                    name="uuid"
                    label="UUID"
                    type="search"
                    style={{ width: 380 }}
                    className={classes.textField}
                    onChange={this.handleChange}
                    value={this.state.uuid}
                    margin="none"
                  />
                  {this.validator.message("uuid", this.state.uuid, "required")}
                </td>
                <td>&nbsp;</td>
                <td className="VerticalAlignBottom">
                  <FormControl>
                    <InputLabel htmlFor="accordType">Accord Type</InputLabel>
                    <Select
                      native
                      autoWidth={true}
                      value={this.state.accordType}
                      onChange={this.handleChange}
                      inputProps={{
                        name: "accordType",
                        id: "accordType"
                      }}
                    >
                      <option value="" />
                      {accordTypes.map(option => (
                        <option key={option.value} value={option.value}>
                          {option.label}
                        </option>
                      ))}
                    </Select>
                    {this.validator.message(
                      "accordType",
                      this.state.accordType,
                      "required"
                    )}
                  </FormControl>
                </td>
              </tr>
            </tbody>
          </table>
          <div className="LeftActionBarStyle">
            <Button
              className={classes.button}
              variant="contained"
              color="primary"
              onClick={() => this.handleAction("search")}
            >
              Submit
            </Button>
            &nbsp;
            <Button
              className={classes.button}
              variant="contained"
              color="primary"
              onClick={() => this.handleAction("clear")}
            >
              Clear
            </Button>
            <Snackbar
              place="tr"
              color="success"
              icon={InfoOutlined}
              message="Policy configuration successfully saved!"
              open={this.state.successElt}
              closeNotification={() =>
                this._isMounted ? this.setState({ successElt: false }) : null
              }
              close
            />
            <Snackbar
              place="tr"
              color="danger"
              icon={InfoOutlined}
              message="Failed to save policy configuration!"
              open={this.state.errorElt}
              closeNotification={() =>
                this._isMounted ? this.setState({ errorElt: false }) : null
              }
              close
            />
          </div>
          <div style={{ width: "800px" }}>
            <Overlay active={this.state.loading} marginTop="200px">
              <GridItem xs={12} sm={12} md={12}>
                <Typography variant="caption">
                  <b>XML Content:</b>
                </Typography>
                <CustomXMLInput multiline value={this.state.xml} />
              </GridItem>
            </Overlay>
          </div>
        </div>
      </React.Fragment>
    );
  }
}

AccordRequestXML.propTypes = {
  classes: PropTypes.object.isRequired,
  policyConfig: PropTypes.object,
  startDate: PropTypes.string,
  endDate: PropTypes.string,
  userName: PropTypes.string,
  isActivated: PropTypes.string
};

export default withStyles(classes)(
  requireAuth(AccordRequestXML, "mainContent")
);
