import React from "react";
import { connect } from "react-redux";
import { bindActionCreators } from "redux";

import { PropTypes } from "prop-types";

import "assets/css/bits-styles-hrtext.css";

// @material-ui/core components
import WarningOutlined from "@material-ui/icons/WarningOutlined";
import withStyles from "@material-ui/core/styles/withStyles";
import Button from "@material-ui/core/Button";
import Typography from "@material-ui/core/Typography";
import FormControl from "@material-ui/core/FormControl";
import Switch from "@material-ui/core/Switch";
import Chip from "@material-ui/core/Chip";
import InfoOutlined from "@material-ui/icons/InfoOutlined";

import Snackbar from "components/Snackbar/Snackbar.jsx";
import GridItem from "components/Grid/GridItem.jsx";
import GridContainer from "components/Grid/GridContainer.jsx";
import DatePickerInput from "components/DatePickerInput/DatePickerInput.jsx";
import APIURIs from "properties/APIURIs.jsx";

// Import actions
import {
  initPolDataConfig,
  getPolDataConfig,
  addPolDataConfig,
  delPolDataConfig
} from "actions/PolicyDataConfigAction.jsx";

// core components
import requireAuth from "utils/AuthenticatedComponent.jsx";
import {
  getData,
  putData,
  isDateLater,
  formatDate,
  formatStringToDate,
  getFromLocalStorage
} from "utils/CommonFunctions.jsx";
import Overlay from "components/CustomWidgets/Overlay.jsx";

const classes = theme => ({
  root: {
    ...theme.mixins.gutters(),
    paddingTop: theme.spacing.unit * 2,
    paddingBottom: theme.spacing.unit * 2
  },
  formControl: {
    margin: theme.spacing.unit,
    minWidth: 120,
    display: "flex",
    wrap: "nowrap"
  },
  textField: {
    marginLeft: theme.spacing.unit,
    marginRight: theme.spacing.unit,
    width: 200,
    display: "flex",
    flexWrap: "wrap"
  },
  button: {
    margin: theme.spacing.unit
  },
  InputClasses: {
    fullWidth: true
  }
});

function getPolicyConfig() {
  return getData(
    APIURIs.ADMIN_POLDATA_CONFIG_URI,
    APIURIs.ADMIN_POLDATA_CONFIG_APIKEY,
    {}
  );
}

function savePolicyConfig(startDate, endDate, isActivated) {
  return putData(
    APIURIs.ADMIN_POLDATA_CONFIG_UPDATE_URI,
    APIURIs.ADMIN_POLDATA_CONFIG_UPDATE_APIKEY,
    {
      startDate: startDate,
      endDate: endDate,
      userName: getFromLocalStorage("userId"),
      isActivated: isActivated ? "Y" : "N"
    }
  );
}

const defaultValues = {
  startDate: "",
  endDate: "",
  isActivated: "",
  validationError: false,
  validationMsg: ""
};

class PolicyDataConfig extends React.Component {
  _isMounted = false;
  constructor(props) {
    super(props);
    this.state = {
      ...defaultValues,
      successElt: false,
      errorElt: false,
      loading: false
    };
  }

  populatePolicyConfig = () => {
    if (this._isMounted) {
      this.setState({ loading: true });
    }
    getPolicyConfig()
      .then(response => {
        if (response) {
          if (response.status === 200) {
            let policyDataConfigTmp = Object.assign(
              {},
              this.props.policyConfig
            );
            policyDataConfigTmp.ruleName = response.data.ruleName;
            policyDataConfigTmp.ruleDesc = response.data.ruleDescription;
            policyDataConfigTmp.startDate = response.data.startDate;
            policyDataConfigTmp.endDate = response.data.endDate;
            policyDataConfigTmp.isActivated =
              response.data.isActivated == "Y" ? true : false;
            policyDataConfigTmp.lastUpdatedBy = response.data.updateUser;
            policyDataConfigTmp.lastUpdatedOn =
              response.data.updateTstampString;

            // Set to default values
            defaultValues.startDate = response.data.startDate;
            defaultValues.endDate = response.data.endDate;
            defaultValues.isActivated =
              response.data.isActivated == "Y" ? true : false;
            this.props.addPolDataConfig(policyDataConfigTmp);
          }
        }
        if (this._isMounted) {
          this.setState({ loading: false });
        }
      })
      .catch(error => {
        console.warn(error);
        if (this._isMounted) {
          this.setState({ loading: false });
        }
      });
  };

  componentDidMount() {
    this._isMounted = true;
    this.populatePolicyConfig();
  }

  componentWillUnmount() {
    this._isMounted = false;
  }

  showNotification(place) {
    var x = [];
    x[place] = true;
    if (this._isMounted) {
      this.setState(x);
    }
    this.alertTimeout = setTimeout(
      function() {
        x[place] = false;
        if (this._isMounted) {
          this.setState(x);
        }
      }.bind(this),
      6000
    );
  }

  handleAction = actionType => {
    if (actionType === "reset") {
      let policyDataConfigTmp = Object.assign({}, this.props.policyConfig);
      policyDataConfigTmp.startDate = defaultValues.startDate;
      policyDataConfigTmp.endDate = defaultValues.endDate;
      policyDataConfigTmp.isActivated = defaultValues.isActivated;
      this.props.addPolDataConfig(policyDataConfigTmp);

      this.setState({
        validationError: false,
        validationMsg: ""
      });
    } else {
      if (
        isDateLater(
          this.props.policyConfig.startDate,
          this.props.policyConfig.endDate
        )
      ) {
        this.setState({
          validationError: true,
          validationMsg:
            "Validation Failed. End Date cannot be before Start End!"
        });
        return;
      } else {
        this.setState({
          validationError: false,
          validationMsg: ""
        });
        savePolicyConfig(
          this.props.policyConfig.startDate,
          this.props.policyConfig.endDate,
          this.props.policyConfig.isActivated
        )
          .then(response => {
            if (response) {
              if (response.status === 200) {
                this.showNotification("successElt");
                this.populatePolicyConfig();
              } else {
                this.showNotification("errorElt");
              }
            }
          })
          .catch(error => {
            console.warn(error);
            if (this._isMounted) {
              this.showNotification("errorElt");
            }
          });
      }
    }
  };

  handleChange = name => event => {
    //this.setState({ ...defaultValues, [name]: event.target.checked });
    let policyDataConfigTmp = Object.assign({}, this.props.policyConfig);
    if (name == "isActivated") {
      policyDataConfigTmp[name] = event.target.checked;
    }
    this.props.addPolDataConfig(policyDataConfigTmp);
  };

  handleDateChange = (dateName, dateValue) => {
    let policyConfigTmp = Object.assign({}, this.props.policyConfig);
    policyConfigTmp[dateName] = formatDate(dateValue);
    this.props.addPolDataConfig(policyConfigTmp);
  };

  render() {
    //const { classes } = this.props;
    return (
      <React.Fragment>
        <div style={{ height: "530px", width: "100%" }}>
          <div style={{ textAlign: "center" }}>
            {this.state.validationError ? (
              <div>
                <Chip
                  icon={<WarningOutlined />}
                  label={this.state.validationMsg}
                  color="secondary"
                />
              </div>
            ) : (
              ""
            )}
          </div>
          <Overlay active={this.state.loading} marginTop="150px">
            <FormControl
              component="fieldset"
              style={{ width: "100%" }}
              className={classes.formControl}
            >
              <GridContainer
                style={{
                  display: "flex",
                  alignItems: "center",
                  textAlign: "right"
                }}
              >
                <GridItem xs={12} sm={12} md={6}>
                  &nbsp;
                </GridItem>
                <GridItem xs={12} sm={12} md={6}>
                  &nbsp;
                </GridItem>
                <GridItem xs={12} sm={12} md={6}>
                  <Typography variant="caption">
                    <b>Name:</b>
                  </Typography>
                </GridItem>
                <GridItem>{this.props.policyConfig.ruleName}</GridItem>
                <GridItem xs={12} sm={12} md={6}>
                  &nbsp;
                </GridItem>
                <GridItem xs={12} sm={12} md={6}>
                  &nbsp;
                </GridItem>
                <GridItem xs={12} sm={12} md={6}>
                  <Typography variant="caption">
                    <b>Description:</b>
                  </Typography>
                </GridItem>
                <GridItem>{this.props.policyConfig.ruleDesc}</GridItem>
                <GridItem xs={12} sm={12} md={6}>
                  &nbsp;
                </GridItem>
                <GridItem xs={12} sm={12} md={6}>
                  &nbsp;
                </GridItem>
                <GridItem xs={12} sm={12} md={6}>
                  <Typography variant="caption">
                    <b>Start Date:</b>
                  </Typography>
                </GridItem>
                <GridItem>
                  <DatePickerInput
                    id="startDate"
                    name="startDate"
                    placeholderText=""
                    selected={formatStringToDate(
                      this.props.policyConfig.startDate
                    )}
                    onChange={dateValue => {
                      this.handleDateChange("startDate", dateValue);
                    }}
                  />
                </GridItem>
                <GridItem xs={12} sm={12} md={6}>
                  &nbsp;
                </GridItem>
                <GridItem xs={12} sm={12} md={6}>
                  &nbsp;
                </GridItem>
                <GridItem xs={12} sm={12} md={6}>
                  <Typography variant="caption">
                    <b>End Date:</b>
                  </Typography>
                </GridItem>
                <GridItem>
                  <DatePickerInput
                    id="endDate"
                    name="endDate"
                    placeholderText=""
                    selected={formatStringToDate(
                      this.props.policyConfig.endDate
                    )}
                    onChange={dateValue => {
                      this.handleDateChange("endDate", dateValue);
                    }}
                  />
                </GridItem>
                <GridItem xs={12} sm={12} md={6}>
                  &nbsp;
                </GridItem>
                <GridItem xs={12} sm={12} md={6}>
                  &nbsp;
                </GridItem>
                <GridItem xs={12} sm={12} md={6}>
                  <Typography variant="caption">
                    <b>Activate/Deactivate:</b>
                  </Typography>
                </GridItem>
                <GridItem xs={12} sm={12} md={6} style={{ textAlign: "left" }}>
                  <Switch
                    checked={this.props.policyConfig.isActivated}
                    onChange={this.handleChange("isActivated")}
                    value="status"
                    color="primary"
                    inputProps={{ "aria-label": "primary checkbox" }}
                  />
                </GridItem>
                <GridItem xs={12} sm={12} md={6}>
                  &nbsp;
                </GridItem>
                <GridItem xs={12} sm={12} md={6}>
                  &nbsp;
                </GridItem>
                <GridItem xs={12} sm={12} md={6}>
                  <Typography variant="caption">
                    <b>Last Updated On:</b>
                  </Typography>
                </GridItem>
                <GridItem xs={12} sm={12} md={6} style={{ textAlign: "left" }}>
                  {this.props.policyConfig.lastUpdatedOn}
                </GridItem>
                <GridItem xs={12} sm={12} md={6}>
                  &nbsp;
                </GridItem>
                <GridItem xs={12} sm={12} md={6}>
                  &nbsp;
                </GridItem>
                <GridItem xs={12} sm={12} md={6}>
                  <Typography variant="caption">
                    <b>Last Updated By:</b>
                  </Typography>
                </GridItem>
                <GridItem xs={12} sm={12} md={6} style={{ textAlign: "left" }}>
                  {this.props.policyConfig.lastUpdatedBy}
                </GridItem>
                <GridItem xs={12} sm={12} md={6}>
                  &nbsp;
                </GridItem>
                <GridItem xs={12} sm={12} md={6}>
                  &nbsp;
                </GridItem>
                <GridItem xs={12} sm={12} md={6}>
                  &nbsp;
                </GridItem>
                <GridItem xs={12} sm={12} md={6}>
                  &nbsp;
                </GridItem>
              </GridContainer>
            </FormControl>
          </Overlay>
          <div style={{ textAlign: "center" }}>
            <Button
              className={classes.button}
              variant="contained"
              color="primary"
              onClick={() => this.handleAction("reset")}
            >
              Reset
            </Button>
            &nbsp;
            <Button
              className={classes.button}
              variant="contained"
              color="primary"
              onClick={() => this.handleAction("save")}
            >
              Save
            </Button>
            <Snackbar
              place="tr"
              color="success"
              icon={InfoOutlined}
              message="Policy configuration successfully saved!"
              open={this.state.successElt}
              closeNotification={() =>
                this._isMounted ? this.setState({ successElt: false }) : null
              }
              close
            />
            <Snackbar
              place="tr"
              color="danger"
              icon={InfoOutlined}
              message="Failed to save policy configuration!"
              open={this.state.errorElt}
              closeNotification={() =>
                this._isMounted ? this.setState({ errorElt: false }) : null
              }
              close
            />
          </div>
        </div>
      </React.Fragment>
    );
  }
}

const mapStateToProps = state => ({
  policyConfig: state.sidebar.policyDataConfig
});

const mapDispatchToProps = dispatch =>
  bindActionCreators(
    {
      initPolDataConfig,
      getPolDataConfig,
      addPolDataConfig,
      delPolDataConfig
    },
    dispatch
  );

PolicyDataConfig.propTypes = {
  addPolDataConfig: PropTypes.func,
  delPolDataConfig: PropTypes.func,
  classes: PropTypes.object.isRequired,
  policyConfig: PropTypes.object,
  startDate: PropTypes.string,
  endDate: PropTypes.string,
  userName: PropTypes.string,
  isActivated: PropTypes.string
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withStyles(classes)(requireAuth(PolicyDataConfig, "mainContent")));
