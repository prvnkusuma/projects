import React from "react";

// @material-ui/core components
import Description from "@material-ui/icons/Description";

// core components
import GridItem from "components/Grid/GridItem.jsx";
import GridContainer from "components/Grid/GridContainer.jsx";
import Card from "components/Card/Card.jsx";
import CardHeader from "components/Card/CardHeader.jsx";
import CardBody from "components/Card/CardBody.jsx";
import PolicyChangeTable from "components/Table/PolicyChangeTable.jsx";
import CardIcon from "components/Card/CardIcon.jsx";

class PolicyChange extends React.Component {
  render() {
    return (
      <GridContainer>
        <GridItem xs={12} sm={12} md={12}>
          <Card>
            <CardHeader color="warning" stats icon>
              <CardIcon color="warning">
                <Description>content_copy</Description>
              </CardIcon>
            </CardHeader>
            <CardBody>
              <PolicyChangeTable ref="policyChangeTable" />
            </CardBody>
          </Card>
        </GridItem>
      </GridContainer>
    );
  }
}

export default PolicyChange;
