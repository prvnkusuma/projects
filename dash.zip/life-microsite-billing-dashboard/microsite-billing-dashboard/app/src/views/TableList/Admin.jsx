import React from "react";
import PropTypes from "prop-types";
import { withStyles } from "@material-ui/core/styles";

// @material-ui/core components
import SupervisorAccount from "@material-ui/icons/SupervisorAccount";

import Paper from "@material-ui/core/Paper";
import Tabs from "@material-ui/core/Tabs";
import Tab from "@material-ui/core/Tab";
import { grey } from "@material-ui/core/colors";

// core components
import GridItem from "components/Grid/GridItem.jsx";
import GridContainer from "components/Grid/GridContainer.jsx";
import Card from "components/Card/Card.jsx";
import CardHeader from "components/Card/CardHeader.jsx";
import CardBody from "components/Card/CardBody.jsx";
import CardIcon from "components/Card/CardIcon.jsx";
import PolicyDataConfig from "views/Other/PolicyDataConfig.jsx";
import ErrorFlagConfig from "views/Other/ErrorFlagConfig.jsx";
import AccordRequestXML from "views/Other/AccordRequestXML.jsx";
import requireAuth from "utils/AuthenticatedComponent.jsx";
import HolidayConfig from "views/Other/HolidayConfig.jsx";
import { getBrowserName } from "utils/CommonFunctions.jsx";

const classes = theme => ({
  root: {
    flexGrow: 1,
    backgroundColor: theme.palette.background.paper
  },
  indicator: {
    backgroundColor: "#009688"
  },
  button: {
    margin: 0
  }
});

const paperStyle = {
  width: getBrowserName() === "IE" ? 905 : 855
};

class Admin extends React.Component {
  _isMounted = false;
  constructor(props) {
    super(props);

    this.state = {
      tabIndex: 0
    };
  }

  componentDidMount() {
    this._isMounted = true;
  }

  componentWillUnmount() {
    this._isMounted = false;
  }

  handleTabChange = (event, tabIndex) => {
    if (this._isMounted) {
      this.setState({ tabIndex });
    }
  };

  render() {
    const { classes } = this.props;
    const { tabIndex } = this.state;
    var styles = {
      default_tab: {
        backgroundColor: grey[50],
        fontWeight: 500
      }
    };
    styles.tab = [];
    for (var i = 0; i < 4; i++) {
      styles.tab[i] = styles.default_tab;
    }

    return (
      <GridContainer>
        <GridItem xs={12} sm={12} md={12}>
          <Card>
            <CardHeader color="warning" stats icon>
              <CardIcon color="warning">
                <SupervisorAccount>content_copy</SupervisorAccount>
              </CardIcon>
            </CardHeader>
            <CardBody>
              <div className={classes.root}>
                <Paper style={paperStyle}>
                  <Tabs
                    value={tabIndex}
                    indicatorColor="primary"
                    textColor="primary"
                    onChange={this.handleTabChange}
                    classes={{
                      indicator: classes.indicator
                    }}
                    style={styles.tab[0]}
                  >
                    <Tab label="Policy Data Configuration" />
                    <Tab label="Error Data Configuration" />
                    <Tab label="Accord Request XML" />
                    <Tab label="Holiday Configuration" />
                  </Tabs>
                </Paper>
                {tabIndex === 0 && <PolicyDataConfig />}
                {tabIndex === 1 && <ErrorFlagConfig />}
                {tabIndex === 2 && <AccordRequestXML />}
                {tabIndex === 3 && <HolidayConfig />}
              </div>
            </CardBody>
          </Card>
        </GridItem>
      </GridContainer>
    );
  }
}

Admin.propTypes = {
  classes: PropTypes.object.isRequired
};

export default withStyles(classes)(requireAuth(Admin, "mainContent"));
