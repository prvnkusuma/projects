import React from "react";

// @material-ui/core components
import Money from "@material-ui/icons/Money";

// core components
import GridItem from "components/Grid/GridItem.jsx";
import GridContainer from "components/Grid/GridContainer.jsx";
import Card from "components/Card/Card.jsx";
import CardHeader from "components/Card/CardHeader.jsx";
import CardBody from "components/Card/CardBody.jsx";
import CardIcon from "components/Card/CardIcon.jsx";
import RemittanceTable from "components/Table/RemittanceTable.jsx";

class Remittance extends React.Component {
  render() {
    return (
      <GridContainer>
        <GridItem xs={12} sm={12} md={12}>
          <Card>
            <CardHeader color="success" stats icon>
              <CardIcon color="success">
                <Money>content_copy</Money>
              </CardIcon>
            </CardHeader>
            <CardBody>
              <RemittanceTable ref="remittanceTable" />
            </CardBody>
          </Card>
        </GridItem>
      </GridContainer>
    );
  }
}

export default Remittance;
