import React from "react";
import PropTypes from "prop-types";
import { withStyles } from "@material-ui/core/styles";

// @material-ui/core components
import MoneyOff from "@material-ui/icons/MoneyOff";

import Paper from "@material-ui/core/Paper";
import Tabs from "@material-ui/core/Tabs";
import Tab from "@material-ui/core/Tab";
import { grey } from "@material-ui/core/colors";

// core components
import GridItem from "components/Grid/GridItem.jsx";
import GridContainer from "components/Grid/GridContainer.jsx";
import Card from "components/Card/Card.jsx";
import CardHeader from "components/Card/CardHeader.jsx";
import CardBody from "components/Card/CardBody.jsx";
import CardIcon from "components/Card/CardIcon.jsx";
import DeclineTable from "components/Table/DeclineTable.jsx";
import EFTReturnsTable from "components/Table/EFTReturnsTable.jsx";
import requireAuth from "utils/AuthenticatedComponent.jsx";
import { isOnlyUserRole } from "utils/CommonFunctions.jsx";

const classes = theme => ({
  root: {
    flexGrow: 1,
    backgroundColor: theme.palette.background.paper
  },
  indicator: {
    backgroundColor: "#009688"
  },
  button: {
    margin: 0
  }
});

class Decline extends React.Component {
  _isMounted = false;
  constructor(props) {
    super(props);

    this.state = {
      tabIndex: 0
    };
  }

  componentDidMount() {
    this._isMounted = true;
  }

  componentWillUnmount() {
    this._isMounted = false;
  }

  handleTabChange = (event, tabIndex) => {
    if (this._isMounted) {
      this.setState({ tabIndex });
    }
  };

  render() {
    const { classes } = this.props;
    const { tabIndex } = this.state;
    var styles = {
      default_tab: {
        backgroundColor: grey[50],
        fontWeight: 500
      }
    };
    styles.tab = [];
    styles.tab[0] = styles.default_tab;
    styles.tab[1] = styles.default_tab;

    return (
      <GridContainer>
        <GridItem xs={12} sm={12} md={12}>
          <Card>
            <CardHeader color="warning" stats icon>
              <CardIcon color="warning">
                <MoneyOff>content_copy</MoneyOff>
              </CardIcon>
            </CardHeader>
            <CardBody>
              <div className={classes.root}>
                {isOnlyUserRole("customercare") ? (
                  <Paper style={{ width: 160 }}>
                    <Tabs
                      value={tabIndex}
                      indicatorColor="primary"
                      textColor="primary"
                      onChange={this.handleTabChange}
                      classes={{
                        indicator: classes.indicator
                      }}
                      style={styles.tab[0]}
                    >
                      <Tab label="EFT Returns" />
                    </Tabs>
                  </Paper>
                ) : (
                  <Paper style={{ width: 325 }}>
                    <Tabs
                      value={tabIndex}
                      indicatorColor="primary"
                      textColor="primary"
                      onChange={this.handleTabChange}
                      classes={{
                        indicator: classes.indicator
                      }}
                      style={styles.tab[0]}
                    >
                      <Tab label="RCC Decline" />
                      <Tab label="EFT Returns" />
                    </Tabs>
                  </Paper>
                )}
                {tabIndex === 0 &&
                  isOnlyUserRole("customercare") && <EFTReturnsTable />}
                {tabIndex === 0 &&
                  !isOnlyUserRole("customercare") && <DeclineTable />}
                {tabIndex === 1 &&
                  !isOnlyUserRole("customercare") && <EFTReturnsTable />}
              </div>
            </CardBody>
          </Card>
        </GridItem>
      </GridContainer>
    );
  }
}

Decline.propTypes = {
  classes: PropTypes.object.isRequired
};

export default withStyles(classes)(requireAuth(Decline, "mainContent"));
