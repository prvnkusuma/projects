import React from "react";

// @material-ui/core components
import DeviceHub from "@material-ui/icons/DeviceHub";

// core components
import GridItem from "components/Grid/GridItem.jsx";
import GridContainer from "components/Grid/GridContainer.jsx";
import Card from "components/Card/Card.jsx";
import CardHeader from "components/Card/CardHeader.jsx";
import CardBody from "components/Card/CardBody.jsx";
import AWDTable from "components/Table/AWDTable.jsx";
import CardIcon from "components/Card/CardIcon.jsx";

class AWD extends React.Component {
  render() {
    return (
      <GridContainer>
        <GridItem xs={12} sm={12} md={12}>
          <Card>
            <CardHeader color="info" stats icon>
              <CardIcon color="info">
                <DeviceHub>content_copy</DeviceHub>
              </CardIcon>
            </CardHeader>
            <CardBody>
              <AWDTable ref="awdTable" />
            </CardBody>
          </Card>
        </GridItem>
      </GridContainer>
    );
  }
}

export default AWD;
