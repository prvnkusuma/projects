import React from "react";

// @material-ui/core components
import PhoneAndroid from "@material-ui/icons/PhoneAndroid";

// core components
import GridItem from "components/Grid/GridItem.jsx";
import GridContainer from "components/Grid/GridContainer.jsx";
import Card from "components/Card/Card.jsx";
import CardHeader from "components/Card/CardHeader.jsx";
import CardBody from "components/Card/CardBody.jsx";
import CardIcon from "components/Card/CardIcon.jsx";
import PhonePaymentTable from "components/Table/PhonePaymentTable.jsx";

class PhonePayment extends React.Component {
  render() {
    return (
      <GridContainer>
        <GridItem xs={12} sm={12} md={12}>
          <Card>
            <CardHeader color="warning" stats icon>
              <CardIcon color="warning">
                <PhoneAndroid>content_copy</PhoneAndroid>
              </CardIcon>
            </CardHeader>
            <CardBody>
              <PhonePaymentTable />
            </CardBody>
          </Card>
        </GridItem>
      </GridContainer>
    );
  }
}

export default PhonePayment;
