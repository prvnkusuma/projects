import React from "react";
import PropTypes from "prop-types";
import { withStyles } from "@material-ui/core/styles";

// @material-ui/core components
import AccountBalanceOutlined from "@material-ui/icons/AccountBalanceOutlined";

import Paper from "@material-ui/core/Paper";
import Tabs from "@material-ui/core/Tabs";
import Tab from "@material-ui/core/Tab";
import { grey } from "@material-ui/core/colors";

// core components
import GridItem from "components/Grid/GridItem.jsx";
import GridContainer from "components/Grid/GridContainer.jsx";
import Card from "components/Card/Card.jsx";
import CardHeader from "components/Card/CardHeader.jsx";
import CardBody from "components/Card/CardBody.jsx";
import CardIcon from "components/Card/CardIcon.jsx";
import EFTBankHeaderInquiryTable from "components/Table/EFTBankHeaderInquiryTable.jsx";
import EFTAccountInquiryTable from "components/Table/EFTAccountInquiryTable.jsx";
import EFTAccountHistoryInquiryTable from "components/Table//EFTAccountHistoryInquiryTable.jsx";
import requireAuth from "utils/AuthenticatedComponent.jsx";

const classes = theme => ({
  root: {
    flexGrow: 1,
    backgroundColor: theme.palette.background.paper
  },
  indicator: {
    backgroundColor: "#009688"
  },
  button: {
    margin: 0
  }
});

const paperStyle = {
  width: 690
};

class EFT extends React.Component {
  _isMounted = false;
  constructor(props) {
    super(props);

    this.state = {
      tabIndex: 0
    };
  }

  componentDidMount() {
    this._isMounted = true;
  }

  componentWillUnmount() {
    this._isMounted = false;
  }

  handleTabChange = (event, tabIndex) => {
    if (this._isMounted) {
      this.setState({ tabIndex });
    }
  };

  render() {
    const { classes } = this.props;
    const { tabIndex } = this.state;
    var styles = {
      default_tab: {
        backgroundColor: grey[50],
        fontWeight: 500
      }
    };
    styles.tab = [];
    for (var i = 0; i < 3; i++) {
      styles.tab[i] = styles.default_tab;
    }

    return (
      <GridContainer>
        <GridItem xs={12} sm={12} md={12}>
          <Card>
            <CardHeader color="success" stats icon>
              <CardIcon color="success">
                <AccountBalanceOutlined>content_copy</AccountBalanceOutlined>
              </CardIcon>
            </CardHeader>
            <CardBody>
              <div className={classes.root}>
                <Paper style={paperStyle}>
                  <Tabs
                    value={tabIndex}
                    indicatorColor="primary"
                    textColor="primary"
                    onChange={this.handleTabChange}
                    classes={{
                      indicator: classes.indicator
                    }}
                    style={styles.tab[0]}
                  >
                    <Tab label="ABC Bank Header Inquiry" />
                    <Tab label="ABC Account Inquiry" />
                    <Tab label="ABC Account History Inquiry" />
                  </Tabs>
                </Paper>
                {tabIndex === 0 && <EFTBankHeaderInquiryTable />}
                {tabIndex === 1 && <EFTAccountInquiryTable />}
                {tabIndex === 2 && <EFTAccountHistoryInquiryTable />}
              </div>
            </CardBody>
          </Card>
        </GridItem>
      </GridContainer>
    );
  }
}

EFT.propTypes = {
  classes: PropTypes.object.isRequired
};

export default withStyles(classes)(requireAuth(EFT, "mainContent"));
