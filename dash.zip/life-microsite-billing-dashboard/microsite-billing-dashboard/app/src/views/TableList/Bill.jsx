import React from "react";

// @material-ui/core components
import LibraryBooks from "@material-ui/icons/LibraryBooks";

// core components
import GridItem from "components/Grid/GridItem.jsx";
import GridContainer from "components/Grid/GridContainer.jsx";
import Card from "components/Card/Card.jsx";
import CardHeader from "components/Card/CardHeader.jsx";
import CardBody from "components/Card/CardBody.jsx";
import BillsTable from "components/Table/BillTable.jsx";
import CardIcon from "components/Card/CardIcon.jsx";

class Bill extends React.Component {
  render() {
    return (
      <GridContainer>
        <GridItem xs={12} sm={12} md={12}>
          <Card>
            <CardHeader color="info" stats icon>
              <CardIcon color="info">
                <LibraryBooks>content_copy</LibraryBooks>
              </CardIcon>
            </CardHeader>
            <CardBody>
              <BillsTable ref="billsTable" />
            </CardBody>
          </Card>
        </GridItem>
      </GridContainer>
    );
  }
}

export default Bill;
