import React from "react";

// @material-ui/core components
import KeyboardReturn from "@material-ui/icons/KeyboardReturn";

// core components
import GridItem from "components/Grid/GridItem.jsx";
import GridContainer from "components/Grid/GridContainer.jsx";
import Card from "components/Card/Card.jsx";
import CardHeader from "components/Card/CardHeader.jsx";
import CardBody from "components/Card/CardBody.jsx";
import CardIcon from "components/Card/CardIcon.jsx";
import EFTReturnsTable from "components/Table/EFTReturnsTable.jsx";

class EFTReturns extends React.Component {
  render() {
    return (
      <GridContainer>
        <GridItem xs={12} sm={12} md={12}>
          <Card>
            <CardHeader color="success" stats icon>
              <CardIcon color="success">
                <KeyboardReturn>content_copy</KeyboardReturn>
              </CardIcon>
            </CardHeader>
            <CardBody>
              <EFTReturnsTable />
            </CardBody>
          </Card>
        </GridItem>
      </GridContainer>
    );
  }
}

export default EFTReturns;
