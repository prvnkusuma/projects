import React from "react";
import PropTypes from "prop-types";
// @material-ui/core
import withStyles from "@material-ui/core/styles/withStyles";
// @material-ui/icons
import Refresh from "@material-ui/icons/Refresh";
// core components
import GridItem from "components/Grid/GridItem.jsx";
import GridContainer from "components/Grid/GridContainer.jsx";
import Card from "components/Card/Card.jsx";
import CardHeader from "components/Card/CardHeader.jsx";
import CardBody from "components/Card/CardBody.jsx";
import CardFooter from "components/Card/CardFooter.jsx";
import APIURIs from "properties/APIURIs.jsx";

//react plugin for creating charts
import { Pie, Bar, Line } from "react-chartjs-2";

import dashboardStyle from "assets/jss/material-dashboard-react/views/dashboardStyle.jsx";
import { getData } from "utils/CommonFunctions.jsx";

const dataSingle = {
  labels: ["January", "February", "March", "April", "May", "June", "July"],
  datasets: [
    {
      label: "RCC Decline Counts",
      fill: false,
      lineTension: 0.2,
      pointLabelFontColor: "#ffffff",
      backgroundColor: "rgba(255,152,0,1)",
      borderColor: "rgba(255,152,0,1)",
      borderCapStyle: "butt",
      borderDash: [],
      borderDashOffset: 0.0,
      borderJoinStyle: "miter",
      pointBorderColor: "rgba(255,152,0,1)",
      pointBackgroundColor: "#fff",
      pointBorderWidth: 1,
      pointHoverRadius: 4,
      pointHoverBackgroundColor: "rgba(255,152,0,1)",
      pointHoverBorderColor: "rgba(220,220,220,1)",
      pointHoverBorderWidth: 2,
      pointRadius: 3,
      pointHitRadius: 10,
      data: [12345, 42221, 12522, 31112, 67432, 23145, 54325]
    }
  ]
};

const dataSingleBar = {
  labels: ["January", "February", "March", "April", "May", "June", "July"],
  datasets: [
    {
      label: "Bill Requests Received",
      fill: true,
      lineTension: 0.2,
      pointLabelFontColor: "#ffffff",
      backgroundColor: "rgba(249,168,37,0.7)",
      borderColor: "rgba(255,255,255,1)",
      borderCapStyle: "butt",
      borderDash: [],
      borderDashOffset: 0.0,
      borderJoinStyle: "miter",
      pointBorderColor: "rgba(249,168,37,0.7)",
      pointBackgroundColor: "#fff",
      pointBorderWidth: 1,
      pointHoverRadius: 3,
      pointHoverBackgroundColor: "rgba(255,255,255,1)",
      pointHoverBorderColor: "rgba(249,168,37,0.7)",
      pointHoverBorderWidth: 2,
      pointRadius: 3,
      pointHitRadius: 7,
      data: [12345, 42221, 12522, 31112, 67432, 23145, 54325]
    }
  ]
};

const data = {
  labels: ["January", "February", "March", "April", "May", "June", "July"],
  datasets: [
    {
      label: "Bills Received",
      fill: false,
      lineTension: 0.2,
      pointLabelFontColor: "#ffffff",
      backgroundColor: "rgba(72,71,69,1)",
      borderColor: "rgba(255,255,255,1)",
      borderCapStyle: "butt",
      borderDash: [],
      borderDashOffset: 0.0,
      borderJoinStyle: "miter",
      pointBorderColor: "rgba(72,71,69,1)",
      pointBackgroundColor: "#fff",
      pointBorderWidth: 1,
      pointHoverRadius: 3,
      pointHoverBackgroundColor: "rgba(255,255,255,1)",
      pointHoverBorderColor: "rgba(72,71,69,1)",
      pointHoverBorderWidth: 2,
      pointRadius: 3,
      pointHitRadius: 7,
      data: [12345, 42221, 12522, 31112, 67432, 23145, 54325]
    },
    {
      label: "Remittances Received",
      fill: false,
      lineTension: 0.2,
      pointLabelFontColor: "#ffffff",
      backgroundColor: "rgba(0,121,107,1)",
      borderColor: "rgba(255,255,255,1)",
      borderCapStyle: "butt",
      borderDash: [],
      borderDashOffset: 0.0,
      borderJoinStyle: "miter",
      pointBorderColor: "rgba(0,121,107,1)",
      pointBackgroundColor: "#fff",
      pointBorderWidth: 1,
      pointHoverRadius: 3,
      pointHoverBackgroundColor: "rgba(255,255,255,1)",
      pointHoverBorderColor: "rgba(0,121,107,1)",
      pointHoverBorderWidth: 2,
      pointRadius: 3,
      pointHitRadius: 7,
      data: [67432, 23145, 54325, 2345, 42221, 12522, 31112]
    }
  ]
};

const dataOptions = {
  legend: {
    display: true,
    position: "top",
    labels: {
      boxWidth: 20,
      fontColor: "white"
    }
  },
  scales: {
    yAxes: [
      {
        ticks: {
          fontColor: "white"
        },
        gridLines: {
          color: "rgba(256,256,256,0.3)",
          borderDash: [2, 2],
          zeroLineColor: "rgba(256,256,256,0.3)",
          zeroLineBorderDash: [2, 2]
        }
      }
    ],
    xAxes: [
      {
        ticks: {
          fontColor: "white"
        },
        gridLines: {
          color: "rgba(256,256,256,0.3)",
          borderDash: [2, 2],
          zeroLineColor: "rgba(256,256,256,0.3)",
          zeroLineBorderDash: [2, 2]
        }
      }
    ]
  },
  responsive: true
};

const dailyRemittancesOptions = {
  legend: {
    display: true,
    position: "right",
    labels: {
      boxWidth: 20,
      fontColor: "white"
    }
  },
  animateRotate: true,
  animateScale: true,
  animationSteps: 120,
  segmentStrokeWidth: 1,
  responsive: true,
  segmentShowStroke: true,
  segmentStrokeColor: "#CCCCCC"
};

class Dashboard extends React.Component {
  _isMounted = false;
  constructor(props) {
    super(props);
    this.state = {
      refreshColor: "disabled",
      dailyRemittancesData: {
        labels: [],
        datasets: [
          {
            data: [],
            backgroundColor: ["#8eb021", "#e94441", "#654982"],
            hoverBackgroundColor: ["#8eb021", "#e94441", "#654982"]
          }
        ]
      }
    };
  }

  fetchDailyRemittances(obj) {
    return getData(
      APIURIs.DASHBOARD_DAILYREMITS_DATA_URL,
      APIURIs.DASHBOARD_DAILYREMITS_DATA_APIKEY,
      {}
    )
      .then(res => {
        const dailyRemittancesDataTmp = Object.assign(
          {},
          obj.state.dailyRemittancesData
        );
        dailyRemittancesDataTmp.labels = res.data.labels;
        dailyRemittancesDataTmp.datasets[0].data = res.data.data;

        if (this._isMounted) {
          obj.setState({
            dailyRemittancesData: dailyRemittancesDataTmp
          });
        }
      })
      .catch(error => {
        console.warn(error);
      });
  }

  componentDidMount() {
    this._isMounted = true;
    this.fetchDailyRemittances(this);
  }

  componentWillUnmount() {
    this._isMounted = false;
  }

  handleDailyRemittancesRefresh = () => {
    this.fetchDailyRemittances(this);
  };

  handleMouseEnterRefresh = () => {
    if (this._isMounted) {
      this.setState({ refreshColor: "primary" });
    }
  };

  handleMouseLeaveRefresh = () => {
    if (this._isMounted) {
      this.setState({ refreshColor: "disabled" });
    }
  };

  render() {
    const { classes } = this.props;
    return (
      <div>
        <GridContainer>
          <GridItem xs={12} sm={12} md={6}>
            <Card chart style={{ marginBottom: "30px" }}>
              <CardHeader color="lightGreen">
                <Pie
                  data={this.state.dailyRemittancesData}
                  options={dailyRemittancesOptions}
                />
              </CardHeader>
              <CardBody>
                <h4 className={classes.cardTitle}>
                  Daily Remittances Received
                </h4>
                <p className={classes.cardCategory}>
                  Daily Remittances Received
                </p>
              </CardBody>
              <CardFooter chart>
                <div className={classes.stats}>
                  <div
                    onClick={this.handleDailyRemittancesRefresh}
                    onMouseEnter={this.handleMouseEnterRefresh}
                    onMouseLeave={this.handleMouseLeaveRefresh}
                    style={{
                      cursor: "pointer",
                      color:
                        this.state.refreshColor === "primary"
                          ? "#3f51b5"
                          : "gray"
                    }}
                  >
                    <Refresh color={this.state.refreshColor} />
                    Refresh
                  </div>
                </div>
              </CardFooter>
            </Card>
          </GridItem>

          <GridItem xs={12} sm={12} md={6}>
            <Card chart style={{ marginBottom: "30px" }}>
              <CardHeader color="success">
                <Line data={dataSingle} options={dataOptions} />
              </CardHeader>
              <CardBody>
                <h4 className={classes.cardTitle}>Daily RCC Decline Counts</h4>
                <p className={classes.cardCategory}>Daily RCC Decline Counts</p>
              </CardBody>
              <CardFooter chart>
                <div className={classes.stats}>
                  <Refresh /> Refresh
                </div>
              </CardFooter>
            </Card>
          </GridItem>
        </GridContainer>

        <GridContainer>
          <GridItem xs={12} sm={12} md={6}>
            <Card chart>
              <CardHeader color="info">
                <Bar data={data} options={dataOptions} />
              </CardHeader>
              <CardBody>
                <h4 className={classes.cardTitle}>
                  Daily Bills & Remittances Received
                </h4>
                <p className={classes.cardCategory}>
                  Daily Bills & Remittances Received
                </p>
              </CardBody>
              <CardFooter chart>
                <div className={classes.stats}>
                  <Refresh /> Refresh
                </div>
              </CardFooter>
            </Card>
          </GridItem>

          <GridItem xs={12} sm={12} md={6}>
            <Card chart>
              <CardHeader color="brown">
                <Bar data={dataSingleBar} options={dataOptions} />
              </CardHeader>
              <CardBody>
                <h4 className={classes.cardTitle}>
                  Daily Bill Requests Received
                </h4>
                <p className={classes.cardCategory}>
                  Daily Bill Requests Received
                </p>
              </CardBody>
              <CardFooter chart>
                <div className={classes.stats}>
                  <Refresh /> Refresh
                </div>
              </CardFooter>
            </Card>
          </GridItem>
        </GridContainer>
      </div>
    );
  }
}

Dashboard.propTypes = {
  classes: PropTypes.object.isRequired
};

export default withStyles(dashboardStyle)(Dashboard);
