import React from "react";
import PropTypes from "prop-types";
import { withStyles } from "@material-ui/core/styles";

// @material-ui/core components
import SwapHoriz from "@material-ui/icons/SwapHoriz";
import Typography from "@material-ui/core/Typography";
import Paper from "@material-ui/core/Paper";
import Tabs from "@material-ui/core/Tabs";
import Tab from "@material-ui/core/Tab";
import { grey } from "@material-ui/core/colors";

import GridItem from "components/Grid/GridItem.jsx";
import GridContainer from "components/Grid/GridContainer.jsx";
import Card from "components/Card/Card.jsx";
import CardHeader from "components/Card/CardHeader.jsx";
import CardBody from "components/Card/CardBody.jsx";
import CardIcon from "components/Card/CardIcon.jsx";
import ReconFlowStepper from "components/Stepper/ReconFlowStepper.jsx";
import ReconciliationTable from "components/Table/ReconciliationTable.jsx";
import { getData } from "utils/CommonFunctions.jsx";
import APIURIs from "properties/APIURIs.jsx";
import Refresh from "components/CustomWidgets/Refresh.jsx";
import Overlay from "components/CustomWidgets/Overlay.jsx";
import requireAuth from "utils/AuthenticatedComponent.jsx";
import "assets/css/bits-styles-override.css";

const classes = theme => ({
  root: {
    flexGrow: 1,
    backgroundColor: theme.palette.background.paper
  },
  indicator: {
    backgroundColor: "#009688"
  },
  button: {
    margin: 0
  }
});

const paperStyle = {
  width: 645
};

const billHeaders = ["ALIP", "BITS", "AIH", "SAP"];
const remitHeaders = ["SAP", "AIH", "BITS", "ALIP"];
const invoiceHeaders = ["SAP", "AIH", "BITS", "XPRESSION"];
const eftSAPReturnHeaders = ["SAP", "BITS", "ALIP"];
const eftALIPReversalHeaders = ["ALIP", "BITS", "XPRESSION"];
const billPopperHeaders = [
  ["Payment Method", "Total"],
  ["Payment Method", "Success/Total"],
  ["Payment Method", "Success/Total"],
  ["Payment Method", "Success/Total"]
];
const remitPopperHeaders = [
  ["Payment Method", "Success/Total"],
  ["Payment Method", "Success/Total"],
  ["Payment Method", "Success/Total"],
  ["Payment Method", "Total"]
];
const eftSAPReturnPopperHeaders = [
  ["Type", "Success/Total"],
  ["Type", "Success/Total"],
  ["Type", "Total"]
];
const eftALIPReversalPopperHeaders = [
  ["Type", "Success/Total"],
  ["Type", "Success/Total"],
  ["Type", "Total"]
];
const defaultLatestCounts = {
  alipCount: 0,
  bitsCountRatio: 0,
  aihCountRatio: 0,
  sapCountRatio: 0,
  xpressionCountRatio: 0
};
const defaultPMCounts = {
  alipPMCounts: 0,
  bitsPMCounts: 0,
  aihPMCounts: 0,
  sapPMCounts: 0,
  xpressionPMCounts: 0
};
const billHeaderLinks = [
  "https://alip.qa.aig.net/aigqa03/saml/SSO",
  "/bill",
  "https://qa.alipsso.aig.net/A03",
  "https://www.aig.com"
];
const remitHeaderLinks = [
  "https://www.aig.com",
  "https://qa.alipsso.aig.net/A03",
  "/remittance",
  "https://alip.qa.aig.net/aigqa03/saml/SSO"
];

function getPaymentMethodCounts(pmtCounts) {
  let paymentMethodObj = {};
  for (var i in pmtCounts) {
    if (pmtCounts.hasOwnProperty(i)) {
      paymentMethodObj[pmtCounts[i].paymentMethod] = pmtCounts[i].countRatio;
    }
  }
  return paymentMethodObj;
}

function transformPopperData(latestCounts, type) {
  let popperData = [];
  if (type === "Bill") {
    popperData.push(getPaymentMethodCounts(latestCounts.alipPMCounts));
    popperData.push(getPaymentMethodCounts(latestCounts.bitsPMCounts));
    popperData.push(getPaymentMethodCounts(latestCounts.aihPMCounts));
    popperData.push(getPaymentMethodCounts(latestCounts.sapPMCounts));
  } else if (type === "Remit") {
    popperData.push(getPaymentMethodCounts(latestCounts.sapPMCounts));
    popperData.push(getPaymentMethodCounts(latestCounts.aihPMCounts));
    popperData.push(getPaymentMethodCounts(latestCounts.bitsPMCounts));
    popperData.push(getPaymentMethodCounts(latestCounts.alipPMCounts));
  } else if (type === "SAP_RETURN") {
    popperData.push(getPaymentMethodCounts(latestCounts.sapPMCounts));
    popperData.push(getPaymentMethodCounts(latestCounts.bitsPMCounts));
    popperData.push(getPaymentMethodCounts(latestCounts.alipPMCounts));
  } else if (type === "ALIP_REVERSAL") {
    popperData.push(getPaymentMethodCounts(latestCounts.alipPMCounts));
    popperData.push(getPaymentMethodCounts(latestCounts.bitsPMCounts));
    popperData.push(getPaymentMethodCounts(latestCounts.xpressionPMCounts));
  } else {
    // Invoice
    popperData.push(getPaymentMethodCounts(latestCounts.sapPMCounts));
    popperData.push(getPaymentMethodCounts(latestCounts.aihPMCounts));
    popperData.push(getPaymentMethodCounts(latestCounts.bitsPMCounts));
    popperData.push(getPaymentMethodCounts(latestCounts.xpressionPMCounts));
  }
  return popperData;
}

function extractCounts(counts, type) {
  let billDataTmp = [];
  if (type === "Bill") {
    billDataTmp.push(counts.alipCount);
    billDataTmp.push(counts.bitsCountRatio);
    billDataTmp.push(counts.aihCountRatio);
    billDataTmp.push(counts.sapCountRatio);
  } else if (type === "Remit") {
    billDataTmp.push(counts.sapCountRatio);
    billDataTmp.push(counts.aihCountRatio);
    billDataTmp.push(counts.bitsCountRatio);
    billDataTmp.push(counts.alipCount);
  } else if (type === "SAP_RETURN") {
    billDataTmp.push(counts.sapCountRatio);
    billDataTmp.push(counts.bitsCountRatio);
    billDataTmp.push(counts.alipCount);
  } else if (type === "ALIP_REVERSAL") {
    billDataTmp.push(counts.alipCount);
    billDataTmp.push(counts.bitsCountRatio);
    billDataTmp.push(counts.xpressionCountRatio);
  } else {
    // Invoice
    billDataTmp.push(counts.sapCountRatio);
    billDataTmp.push(counts.aihCountRatio);
    billDataTmp.push(counts.bitsCountRatio);
    billDataTmp.push(counts.xpressionCountRatio);
  }
  return billDataTmp;
}

function getCurrentDayData(obj, tabIndex, isRefresh) {
  // Bill tab is selected
  let accordType = "Bill";
  let accordTypeCode = 1801;
  if (tabIndex == 1) {
    // Remittance tab is selected
    accordType = "Remit";
    accordTypeCode = 508;
  } else if (tabIndex == 2) {
    // Invoice tab is selected
    accordType = "Invoice";
    accordTypeCode = 118;
  } else if (tabIndex == 3) {
    // EFT tab is selected
    accordType = "EFT";
    accordTypeCode = "ALIP_REVERSAL";
  }

  let params = {};
  if (isRefresh) {
    params = { isRefresh: true };
  }

  if (accordType == "EFT") {
    params = { isRefresh: false };
    // SAP_RETURN
    getReconData(
      APIURIs.CURDAY_RECON_DATA_URI,
      params,
      "SAP_RETURN",
      "SAP_RETURN",
      obj
    );

    params = { isRefresh: true };
    // ALIP_REVERSAL
    getReconData(
      APIURIs.CURDAY_RECON_DATA_URI,
      params,
      "ALIP_REVERSAL",
      "ALIP_REVERSAL",
      obj
    );
  } else {
    getReconData(
      APIURIs.CURDAY_RECON_DATA_URI,
      params,
      accordType,
      accordTypeCode,
      obj
    );
  }
}

function getReconData(uri, params, accordType, accordTypeCode, obj) {
  return getData(
    uri + "/" + accordTypeCode + "?",
    APIURIs.CURDAY_RECON_DATA_APIKEY,
    params
  )
    .then(res => {
      if (obj._isMounted) {
        extractData(obj, res, accordType);
      }
    })
    .catch(error => {
      console.warn(error);
      if (obj._isMounted) {
        obj.setState({ loading: false });
      }
    });
}

function extractData(obj, res, accordType) {
  let countVariable = "latestDateCounts";
  let data = "data";
  let popperData = "popperData";
  let lastUpdatedOn = "lastUpdatedOn";
  let cycleDate = "cycleDate";
  if (accordType == "ALIP_REVERSAL") {
    data = "secondaryData";
    cycleDate = "secondaryCycleDate";
    popperData = "secondaryPopperData";
    lastUpdatedOn = "secondaryLastUpdatedOn";
  }
  let dataParsed =
    res.data[countVariable] != null && res.data[countVariable] != undefined
      ? extractCounts(res.data[countVariable], accordType)
      : defaultLatestCounts;
  let cycleDateParsed =
    res.data[countVariable] != null && res.data[countVariable] != undefined
      ? res.data[countVariable].cycleDate
      : "";
  let updateTmstmpParsed =
    res.data[countVariable] != null && res.data[countVariable] != undefined
      ? res.data[countVariable].updateTmstmp
      : "";
  let popperDataParsed =
    res.data[countVariable] != null && res.data[countVariable] != undefined
      ? transformPopperData(res.data[countVariable], accordType)
      : defaultPMCounts;
  obj.setState({
    [data]: dataParsed,
    [cycleDate]: cycleDateParsed,
    [popperData]: popperDataParsed,
    [lastUpdatedOn]: updateTmstmpParsed
  });
  obj.setState({ loading: false });
}

class Reconciliation extends React.Component {
  _isMounted = false;
  constructor(props) {
    super(props);

    this.state = {
      data: [],
      secondaryData: [],
      cycleDate: "",
      secondaryCycleDate: "",
      loading: true,
      popperData: [],
      secondaryPopperData: [],
      tabIndex: 0,
      lastUpdatedOn: "",
      secondaryLastUpdatedOn: ""
    };
  }

  componentDidMount() {
    this._isMounted = true;
    getCurrentDayData(this, 0, false);
  }

  componentWillUnmount() {
    this._isMounted = false;
  }

  handleTabChange = (event, tabIndex) => {
    if (this._isMounted) {
      this.setState({ loading: true });
      this.setState({ tabIndex });
    }
    getCurrentDayData(this, tabIndex, false);
  };

  handleRefresh = () => {
    this.setState({ loading: true });
    getCurrentDayData(this, this.state.tabIndex, true);
  };

  render() {
    const { classes } = this.props;
    const { tabIndex } = this.state;
    var styles = {
      default_tab: {
        backgroundColor: grey[50],
        fontWeight: 500
      }
    };
    styles.tab = [];
    for (var i = 0; i < 4; i++) {
      styles.tab[i] = styles.default_tab;
    }

    return (
      <React.Fragment>
        <GridContainer>
          <GridItem xs={12} sm={12} md={12}>
            <Card>
              <CardHeader color="warning" stats icon>
                <CardIcon color="warning">
                  <SwapHoriz>content_copy</SwapHoriz>
                </CardIcon>
              </CardHeader>
              <CardBody>
                <Typography variant="subheading">
                  Reconciliation - Latest
                </Typography>
                <p />
                <div className={classes.root}>
                  <Paper style={paperStyle}>
                    <Tabs
                      value={tabIndex}
                      indicatorColor="primary"
                      textColor="primary"
                      onChange={this.handleTabChange}
                      classes={{
                        indicator: classes.indicator
                      }}
                      style={styles.tab[0]}
                    >
                      <Tab label="Bill" />
                      <Tab label="Remittance" />
                      <Tab label="Invoice" />
                      <Tab label="EFT" />
                    </Tabs>
                  </Paper>
                  <Overlay active={this.state.loading} marginTop="150px">
                    {tabIndex === 0 && (
                      <div>
                        <p />
                        <div className="LeftActionBarStyle">
                          <span className="RightActionBarStyle">
                            <Refresh onClick={this.handleRefresh} />
                          </span>
                        </div>
                        <Typography variant="subheading">
                          Bill Reconciliation - [{this.state.cycleDate}]
                        </Typography>
                        <ReconFlowStepper
                          headers={billHeaders}
                          headerLinks={billHeaderLinks}
                          data={this.state.data}
                          popperData={this.state.popperData}
                          popperHeaders={billPopperHeaders}
                          bgcolor={
                            "linear-gradient(45deg, #20a8d8 15%, #20a8d8 90%)"
                          }
                        />
                        <span className="RightActionBarStyle">
                          Last updated on : {this.state.lastUpdatedOn}
                        </span>
                      </div>
                    )}
                    {tabIndex === 1 && (
                      <div>
                        <p />
                        <div className="LeftActionBarStyle">
                          <span className="RightActionBarStyle">
                            <Refresh onClick={this.handleRefresh} />
                          </span>
                        </div>
                        <Typography variant="subheading">
                          Remittance Reconciliation - [{this.state.cycleDate}]
                        </Typography>
                        <ReconFlowStepper
                          headers={remitHeaders}
                          headerLinks={remitHeaderLinks}
                          data={this.state.data}
                          popperData={this.state.popperData}
                          popperHeaders={remitPopperHeaders}
                          bgcolor={
                            "linear-gradient(45deg, #17a2b8 15%, #17a2b8 90%)"
                          }
                        />
                        <span className="RightActionBarStyle">
                          Last updated on : {this.state.lastUpdatedOn}
                        </span>
                      </div>
                    )}
                    {tabIndex === 2 && (
                      <div>
                        <p />
                        <div className="LeftActionBarStyle">
                          <span className="RightActionBarStyle">
                            <Refresh onClick={this.handleRefresh} />
                          </span>
                        </div>
                        <Typography variant="subheading">
                          Invoice Reconciliation - [{this.state.cycleDate}]
                        </Typography>
                        <ReconFlowStepper
                          headers={invoiceHeaders}
                          headerLinks={remitHeaderLinks}
                          data={this.state.data}
                          popperData={this.state.popperData}
                          popperHeaders={remitPopperHeaders}
                          bgcolor={
                            "linear-gradient(45deg, #26a69a 15%, #26a69a 90%)"
                          }
                        />
                        <span className="RightActionBarStyle">
                          Last updated on : {this.state.lastUpdatedOn}
                        </span>
                      </div>
                    )}
                    {tabIndex === 3 && (
                      <div>
                        <div>
                          <p />
                          <div className="LeftActionBarStyle">
                            <span className="RightActionBarStyle">
                              <Refresh onClick={this.handleRefresh} />
                            </span>
                          </div>
                          <div>&nbsp;</div>
                          <Typography variant="subheading">
                            SAP Return Reconciliation - [{this.state.cycleDate}]
                          </Typography>
                          <ReconFlowStepper
                            headers={eftSAPReturnHeaders}
                            headerLinks={remitHeaderLinks}
                            data={this.state.data}
                            popperData={this.state.popperData}
                            popperHeaders={eftSAPReturnPopperHeaders}
                            bgcolor={
                              "linear-gradient(45deg, #00838f 15%, #00838f 90%)"
                            }
                          />
                        </div>
                        <div>&nbsp;</div>
                        <div>
                          <Typography
                            variant="subheading"
                            style={{ margin: 0 }}
                          >
                            ALIP Reversal Reconciliation - [
                            {this.state.secondaryCycleDate}]
                          </Typography>
                          <ReconFlowStepper
                            headers={eftALIPReversalHeaders}
                            headerLinks={remitHeaderLinks}
                            data={this.state.secondaryData}
                            popperData={this.state.secondaryPopperData}
                            popperHeaders={eftALIPReversalPopperHeaders}
                            bgcolor={
                              "linear-gradient(45deg, #00838f 15%, #00838f 90%)"
                            }
                          />
                          <span className="RightActionBarStyle">
                            Last updated on :{this.state.secondaryLastUpdatedOn}
                          </span>
                        </div>
                      </div>
                    )}
                  </Overlay>
                </div>
              </CardBody>
            </Card>
          </GridItem>
          <GridItem xs={12} sm={12} md={12}>
            <Card>
              <CardBody>
                <Typography variant="subheading">
                  Reconciliation - Historical
                </Typography>
                <ReconciliationTable ref="remittanceTable" />
              </CardBody>
            </Card>
          </GridItem>
        </GridContainer>
      </React.Fragment>
    );
  }
}

Reconciliation.propTypes = {
  classes: PropTypes.object.isRequired
};

export default withStyles(classes)(requireAuth(Reconciliation, "mainContent"));
