import React from "react";
import "babel-polyfill";
import { PropTypes } from "prop-types";
import SimpleReactValidator from "simple-react-validator";

// @material-ui/core components
import withStyles from "@material-ui/core/styles/withStyles";
import WarningOutlined from "@material-ui/icons/WarningOutlined";
import InputAdornment from "@material-ui/core/InputAdornment";
// @material-ui/icons
import People from "@material-ui/icons/People";
import LockOutlined from "@material-ui/icons/LockOutlined";
// core components
import GridContainer from "components/Grid/GridContainer.jsx";
import GridItem from "components/Grid/GridItem.jsx";
import Button from "components/CustomButtons/Button.jsx";
import Chip from "@material-ui/core/Chip";
import Card from "components/Card/Card.jsx";
import CardBody from "components/Card/CardBody.jsx";
import CardHeader from "components/Card/CardHeader.jsx";
import CardFooter from "components/Card/CardFooter.jsx";
import CustomInput from "components/CustomInput/CustomInput.jsx";
import { withRouter } from "react-router-dom";
import {
  validateUser,
  setToLocalStorage,
  isOnlyUserRole
} from "utils/CommonFunctions.jsx";

import loginPageStyle from "assets/jss/material-dashboard-react/views/loginPage.jsx";

import image from "assets/img/aig_bg.jpg";
import logo from "assets/img/aig_login_logo.svg";
import Overlay from "components/CustomWidgets/Overlay.jsx";

const initialState = {
  userId: "",
  userPassword: "",
  userIdError: false,
  userPwdError: false,
  userIdSuccess: false,
  userPwdSuccess: false,
  validationError: false
};

class LoginPage extends React.Component {
  constructor(props) {
    super(props);
    // we use this to make the card to appear after the page has been rendered
    this.state = {
      cardAnimaton: "cardHidden",
      loading: false,
      ...initialState
    };
    this.validator = new SimpleReactValidator();
  }

  componentDidMount() {
    // we add a hidden class to the card and after 700 ms we delete it and the transition appears
    setTimeout(
      function() {
        this.setState({ cardAnimaton: "" });
      }.bind(this),
      700
    );
    document.getElementById("userId").focus();
  }

  handleChange = event => {
    let loginStateTmp = Object.assign({}, this.state);
    loginStateTmp[event.target.name] = event.target.value;
    this.setState(loginStateTmp);
  };

  handleClear = () => {
    this.setState(initialState);
    document.getElementById("userId").value = "";
    document.getElementById("userPassword").value = "";
    document.getElementById("userId").focus();
  };

  handleLogin = () => {
    if (this.validator.fieldValid("userId")) {
      this.setState({
        userIdError: false,
        userIdSuccess: true
      });
    } else {
      this.setState({
        userIdError: true,
        userIdSuccess: false
      });
      return;
    }

    if (this.validator.fieldValid("userPassword")) {
      this.setState({
        userPwdError: false,
        userPwdSuccess: true
      });
    } else {
      this.setState({
        userPwdError: true,
        userPwdSuccess: false
      });
      return;
    }
    this.setState({ loading: true });
    validateUser(this.state.userId, this.state.userPassword).then(res => {
      if (res.data && res.data.authenticatedUser == false) {
        this.setState({
          validationError: true,
          loading: false,
          userIdError: true,
          userPwdError: true
        });
        return;
      }
      this.setState({ loading: false });
      setToLocalStorage("userId", this.state.userId);
      setToLocalStorage("userEmail", res.data.userDetails.emailId);
      setToLocalStorage("firstName", res.data.userDetails.firstName);
      setToLocalStorage("lastName", res.data.userDetails.lastName);
      setToLocalStorage("userRole", res.data.userDetails.roles);
      if (isOnlyUserRole("customercare")) {
        this.props.history.replace("/decline");
      } else {
        this.props.history.replace("/reconciliation");
      }
    });
  };

  render() {
    const { classes } = this.props;
    return (
      <div>
        <div
          className={classes.pageHeader}
          style={{
            backgroundImage: "url(" + image + ")",
            backgroundSize: "cover",
            backgroundPosition: "top center"
          }}
        >
          <div className={classes.container}>
            <GridContainer justify="center">
              <GridItem xs={12} sm={12} md={4}>
                <Overlay active={this.state.loading} marginTop="150px">
                  <Card className={classes[this.state.cardAnimaton]}>
                    <form id="my-form-id" className={classes.form}>
                      <CardHeader color="info" className={classes.cardHeader}>
                        <div>
                          <img
                            src={logo}
                            alt="logo"
                            style={{ width: "120px", maxHeight: "75px" }}
                            className={classes.img}
                          />
                        </div>
                        <h4>
                          <b>Billing Integration Technology Services</b>
                        </h4>
                      </CardHeader>
                      <CardBody>
                        {this.state.validationError ? (
                          <Chip
                            icon={<WarningOutlined />}
                            label="Error! Please enter valid credentials."
                            color="secondary"
                          />
                        ) : (
                          ""
                        )}
                        <CustomInput
                          labelText="User Id"
                          name="userId"
                          id="userId"
                          formControlProps={{
                            fullWidth: true
                          }}
                          inputProps={{
                            type: "text",
                            startAdornment: (
                              <InputAdornment position="start">
                                <People className={classes.inputIconsColor} />
                              </InputAdornment>
                            )
                          }}
                          onChange={this.handleChange}
                          error={this.state.userIdError}
                          success={this.state.userIdSuccess}
                          value={this.state.userId}
                          onKeyPress={e => {
                            if (e.key === "Enter") {
                              this.handleLogin();
                            }
                          }}
                        />
                        {this.validator.message(
                          "userId",
                          this.state.userId,
                          "required|alpha_num"
                        )}
                        <CustomInput
                          labelText="Password"
                          id="userPassword"
                          name="userPassword"
                          formControlProps={{
                            fullWidth: true
                          }}
                          inputProps={{
                            type: "password",
                            startAdornment: (
                              <InputAdornment position="start">
                                <LockOutlined
                                  className={classes.inputIconsColor}
                                />
                              </InputAdornment>
                            )
                          }}
                          onChange={this.handleChange}
                          error={this.state.userPwdError}
                          success={this.state.userPwdSuccess}
                          value={this.state.userPassword}
                          onKeyPress={e => {
                            if (e.key === "Enter") {
                              this.handleLogin();
                            }
                          }}
                        />
                        {this.validator.message(
                          "userPassword",
                          this.state.userPassword,
                          "required"
                        )}
                      </CardBody>
                      <CardFooter className={classes.cardFooter}>
                        <Button
                          simple
                          form="my-form-id"
                          variant="contained"
                          color="info"
                          size="lg"
                          onClick={this.handleLogin}
                        >
                          Login
                        </Button>
                        <Button
                          simple
                          variant="contained"
                          color="info"
                          size="lg"
                          onClick={this.handleClear}
                        >
                          Clear
                        </Button>
                      </CardFooter>
                    </form>
                  </Card>
                </Overlay>
              </GridItem>
            </GridContainer>
          </div>
        </div>
      </div>
    );
  }
}

LoginPage.propTypes = {
  classes: PropTypes.object.isRequired,
  history: PropTypes.object
};

export default withStyles(loginPageStyle)(withRouter(LoginPage));
