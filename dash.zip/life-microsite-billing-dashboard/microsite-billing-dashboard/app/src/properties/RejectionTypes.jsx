const rejectionTypes = [
  {
    value: "AWD_ABCRETURN",
    label: "ABC Return"
  },
  {
    value: "AWD_ABCPRENOTE",
    label: "ABC Prenote"
  },
  {
    value: "AWD_ABCRETURN_SAP",
    label: "ABC Return SAP"
  }
];

export default rejectionTypes;
