export const statusTypes = [
  {
    value: "completed",
    label: "Completed"
  },
  {
    value: "pending",
    label: "Pending"
  },
  {
    value: "inprogress",
    label: "In Progress"
  },
  {
    value: "failed",
    label: "Failed"
  }
];

export const eventCodeTypes = [
  {
    value: "70001",
    label: "70001 - EFT Termination Letter"
  },
  {
    value: "70002",
    label: "70002 - EFT Return Letter"
  },
  {
    value: "70003",
    label: "70003 - EFT Confirmation Letter"
  },
  {
    value: "70004",
    label: "70004 - EFT Mode Change Letter"
  },
  {
    value: "70005",
    label: "70005 - E-Bill Payment Scheduled Email Returned Letter"
  },
  {
    value: "70006",
    label: "70006 - E-Bill Payment Confirmation Returned Letter"
  },
  {
    value: "70007",
    label: "70007 - Phone Payment Confirmation Letter"
  },
  {
    value: "70008",
    label: "70008 - Phone Payment Return Letter"
  },
  {
    value: "70009",
    label: "70009 - Draft at Submit Return Letter"
  }
];
