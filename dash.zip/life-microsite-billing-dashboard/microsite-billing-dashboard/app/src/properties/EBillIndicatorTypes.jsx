const ebillIndTypes = [
  {
    value: "X",
    label: "Paper"
  },
  {
    value: "Y",
    label: "E-Bill"
  },
  {
    value: "Z",
    label: "Both"
  }
];

export default ebillIndTypes;
