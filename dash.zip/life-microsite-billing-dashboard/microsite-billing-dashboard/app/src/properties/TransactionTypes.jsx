const transactionTypes = [
  {
    value: "AWD",
    label: "AWD"
  },
  {
    value: "EMAIL",
    label: "EMAIL"
  },
  {
    value: "FDM",
    label: "FDM"
  },
  {
    value: "NOTIFICATION",
    label: "NOTIFICATION"
  }
];

export default transactionTypes;
