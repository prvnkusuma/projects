const accordTypes = [
  {
    value: "1801",
    label: "Bill"
  },
  {
    value: "508",
    label: "Remittance"
  },
  {
    value: "184",
    label: "Decline"
  },
  {
    value: "118",
    label: "Invoice"
  },
  {
    value: "1203",
    label: "Policy Change"
  }
];

export default accordTypes;
