const paymentTypes = [
  {
    value: "Loan",
    label: "Loan"
  },
  {
    value: "Premium",
    label: "Premium"
  },
  {
    value: "Reinstatement",
    label: "Reinstatement"
  }
];

export default paymentTypes;
