const paymentSources = [
  {
    value: "Credit Card",
    label: "CREDIT CARD"
  },
  {
    value: "Default",
    label: "DEFAULT"
  },
  {
    value: "FE-FISERV/CHKFREE ESERVICE",
    label: "FE-FISERV/CHKFREE ESERVICE"
  },
  {
    value: "One Time EFT-phone",
    label: "One Time EFT-phone"
  },
  {
    value: "SAP-SAP CD Check",
    label: "SAP-SAP CD Check"
  },
  {
    value: "SAP-SAP CD Clarification Check",
    label: "SAP-SAP CD Clarification Check"
  }
];

export default paymentSources;
