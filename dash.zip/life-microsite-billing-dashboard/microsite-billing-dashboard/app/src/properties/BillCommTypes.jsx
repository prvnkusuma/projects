const billCommTypes = [
  {
    value: "E",
    label: "E-Bill"
  },
  {
    value: "P",
    label: "Paper"
  }
];

export default billCommTypes;
