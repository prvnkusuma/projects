const paymentMethods = [
  {
    value: "Bank Draft",
    label: "Bank Draft"
  },
  {
    value: "Credit Card",
    label: "Credit Card"
  },
  {
    value: "Direct Billing",
    label: "Direct Billing"
  }
];

export const billPaymentMethods = [
  {
    value: "Bank Draft",
    label: "Bank Draft"
  },
  {
    value: "Credit Card",
    label: "Credit Card"
  },
  {
    value: "Direct Billing",
    label: "Direct Billing"
  },
  {
    value: "Draft At Submit",
    label: "Draft At Submit"
  },
  {
    value: "Phone Payment",
    label: "Phone Payment"
  }
];

export default paymentMethods;
