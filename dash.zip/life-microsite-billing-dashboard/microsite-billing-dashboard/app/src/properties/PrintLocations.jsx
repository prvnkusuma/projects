const printLocations = [
  {
    value: "reprint",
    label: "Reprint"
  },
  {
    value: "nashville",
    label: "Nashville"
  }
];

export default printLocations;
