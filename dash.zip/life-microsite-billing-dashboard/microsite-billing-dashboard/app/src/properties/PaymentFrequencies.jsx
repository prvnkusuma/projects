const paymentFrequencies = [
  {
    value: "Annual",
    label: "Annual"
  },
  /*{
    value: "Bi-Monthly",
    label: "Bi-Monthly"
  },
  {
    value: "Bi-Weekly",
    label: "Bi-Weekly"
  },
  {
    value: "Lifetime",
    label: "Lifetime"
  },*/
  {
    value: "Monthly",
    label: "Monthly"
  },
  {
    value: "Quarterly",
    label: "Quarterly"
  },
  {
    value: "Semi-Annual",
    label: "Semi-Annual"
  },
  {
    value: "Single",
    label: "Single"
  },
  {
    value: "Weekly",
    label: "Weekly"
  }
];

export default paymentFrequencies;
