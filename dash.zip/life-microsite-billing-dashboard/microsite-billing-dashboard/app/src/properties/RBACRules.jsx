const RBACRules = {
  // Invoice Actions
  business_invoice_print: true,
  support_invoice_print: false,
  customercare_invoice_print: true,

  // Reporting Actions
  business_reporting_reprocess: true,
  support_reporting_reprocess: false,

  // Correspondence Actions
  business_correspondence_print: true,
  support_correspondence_print: false,

  // E-Bill Actions
  business_ebill_activate_deactivate: true,
  support_ebill_activate_deactivate: false
};

export default RBACRules;
