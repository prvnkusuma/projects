const countries = [
  {
    OLICode: "OLI_UNKNOWN",
    TypeCode: "0",
    ALIPCode: "0",
    Desc: "Other",
    ISOCode: "ZZ"
  },
  {
    OLICode: "OLI_NATION_AFGHANISTAN",
    TypeCode: "93",
    ALIPCode: "93",
    Desc: "Afghanistan",
    ISOCode: "AF"
  },
  {
    OLICode: "OLI_NATION_ALBANIA",
    TypeCode: "355",
    ALIPCode: "355",
    Desc: "Albania",
    ISOCode: "AL"
  },
  {
    OLICode: "OLI_NATION_ALGERIA",
    TypeCode: "213",
    ALIPCode: "213",
    Desc: "Algeria",
    ISOCode: "DZ"
  },
  {
    OLICode: "OLI_NATION_AMERICANSAMOA",
    TypeCode: "684",
    ALIPCode: "684",
    Desc: "American Samoa",
    ISOCode: "AS"
  },
  {
    OLICode: "OLI_NATION_ANDORRA",
    TypeCode: "376",
    ALIPCode: "376",
    Desc: "Andorra",
    ISOCode: "AD"
  },
  {
    OLICode: "OLI_NATION_ANGOLA",
    TypeCode: "244",
    ALIPCode: "244",
    Desc: "Angola",
    ISOCode: "AO"
  },
  {
    OLICode: "OLI_NATION_ANGUILLA",
    TypeCode: "1001",
    ALIPCode: "999",
    Desc: "Anguilla",
    ISOCode: "AI"
  },
  {
    OLICode: "OLI_NATION_ANTARCTICA",
    TypeCode: "672",
    ALIPCode: "672",
    Desc: "Antarctica",
    ISOCode: "AQ"
  },
  {
    OLICode: "OLI_NATION_ANTIGUABARBUDA",
    TypeCode: "268",
    ALIPCode: "268",
    Desc: "Antigua And Barbuda",
    ISOCode: "AG"
  },
  {
    OLICode: "OLI_NATION_ARGENTINA",
    TypeCode: "54",
    ALIPCode: "54",
    Desc: "Argentina",
    ISOCode: "AR"
  },
  {
    OLICode: "OLI_NATION_ARMENIA",
    TypeCode: "374",
    ALIPCode: "374",
    Desc: "Armenia",
    ISOCode: "AM"
  },
  {
    OLICode: "OLI_NATION_ARUBA",
    TypeCode: "297",
    ALIPCode: "297",
    Desc: "Aruba",
    ISOCode: "AW"
  },
  {
    OLICode: "OLI_NATION_AUSTRALIA",
    TypeCode: "61",
    ALIPCode: "61",
    Desc: "Australia",
    ISOCode: "AU"
  },
  {
    OLICode: "OLI_NATION_AUSTRIA",
    TypeCode: "43",
    ALIPCode: "43",
    Desc: "Austria",
    ISOCode: "AT"
  },
  {
    OLICode: "OLI_NATION_AZERBAIJAN",
    TypeCode: "994",
    ALIPCode: "994",
    Desc: "Azerbaijan",
    ISOCode: "AZ"
  },
  {
    OLICode: "OLI_NATION_BAHAMAS",
    TypeCode: "242",
    ALIPCode: "242",
    Desc: "Bahamas",
    ISOCode: "BS"
  },
  {
    OLICode: "OLI_NATION_BAHRAIN",
    TypeCode: "973",
    ALIPCode: "973",
    Desc: "Bahrain",
    ISOCode: "BH"
  },
  {
    OLICode: "OLI_NATION_BANGLADESH",
    TypeCode: "880",
    ALIPCode: "880",
    Desc: "Bangladesh",
    ISOCode: "BD"
  },
  {
    OLICode: "OLI_NATION_BARBADOS",
    TypeCode: "246",
    ALIPCode: "246",
    Desc: "Barbados",
    ISOCode: "BB"
  },
  {
    OLICode: "OLI_NATION_BELARUS",
    TypeCode: "375",
    ALIPCode: "375",
    Desc: "Belarus",
    ISOCode: "BY"
  },
  {
    OLICode: "OLI_NATION_BELGIUM",
    TypeCode: "32",
    ALIPCode: "32",
    Desc: "Belgium",
    ISOCode: "BE"
  },
  {
    OLICode: "OLI_NATION_BELIZE",
    TypeCode: "501",
    ALIPCode: "501",
    Desc: "Belize",
    ISOCode: "BZ"
  },
  {
    OLICode: "OLI_NATION_BENIN",
    TypeCode: "229",
    ALIPCode: "229",
    Desc: "Benin",
    ISOCode: "BJ"
  },
  {
    OLICode: "OLI_NATION_BERMUDA",
    TypeCode: "441",
    ALIPCode: "441",
    Desc: "Bermuda",
    ISOCode: "BM"
  },
  {
    OLICode: "OLI_NATION_BHUTAN",
    TypeCode: "975",
    ALIPCode: "975",
    Desc: "Bhutan",
    ISOCode: "BT"
  },
  {
    OLICode: "OLI_NATION_BOLIVIA",
    TypeCode: "591",
    ALIPCode: "591",
    Desc: "Bolivia",
    ISOCode: "BO"
  },
  {
    OLICode: "OLI_NATION_BOSNIAHERZEGOVINA",
    TypeCode: "387",
    ALIPCode: "387",
    Desc: "Bosnia And Herzegovina",
    ISOCode: "BA"
  },
  {
    OLICode: "OLI_NATION_BOTSWANA",
    TypeCode: "267",
    ALIPCode: "267",
    Desc: "Botswana",
    ISOCode: "BW"
  },
  {
    OLICode: "OLI_NATION_BOUVETISLAND",
    TypeCode: "1009",
    ALIPCode: "5004",
    Desc: "Bouvet Island",
    ISOCode: "BV"
  },
  {
    OLICode: "OLI_NATION_BRAZIL",
    TypeCode: "55",
    ALIPCode: "55",
    Desc: "Brazil",
    ISOCode: "BR"
  },
  {
    OLICode: "OLI_NATION_BRITISHINDIANOCNTERR",
    TypeCode: "1011",
    ALIPCode: "5015",
    Desc: "British Indian Ocean Territory",
    ISOCode: "IO"
  },
  {
    OLICode: "OLI_NATION_BRUNEI",
    TypeCode: "673",
    ALIPCode: "673",
    Desc: "Brunei",
    ISOCode: "BN"
  },
  {
    OLICode: "OLI_NATION_BULGARIA",
    TypeCode: "359",
    ALIPCode: "359",
    Desc: "Bulgaria",
    ISOCode: "BG"
  },
  {
    OLICode: "OLI_NATION_BURKINAFASO",
    TypeCode: "226",
    ALIPCode: "226",
    Desc: "Burkina Faso",
    ISOCode: "BF"
  },
  {
    OLICode: "OLI_NATION_BURUNDI",
    TypeCode: "257",
    ALIPCode: "257",
    Desc: "Burundi",
    ISOCode: "BI"
  },
  {
    OLICode: "OLI_NATION_BURMA",
    TypeCode: "95",
    ALIPCode: "95",
    Desc: "Burma",
    ISOCode: "BU"
  },
  {
    OLICode: "OLI_NATION_CAMBODIA",
    TypeCode: "855",
    ALIPCode: "855",
    Desc: "Cambodia",
    ISOCode: "KH"
  },
  {
    OLICode: "OLI_NATION_CAMEROON",
    TypeCode: "237",
    ALIPCode: "237",
    Desc: "Cameroon",
    ISOCode: "CM"
  },
  {
    OLICode: "OLI_NATION_CANADA",
    TypeCode: "2",
    ALIPCode: "2",
    Desc: "Canada",
    ISOCode: "CA"
  },
  {
    OLICode: "OLI_NATION_CAPEVERDEISLAND",
    TypeCode: "238",
    ALIPCode: "238",
    Desc: "Cape Verde",
    ISOCode: "CV"
  },
  {
    OLICode: "OLI_NATION_CAYMANIS",
    TypeCode: "345",
    ALIPCode: "345",
    Desc: "Cayman Islands",
    ISOCode: "KY"
  },
  {
    OLICode: "OLI_NATION_CENTRALAFRICANREP",
    TypeCode: "236",
    ALIPCode: "236",
    Desc: "Central African Rep.",
    ISOCode: "CF"
  },
  {
    OLICode: "OLI_NATION_CHAD",
    TypeCode: "235",
    ALIPCode: "235",
    Desc: "Chad",
    ISOCode: "TD"
  },
  {
    OLICode: "OLI_NATION_CHILE",
    TypeCode: "56",
    ALIPCode: "56",
    Desc: "Chile",
    ISOCode: "CL"
  },
  {
    OLICode: "OLI_NATION_CHINA",
    TypeCode: "86",
    ALIPCode: "86",
    Desc: "China",
    ISOCode: "CN"
  },
  {
    OLICode: "OLI_NATION_CHRISTMASISLANDS",
    TypeCode: "1024",
    ALIPCode: "5016",
    Desc: "Christmas Island",
    ISOCode: "CX"
  },
  {
    OLICode: "OLI_NATION_COCOS",
    TypeCode: "1007",
    ALIPCode: "172",
    Desc: "Cocos island",
    ISOCode: "CC"
  },
  {
    OLICode: "OLI_NATION_COLUMBIA",
    TypeCode: "57",
    ALIPCode: "57",
    Desc: "Colombia",
    ISOCode: "CO"
  },
  {
    OLICode: "OLI_NATION_COMOROS",
    TypeCode: "269",
    ALIPCode: "269",
    Desc: "Comoros",
    ISOCode: "KM"
  },
  {
    OLICode: "OLI_NATION_CONGO",
    TypeCode: "1027",
    ALIPCode: "5006",
    Desc: "Congo",
    ISOCode: "CG"
  },
  {
    OLICode: "OLI_NATION_CONGODEMREP",
    TypeCode: "271",
    ALIPCode: "243",
    Desc: "Congo Dem. Rep.",
    ISOCode: "CD"
  },
  {
    OLICode: "OLI_NATION_COOKISLANDS",
    TypeCode: "682",
    ALIPCode: "682",
    Desc: "Cook Islands",
    ISOCode: "CK"
  },
  {
    OLICode: "OLI_NATION_COSTARICA",
    TypeCode: "506",
    ALIPCode: "506",
    Desc: "Costa Rica",
    ISOCode: "CR"
  },
  {
    OLICode: "OLI_NATION_COTEDIVORIE",
    TypeCode: "1003",
    ALIPCode: "225",
    Desc: "Cote dâ€™Ivoire",
    ISOCode: "CI"
  },
  {
    OLICode: "OLI_NATION_CROATIA",
    TypeCode: "385",
    ALIPCode: "5007",
    Desc: "Croatia",
    ISOCode: "HR"
  },
  {
    OLICode: "OLI_NATION_CUBA",
    TypeCode: "53",
    ALIPCode: "53",
    Desc: "Cuba",
    ISOCode: "CU"
  },
  {
    OLICode: "OLI_NATION_CYPRUS",
    TypeCode: "357",
    ALIPCode: "357",
    Desc: "Cyprus",
    ISOCode: "CY"
  },
  {
    OLICode: "OLI_NATION_CZECHREPUBLIC",
    TypeCode: "420",
    ALIPCode: "420",
    Desc: "Czech Republic",
    ISOCode: "CZ"
  },
  {
    OLICode: "OLI_NATION_DENMARK",
    TypeCode: "45",
    ALIPCode: "45",
    Desc: "Denmark",
    ISOCode: "DK"
  },
  {
    OLICode: "OLI_NATION_DJIBOUTI",
    TypeCode: "253",
    ALIPCode: "253",
    Desc: "Djibouti",
    ISOCode: "DJ"
  },
  {
    OLICode: "OLI_NATION_DOMINICA",
    TypeCode: "767",
    ALIPCode: "767",
    Desc: "Dominica",
    ISOCode: "DM"
  },
  {
    OLICode: "OLI_NATION_DOMINICANREPUBLIC",
    TypeCode: "809",
    ALIPCode: "809",
    Desc: "Dominican Republic",
    ISOCode: "DO"
  },
  {
    OLICode: "OLI_NATION_ECUADOR",
    TypeCode: "593",
    ALIPCode: "593",
    Desc: "Ecuador",
    ISOCode: "EC"
  },
  {
    OLICode: "OLI_NATION_EGYPT",
    TypeCode: "20",
    ALIPCode: "20",
    Desc: "Egypt",
    ISOCode: "EG"
  },
  {
    OLICode: "OLI_NATION_ELSALVADOR",
    TypeCode: "503",
    ALIPCode: "503",
    Desc: "El Salvador",
    ISOCode: "SV"
  },
  {
    OLICode: "OLI_NATION_EQUATORIALGUINEA",
    TypeCode: "240",
    ALIPCode: "240",
    Desc: "Equatorial Guinea",
    ISOCode: "GQ"
  },
  {
    OLICode: "OLI_NATION_ERITREA",
    TypeCode: "1004",
    ALIPCode: "291",
    Desc: "Eritrea",
    ISOCode: "ER"
  },
  {
    OLICode: "OLI_NATION_ESTONIA",
    TypeCode: "372",
    ALIPCode: "372",
    Desc: "Estonia",
    ISOCode: "EE"
  },
  {
    OLICode: "OLI_NATION_ETHIOPIA",
    TypeCode: "251",
    ALIPCode: "251",
    Desc: "Ethiopia",
    ISOCode: "ET"
  },
  {
    OLICode: "OLI_NATION_FALKLANDISLANDS",
    TypeCode: "500",
    ALIPCode: "500",
    Desc: "Falkland Islands",
    ISOCode: "FK"
  },
  {
    OLICode: "OLI_NATION_FAEROEISLANDS",
    TypeCode: "298",
    ALIPCode: "298",
    Desc: "Faroe Islands",
    ISOCode: "FO"
  },
  {
    OLICode: "OLI_NATION_FIJI",
    TypeCode: "679",
    ALIPCode: "679",
    Desc: "Fiji",
    ISOCode: "FJ"
  },
  {
    OLICode: "OLI_NATION_FINLAND",
    TypeCode: "358",
    ALIPCode: "358",
    Desc: "Finland",
    ISOCode: "FI"
  },
  {
    OLICode: "OLI_NATION_FRANCE",
    TypeCode: "33",
    ALIPCode: "33",
    Desc: "France",
    ISOCode: "FR"
  },
  {
    OLICode: "OLI_NATION_FRENCHGUIANA",
    TypeCode: "594",
    ALIPCode: "178",
    Desc: "French Guiana",
    ISOCode: "GF"
  },
  {
    OLICode: "OLI_NATION_FRENCHPOLYNESIA",
    TypeCode: "689",
    ALIPCode: "689",
    Desc: "French Polynesia",
    ISOCode: "PF"
  },
  {
    OLICode: "OLI_NATION_FRENCHSOUTHERNTERRITIOIES",
    TypeCode: "1015",
    ALIPCode: "180",
    Desc: "French Southern Territories",
    ISOCode: "TF"
  },
  {
    OLICode: "OLI_NATION_GABON",
    TypeCode: "241",
    ALIPCode: "241",
    Desc: "Gabon",
    ISOCode: "GA"
  },
  {
    OLICode: "OLI_NATION_GAMBIA",
    TypeCode: "220",
    ALIPCode: "220",
    Desc: "Gambia",
    ISOCode: "GM"
  },
  {
    OLICode: "OLI_NATION_GEORGIA",
    TypeCode: "995",
    ALIPCode: "995",
    Desc: "Georgia",
    ISOCode: "GE"
  },
  {
    OLICode: "OLI_NATION_GERMANY",
    TypeCode: "49",
    ALIPCode: "49",
    Desc: "Germany",
    ISOCode: "DE"
  },
  {
    OLICode: "OLI_NATION_GHANA",
    TypeCode: "233",
    ALIPCode: "233",
    Desc: "Ghana",
    ISOCode: "GH"
  },
  {
    OLICode: "OLI_NATION_GIBRALTAR",
    TypeCode: "350",
    ALIPCode: "350",
    Desc: "Gibraltar",
    ISOCode: "GI"
  },
  {
    OLICode: "OLI_NATION_GREECE",
    TypeCode: "30",
    ALIPCode: "30",
    Desc: "Greece",
    ISOCode: "GR"
  },
  {
    OLICode: "OLI_NATION_GREENLAND",
    TypeCode: "299",
    ALIPCode: "299",
    Desc: "Greenland",
    ISOCode: "GL"
  },
  {
    OLICode: "OLI_NATION_CRENADA",
    TypeCode: "473",
    ALIPCode: "473",
    Desc: "Grenada",
    ISOCode: "GD"
  },
  {
    OLICode: "OLI_NATION_GUADALOUPE",
    TypeCode: "590",
    ALIPCode: "590",
    Desc: "Guadeloupe",
    ISOCode: "GP"
  },
  {
    OLICode: "OLI_NATION_GUAM",
    TypeCode: "671",
    ALIPCode: "671",
    Desc: "Guam",
    ISOCode: "GU"
  },
  {
    OLICode: "OLI_NATION_GUATEMALA",
    TypeCode: "502",
    ALIPCode: "502",
    Desc: "Guatemala",
    ISOCode: "GT"
  },
  {
    OLICode: "OLI_NATION_GUERNSEY",
    TypeCode: "360",
    ALIPCode: "275",
    Desc: "Guernsey",
    ISOCode: "GG"
  },
  {
    OLICode: "OLI_NATION_GUINEA",
    TypeCode: "224",
    ALIPCode: "224",
    Desc: "Guinea",
    ISOCode: "GN"
  },
  {
    OLICode: "OLI_NATION_GUINEABISSAU",
    TypeCode: "270",
    ALIPCode: "245",
    Desc: "Guinea Bissau",
    ISOCode: "GW"
  },
  {
    OLICode: "OLI_NATION_GUYANA",
    TypeCode: "592",
    ALIPCode: "592",
    Desc: "Guyana",
    ISOCode: "GY"
  },
  {
    OLICode: "OLI_NATION_HAITI",
    TypeCode: "509",
    ALIPCode: "509",
    Desc: "Haiti",
    ISOCode: "HT"
  },
  {
    OLICode: "OLI_NATION_HEARDISLISLAND",
    TypeCode: "1016",
    ALIPCode: "188",
    Desc: "Heard Island and McDonald Islands",
    ISOCode: "HM"
  },
  {
    OLICode: "OLI_NATION_HOLYSEE",
    TypeCode: "1029",
    ALIPCode: "5017",
    Desc: "Holy See (Vatican City State)",
    ISOCode: "VA"
  },
  {
    OLICode: "OLI_NATION_HONDURAS",
    TypeCode: "504",
    ALIPCode: "504",
    Desc: "Honduras",
    ISOCode: "HN"
  },
  {
    OLICode: "OLI_NATION_HONGKONG",
    TypeCode: "852",
    ALIPCode: "852",
    Desc: "Hong Kong",
    ISOCode: "HK"
  },
  {
    OLICode: "OLI_NATION_HUNGARY",
    TypeCode: "36",
    ALIPCode: "36",
    Desc: "Hungary",
    ISOCode: "HU"
  },
  {
    OLICode: "OLI_NATION_ICELAND",
    TypeCode: "354",
    ALIPCode: "354",
    Desc: "Iceland",
    ISOCode: "IS"
  },
  {
    OLICode: "OLI_NATION_INDIA",
    TypeCode: "91",
    ALIPCode: "91",
    Desc: "India",
    ISOCode: "IN"
  },
  {
    OLICode: "OLI_NATION_INDONESIA",
    TypeCode: "62",
    ALIPCode: "62",
    Desc: "Indonesia",
    ISOCode: "ID"
  },
  {
    OLICode: "OLI_NATION_IRAN",
    TypeCode: "98",
    ALIPCode: "98",
    Desc: "Iran",
    ISOCode: "IR"
  },
  {
    OLICode: "OLI_NATION_IRAQ",
    TypeCode: "964",
    ALIPCode: "964",
    Desc: "Iraq",
    ISOCode: "IQ"
  },
  {
    OLICode: "OLI_NATION_IRELAND",
    TypeCode: "2147483647",
    ALIPCode: "5009",
    Desc: "Northern Ireland",
    ISOCode: []
  },
  {
    OLICode: "OLI_NATION_IRELAND",
    TypeCode: "353",
    ALIPCode: "353",
    Desc: "Ireland",
    ISOCode: "IE"
  },
  {
    OLICode: "OLI_NATION_ISLEOFMAN",
    TypeCode: "1035",
    ALIPCode: "5024",
    Desc: "Isle of Man",
    ISOCode: "IM"
  },
  {
    OLICode: "OLI_NATION_ISRAEL",
    TypeCode: "972",
    ALIPCode: "972",
    Desc: "Israel",
    ISOCode: "IL"
  },
  {
    OLICode: "OLI_NATION_ITALY",
    TypeCode: "39",
    ALIPCode: "39",
    Desc: "Italy",
    ISOCode: "IT"
  },
  {
    OLICode: "OLI_NATION_JAMAICA",
    TypeCode: "876",
    ALIPCode: "876",
    Desc: "Jamaica",
    ISOCode: "JM"
  },
  {
    OLICode: "OLI_NATION_JAPAN",
    TypeCode: "81",
    ALIPCode: "81",
    Desc: "Japan",
    ISOCode: "JP"
  },
  {
    OLICode: "OLI_NATION_JERSEY",
    TypeCode: "1034",
    ALIPCode: "278",
    Desc: "Jersey",
    ISOCode: "JE"
  },
  {
    OLICode: "OLI_NATION_JORDAN",
    TypeCode: "962",
    ALIPCode: "962",
    Desc: "Jordan",
    ISOCode: "JO"
  },
  {
    OLICode: "OLI_NATION_KAZAKHSTAN",
    TypeCode: "1005",
    ALIPCode: "5020",
    Desc: "Kazakhstan",
    ISOCode: "KZ"
  },
  {
    OLICode: "OLI_NATION_KENYA",
    TypeCode: "254",
    ALIPCode: "254",
    Desc: "Kenya",
    ISOCode: "KE"
  },
  {
    OLICode: "OLI_NATION_KIRIBATI",
    TypeCode: "686",
    ALIPCode: "281",
    Desc: "Kiribati",
    ISOCode: "KI"
  },
  {
    OLICode: "OLI_NATION_KOREADEMPEOPLEREP",
    TypeCode: "952",
    ALIPCode: "69",
    Desc: "Korea, Democratic Peoples Republic of",
    ISOCode: "KP"
  },
  {
    OLICode: "OLI_NATION_KOREAREPUBLIC",
    TypeCode: "951",
    ALIPCode: "70",
    Desc: "Korea, Republic of",
    ISOCode: "KR"
  },
  {
    OLICode: "OLI_NATION_KOSOVO",
    TypeCode: "390",
    ALIPCode: "381",
    Desc: "Kosovo",
    ISOCode: "XK"
  },
  {
    OLICode: "OLI_NATION_KUWAIT",
    TypeCode: "965",
    ALIPCode: "965",
    Desc: "Kuwait",
    ISOCode: "KW"
  },
  {
    OLICode: "OLI_NATION_KYRGYZSTAN",
    TypeCode: "1006",
    ALIPCode: "996",
    Desc: "Kyrgyzstan",
    ISOCode: "KG"
  },
  {
    OLICode: "OLI_NATION_LAOS",
    TypeCode: "856",
    ALIPCode: "856",
    Desc: "Laos",
    ISOCode: "LA"
  },
  {
    OLICode: "OLI_NATION_LATVIA",
    TypeCode: "371",
    ALIPCode: "371",
    Desc: "Latvia",
    ISOCode: "LV"
  },
  {
    OLICode: "OLI_NATION_LEBANON",
    TypeCode: "961",
    ALIPCode: "961",
    Desc: "Lebanon",
    ISOCode: "LB"
  },
  {
    OLICode: "OLI_NATION_LESOTHO",
    TypeCode: "266",
    ALIPCode: "266",
    Desc: "Lesotho",
    ISOCode: "LS"
  },
  {
    OLICode: "OLI_NATION_LIBERIA",
    TypeCode: "231",
    ALIPCode: "231",
    Desc: "Liberia",
    ISOCode: "LR"
  },
  {
    OLICode: "OLI_NATION_LIBYA",
    TypeCode: "218",
    ALIPCode: "218",
    Desc: "Libya",
    ISOCode: "LY"
  },
  {
    OLICode: "OLI_NATION_LIECHTENSTEIN",
    TypeCode: "423",
    ALIPCode: "423",
    Desc: "Liechtenstein",
    ISOCode: "LI"
  },
  {
    OLICode: "OLI_NATION_LITHUANIA",
    TypeCode: "370",
    ALIPCode: "370",
    Desc: "Lithuania",
    ISOCode: "LT"
  },
  {
    OLICode: "OLI_NATION_LUXEMBOURG",
    TypeCode: "352",
    ALIPCode: "352",
    Desc: "Luxembourg",
    ISOCode: "LU"
  },
  {
    OLICode: "OLI_NATION_MACAO",
    TypeCode: "853",
    ALIPCode: "853",
    Desc: "Macao",
    ISOCode: "MO"
  },
  {
    OLICode: "OLI_NATION_MACEDONIA",
    TypeCode: "389",
    ALIPCode: "389",
    Desc: "Macedonia (FYROM)",
    ISOCode: "MK"
  },
  {
    OLICode: "OLI_NATION_MADAGASCAR",
    TypeCode: "261",
    ALIPCode: "261",
    Desc: "Madagascar",
    ISOCode: "MG"
  },
  {
    OLICode: "OLI_NATION_MALAWI",
    TypeCode: "265",
    ALIPCode: "265",
    Desc: "Malawi",
    ISOCode: "MW"
  },
  {
    OLICode: "OLI_NATION_MALAYSIA",
    TypeCode: "60",
    ALIPCode: "60",
    Desc: "Malaysia",
    ISOCode: "MY"
  },
  {
    OLICode: "OLI_NATION_MALDIVES",
    TypeCode: "1023",
    ALIPCode: "960",
    Desc: "Maldives",
    ISOCode: "MV"
  },
  {
    OLICode: "OLI_NATION_MALI",
    TypeCode: "223",
    ALIPCode: "223",
    Desc: "Mali",
    ISOCode: "ML"
  },
  {
    OLICode: "OLI_NATION_MALTA",
    TypeCode: "356",
    ALIPCode: "356",
    Desc: "Malta",
    ISOCode: "MT"
  },
  {
    OLICode: "OLI_NATION_MARSHALLISLANDS",
    TypeCode: "694",
    ALIPCode: "692",
    Desc: "Marshall Islands",
    ISOCode: "MH"
  },
  {
    OLICode: "OLI_NATION_MARTINIQUE",
    TypeCode: "596",
    ALIPCode: "198",
    Desc: "Martinique",
    ISOCode: "MQ"
  },
  {
    OLICode: "OLI_NATION_MAURITANIA",
    TypeCode: "222",
    ALIPCode: "222",
    Desc: "Mauritania",
    ISOCode: "MR"
  },
  {
    OLICode: "OLI_NATION_MAURITIUS",
    TypeCode: "230",
    ALIPCode: "230",
    Desc: "Mauritius",
    ISOCode: "MU"
  },
  {
    OLICode: "OLI_NATION_MEXICO",
    TypeCode: "52",
    ALIPCode: "52",
    Desc: "Mexico",
    ISOCode: "MX"
  },
  {
    OLICode: "OLI_NATION_MICRONESIA",
    TypeCode: "695",
    ALIPCode: "691",
    Desc: "Micronesia, Federated States of",
    ISOCode: "FM"
  },
  {
    OLICode: "OLI_NATION_MOLDOVA",
    TypeCode: "373",
    ALIPCode: "373",
    Desc: "Moldova",
    ISOCode: "MD"
  },
  {
    OLICode: "OLI_NATION_MONACO",
    TypeCode: "1028",
    ALIPCode: "377",
    Desc: "Monaco",
    ISOCode: "MC"
  },
  {
    OLICode: "OLI_NATION_MONGOLIA",
    TypeCode: "1008",
    ALIPCode: "976",
    Desc: "Mongolia",
    ISOCode: "MN"
  },
  {
    OLICode: "OLI_NATION_MONTENEGRO",
    TypeCode: "1037",
    ALIPCode: "382",
    Desc: "Montenegro",
    ISOCode: "ME"
  },
  {
    OLICode: "OLI_NATION_MONTSERRAT",
    TypeCode: "664",
    ALIPCode: "664",
    Desc: "Montserrat",
    ISOCode: "MS"
  },
  {
    OLICode: "OLI_NATION_MOROCCO",
    TypeCode: "212",
    ALIPCode: "212",
    Desc: "Morocco",
    ISOCode: "MA"
  },
  {
    OLICode: "OLI_NATION_MOZAMBIQUE",
    TypeCode: "258",
    ALIPCode: "258",
    Desc: "Mozambique",
    ISOCode: "MZ"
  },
  {
    OLICode: "OLI_NATION_MYANMAR",
    TypeCode: "950",
    ALIPCode: "95",
    Desc: "Myanmar",
    ISOCode: "MM"
  },
  {
    OLICode: "OLI_NATION_NAMIBIA",
    TypeCode: "264",
    ALIPCode: "264",
    Desc: "Namibia",
    ISOCode: "NA"
  },
  {
    OLICode: "OLI_NATION_NAURU",
    TypeCode: "674",
    ALIPCode: "674",
    Desc: "Nauru",
    ISOCode: "NR"
  },
  {
    OLICode: "OLI_NATION_NEPAL",
    TypeCode: "977",
    ALIPCode: "977",
    Desc: "Nepal",
    ISOCode: "NP"
  },
  {
    OLICode: "OLI_NATION_NETHERLANDS",
    TypeCode: "31",
    ALIPCode: "31",
    Desc: "Netherlands",
    ISOCode: "NL"
  },
  {
    OLICode: "OLI_NATION_NETHERLANDSANTILLES",
    TypeCode: "599",
    ALIPCode: "599",
    Desc: "Netherlands Antilles",
    ISOCode: "AN"
  },
  {
    OLICode: "OLI_NATION_NEWCALEDONIA",
    TypeCode: "687",
    ALIPCode: "687",
    Desc: "New Caledonia",
    ISOCode: "NC"
  },
  {
    OLICode: "OLI_NATION_NEWZEALAND",
    TypeCode: "64",
    ALIPCode: "64",
    Desc: "New Zealand",
    ISOCode: "NZ"
  },
  {
    OLICode: "OLI_NATION_NICARAGUA",
    TypeCode: "505",
    ALIPCode: "505",
    Desc: "Nicaragua",
    ISOCode: "NI"
  },
  {
    OLICode: "OLI_NATION_NIGER",
    TypeCode: "227",
    ALIPCode: "227",
    Desc: "Niger",
    ISOCode: "NE"
  },
  {
    OLICode: "OLI_NATION_NIGERIA",
    TypeCode: "234",
    ALIPCode: "234",
    Desc: "Nigeria",
    ISOCode: "NG"
  },
  {
    OLICode: "OLI_NATION_NIUE",
    TypeCode: "683",
    ALIPCode: "683",
    Desc: "Niue",
    ISOCode: "NU"
  },
  {
    OLICode: "OLI_NATION_NORFOLKISLAND",
    TypeCode: "1025",
    ALIPCode: "5018",
    Desc: "Norfolk Island",
    ISOCode: "NF"
  },
  {
    OLICode: "OLI_NATION_NORTHMARIANAISLANDS",
    TypeCode: "691",
    ALIPCode: "1670",
    Desc: "Northern Mariana Islands",
    ISOCode: "MP"
  },
  {
    OLICode: "OLI_NATION_NORWAY",
    TypeCode: "47",
    ALIPCode: "47",
    Desc: "Norway",
    ISOCode: "NO"
  },
  {
    OLICode: "OLI_NATION_OMAN",
    TypeCode: "968",
    ALIPCode: "968",
    Desc: "Oman",
    ISOCode: "OM"
  },
  {
    OLICode: "OLI_NATION_PAKISTAN",
    TypeCode: "92",
    ALIPCode: "92",
    Desc: "Pakistan",
    ISOCode: "PK"
  },
  {
    OLICode: "OLI_NATION_PALAU",
    TypeCode: "693",
    ALIPCode: "680",
    Desc: "Palau",
    ISOCode: "PW"
  },
  {
    OLICode: "OLI_NATION_PANAMA",
    TypeCode: "1002",
    ALIPCode: "507",
    Desc: "Panama",
    ISOCode: "PA"
  },
  {
    OLICode: "OLI_NATION_PAPUANEWGUINEA",
    TypeCode: "675",
    ALIPCode: "675",
    Desc: "Papua New Guinea",
    ISOCode: "PG"
  },
  {
    OLICode: "OLI_NATION_PARAGUAY",
    TypeCode: "595",
    ALIPCode: "595",
    Desc: "Paraguay",
    ISOCode: "PY"
  },
  {
    OLICode: "OLI_NATION_PERU",
    TypeCode: "51",
    ALIPCode: "51",
    Desc: "Peru",
    ISOCode: "PE"
  },
  {
    OLICode: "OLI_NATION_PHILIPPINES",
    TypeCode: "63",
    ALIPCode: "63",
    Desc: "Philippines",
    ISOCode: "PH"
  },
  {
    OLICode: "OLI_NATION_PITCARINISLANDS",
    TypeCode: "1018",
    ALIPCode: "870",
    Desc: "Pitcairn",
    ISOCode: "PN"
  },
  {
    OLICode: "OLI_NATION_POLAND",
    TypeCode: "48",
    ALIPCode: "48",
    Desc: "Poland",
    ISOCode: "PL"
  },
  {
    OLICode: "OLI_NATION_PORTUGAL",
    TypeCode: "351",
    ALIPCode: "351",
    Desc: "Portugal",
    ISOCode: "PT"
  },
  {
    OLICode: "OLI_NATION_PUERTORICO",
    TypeCode: "510",
    ALIPCode: "5025",
    Desc: "Puerto Rico",
    ISOCode: "PR"
  },
  {
    OLICode: "OLI_NATION_QATAR",
    TypeCode: "974",
    ALIPCode: "974",
    Desc: "Qatar",
    ISOCode: "QA"
  },
  {
    OLICode: "OLI_NATION_REUNIONISLAND",
    TypeCode: "262",
    ALIPCode: "5019",
    Desc: "Reunion",
    ISOCode: "RE"
  },
  {
    OLICode: "OLI_NATION_ROMANIA",
    TypeCode: "40",
    ALIPCode: "40",
    Desc: "Romania",
    ISOCode: "RO"
  },
  {
    OLICode: "OLI_NATION_RUSSIA",
    TypeCode: "7",
    ALIPCode: "7",
    Desc: "Russia",
    ISOCode: "RU"
  },
  {
    OLICode: "OLI_NATION_RWANDA",
    TypeCode: "250",
    ALIPCode: "250",
    Desc: "Rwanda",
    ISOCode: "RW"
  },
  {
    OLICode: "OLI_NATION_SAMOA",
    TypeCode: "1013",
    ALIPCode: "685",
    Desc: "Samoa",
    ISOCode: "WS"
  },
  {
    OLICode: "OLI_NATION_SANMARINO",
    TypeCode: "378",
    ALIPCode: "378",
    Desc: "San Marino",
    ISOCode: "SM"
  },
  {
    OLICode: "OLI_NATION_SAOTOME",
    TypeCode: "239",
    ALIPCode: "239",
    Desc: "Sao Tome And Principe",
    ISOCode: "ST"
  },
  {
    OLICode: "OLI_NATION_SAUDIARABIA",
    TypeCode: "966",
    ALIPCode: "966",
    Desc: "Saudi Arabia",
    ISOCode: "SA"
  },
  {
    OLICode: "OLI_NATION_SENEGAL",
    TypeCode: "221",
    ALIPCode: "221",
    Desc: "Senegal",
    ISOCode: "SN"
  },
  {
    OLICode: "OLI_NATION_SERBIA",
    TypeCode: "1036",
    ALIPCode: "5021",
    Desc: "Serbia",
    ISOCode: "RS"
  },
  {
    OLICode: "OLI_NATION_SEYCHELLES",
    TypeCode: "1010",
    ALIPCode: "248",
    Desc: "Seychelles And Dependencies",
    ISOCode: "SC"
  },
  {
    OLICode: "OLI_NATION_SIERRALEONE",
    TypeCode: "232",
    ALIPCode: "232",
    Desc: "Sierra Leone",
    ISOCode: "SL"
  },
  {
    OLICode: "OLI_NATION_SINGAPORE",
    TypeCode: "65",
    ALIPCode: "65",
    Desc: "Singapore",
    ISOCode: "SG"
  },
  {
    OLICode: "OLI_NATION_SLOVAKIA",
    TypeCode: "421",
    ALIPCode: "5022",
    Desc: "Slovakia",
    ISOCode: "SK"
  },
  {
    OLICode: "OLI_NATION_SLOVENIA",
    TypeCode: "386",
    ALIPCode: "386",
    Desc: "Slovenia",
    ISOCode: "SI"
  },
  {
    OLICode: "OLI_NATION_SOLOMONISLANDS",
    TypeCode: "677",
    ALIPCode: "677",
    Desc: "Solomon Islands",
    ISOCode: "SB"
  },
  {
    OLICode: "OLI_NATION_SOMALIA",
    TypeCode: "252",
    ALIPCode: "252",
    Desc: "Somalia",
    ISOCode: "SO"
  },
  {
    OLICode: "OLI_NATION_SOUTHAFRICA",
    TypeCode: "27",
    ALIPCode: "27",
    Desc: "South Africa",
    ISOCode: "ZA"
  },
  {
    OLICode: "OLI_NATION_SOUTHGEORGIASANDWICH",
    TypeCode: "512",
    ALIPCode: "5010",
    Desc: "South Georgia and the South Sandwich Islands",
    ISOCode: "GS"
  },
  {
    OLICode: "OLI_NATION_SAINTBARTHELEMY",
    TypeCode: "652",
    ALIPCode: "5011",
    Desc: "Saint Barthelemy",
    ISOCode: "BL"
  },
  {
    OLICode: "OLI_NATION_SOUTH_SUDAN",
    TypeCode: "728",
    ALIPCode: "249",
    Desc: "South Sudan",
    ISOCode: "SS"
  },
  {
    OLICode: "OLI_NATION_SPAIN",
    TypeCode: "34",
    ALIPCode: "34",
    Desc: "Spain",
    ISOCode: "ES"
  },
  {
    OLICode: "OLI_NATION_SRILANKA",
    TypeCode: "94",
    ALIPCode: "94",
    Desc: "Sri Lanka",
    ISOCode: "LK"
  },
  {
    OLICode: "OLI_NATION_SAINTMARTINFRENCH",
    TypeCode: "663",
    ALIPCode: "5013",
    Desc: "Saint Martin (French Part)",
    ISOCode: "MF"
  },
  {
    OLICode: "OLI_NATION_STPIERRE",
    TypeCode: "508",
    ALIPCode: "5014",
    Desc: "St Pierre And Miquelon",
    ISOCode: "PM"
  },
  {
    OLICode: "OLI_NATION_STHELENA",
    TypeCode: "290",
    ALIPCode: "5012",
    Desc: "Saint Helena, Ascension and Tristan da Cunha",
    ISOCode: "SH"
  },
  {
    OLICode: "OLI_NATION_STKITTSNEVIS",
    TypeCode: "869",
    ALIPCode: "869",
    Desc: "St. Kitts And Nevis",
    ISOCode: "KN"
  },
  {
    OLICode: "OLI_NATION_STLUCIA",
    TypeCode: "758",
    ALIPCode: "758",
    Desc: "St. Lucia",
    ISOCode: "LC"
  },
  {
    OLICode: "OLI_NATION_STVINCENT",
    TypeCode: "784",
    ALIPCode: "784",
    Desc: "St. Vincent",
    ISOCode: "VC"
  },
  {
    OLICode: "OLI_NATION_SUDAN",
    TypeCode: "249",
    ALIPCode: "249",
    Desc: "Sudan",
    ISOCode: "SD"
  },
  {
    OLICode: "OLI_NATION_SURINAME",
    TypeCode: "597",
    ALIPCode: "597",
    Desc: "Suriname",
    ISOCode: "SR"
  },
  {
    OLICode: "OLI_NATION_SVALBARDISLAND",
    TypeCode: "1019",
    ALIPCode: "194",
    Desc: "Svalbard and Jan Mayen",
    ISOCode: "SJ"
  },
  {
    OLICode: "OLI_NATION_SWAZILAND",
    TypeCode: "1031",
    ALIPCode: "5023",
    Desc: "Swaziland",
    ISOCode: "SZ"
  },
  {
    OLICode: "OLI_NATION_SWEDEN",
    TypeCode: "46",
    ALIPCode: "46",
    Desc: "Sweden",
    ISOCode: "SE"
  },
  {
    OLICode: "OLI_NATION_SWITZERLAND",
    TypeCode: "41",
    ALIPCode: "41",
    Desc: "Switzerland",
    ISOCode: "CH"
  },
  {
    OLICode: "OLI_NATION_SYRIA",
    TypeCode: "963",
    ALIPCode: "963",
    Desc: "Syria",
    ISOCode: "SY"
  },
  {
    OLICode: "OLI_NATION_TAIWAN",
    TypeCode: "886",
    ALIPCode: "886",
    Desc: "Taiwan",
    ISOCode: "TW"
  },
  {
    OLICode: "OLI_NATION_TAJIKISTAN",
    TypeCode: "992",
    ALIPCode: "992",
    Desc: "Tajikistan",
    ISOCode: "TJ"
  },
  {
    OLICode: "OLI_NATION_TANZANIA",
    TypeCode: "255",
    ALIPCode: "255",
    Desc: "Tanzania",
    ISOCode: "TZ"
  },
  {
    OLICode: "OLI_NATION_THAILAND",
    TypeCode: "66",
    ALIPCode: "66",
    Desc: "Thailand",
    ISOCode: "TH"
  },
  {
    OLICode: "OLI_NATION_EASTTIMOR",
    TypeCode: "1014",
    ALIPCode: "670",
    Desc: "Timor-Leste",
    ISOCode: "TL"
  },
  {
    OLICode: "OLI_NATION_TOGO",
    TypeCode: "228",
    ALIPCode: "228",
    Desc: "Togo",
    ISOCode: "TG"
  },
  {
    OLICode: "OLI_NATION_TOKELAU",
    TypeCode: "1020",
    ALIPCode: "690",
    Desc: "Tokelau",
    ISOCode: "TK"
  },
  {
    OLICode: "OLI_NATION_TONGAISLANDS",
    TypeCode: "676",
    ALIPCode: "676",
    Desc: "Tonga",
    ISOCode: "TO"
  },
  {
    OLICode: "OLI_NATION_TRINIDADTOBAGO",
    TypeCode: "868",
    ALIPCode: "868",
    Desc: "Trinidad And Tobago",
    ISOCode: "TT"
  },
  {
    OLICode: "OLI_NATION_TUNISIA",
    TypeCode: "216",
    ALIPCode: "216",
    Desc: "Tunisia",
    ISOCode: "TN"
  },
  {
    OLICode: "OLI_NATION_TURKEY",
    TypeCode: "90",
    ALIPCode: "90",
    Desc: "Turkey",
    ISOCode: "TR"
  },
  {
    OLICode: "OLI_NATION_TURKMENISTAN",
    TypeCode: "993",
    ALIPCode: "993",
    Desc: "Turkmenistan",
    ISOCode: "TM"
  },
  {
    OLICode: "OLI_NATION_TURKSCAICOSIS",
    TypeCode: "649",
    ALIPCode: "649",
    Desc: "Turks And Caicos Islands",
    ISOCode: "TC"
  },
  {
    OLICode: "OLI_NATION_TUVALU",
    TypeCode: "688",
    ALIPCode: "688",
    Desc: "Tuvalu",
    ISOCode: "TV"
  },
  {
    OLICode: "OLI_NATION_UGANDA",
    TypeCode: "256",
    ALIPCode: "256",
    Desc: "Uganda",
    ISOCode: "UG"
  },
  {
    OLICode: "OLI_NATION_UKRAINE",
    TypeCode: "380",
    ALIPCode: "380",
    Desc: "Ukraine",
    ISOCode: "UA"
  },
  {
    OLICode: "OLI_NATION_UNITEDARABEMIRATES",
    TypeCode: "971",
    ALIPCode: "971",
    Desc: "United Arab Emirates",
    ISOCode: "AE"
  },
  {
    OLICode: "OLI_NATION_UK",
    TypeCode: "44",
    ALIPCode: "44",
    Desc: "United Kingdom",
    ISOCode: "GB"
  },
  {
    OLICode: "OLI_NATION_USA",
    TypeCode: "1",
    ALIPCode: "1",
    Desc: "United States of America",
    ISOCode: "US"
  },
  {
    OLICode: "OLI_NATION_URUGUAY",
    TypeCode: "598",
    ALIPCode: "598",
    Desc: "Uruguay",
    ISOCode: "UY"
  },
  {
    OLICode: "OLI_NATION_VIRGINISLANDSUS",
    TypeCode: "511",
    ALIPCode: "1340",
    Desc: "US Virgin Islands",
    ISOCode: "VI"
  },
  {
    OLICode: "OLI_NATION_UZBEKISTAN",
    TypeCode: "998",
    ALIPCode: "998",
    Desc: "Uzbekistan",
    ISOCode: "UZ"
  },
  {
    OLICode: "OLI_NATION_VANUATU",
    TypeCode: "678",
    ALIPCode: "678",
    Desc: "Vanuatu",
    ISOCode: "VU"
  },
  {
    OLICode: "OLI_NATION_VENEZUELA",
    TypeCode: "58",
    ALIPCode: "58",
    Desc: "Venezuela",
    ISOCode: "VE"
  },
  {
    OLICode: "OLI_NATION_VIETNAM",
    TypeCode: "84",
    ALIPCode: "84",
    Desc: "Vietnam",
    ISOCode: "VN"
  },
  {
    OLICode: "OLI_NATION_BRITISHVIRGINIS",
    TypeCode: "284",
    ALIPCode: "1284",
    Desc: "Virgin Islands, British",
    ISOCode: "VG"
  },
  {
    OLICode: "OLI_NATION_WALLISISLANDS",
    TypeCode: "681",
    ALIPCode: "681",
    Desc: "Wallis And Futuna Islands",
    ISOCode: "WF"
  },
  {
    OLICode: "OLI_NATION_WESTERNSARAHA",
    TypeCode: "1022",
    ALIPCode: "5026",
    Desc: "Western Sahara",
    ISOCode: "EH"
  },
  {
    OLICode: "OLI_NATION_WESTERNSAMOA",
    TypeCode: "685",
    ALIPCode: "685",
    Desc: "Western Samoa"
  },
  {
    OLICode: "OLI_NATION_YEMEN",
    TypeCode: "967",
    ALIPCode: "967",
    Desc: "Yemen",
    ISOCode: "YE"
  },
  {
    OLICode: "OLI_NATION_ZAMBIA",
    TypeCode: "260",
    ALIPCode: "260",
    Desc: "Zambia",
    ISOCode: "ZM"
  },
  {
    OLICode: "OLI_NATION_ZIMBABWE",
    TypeCode: "263",
    ALIPCode: "263",
    Desc: "Zimbabwe",
    ISOCode: "ZW"
  }
];

export default countries;
