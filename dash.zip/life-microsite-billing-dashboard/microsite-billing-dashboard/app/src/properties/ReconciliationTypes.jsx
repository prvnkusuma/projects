const reconciliationTypes = [
  {
    value: "Bill",
    label: "Bill"
  },
  {
    value: "Remittance",
    label: "Remittance"
  }
];

export default reconciliationTypes;
