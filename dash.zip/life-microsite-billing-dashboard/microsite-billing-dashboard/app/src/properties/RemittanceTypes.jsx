const remittanceTypes = [
  {
    value: "Chargeback",
    label: "Charge Back"
  },
  {
    value: "Refund",
    label: "Refund"
  },
  {
    value: "Remittance",
    label: "Remittance"
  },
  {
    value: "Returns",
    label: "Returns"
  }
];

export default remittanceTypes;
