const statusTypes = [
  {
    value: "completed",
    label: "Completed"
  },
  {
    value: "inprogress",
    label: "In Progress"
  },
  {
    value: "failed",
    label: "Failed"
  }
];

export default statusTypes;
