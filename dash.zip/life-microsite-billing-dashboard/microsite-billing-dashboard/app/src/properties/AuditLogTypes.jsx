const auditLogTypes = [
  {
    accordType: "Bill",
    accordId: "1801",
    actions: [
      {
        value: "bill_reprocess_indv",
        label: "Reprocess"
      },
      {
        value: "bill_reprocess_bulk",
        label: "Bulk Reprocess"
      }
    ]
  },
  {
    accordType: "Remittance",
    accordId: "508",
    actions: [
      {
        value: "remittance_reprocess_indv",
        label: "Reprocess"
      },
      {
        value: "remittance_reprocess_bulk",
        label: "Bulk Reprocess"
      }
    ]
  },
  {
    accordType: "RCC Decline",
    accordId: "184",
    actions: [
      {
        value: "decline_reprocess_indv",
        label: "Reprocess"
      },
      {
        value: "decline_reprocess_bulk",
        label: "Bulk Reprocess"
      }
    ]
  },
  {
    accordType: "EFT Returns",
    accordId: "EFT Return",
    actions: [
      {
        value: "eft_return_reprocess_indv",
        label: "Reprocess"
      },
      {
        value: "eft_return_reprocess_bulk",
        label: "Bulk Reprocess"
      }
    ]
  },
  {
    accordType: "Invoice",
    accordId: "118",
    actions: [
      {
        value: "invoice_reprocess_indv",
        label: "Reprocess"
      },
      {
        value: "invoice_reprocess_bulk",
        label: "Bulk Reprocess"
      },
      {
        value: "invoice_reprint",
        label: "Reprint"
      },
      {
        value: "invoice_email_indv",
        label: "Email"
      }
    ]
  },
  {
    accordType: "Business Errors",
    accordId: "400",
    actions: [
      {
        value: "report_reprocess_indv",
        label: "Reprocess"
      },
      {
        value: "report_reprocess_bulk",
        label: "Bulk Reprocess"
      }
    ]
  },
  {
    accordType: "Policy Change",
    accordId: "1203",
    actions: [
      {
        value: "policy_reprocess_indv",
        label: "Reprocess"
      },
      {
        value: "policy_reprocess_bulk",
        label: "Bulk Reprocess"
      },
      {
        value: "policy_change_upload_indv",
        label: "Upload CSV"
      }
    ]
  },
  {
    accordType: "AWD",
    accordId: "AWD",
    actions: [
      {
        value: "awd_reprocess_indv",
        label: "Reprocess"
      },
      {
        value: "awd_reprocess_bulk",
        label: "Bulk Reprocess"
      }
    ]
  },
  {
    accordType: "Correspondence",
    accordId: "Correspondence",
    actions: [
      {
        value: "correspondence_reprocess_indv",
        label: "Reprocess"
      },
      {
        value: "correspondence_force_status_update",
        label: "Mark As Complete"
      },
      {
        value: "correspondence_reprocess_bulk",
        label: "Bulk Reprocess"
      },
      {
        value: "correspondence_email_indv",
        label: "Email"
      }
    ]
  },
  {
    accordType: "E-Bill",
    accordId: "EBill Indicator Change",
    actions: [
      {
        value: "ebill_indicator_change",
        label: "Indicator Change"
      }
    ]
  },
  {
    accordType: "Manual Bill",
    accordId: "Manual Bill",
    actions: [
      {
        value: "manual_bill",
        label: "Generate Bill"
      }
    ]
  },
  {
    accordType: "Phone Payment",
    accordId: "Phone Payment",
    actions: [
      {
        value: "phone_bill",
        label: "Create Payment"
      },
      {
        value: "draft_status_update",
        label: "Draft Status Update"
      },
      {
        value: "correspondence_update",
        label: "Correspondence Update"
      }
    ]
  },
  {
    accordType: "Admin Policy Data",
    accordId: "Admin",
    actions: [
      {
        value: "admin_data_src",
        label: "Save"
      }
    ]
  },
  {
    accordType: "Admin Error Data",
    accordId: "Error Code",
    actions: [
      {
        value: "error_code_update",
        label: "Update"
      },
      {
        value: "error_code_insert",
        label: "Insert"
      }
    ]
  }
];

export default auditLogTypes;
