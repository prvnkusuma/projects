export const types = [
  {
    value: "ALIP_RETURN",
    label: "ALIP Return"
  },
  {
    value: "AWD_ABCPRENOTE",
    label: "AWD ABC Prenote"
  },
  {
    value: "AWD_ABCRETURN",
    label: "AWD ABC Return"
  },
  {
    value: "AWD_ABCRETURN_SAP",
    label: "AWD ABC Return SAP"
  },
  {
    value: "MAN_ALIP_RETURN",
    label: "Manual ALIP Return"
  },
  {
    value: "SAP_RETURN",
    label: "SAP Return"
  }
];

export const eftTypes = [
  {
    value: "1",
    label: "1 - EFT Premium"
  },
  {
    value: "2",
    label: "2 - EFT Loan"
  },
  {
    value: "3",
    label: "3 - Draft at Issue"
  },
  {
    value: "4",
    label: "4 - Draft at Submit"
  },
  {
    value: "5",
    label: "5 - Phone Payments"
  }
];

export const paymentTypes = [
  {
    value: "Loan",
    label: "Loan"
  },
  {
    value: "Premium",
    label: "Premium"
  },
  {
    value: "Reinstatement",
    label: "Reinstatement"
  }
];
