const declineTypes = [
  {
    value: "RCCDecline",
    label: "RCCDecline"
  },
  {
    value: "RCCStart",
    label: "RCCStart"
  },
  {
    value: "RCCStop",
    label: "RCCStop"
  }
];

export default declineTypes;
