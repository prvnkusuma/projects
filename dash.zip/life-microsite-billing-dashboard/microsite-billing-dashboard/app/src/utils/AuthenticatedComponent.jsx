import React from "react";
import { withRouter } from "react-router";
import {
  getFromLocalStorage,
  setToLocalStorage
} from "utils/CommonFunctions.jsx";

function requireAuth(Component, origin) {
  class AuthenticatedComponent extends React.Component {
    constructor(props) {
      super(props);
    }

    componentDidMount() {
      this.checkAuth();
    }

    componentDidUpdate() {
      this.checkAuth();
    }

    checkAuth() {
      // When direct url is typed in the browser and not clicked on sidebar
      if (origin === undefined) {
        if (this.props.history.location.pathname !== "/login") {
          setToLocalStorage("userId", "false");
          this.props.history.replace("/login");
          return;
        }
      }
      // When the session expired and not on login screen
      if (
        this.props.history.location.pathname !== "/login" &&
        (getFromLocalStorage("userId") == "" ||
          getFromLocalStorage("userId") == null ||
          getFromLocalStorage("userId") === undefined)
      ) {
        setToLocalStorage("userId", "false");
        this.props.history.replace("/login");
        return;
      }
    }

    render() {
      return <Component {...this.props} />;
    }
  }

  return withRouter(AuthenticatedComponent);
}

export default requireAuth;
