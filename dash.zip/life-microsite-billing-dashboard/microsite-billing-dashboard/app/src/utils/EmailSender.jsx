import React, { Component } from "react";
import PropTypes from "prop-types";
import SimpleReactValidator from "simple-react-validator";

import Button from "@material-ui/core/Button";
import FormControl from "@material-ui/core/FormControl";
import GridItem from "components/Grid/GridItem.jsx";
import GridContainer from "components/Grid/GridContainer.jsx";
import Typography from "@material-ui/core/Typography";
import TextField from "@material-ui/core/TextField";
import Paper from "@material-ui/core/Paper";
import Attachment from "@material-ui/icons/Attachment";
import Snackbar from "components/Snackbar/Snackbar.jsx";
import InfoOutlined from "@material-ui/icons/InfoOutlined";
import WarningOutlined from "@material-ui/icons/WarningOutlined";
import Chip from "@material-ui/core/Chip";

import requireAuth from "utils/AuthenticatedComponent.jsx";
import {
  DialogTitle,
  DialogContent,
  DialogActions
} from "components/Dialog/CommonDialog.jsx";
import Overlay from "components/CustomWidgets/Overlay.jsx";
import {
  postData,
  validateEmailList,
  getFromLocalStorage
} from "utils/CommonFunctions.jsx";
import APIURIs from "properties/APIURIs.jsx";

const classes = theme => ({
  root: {
    ...theme.mixins.gutters(),
    paddingTop: theme.spacing.unit * 2,
    paddingBottom: theme.spacing.unit * 2
  },
  emailPreview: {
    ...theme.mixins.gutters(),
    paddingTop: theme.spacing.unit * 2,
    paddingBottom: theme.spacing.unit * 2,
    paddingLeft: 0,
    paddingRight: 0,
    color: "#FFFFFF",
    boxShadow: "none",
    borderRadius: ".25rem",
    minHeight: "70px",
    minWidth: "220px",
    border: 1,
    borderStyle: "solid"
  },
  formControl: {
    margin: theme.spacing.unit,
    minWidth: 120,
    display: "flex",
    wrap: "nowrap"
  },
  textField: {
    marginLeft: theme.spacing.unit,
    marginRight: theme.spacing.unit,
    width: 200,
    display: "flex",
    flexWrap: "wrap"
  },
  button: {
    margin: theme.spacing.unit
  },
  InputClasses: {
    fullWidth: true
  }
});

const defaultValues = {
  toEmail: "",
  successElt: false,
  errorElt: false,
  infoElt: false,
  successMessage: "",
  failureMessage: "",
  infoMessage: "",
  validationError: false,
  loading: false
};

function sendEmail(params, uri) {
  /*
  billId = "0001";
  polCont = "05E119";
  emails = "Praveen.Kusuma@aig.com";
  billDueDate = "07/01/2019";
  */
  return postData(uri, APIURIs.BITS_APIKEY, params);
}

class EmailSender extends Component {
  _isMounted = false;
  constructor(props) {
    super(props);
    this.state = {
      ...defaultValues
    };
    this.validator = new SimpleReactValidator();
  }

  componentDidMount() {
    this._isMounted = true;
    this.props.onRef(this);
  }

  componentWillUnmount() {
    this._isMounted = false;
    this.props.onRef(undefined);
  }

  setLoading = status => {
    if (this._isMounted) {
      this.setState({ loading: status });
    }
  };

  handleChange = event => {
    let reprocessFieldsTmp = Object.assign({}, this.state);
    reprocessFieldsTmp[event.target.name] = event.target.value;
    if (this._isMounted) {
      this.setState({
        ...reprocessFieldsTmp
      });
    }
  };

  handleSendEmail = () => {
    if (this._isMounted) {
      this.setState({ loading: true });
    }
    if (!validateEmailList(this.state.toEmail)) {
      if (this._isMounted) {
        this.setState({
          validationError: true,
          loading: false
        });
      }
      return;
    }

    let params = {
      ...this.props.params,
      emails: this.state.toEmail,
      userName: getFromLocalStorage("userId")
    };

    sendEmail(params, this.props.uri)
      .then(res => {
        if (res.status === 200) {
          this.handleEmailNotification("success", "Email successfully sent");
          // Close the window after 2 seconds
          this.closeWindow = setTimeout(
            function() {
              this.props.handleClose();
            }.bind(this),
            2000
          );
        } else if (res.data === "No records found!") {
          this.handleEmailNotification(
            "info",
            "Failed to send email. No record found!"
          );
        } else {
          this.handleEmailNotification("failure", "Error sending email!");
        }
        if (this._isMounted) {
          this.setState({
            loading: false
          });
        }
      })
      .catch(error => {
        console.warn(error);
        if (this._isMounted) {
          this.setState({
            loading: false
          });
        }
        this.handleEmailNotification("failure", "Error sending email!");
      });
    if (this._isMounted) {
      this.setState({
        validationError: false
      });
    }
  };

  handleClear = () => {
    this.setState({
      ...defaultValues
    });
  };

  handleInvoiceDownload = () => {
    this.props.handleDownload();
  };

  handleEmailNotification = (messageType, message) => {
    if (messageType === "success") {
      if (this._isMounted) {
        this.setState(
          {
            successMessage: message
          },
          () => {
            this.showNotification("successElt");
          }
        );
      }
    } else if (messageType === "info") {
      if (this._isMounted) {
        this.setState(
          {
            infoMessage: message
          },
          () => {
            this.showNotification("infoElt");
          }
        );
      }
    } else {
      if (this._isMounted) {
        this.setState(
          {
            failureMessage: message
          },
          () => {
            this.showNotification("errorElt");
          }
        );
      }
    }
  };

  showNotification(place) {
    var x = [];
    x[place] = true;
    if (this._isMounted) {
      this.setState(x);
    }
    this.alertTimeout = setTimeout(
      function() {
        x[place] = false;
        if (this._isMounted) {
          this.setState(x);
        }
      }.bind(this),
      6000
    );
  }

  render() {
    return (
      <React.Fragment>
        <DialogTitle
          id="customized-dialog-title"
          onClose={() => this.props.handleClose()}
        >
          <b>Email</b>
        </DialogTitle>
        <DialogContent style={{ overflowX: "hidden", overflowY: "hidden" }}>
          <Overlay
            style={{
              overflowX: "hidden",
              overflowY: "hidden"
            }}
            active={this.state.loading}
            marginTop="150px"
          >
            <div
              style={{
                height: "500px",
                paddingTop: "15px",
                overflowX: "hidden",
                overflowY: "hidden"
              }}
            >
              {this.state.validationError ? (
                <Chip
                  icon={<WarningOutlined />}
                  label="Validation Failed. Please enter email addresses in valid format and try again."
                  color="secondary"
                />
              ) : (
                ""
              )}
              <FormControl component="fieldset" className={classes.formControl}>
                <GridContainer
                  style={{ display: "flex", alignItems: "center" }}
                >
                  <GridItem xs={12} sm={12} md={6}>
                    <Typography variant="caption">
                      <TextField
                        id="toEmail"
                        name="toEmail"
                        label="To"
                        type="search"
                        className={classes.textField}
                        onChange={this.handleChange}
                        value={this.state.toEmail}
                        style={{ width: 550 }}
                        margin="none"
                        variant="outlined"
                        placeholder="Enter comma separated list of email addresses only"
                      />
                      {this.validator.message(
                        "toEmail",
                        this.state.toEmail,
                        "required|email"
                      )}
                    </Typography>
                  </GridItem>
                </GridContainer>
                <GridContainer
                  style={{
                    paddingTop: "15px",
                    display: "flex",
                    alignItems: "center"
                  }}
                >
                  <GridItem xs={12} sm={12} md={6}>
                    <Typography variant="caption">
                      <TextField
                        id="subject"
                        name="subject"
                        label="Subject"
                        type="search"
                        className={classes.textField}
                        onChange={this.handleChange}
                        value={this.props.subject}
                        style={{ width: 550 }}
                        margin="none"
                        variant="outlined"
                        disabled={true}
                      />
                    </Typography>
                  </GridItem>
                </GridContainer>
                <GridContainer
                  style={{
                    paddingTop: "15px",
                    display: "flex",
                    alignItems: "center"
                  }}
                >
                  <GridItem>
                    <Paper className={classes.emailPreview} elevation={0}>
                      <Typography variant="body2">Email Preview:</Typography>
                      <div
                        dangerouslySetInnerHTML={{
                          __html: this.props.emailPreview
                        }}
                        style={{
                          padding: "2px",
                          overflowY: "auto",
                          width: "550px",
                          height: "250px"
                        }}
                      />
                    </Paper>
                  </GridItem>
                </GridContainer>
              </FormControl>
              <div>&nbsp;</div>
              <div style={{ verticalAlign: "middle" }}>
                <a
                  role="button"
                  style={{
                    cursor: "pointer"
                  }}
                  onClick={() => {
                    this.handleInvoiceDownload();
                  }}
                >
                  <Attachment
                    style={{
                      color: "#1565c0",
                      transition: "all .3s ease"
                    }}
                  />
                  <span style={{ height: "24px", verticalAlign: "top" }}>
                    &nbsp;
                    <b>{this.props.fileName}</b>
                  </span>
                </a>
              </div>
            </div>
          </Overlay>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => this.handleSendEmail()} color="primary">
            Send Email
          </Button>
          <Button onClick={() => this.handleClear()} color="primary">
            Clear
          </Button>
          <Button onClick={() => this.props.handleClose()} color="primary">
            Close
          </Button>
        </DialogActions>
        <Snackbar
          place="tr"
          color="success"
          icon={InfoOutlined}
          message={this.state.successMessage}
          open={this.state.successElt}
          closeNotification={() => this.setState({ successElt: false })}
          close
        />
        <Snackbar
          place="tr"
          color="danger"
          icon={InfoOutlined}
          message={this.state.failureMessage}
          open={this.state.errorElt}
          closeNotification={() => this.setState({ errorElt: false })}
          close
        />
        <Snackbar
          place="tr"
          color="info"
          icon={InfoOutlined}
          message={this.state.infoMessage}
          open={this.state.infoElt}
          closeNotification={() => this.setState({ infoElt: false })}
          close
        />
      </React.Fragment>
    );
  }
}

EmailSender.propTypes = {
  subject: PropTypes.string,
  fileName: PropTypes.string,
  emailPreview: PropTypes.string,
  onRef: PropTypes.any,
  handleClose: PropTypes.func,
  handleDownload: PropTypes.func,
  params: PropTypes.object,
  uri: PropTypes.string
};

export default requireAuth(EmailSender, "mainContent");
