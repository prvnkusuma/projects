import React from "react";
import PropTypes from "prop-types";

// Components
import { Page } from "./Page";

const Viewer = ({ pdf, ...props }) => {
  const numPages = pdf ? pdf.numPages : 0;

  if (pdf) {
    return (
      <div className="pdf-viewer">
        {Array.apply(null, { length: numPages }).map((v, i) => (
          <div key={`document-page-${i}`}>
            <Page
              pdf={pdf}
              index={i + 1}
              key={`document-page-${i}`}
              {...props}
            />
            {i + 1 != numPages ? (
              <hr
                style={{
                  border: "0",
                  height: "0",
                  borderTop: "1px solid rgba(0, 0, 0, 0.1)",
                  borderBottom: "1px solid rgba(255, 255, 255, 0.3)"
                }}
              />
            ) : (
              ""
            )}
          </div>
        ))}
      </div>
    );
  }

  return null;
};

Viewer.propTypes = {
  pdf: PropTypes.oneOfType([PropTypes.string, PropTypes.object])
};

export { Viewer };
