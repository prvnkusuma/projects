import React from "react";
import PropTypes from "prop-types";

const PrintFileIFrame = ({ src }) => {
  return (
    <div style={{ display: "none" }}>
      <iframe src={src} id="iFramePDF" />
    </div>
  );
};

PrintFileIFrame.propTypes = {
  src: PropTypes.string
};

export default PrintFileIFrame;
