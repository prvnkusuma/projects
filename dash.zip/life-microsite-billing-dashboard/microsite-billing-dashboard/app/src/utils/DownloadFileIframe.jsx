import React from "react";
import PropTypes from "prop-types";
import requireAuth from "utils/AuthenticatedComponent.jsx";

const DownloadFileIframe = ({ src }) => {
  return (
    <div style={{ display: "none" }}>
      <iframe src={src} />
    </div>
  );
};

DownloadFileIframe.propTypes = {
  src: PropTypes.string
};

export default requireAuth(DownloadFileIframe, "mainContent");
