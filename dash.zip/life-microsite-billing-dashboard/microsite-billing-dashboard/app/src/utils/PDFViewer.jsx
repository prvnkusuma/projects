import React from "react";
import PropTypes from "prop-types";
import requireAuth from "utils/AuthenticatedComponent.jsx";
import * as PdfJs from "pdfjs-dist";
import PDFJSWorker from "worker-loader!pdfjs-dist/build/pdf.worker.js";

// Components
import { Viewer } from "./pdf/Viewer";

PdfJs.GlobalWorkerOptions.workerPort = new PDFJSWorker();

class PDFViewer extends React.Component {
  state = {
    pdf: null,
    scale: 1.3
  };

  componentDidMount() {
    var loadingTask = PdfJs.getDocument({
      data: this.props.file,
      disableFontFace: this.props.disableFontFace
    });
    loadingTask.promise.then(pdf => {
      this.setState({ pdf });
    });
  }

  render() {
    const { pdf, scale } = this.state;
    return (
      <div className="pdf-context">
        <Viewer pdf={pdf} scale={scale} />
      </div>
    );
  }
}

PDFViewer.propTypes = {
  file: PropTypes.oneOfType([PropTypes.string, PropTypes.object]),
  disableFontFace: PropTypes.bool
};

export default requireAuth(PDFViewer, "mainContent");
