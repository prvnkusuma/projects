import React, { Component } from "react";
import PropTypes from "prop-types";

import { withStyles } from "@material-ui/core/styles";
import Button from "@material-ui/core/Button";
import Select from "@material-ui/core/Select";
import FormControl from "@material-ui/core/FormControl";
import Typography from "@material-ui/core/Typography";
import printLocations from "properties/PrintLocations.jsx";
import requireAuth from "utils/AuthenticatedComponent.jsx";

import {
  DialogTitle,
  DialogContent,
  DialogActions
} from "components/Dialog/CommonDialog.jsx";

const styles = theme => ({
  root: {
    display: "flex"
  },
  formControl: {
    margin: 0
  },
  group: {
    margin: `${theme.spacing.unit}px 0`
  },
  title: {
    margin: `${theme.spacing.unit * 4}px ${theme.spacing.unit * 4}px
      ${theme.spacing.unit * 4}px ${theme.spacing.unit * 2}px`
  }
});

class PrintSender extends Component {
  state = {
    location: "reprint"
  };

  handleChange = event => {
    this.setState({ location: event.target.value });
  };

  render() {
    const { classes } = this.props;
    return (
      <React.Fragment>
        <DialogTitle
          id="customized-dialog-title"
          onClose={() => this.props.handleClose()}
        >
          <b>Print</b>
        </DialogTitle>
        <DialogContent>
          <div style={{ height: "150px", width: "220px" }}>
            <FormControl component="fieldset" className={classes.formControl}>
              <Typography variant="subheading" className={classes.title}>
                <b>Select a print option:</b>
              </Typography>
              <Select
                native
                autoWidth={true}
                value={this.state.location}
                onChange={this.handleChange}
                inputProps={{
                  name: "location",
                  id: "location"
                }}
              >
                {printLocations.map(option => (
                  <option key={option.value} value={option.value}>
                    {option.label}
                  </option>
                ))}
              </Select>
            </FormControl>
          </div>
        </DialogContent>
        <DialogActions>
          <Button
            onClick={() => this.props.handlePrint(this.state.location)}
            color="primary"
          >
            Print
          </Button>
          <Button onClick={() => this.props.handleClose()} color="primary">
            Close
          </Button>
        </DialogActions>
      </React.Fragment>
    );
  }
}

PrintSender.propTypes = {
  classes: PropTypes.object.isRequired,
  handleClose: PropTypes.func,
  handlePrint: PropTypes.func
};

export default withStyles(styles)(requireAuth(PrintSender, "mainContent"));
