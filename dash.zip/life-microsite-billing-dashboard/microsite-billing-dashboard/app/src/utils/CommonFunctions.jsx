import axios from "axios";
import moment from "moment";
import momentTZ from "moment-timezone";
import APIURIs from "properties/APIURIs.jsx";
import RBACRules from "properties/RBACRules.jsx";

var clientId = "sKV4qxbUQ0ns2934S72TJr5lEGVGN503";
var clientSecret = "g6UM2x11CoJVGfNA";
var ClientOAuth2 = require("client-oauth2");
var accessTokenAuth = new ClientOAuth2({
  clientId: clientId,
  clientSecret: clientSecret,
  accessTokenUri: APIURIs.OAUTH_ACCESS_TOKEN_URI,
  scopes: [""]
});

var refreshTokenAuth = new ClientOAuth2({
  clientId: clientId,
  clientSecret: clientSecret,
  accessTokenUri: APIURIs.OAUTH_REFRESH_TOKEN_URI,
  scopes: [""]
});

var userProf = {
  userId: "",
  userEmail: "",
  firstName: "",
  lastName: "",
  userRole: ""
};

var key =
  "1234567890abcdefghijklmnopqrstuvwxyz1234567890ABCDEFGHIJKLMNOPQRSTUVWXYZ";
var encryptor = require("simple-encryptor")(key);
const TOKEN_REFRESH_INTERVAL = 28 * 60 * 1000; // 28 minutes

export function formatDate(date) {
  if (date === "" || date === null) {
    return "";
  } else {
    return moment(date).format("YYYY-MM-DD");
  }
}

export function formatDateWithPattern(date, pattern) {
  if (date === undefined || date === "" || date === null) {
    return "";
  } else {
    return moment(date).format(pattern);
  }
}

export function formatStringToDate(date) {
  if (date === "" || date === null) {
    return null;
  } else {
    return moment(date, "YYYY-MM-DD").toDate();
  }
}

export function objToQueryString(obj) {
  const keyValuePairs = [];
  for (const key in obj) {
    keyValuePairs.push(
      encodeURIComponent(key) + "=" + encodeURIComponent(obj[key])
    );
  }
  return keyValuePairs.join("&");
}

export function convertStringToList(str) {
  var strList = str.split(",");
  return strList;
}

export function isSearchCriteriaEmpty(obj) {
  let flag = true;
  for (const key in obj) {
    if (obj[key] !== "") {
      flag = false;
      break;
    }
  }
  return flag;
}

export function getFromLocalStorage(key) {
  //let userProf = JSON.parse(localStorage.getItem("userProf"));
  let userProf = JSON.parse(
    encryptor.decrypt(localStorage.getItem("userProf"))
  );
  if (userProf) {
    return userProf[key];
  } else {
    return "";
  }
}

export function setToLocalStorage(key, value) {
  userProf[key] = value;
  //localStorage.setItem("userProf", JSON.stringify(userProf));
  localStorage.setItem("userProf", encryptor.encrypt(JSON.stringify(userProf)));
}

export function createSortQuery(sorted) {
  var sortedTmp = "";
  if (Object.keys(sorted).length > 0) {
    sortedTmp =
      sorted[0].desc === false
        ? encodeURIComponent("+") + sorted[0].id
        : "-" + sorted[0].id;
  }
  return sortedTmp;
}

function createTokenToStore(user) {
  var refreshExpires = new Date();
  refreshExpires.setSeconds(
    Number(refreshExpires.getSeconds()) +
      Number(user.data.refresh_token_expires_in)
  );
  let tokenToStore = {
    accessToken: user.accessToken,
    refreshToken: user.refreshToken,
    token_type: user.data.token_type,
    expires: user.expires,
    refreshTokenExpires: refreshExpires
  };
  /*
  console.log(
    "Storing token with access expiry: " +
      user.expires +
      " and refresh expiry: " +
      refreshExpires
  );*/
  return tokenToStore;
}

/*
 * Validates the user and assign the access token to the 
 * global access token variable. If the token has expired
 * (chances of this are very minimal - Added for corner case scenario),
 * fetch the refresh token intead and assign to the global access token
 */
export function validateUser(userId, password) {
  // Access API
  const headers = {
    headers: {
      Pragma: "no-cache",
      apikey: APIURIs.LDAP_AUTH_APIKEY
    }
  };

  let paramObject = {
    userName: userId,
    keyValue: password
  };
  let apiUrl = APIURIs.LDAP_AUTH_URI;
  return axios
    .post(apiUrl, paramObject, headers)
    .then(res => {
      return res;
    })
    .catch(error => {
      return error;
    });
}

/*
 * Validates the user and assign the access token to the 
 * global access token variable. If the token has expired
 * (chances of this are very minimal - Added for corner case scenario),
 * fetch the refresh token intead and assign to the global access token
 */
export function validateUserOAuth(userId, password) {
  // Get access token
  return accessTokenAuth.owner
    .getToken(userId, password)
    .then(function(user) {
      var token = refreshTokenAuth.createToken(
        user.accessToken,
        user.refreshToken,
        user.data.token_type
      );
      token.expiresIn(user.expires);
      // Store the token
      return addTokenToStore(user).then(function() {
        /*
        console.log("is token expired : " + token.expired());
        console.log(
          "is refresh expired : " +
            isTokenExpired(getTokenFromStore().refreshTokenExpires)
        );
        */
        // Check if access token expired - happens when expiry time is very less
        // Added the code for extra safety
        // Get New access token using refresh token
        let tmpUserId =
          getFromLocalStorage("userId") == undefined
            ? false
            : getFromLocalStorage("userId");
        if (token.expired() && tmpUserId) {
          if (getNewAccessTokenUsingRefresh(token)) {
            return user;
          } else {
            return false;
          }
        } else {
          return user;
        }
      });
    })
    .catch(error => {
      return error;
    });
}

export function getData(apiUrl, apiKey, paramObject) {
  return axios
    .request({
      url: apiUrl + objToQueryString(paramObject),
      method: "get",
      headers: {
        Pragma: "no-cache",
        apikey: apiKey
      }
    })
    .then(response => {
      return response;
    })
    .catch(error => {
      return handleErrors(error, "No records found!");
    });
}

export function requestData(apiUrl, apiKey, method, paramObject) {
  return axios
    .request({
      url: apiUrl + objToQueryString(paramObject),
      method: method,
      headers: {
        Pragma: "no-cache",
        apikey: apiKey
      }
    })
    .then(response => {
      return response;
    })
    .catch(error => {
      return handleErrors(error, "No records found!");
    });
}

export function getDataWithNoErrorHandling(apiUrl, apiKey, paramObject) {
  return axios
    .request({
      url: apiUrl + objToQueryString(paramObject),
      method: "get",
      headers: {
        Pragma: "no-cache",
        apikey: apiKey
      }
    })
    .then(response => {
      return response;
    })
    .catch(error => {
      return error.response;
    });
}

const updateTokenInStore = tokenForLocalStorage => {
  localStorage.setItem(
    "user",
    encryptor.encrypt(JSON.stringify(tokenForLocalStorage))
    //JSON.stringify(tokenForLocalStorage)
  );
  return Promise.resolve();
};

function getTokenFromStore() {
  return JSON.parse(encryptor.decrypt(localStorage.getItem("user")));
  //return JSON.parse(localStorage.getItem("user"));
}

function addTokenToStore(user) {
  return updateTokenInStore(createTokenToStore(user)).then(() => {
    return true;
  });
}

export function getNewAccessTokenUsingRefresh(token) {
  return token
    .refresh()
    .then(function(user) {
      //console.log("Access token after refresh: " + user.accessToken);
      return addTokenToStore(user).then(() => {
        return true;
      });
    })
    .catch(error => {
      console.warn(error);
      return false;
    });
}

let timeout = null;

export const autoRefreshToken = () => {
  //console.log("Started autoRefreshToken process...");
  clearTimeout(timeout);
  timeout = setTimeout(() => autoRefreshToken(), TOKEN_REFRESH_INTERVAL);
  return updateRefreshToken();
};

export const clearAutoRefreshToken = () => {
  clearTimeout(timeout);
};

function updateRefreshToken() {
  let tokenFromStore = getTokenFromStore();
  // Get the existing token from store and get refresh token
  if (tokenFromStore != undefined) {
    //console.log(
    //  "Refresh token is about to expire soon. Updating the refresh token..."
    //);
    var token = refreshTokenAuth.createToken(
      tokenFromStore.accessToken,
      tokenFromStore.refreshToken,
      tokenFromStore.token_type
    );
    return getNewAccessTokenUsingRefresh(token).then(() => {
      //console.log(
      //  "Access token in store after refresh: " +
      //    getTokenFromStore().accessToken
      //);
    });
  }
}

export function getDataUsingToken(
  apiUrl,
  optionsObject,
  paramObject,
  functionName
) {
  let tokenFromStore = getTokenFromStore();
  let tokenForAPI =
    tokenFromStore != undefined ? tokenFromStore.accessToken : "";
  // Get the existing token from store and check if already expired then get refresh token
  if (tokenFromStore != undefined && isTokenExpired(tokenFromStore.expires)) {
    //console.log("Token has expired. Getting new token using refresh token...");
    var token = refreshTokenAuth.createToken(
      tokenFromStore.accessToken,
      tokenFromStore.refreshToken,
      tokenFromStore.token_type
    );
    return getNewAccessTokenUsingRefresh(token).then(status => {
      if (status) {
        tokenForAPI = getTokenFromStore().accessToken;
      }
      //console.log("Token being used after refresh: " + tokenForAPI);
      return eval(functionName)(
        apiUrl,
        tokenForAPI,
        optionsObject,
        paramObject
      );
    });
  } else {
    // if not expired use the same token
    return eval(functionName)(apiUrl, tokenForAPI, optionsObject, paramObject);
  }
}

function isTokenExpired(expires) {
  return Date.now() > new Date(expires).getTime();
}

function handleErrors(error, returnMsg) {
  // If any error other than no data found
  if (
    !(
      error.response.status === 500 &&
      (error.response.data === "404 NOT_FOUND" ||
        error.response.statusText === "Internal Server Error")
    )
  ) {
    console.warn(error);
  } else {
    if (returnMsg === undefined || returnMsg == null) {
      return {};
    } else {
      if (error.response.data === "Bill reprocessing is in-progress") {
        return { data: error.response.data };
      } else {
        return { data: returnMsg };
      }
    }
  }
}

function handleErrorsUsingToken(
  functionName,
  apiUrl,
  token,
  optionsObject,
  paramObject,
  error,
  returnMsg
) {
  if (
    getTokenFromStore().accessToken != token &&
    error.response.status === 401
  ) {
    //console.log("Existing token expired. Using updated token from store");
    return eval(functionName)(
      apiUrl,
      getTokenFromStore().accessToken,
      optionsObject,
      paramObject
    );
  }
  // If any error other than no data found
  if (
    !(
      error.response.status === 500 &&
      (error.response.data === "404 NOT_FOUND" ||
        error.response.statusText === "Internal Server Error")
    )
  ) {
    console.warn(error);
  } else {
    if (returnMsg === undefined || returnMsg == null) {
      return {};
    } else {
      if (error.response.data === "Bill reprocessing is in-progress") {
        return { data: error.response.data };
      } else {
        return { data: returnMsg };
      }
    }
  }
}

export function getAPIDataUsingToken(
  apiUrl,
  apiKey,
  optionsObject,
  paramObject
) {
  // Access API
  const headers = {
    headers: {
      Pragma: "no-cache",
      apikey: optionsObject.apiKey
    }
  };

  return axios
    .get(apiUrl + objToQueryString(paramObject), headers)
    .then(res => {
      return res;
    })
    .catch(error => {
      return handleErrorsUsingToken(
        "getAPIDataUsingToken",
        apiUrl,
        optionsObject.apiKey,
        paramObject,
        error,
        "No records found!"
      );
    });
}

function sortJSONObjects(data, prop, desc) {
  return data.sort(function(a, b) {
    if (desc) {
      return b[prop] > a[prop] ? 1 : b[prop] < a[prop] ? -1 : 0;
    } else {
      return a[prop] > b[prop] ? 1 : a[prop] < b[prop] ? -1 : 0;
    }
  });
}

export function getTableDataFromJSONObject(
  jsonData,
  pageSize,
  page,
  sorted,
  dataKey
) {
  let startIndex = 0;
  let endIndex = pageSize;
  if (page > 0) {
    startIndex = page * pageSize;
    endIndex = startIndex + pageSize;
  }
  jsonData = sortJSONObjects(jsonData, sorted[0].id, sorted[0].desc);
  return new Promise((resolve, reject) => {
    if (jsonData) {
      let rows = {
        rows: [
          {
            [dataKey]: jsonData.slice(startIndex, endIndex)
          }
        ],
        pages: Math.ceil(jsonData.length / pageSize),
        totalRecords: jsonData.length
      };
      resolve(rows);
    } else {
      reject("Error");
    }
  });
}

export function getTableData(
  apiUrl,
  apiKey,
  pageSize,
  page,
  sorted,
  filtered,
  paramObject
) {
  let sortedTmp = createSortQuery(sorted);
  const headers = {
    headers: {
      Pragma: "no-cache",
      apiKey: apiKey
    }
  };
  return axios
    .get(
      apiUrl +
        objToQueryString(paramObject) +
        "&sort=" +
        sortedTmp +
        "&offset=" +
        page +
        "&limit=" +
        pageSize,
      headers
    )

    .then(res => {
      return res.data;
    })
    .catch(error => {
      return handleErrors(error, "No records found!");
    });
}

export function createSortQueryForPost(sorted) {
  var sortedTmp = "";
  if (Object.keys(sorted).length > 0) {
    sortedTmp =
      sorted[0].desc === false ? "+" + sorted[0].id : "-" + sorted[0].id;
  }
  return sortedTmp;
}

export function postTableData(
  apiUrl,
  apiKey,
  pageSize,
  page,
  sorted,
  filtered,
  paramObject
) {
  let sortedTmp = createSortQueryForPost(sorted);
  const headers = {
    headers: {
      Pragma: "no-cache",
      apiKey: apiKey
    }
  };
  return axios
    .post(
      apiUrl,
      {
        searchCriteria: {
          ...paramObject,
          sort: sortedTmp,
          offset: page,
          limit: pageSize
        }
      },
      headers
    )
    .then(res => {
      return res.data;
    })
    .catch(error => {
      return handleErrors(error, "No records found!");
    });
}

export function convertToSearchParams(params) {
  let searchParams = [];
  if (params != undefined && params != "") {
    for (let i of Object.keys(params)) {
      searchParams.push({ searchName: i, searchValue: params[i] });
    }
  }
  return searchParams;
}

export function postTableDataWithSearchParams(
  apiUrl,
  apiKey,
  pageSize,
  page,
  sorted,
  filtered,
  paramObject
) {
  let sortedTmp = createSortQueryForPost(sorted);
  const headers = {
    headers: {
      Pragma: "no-cache",
      apiKey: apiKey
    }
  };
  let paramObjectTmp = Object.assign({}, paramObject);
  paramObjectTmp["sort"] = sortedTmp;
  paramObjectTmp["offset"] = page;
  paramObjectTmp["limit"] = pageSize;
  return axios
    .post(
      apiUrl,
      {
        searchCriteria: convertToSearchParams({ ...paramObjectTmp })
      },
      headers
    )
    .then(res => {
      return res.data;
    })
    .catch(error => {
      return handleErrors(error, "No records found!");
    });
}

export function getTableDataUsingToken(
  apiUrl,
  token,
  optionsObject,
  paramObject
) {
  let sortedTmp = createSortQuery(optionsObject.sorted);
  const headers = {
    headers: {
      Pragma: "no-cache",
      Authorization: "Bearer " + token
    }
  };
  return axios
    .get(
      apiUrl +
        objToQueryString(paramObject) +
        "&sort=" +
        sortedTmp +
        "&offset=" +
        optionsObject.page +
        "&limit=" +
        optionsObject.pageSize,
      headers
    )

    .then(res => {
      return res.data;
    })
    .catch(error => {
      return handleErrors(
        "getTableDataUsingToken",
        apiUrl,
        token,
        optionsObject,
        paramObject,
        error,
        "No records found!"
      );
    });
}

export function postData(apiUrl, apiKey, paramObject) {
  const headers = {
    headers: {
      Pragma: "no-cache",
      apiKey: apiKey
    }
  };

  return axios
    .post(apiUrl, paramObject, headers)
    .then(res => {
      return res;
    })
    .catch(error => {
      return handleErrors(error, "No records found!");
    });
}

export function postFile(apiUrl, apiKey, formData) {
  const headers = {
    headers: {
      Pragma: "no-cache",
      apiKey: apiKey,
      "content-type": "multipart/form-data"
    }
  };

  return axios
    .post(apiUrl, formData, headers)
    .then(res => {
      return res;
    })
    .catch(error => {
      return handleErrors(error, "Failed to upload the file");
    });
}

export function putData(apiUrl, apiKey, paramObject) {
  const headers = {
    headers: {
      Pragma: "no-cache",
      apiKey: apiKey
    }
  };

  return axios
    .put(apiUrl, paramObject, headers)
    .then(res => {
      return res;
    })
    .catch(error => {
      return handleErrors(error, "No records found!");
    });
}

export function getBinaryData(apiUrl, apiKey, paramObject, fileName, sorted) {
  let fileDownload = require("js-file-download");
  let sortedTmp = createSortQuery(sorted);
  let url = apiUrl + objToQueryString(paramObject) + "&sort=" + sortedTmp;
  let isEmail = Object.assign({}, paramObject)["isEmail"];
  if (isEmail) {
    return axios
      .request({
        url: url,
        method: "get",
        headers: {
          Pragma: "no-cache",
          apiKey: apiKey
        }
      })
      .then(response => {
        if (response.status == 200) {
          response.message = "email";
        }
        return response;
      })
      .catch(error => {
        return handleErrors(error, "No records found!");
      });
  } else {
    return axios
      .request({
        responseType: "blob",
        url: url,
        method: "get",
        headers: {
          Pragma: "no-cache",
          apiKey: apiKey
        }
      })
      .then(response => {
        if (response.status == 200) {
          response.message = "download";
        }
        fileDownload(response.data, fileName);
        return response;
      })
      .catch(error => {
        return handleErrors(error, "No records found!");
      });
  }
}

export function getBinaryDataWithSearchParams(
  apiUrl,
  apiKey,
  paramObject,
  fileName,
  sorted
) {
  let fileDownload = require("js-file-download");
  let sortedTmp = createSortQueryForPost(sorted);
  let paramObjectTmp = Object.assign({}, paramObject);
  paramObjectTmp["sort"] = sortedTmp;
  return axios
    .request({
      responseType: "blob",
      url: apiUrl,
      data: {
        searchCriteria: convertToSearchParams({ ...paramObjectTmp })
      },
      method: "post",
      headers: {
        Pragma: "no-cache",
        apiKey: apiKey
      }
    })
    .then(response => {
      fileDownload(response.data, fileName);
    })
    .catch(error => {
      return handleErrors(error, "No records found!");
    });
}

export function getBinaryDataUsingToken(
  apiUrl,
  token,
  optionsObject,
  paramObject
) {
  let fileDownload = require("js-file-download");
  let sortedTmp = createSortQuery(optionsObject.sorted);
  let url = "";
  if (optionsObject.apiKey == "" && optionsObject.sorted == "") {
    url = apiUrl;
  } else {
    url = apiUrl + objToQueryString(paramObject) + "&sort=" + sortedTmp;
  }
  return axios
    .request({
      responseType: "blob",
      url: url,
      method: "get",
      headers: {
        Pragma: "no-cache",
        Authorization: "Bearer " + token
      }
    })
    .then(response => {
      fileDownload(response.data, optionsObject.fileName);
    })
    .catch(error => {
      return handleErrors(
        "getBinaryDataUsingToken",
        apiUrl,
        token,
        optionsObject,
        paramObject,
        error,
        "No records found!"
      );
    });
}

export function validateCommaSepList(selectedCommaSepList) {
  let exp = /^\w(\s*,?\s*\w*-*)*$/;
  return exp.test(selectedCommaSepList) ? true : false;
}

export function setCookie(name, value, hours) {
  var expires = "";
  if (hours) {
    var date = new Date();
    date.setTime(date.getTime() + hours * 60 * 60 * 1000);
    //date.setTime(date.getTime() + hours * 10 * 1000);
    expires = "; expires=" + date.toUTCString();
  } else {
    expires = "; expires=Fri, 31 Dec 9999 23:59:59 GMT";
  }
  document.cookie = name + "=" + (value || "") + expires + "; path=/";
}

export function getCookie(name) {
  var nameEQ = name + "=";
  var ca = document.cookie.split(";");
  for (var i = 0; i < ca.length; i++) {
    var c = ca[i];
    while (c.charAt(0) == " ") c = c.substring(1, c.length);
    if (c.indexOf(nameEQ) == 0) return c.substring(nameEQ.length, c.length);
  }
  return null;
}

export function eraseCookie(name) {
  document.cookie = name + "=; Max-Age=-99999999;";
}

export function isUserAuthorized(screen, action) {
  let roles = getFromLocalStorage("userRole");
  // If user has both the roles, directly return true
  if (roles.indexOf("business") != -1) {
    return true;
  } else {
    // If user has only one role, check the RBAC rule
    let ruleName = roles + "_" + screen + "_" + action;
    return RBACRules[ruleName];
  }
}

export function isUserRole(role) {
  let roles = getFromLocalStorage("userRole");
  if (roles.indexOf(role) != -1) {
    return true;
  } else {
    return false;
  }
}

export function isOnlyUserRole(role) {
  let roles = getFromLocalStorage("userRole");
  if (roles === role) {
    return true;
  } else {
    return false;
  }
}

export function getLastWorkingDay() {
  // Get yesterday
  var yesterday = new moment().subtract(1, "days");
  // If yesterday is Saturday or Sunday, iterate until we get last working day
  // Saturday = 6, Sunday = 0
  while ([0, 6].indexOf(yesterday.day()) !== -1) {
    yesterday = yesterday.subtract(1, "days");
  }
  // Return previous working day
  return yesterday;
}

export function getLastWorkingDayForGivenDate(givenDate) {
  // Get yesterday
  var yesterday = new moment(givenDate, "YYYY-MM-DD").subtract(1, "days");
  // If yesterday is Saturday or Sunday, iterate until we get last working day
  // Saturday = 6, Sunday = 0
  while ([0, 6].indexOf(yesterday.day()) !== -1) {
    yesterday = yesterday.subtract(1, "days");
  }
  // Return previous working day
  return yesterday;
}

export function getNextWorkingDay(givenDate) {
  // Get tomorrow
  var tomorrow = moment(givenDate, "YYYY-MM-DD").add(1, "days");
  // If tomorrow is Saturday or Sunday, iterate until we get next working day
  // Saturday = 6, Sunday = 0
  while ([0, 6].indexOf(tomorrow.day()) !== -1) {
    tomorrow = tomorrow.add(1, "days");
  }
  // Return next working day
  return tomorrow;
}

export function addDays(currentDay, noOfDays) {
  return moment(currentDay, "YYYY-MM-DD")
    .add(noOfDays, "days")
    .toDate();
}

export function diffDays(fromDate, toDate) {
  return Math.abs(
    moment.duration(moment(fromDate).diff(moment(toDate))).asDays()
  );
}

export function diffWeekendDays(fromDate, toDate) {
  fromDate = formatStringToDate(formatDate(fromDate));
  toDate = formatStringToDate(formatDate(toDate));
  var numWeekendDays = 0;
  var currentDate = new Date(fromDate);
  while (currentDate <= toDate) {
    // If Sunday and Saturday
    if (currentDate.getDay() === 0 || currentDate.getDay() === 6) {
      numWeekendDays++;
    }
    currentDate = addDays(currentDate, 1);
  }
  return numWeekendDays;
}

export function isDateLater(fromDate, toDate) {
  if (moment.duration(moment(fromDate).diff(moment(toDate))).asDays() > 0) {
    return true;
  } else {
    return false;
  }
}

export function validateEmailList(emailList) {
  var emails = emailList.toString().split(",");
  var valid = true;
  var regex = /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;

  for (var i = 0; i < emails.length; i++) {
    if (emails[i] === "" || !regex.test(emails[i].replace(/\s/g, ""))) {
      valid = false;
    }
  }
  return valid;
}

export function copyToClipboard(text) {
  if (navigator.clipboard) {
    let status = new Promise(function(resolve, reject) {
      navigator.clipboard.writeText(text).then(
        function() {
          resolve(true);
        },
        function(err) {
          console.error("Async: Could not copy text: ", err);
          reject(false);
        }
      );
    });
    return status;
  } else {
    if (window.clipboardData && window.clipboardData.setData) {
      // Internet Explorer-specific code path to prevent textarea being shown while dialog is visible.
      return window.clipboardData.setData("Text", text);
    } else if (
      document.queryCommandSupported &&
      document.queryCommandSupported("copy")
    ) {
      var textarea = document.createElement("textarea");
      textarea.value = text;
      textarea.style.position = "fixed"; // Prevent scrolling to bottom of page in Microsoft Edge.
      document.body.appendChild(textarea);
      textarea.focus();
      textarea.select();
      try {
        return document.execCommand("copy"); // Security exception may be thrown by some browsers.
      } catch (ex) {
        console.warn("Copy to clipboard failed.", ex);
        return false;
      } finally {
        document.body.removeChild(textarea);
      }
    }
  }
}

export function commonExcelDownload(obj, uri, apikey, params, fileName) {
  if (obj._isMounted) {
    obj.setState({ downloadExcelLoading: true });
  }
  if (
    obj.state.totalRecords != null &&
    obj.state.totalRecords != undefined &&
    obj.state.totalRecords > 10000
  ) {
    // Send Email
    params = {
      ...params,
      isEmail: true,
      email: getFromLocalStorage("userEmail")
    };
  }
  return getBinaryData(
    uri,
    apikey,
    params,
    fileName,
    obj.selectTable.state.sorted
  )
    .then(response => {
      if (obj._isMounted) {
        obj.setState({ downloadExcelLoading: false });
      }
      return response;
    })
    .catch(error => {
      console.warn(error);
      if (obj._isMounted) {
        obj.setState({ downloadExcelLoading: false });
      }
    });
}

export function getObjectFromJSONByValue(data, key, val) {
  return data.filter(function(data) {
    return data[key] == val;
  });
}

export function getNewGuid() {
  var sGuid = "";
  for (var i = 0; i < 32; i++) {
    sGuid += Math.floor(Math.random() * 0xf).toString(0xf);
  }
  return sGuid;
}

export function getColumnWidth(rows, accessor, headerText) {
  if (rows) {
    const maxWidth = 400;
    const magicSpacing = 10;
    const cellLength = Math.max(
      ...rows.map(row => (`${row[accessor]}` || "").length),
      headerText.length
    );
    return Math.min(maxWidth, cellLength * magicSpacing);
  } else {
    return;
  }
}

export function getBrowserName() {
  if (
    (navigator.userAgent.indexOf("Opera") ||
      navigator.userAgent.indexOf("OPR")) != -1
  ) {
    return "Opera";
  } else if (navigator.userAgent.indexOf("Chrome") != -1) {
    return "Chrome";
  } else if (navigator.userAgent.indexOf("Safari") != -1) {
    return "Safari";
  } else if (navigator.userAgent.indexOf("Firefox") != -1) {
    return "Firefox";
  } else if (
    navigator.userAgent.indexOf("MSIE") != -1 ||
    !!document.documentMode == true
  ) {
    return "IE";
  } else {
    return "unknown";
  }
}

export function pad(pad, str, padLeft) {
  if (typeof str === "undefined") return pad;
  if (padLeft) {
    return (pad + str).slice(-pad.length);
  } else {
    return (str + pad).substring(0, pad.length);
  }
}

export function formatCurrency(amount) {
  var formatter = new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: "USD"
  });
  return formatter.format(amount);
}

export function trim(str) {
  return str.replace(/\s+/g, "");
}

export function getCSTDate() {
  return momentTZ.tz("America/Chicago").format();
}
