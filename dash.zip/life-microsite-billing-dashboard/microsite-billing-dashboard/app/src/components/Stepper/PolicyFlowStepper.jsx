import React from "react";
import PropTypes from "prop-types";
import { withStyles } from "@material-ui/core/styles";
import Stepper from "@material-ui/core/Stepper";
import Step from "@material-ui/core/Step";
import StepLabel from "@material-ui/core/StepLabel";
import Typography from "@material-ui/core/Typography";
import ReProcessBillStepDialog from "components/Dialog/ReProcessBillStepDialog.jsx";
import RemittanceStepDialog from "components/Dialog/RemittanceStepDialog.jsx";
import DeclineStepDialog from "components/Dialog/DeclineStepDialog.jsx";
import InvoiceStepDialog from "components/Dialog/InvoiceStepDialog.jsx";
import PolicyChangeStepDialog from "components/Dialog/PolicyChangeStepDialog.jsx";
import AWDStepDialog from "components/Dialog/AWDStepDialog.jsx";
import EFTReturnsStepDialog from "components/Dialog/EFTReturnsStepDialog.jsx";
import CorrespondenceStepDialog from "components/Dialog/CorrespondenceStepDialog.jsx";
import requireAuth from "utils/AuthenticatedComponent.jsx";

const styles = {
  root: {
    width: "100%"
  },
  step: {
    "&$completed": {
      color: "green"
    },
    "&$active": {
      color: "orange"
    },
    "&$error": {
      color: "#f44336"
    }
  },
  completed: {},
  active: {}, //needed so that the &$active tag works
  error: {},
  iconContainer: {
    transform: "scale(1)"
  }
};

function getSteps(processType, eftType) {
  if (processType == "eftReturns") {
    return getEFTReturnSteps(eftType);
  }

  if (processType == "remittance") {
    return ["AIH", "Remittance Service", "ALIP"];
  } else if (processType == "decline") {
    return ["AIH", "Decline Service", "ALIP"];
  } else if (processType == "invoice") {
    return ["AIH/SAP", "Invoice Service", "XPression"];
  } else if (processType == "policyChange") {
    return ["ALIP", "Policy Change Listener", "Producer", "AIH/SAP"];
  } else if (processType == "awdRemittance") {
    return ["Remittance Service", "AWD Listener Service", "WISE Gateway"];
  } else if (processType == "awdDecline") {
    return ["Decline Service", "AWD Listener Service", "WISE Gateway"];
  } else if (processType == "awdAIHError") {
    return ["AIH Error Listener", "AWD Listener Service", "WISE Gateway"];
  } else if (processType == "correspondence") {
    return ["ALIP", "Talend Job", "Correspondence Service", "XPression"];
  } else {
    return [
      "Bill Number",
      "Monitoring Service",
      "Notification Service",
      "Producer",
      "AIH/SAP"
    ];
  }
}

function getEFTReturnSteps(type) {
  switch (type) {
    case "SAP_RETURN":
    case "ALIP_RETURN":
      return ["SAP", "BITS", "ALIP", "BITS"];
    case "AWD_ABCPRENOTE":
    case "AWD_ABCRETURN_SAP":
      return ["SAP", "BITS", "AWD"];
    case "AWD_ABCRETURN":
      return ["SAP", "BITS", "ALIP", "BITS", "AWD"];
    case "MAN_ALIP_RETURN":
      return ["ALIP", "BITS"];
  }
}

class PolicyFlowStepper extends React.Component {
  componentDidMount() {
    this.setState({
      activeStep: this.props.stepNumber
    });
  }

  state = {
    activeStep: 0
  };

  render() {
    const { classes, ...other } = this.props;
    const steps = getSteps(this.props.processType, this.props.eftType);
    const { activeStep } = this.state;

    return (
      <div className={classes.root}>
        <Stepper activeStep={activeStep}>
          {steps.map((label, index) => {
            const props = {};
            const labelProps = {};

            if (index === activeStep) {
              if (this.props.status === "failed") {
                labelProps.error = true;
              }
              if (this.props.status === "completed") {
                labelProps.completed = true;
              }

              switch (this.props.processType) {
                case "bill":
                  labelProps.optional = (
                    <Typography variant="caption" color="error">
                      <ReProcessBillStepDialog
                        button1Name="Show Log"
                        button2Name="Reprocess"
                        {...other}
                      />
                    </Typography>
                  );
                  break;
                case "remittance":
                  labelProps.optional = (
                    <Typography variant="caption" color="error">
                      <RemittanceStepDialog
                        button1Name="Show Log"
                        button2Name="Reprocess"
                        {...other}
                      />
                    </Typography>
                  );
                  break;
                case "decline":
                  labelProps.optional = (
                    <Typography variant="caption" color="error">
                      <DeclineStepDialog
                        button1Name="Show Log"
                        button2Name="Reprocess"
                        {...other}
                      />
                    </Typography>
                  );
                  break;
                case "invoice":
                  labelProps.optional = (
                    <Typography variant="caption" color="error">
                      <InvoiceStepDialog
                        button1Name="Show Log"
                        button2Name="Reprocess"
                        {...other}
                      />
                    </Typography>
                  );
                  break;
                case "policyChange":
                  labelProps.optional = (
                    <Typography variant="caption" color="error">
                      <PolicyChangeStepDialog
                        button1Name="Show Log"
                        button2Name="Reprocess"
                        {...other}
                      />
                    </Typography>
                  );
                  break;
                case "awdRemittance":
                case "awdDecline":
                case "awdAIHError":
                  labelProps.optional = (
                    <Typography variant="caption" color="error">
                      <AWDStepDialog
                        button1Name="Show Log"
                        button2Name="Reprocess"
                        {...other}
                      />
                    </Typography>
                  );
                  break;
                case "eftReturns":
                  labelProps.optional = (
                    <Typography variant="caption" color="error">
                      <EFTReturnsStepDialog
                        button1Name="Show Log"
                        button2Name="Reprocess"
                        {...other}
                      />
                    </Typography>
                  );
                  break;
                case "correspondence":
                  labelProps.optional = (
                    <Typography variant="caption" color="error">
                      <CorrespondenceStepDialog
                        button1Name="Show Log"
                        button2Name="Reprocess"
                        button3Name="Mark as Complete"
                        {...other}
                      />
                    </Typography>
                  );
                  break;
              }
            }
            return (
              <Step key={label} {...props}>
                <StepLabel
                  {...labelProps}
                  classes={{
                    iconContainer: classes.iconContainer
                  }}
                  StepIconProps={{
                    classes: {
                      root: classes.step,
                      completed: classes.completed,
                      active: classes.active,
                      error: classes.error
                    }
                  }}
                >
                  &nbsp;&nbsp;
                  {label}
                  <br />
                </StepLabel>
              </Step>
            );
          })}
        </Stepper>
      </div>
    );
  }
}

PolicyFlowStepper.propTypes = {
  classes: PropTypes.object
};

export default withStyles(styles)(
  requireAuth(PolicyFlowStepper, "mainContent")
);
