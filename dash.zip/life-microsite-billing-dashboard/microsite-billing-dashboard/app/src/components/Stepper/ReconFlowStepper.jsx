import React from "react";
import PropTypes from "prop-types";
import { withStyles } from "@material-ui/core/styles";
import Stepper from "@material-ui/core/Stepper";
import Step from "@material-ui/core/Step";
import StepLabel from "@material-ui/core/StepLabel";
import MetricsBox from "components/CustomWidgets/MetricsBox.jsx";
import requireAuth from "utils/AuthenticatedComponent.jsx";

const styles = {
  root: {
    width: "100%"
  },
  step: {
    "&$completed": {
      color: "green"
    },
    "&$active": {
      color: "orange"
    },
    "&$error": {
      color: "#f44336"
    }
  },
  completed: {},
  active: {}, //needed so that the &$active tag works
  error: {},
  iconContainer: {
    transform: "scale(1)"
  }
};

class ReconFlowStepper extends React.Component {
  componentDidMount() {
    this.setState({
      activeStep: this.props.stepNumber
    });
  }

  state = {
    activeStep: 0
  };

  render() {
    const {
      classes,
      headers,
      headerLinks,
      data,
      popperData,
      popperHeaders,
      bgcolor
    } = this.props;

    return (
      <div className={classes.root}>
        <Stepper>
          {headers.map((header, index) => {
            const props = {};

            return (
              <Step key={header} {...props}>
                <StepLabel
                  icon={
                    <MetricsBox
                      bgcolor={bgcolor}
                      header={header}
                      headerLink={headerLinks[index]}
                      data={data[index]}
                      popperData={popperData[index]}
                      popperHeaders={popperHeaders[index]}
                    />
                  }
                  classes={{
                    iconContainer: classes.iconContainer
                  }}
                  StepIconProps={{
                    classes: {
                      root: classes.step,
                      completed: classes.completed,
                      active: classes.active,
                      error: classes.error
                    }
                  }}
                >
                  &nbsp;
                  <br />
                </StepLabel>
              </Step>
            );
          })}
        </Stepper>
      </div>
    );
  }
}

ReconFlowStepper.propTypes = {
  classes: PropTypes.object
};

export default withStyles(styles)(requireAuth(ReconFlowStepper, "mainContent"));
