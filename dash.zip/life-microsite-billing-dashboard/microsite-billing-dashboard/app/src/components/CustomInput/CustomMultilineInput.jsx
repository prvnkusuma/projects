import React from "react";

import TextField from "@material-ui/core/TextField";
import { createMuiTheme, MuiThemeProvider } from "@material-ui/core/styles";

const customMultilineInputTheme = createMuiTheme({
  overrides: {
    MuiFormLabel: {
      root: {
        height: 100
      }
    },
    MuiInputBase: {
      root: {
        height: 100
      }
    }
  }
});

const CustomMultilineInput = ({ onChange, ...props }) => {
  return (
    <MuiThemeProvider theme={customMultilineInputTheme}>
      <TextField
        multiline={true}
        onChange={onChange}
        margin="normal"
        {...props}
      />
    </MuiThemeProvider>
  );
};

export default CustomMultilineInput;
