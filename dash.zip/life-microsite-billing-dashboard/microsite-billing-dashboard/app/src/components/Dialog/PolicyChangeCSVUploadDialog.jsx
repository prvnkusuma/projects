import React from "react";
import axios from "axios";
import PropTypes from "prop-types";
import SimpleReactValidator from "simple-react-validator";

import { withStyles } from "@material-ui/core/styles";
import InfoOutlined from "@material-ui/icons/InfoOutlined";
import WarningOutlined from "@material-ui/icons/WarningOutlined";
import InsertDriveFileOutlined from "@material-ui/icons/InsertDriveFileOutlined";
import Avatar from "@material-ui/core/Avatar";
import Chip from "@material-ui/core/Chip";
import Dialog from "@material-ui/core/Dialog";
import Button from "@material-ui/core/Button";
import FormControl from "@material-ui/core/FormControl";

import GridItem from "components/Grid/GridItem.jsx";
import GridContainer from "components/Grid/GridContainer.jsx";
import Overlay from "components/CustomWidgets/Overlay.jsx";
import CustomFileUpload from "components/CustomWidgets/CustomFileUpload.jsx";
import snackbarContentStyle from "assets/jss/material-dashboard-react/components/snackbarContentStyle.jsx";
import { DialogTitle, DialogContent, DialogActions } from "./CommonDialog.jsx";
import APIURIs from "properties/APIURIs.jsx";
import { postFile, getFromLocalStorage } from "utils/CommonFunctions.jsx";

import CustomIcon from "components/CustomWidgets/CustomIcon.jsx";
import { insertTemplate } from "react-icons-kit/icomoon/insertTemplate";

var defaultMessage = "Select a CSV file and click Upload",
  messageType = "",
  validationError = false,
  validationMsg = defaultMessage,
  toggleUploadBtn = true;
const classes = theme => ({
  root: {
    ...theme.mixins.gutters(),
    paddingTop: theme.spacing.unit * 2,
    paddingBottom: theme.spacing.unit * 2
  },
  formControl: {
    margin: theme.spacing.unit,
    minWidth: 120,
    display: "flex",
    wrap: "nowrap"
  },
  group: {
    margin: `${theme.spacing.unit}px 0`
  },
  textField: {
    marginLeft: theme.spacing.unit,
    marginRight: theme.spacing.unit,
    width: 200,
    display: "flex",
    flexWrap: "wrap"
  },
  button: {
    margin: theme.spacing.unit
  },
  InputClasses: {
    fullWidth: true
  }
});

const defaultValues = {
  acceptedFileName: "",
  acceptedFile: "",
  rejectedFileName: ""
};

function upload(file) {
  var formData = new FormData();
  formData.append("file", file);
  formData.append("userName", getFromLocalStorage("userId"));

  // Call upload API
  return postFile(
    APIURIs.POL_CHANGE_CSV_FILEUPLOAD_URI,
    APIURIs.POL_CHANGE_CSV_FILEUPLOAD_APIKEY,
    formData
  );
}

class PolicyChangeCSVUploadDialog extends React.Component {
  _isMounted = false;
  constructor(props) {
    super(props);

    this.state = {
      ...defaultValues,
      loading: false
    };
    this.validator = new SimpleReactValidator();
  }

  componentDidMount() {
    this._isMounted = true;
  }

  componentWillUnmount() {
    this._isMounted = false;
  }

  getMessage = msgType => {
    messageType = msgType;
    if (messageType == "fileTypeReject") {
      validationError = true;
      validationMsg = "File type is not supported. Upload only CSV files";
    } else if (messageType == "sizeReject") {
      validationError = true;
      validationMsg = "File size is too large. Allowed limit is upto 5MB";
    } else if (messageType == "accept") {
      validationError = false;
      validationMsg = "Valid CSV file. Click Upload";
    } else if (this.state.acceptedFileName == "") {
      validationError = true;
      validationMsg = "Please select a CSV file!";
    } else {
      validationError = false;
    }
    toggleUploadBtn = validationError;
    return;
  };

  handleUpload = () => {
    upload(this.state.acceptedFile)
      .then(response => {
        if (response.status === 200) {
          this.props.showSuccessNotification();
        } else {
          this.props.showErrorNotification();
        }
        this.props.handleClose("reprocess");
      })
      .catch(error => {
        console.warn(error);
        this.props.showErrorNotification();
      });
  };

  handleCSVTemplate = () => {
    var fileDownload = require("js-file-download");
    axios
      .get(`policychange_csv_template.csv`, { responseType: "blob" })
      .then(response => {
        fileDownload(response.data, "PolicyChange CSV Template.csv");
      });
  };

  handleOnDrop = (acceptedFileNames, rejectedFileNames) => {
    this.setState({
      acceptedFileName:
        acceptedFileNames.length > 0 ? acceptedFileNames[0].name : "",
      acceptedFile: acceptedFileNames.length > 0 ? acceptedFileNames[0] : "",
      rejectedFileName:
        rejectedFileNames.length > 0 ? rejectedFileNames[0].name : "",
      validationError: false,
      validationMsg: defaultMessage
    });
  };

  handleClose = actionType => {
    if (actionType === "close") {
      this.setState({
        ...defaultValues
      });
      this.props.handleClose();
    }
    if (this._isMounted) {
      this.setState({
        acceptedFileName: "",
        rejectedFileName: ""
      });
    }
    messageType = "";
    validationError = false;
    validationMsg = defaultMessage;
    toggleUploadBtn = true;
  };

  render() {
    return (
      <React.Fragment>
        <Dialog
          aria-labelledby="customized-dialog-title"
          open={this.props.open}
          onClose={this.handleClose}
        >
          <DialogTitle
            id="customized-dialog-title"
            onClose={() => this.handleClose("close")}
          >
            <b>{this.props.title}</b>
          </DialogTitle>
          <DialogContent>
            <div
              style={{
                height: "320px",
                width: "460px",
                overflowX: "hidden"
              }}
            >
              {validationError ? (
                <Chip
                  icon={<WarningOutlined />}
                  label={validationMsg}
                  color="secondary"
                />
              ) : (
                <Chip
                  icon={<InfoOutlined />}
                  label={validationMsg}
                  color="primary"
                />
              )}
              <span
                style={{ paddingTop: "0px", paddingRight: "5px" }}
                className="RightActionBarStyle"
              >
                <CustomIcon
                  icon={insertTemplate}
                  size="24"
                  toolTip="Download CSV Template"
                  color="#2e7d32"
                  onClick={this.handleCSVTemplate}
                />
              </span>
              <div style={{ paddingTop: "25px" }}>
                <Overlay active={this.state.loading} marginTop="150px">
                  <FormControl
                    component="fieldset"
                    className={classes.formControl}
                    style={{ flexDirection: "row" }}
                  >
                    <GridContainer
                      style={{ display: "flex", alignItems: "center" }}
                    >
                      <GridItem xs={12} sm={12} md={6}>
                        <div>
                          <CustomFileUpload
                            ref={this.csvFileUpload}
                            id="csvFile"
                            name="csvFile"
                            accept=".csv"
                            style={{
                              width: "450px",
                              height: "200px",
                              background: "#CCCCCC",
                              border: "2px dashed #1c87c9",
                              cursor: "pointer"
                            }}
                            iconMargin="50px"
                            onDrop={this.handleOnDrop}
                            getMessage={this.getMessage}
                          />
                        </div>
                      </GridItem>
                      <GridItem xs={12} sm={12} md={6}>
                        &nbsp;
                      </GridItem>
                      <GridItem xs={12} sm={12} md={6}>
                        &nbsp;
                      </GridItem>
                    </GridContainer>
                  </FormControl>
                  <div
                    style={{
                      width: "460px"
                    }}
                  >
                    {this.state.acceptedFileName ? (
                      <Chip
                        avatar={
                          <Avatar>
                            <InsertDriveFileOutlined />
                          </Avatar>
                        }
                        color="primary"
                        label={this.state.acceptedFileName}
                        className={classes.chip}
                        variant="outlined"
                      />
                    ) : (
                      ""
                    )}
                    {this.state.rejectedFileName ? (
                      <Chip
                        avatar={
                          <Avatar>
                            <InsertDriveFileOutlined />
                          </Avatar>
                        }
                        color="secondary"
                        label={this.state.rejectedFileName}
                        className={classes.chip}
                        variant="outlined"
                      />
                    ) : (
                      ""
                    )}
                  </div>
                </Overlay>
              </div>
            </div>
          </DialogContent>
          <DialogActions>
            <Button
              disabled={toggleUploadBtn ? true : false}
              onClick={this.handleUpload}
              color="primary"
            >
              Upload
            </Button>
            <Button onClick={() => this.handleClose("clear")} color="primary">
              Clear
            </Button>
            <Button onClick={() => this.handleClose("close")} color="primary">
              Close
            </Button>
          </DialogActions>
        </Dialog>
      </React.Fragment>
    );
  }
}

PolicyChangeCSVUploadDialog.defaultProps = {
  openReProcessDialog: false
};

PolicyChangeCSVUploadDialog.propTypes = {
  handleClose: PropTypes.func,
  dialogdata: PropTypes.object,
  className: PropTypes.string,
  selectedId: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
  icon: PropTypes.bool,
  open: PropTypes.bool,
  title: PropTypes.string,
  showSuccessNotification: PropTypes.func,
  showErrorNotification: PropTypes.func,
  showInfoNotification: PropTypes.func
};

export default withStyles(snackbarContentStyle)(PolicyChangeCSVUploadDialog);
