import React from "react";
import { connect } from "react-redux";
import { bindActionCreators } from "redux";
import PropTypes from "prop-types";

import { withStyles } from "@material-ui/core/styles";
import InfoOutlined from "@material-ui/icons/InfoOutlined";
import WarningOutlined from "@material-ui/icons/WarningOutlined";
import Chip from "@material-ui/core/Chip";
import Dialog from "@material-ui/core/Dialog";
import Button from "@material-ui/core/Button";
import Typography from "@material-ui/core/Typography";
import Radio from "@material-ui/core/Radio";
import Select from "@material-ui/core/Select";
import FormControl from "@material-ui/core/FormControl";
import FormControlLabel from "@material-ui/core/FormControlLabel";

import GridItem from "components/Grid/GridItem.jsx";
import GridContainer from "components/Grid/GridContainer.jsx";
import DatePickerInput from "components/DatePickerInput/DatePickerInput.jsx";
import CustomMultilineInput from "components/CustomInput/CustomMultilineInput.jsx";

import snackbarContentStyle from "assets/jss/material-dashboard-react/components/snackbarContentStyle.jsx";
import { DialogTitle, DialogContent, DialogActions } from "./CommonDialog.jsx";
import APIURIs from "properties/APIURIs.jsx";
import { billPaymentMethods } from "properties/BillPaymentMethods.jsx";
import {
  formatStringToDate,
  postData,
  formatDate,
  convertStringToList,
  getFromLocalStorage
} from "utils/CommonFunctions.jsx";

//Import actions
import {
  getBulkReProcessBillDialog,
  addBulkReProcessBillDialog,
  delBulkReProcessBillDialog
} from "actions/BulkReProcessBillDialogAction.jsx";

const classes = theme => ({
  root: {
    ...theme.mixins.gutters(),
    paddingTop: theme.spacing.unit * 2,
    paddingBottom: theme.spacing.unit * 2
  },
  formControl: {
    margin: theme.spacing.unit,
    minWidth: 120,
    display: "flex",
    wrap: "nowrap"
  },
  group: {
    margin: `${theme.spacing.unit}px 0`
  },
  textField: {
    marginLeft: theme.spacing.unit,
    marginRight: theme.spacing.unit,
    width: 200,
    display: "flex",
    flexWrap: "wrap"
  },
  button: {
    margin: theme.spacing.unit
  },
  InputClasses: {
    fullWidth: true
  }
});

function reprocess(
  cycleDate,
  paymentMethod,
  selectedBillList,
  holdingInquiry,
  reprocessType
) {
  return postData(
    APIURIs.BULKBILL_REPROCESS_URI,
    APIURIs.BULKBILL_REPROCESS_APIKEY,
    {
      cycleDate: cycleDate,
      paymentMethod: paymentMethod,
      billIds: reprocessType === "allBills" ? [] : selectedBillList,
      holdingInquiry: holdingInquiry,
      isBulk: true,
      userName: getFromLocalStorage("userId")
    }
  );
}

function validateForm(selectedBillList) {
  let exp = /^\w(\s*,?\s*\w)*$/;
  return exp.test(selectedBillList) ? true : false;
}

const defaultValues = {
  disableAllBillsFields: false,
  disableSelectedBillsFields: true,
  validationError: false
};

class BulkReProcessBillDialog extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      ...defaultValues
    };
  }

  handleReprocess = () => {
    if (
      this.props.dialogdata.reprocessType === "allBills" ||
      (this.props.dialogdata.reprocessType === "selectedBills" &&
        validateForm(this.props.dialogdata.selectedBillList))
    ) {
      let billsStrToSend = this.props.dialogdata.selectedBillList;
      if (this.props.dialogdata.reprocessType === "allBills") {
        billsStrToSend = "";
      }
      var billsListToSend = convertStringToList(billsStrToSend);
      reprocess(
        formatDate(this.props.dialogdata.cycleDate),
        this.props.dialogdata.paymentMethod,
        billsListToSend,
        this.props.dialogdata.holdingInquiry,
        this.props.dialogdata.reprocessType
      ).then(response => {
        if (response) {
          if (response.status === 200) {
            this.props.showSuccessNotification();
          } else if (response.data === "No records found!") {
            this.props.showInfoNotification();
          } else {
            this.props.showErrorNotification();
          }
        } else {
          this.props.showErrorNotification();
        }
        let reprocessFieldsTmp = Object.assign({}, this.props.dialogdata);
        this.props.delBulkReProcessBillDialog(reprocessFieldsTmp);
        this.setState({
          ...defaultValues
        });
        this.props.handleClose("reprocess");
      });
    } else {
      this.setState({
        validationError: true
      });
      return;
    }
  };

  handleRadioChange = event => {
    let reprocessFieldsTmp = Object.assign({}, this.props.dialogdata);
    if (event.target.value === "selectedBills") {
      this.setState({
        disableAllBillsFields: true,
        disableSelectedBillsFields: false
      });
      reprocessFieldsTmp[event.target.name] = event.target.value;
    } else if (event.target.value === "allBills") {
      this.setState({
        disableAllBillsFields: false,
        disableSelectedBillsFields: true
      });
      reprocessFieldsTmp.selectedBillList = "";
      reprocessFieldsTmp[event.target.name] = event.target.value;
    } else {
      reprocessFieldsTmp[event.target.name] = event.target.value;
    }
    this.props.addBulkReProcessBillDialog(reprocessFieldsTmp);
  };

  handleChange = event => {
    let reprocessFieldsTmp = Object.assign({}, this.props.dialogdata);
    reprocessFieldsTmp[event.target.name] = event.target.value;
    this.props.addBulkReProcessBillDialog(reprocessFieldsTmp);
  };

  handleDateChange = (dateName, dateValue) => {
    let reprocessFieldsTmp = Object.assign({}, this.props.dialogdata);
    reprocessFieldsTmp[dateName] = formatDate(dateValue);
    this.props.addBulkReProcessBillDialog(reprocessFieldsTmp);
  };

  handleClose = actionType => {
    if (actionType === "reprocess") {
      this.setState({
        ...defaultValues
      });
      this.props.handleClose();
    }
    let reprocessFieldsTmp = Object.assign({}, this.props.dialogdata);
    this.props.delBulkReProcessBillDialog(reprocessFieldsTmp);
    this.setState({
      ...defaultValues
    });
  };

  render() {
    return (
      <React.Fragment>
        <Dialog
          aria-labelledby="customized-dialog-title"
          open={this.props.open}
          onClose={this.handleClose}
        >
          <DialogTitle
            id="customized-dialog-title"
            onClose={() => this.handleClose("reprocess")}
          >
            <b>{this.props.title}</b>
          </DialogTitle>
          <DialogContent>
            <div style={{ height: "500px", width: "550px" }}>
              {this.state.validationError ? (
                <Chip
                  icon={<WarningOutlined />}
                  label="Validation Failed. Please enter bills in valid format and try again."
                  color="secondary"
                />
              ) : (
                <Chip
                  icon={<InfoOutlined />}
                  label="Select the appropriate fields and click REPROCESS"
                  color="primary"
                />
              )}
              <div style={{ paddingTop: "20px" }}>
                <FormControl
                  component="fieldset"
                  className={classes.formControl}
                >
                  <GridContainer
                    style={{ display: "flex", alignItems: "center" }}
                  >
                    <GridItem xs={12} sm={12} md={6}>
                      <Typography variant="caption">
                        <b>Cycle Date:</b>
                      </Typography>
                    </GridItem>
                    <GridItem xs={12} sm={12} md={6}>
                      <DatePickerInput
                        id="cycleDate"
                        name="cycleDate"
                        placeholderText=""
                        selected={formatStringToDate(
                          this.props.dialogdata.cycleDate
                        )}
                        onChange={dateValue => {
                          this.handleDateChange("cycleDate", dateValue);
                        }}
                        withPortal
                      />
                    </GridItem>
                    <GridItem xs={12} sm={12} md={6}>
                      &nbsp;
                    </GridItem>
                    <GridItem xs={12} sm={12} md={6}>
                      &nbsp;
                    </GridItem>
                    <GridItem xs={12} sm={12} md={6}>
                      <Typography variant="caption">
                        <b>Payment Method:</b>
                      </Typography>
                    </GridItem>
                    <GridItem xs={12} sm={12} md={6}>
                      <FormControl>
                        <Select
                          native
                          autoWidth={false}
                          style={{ width: 120 }}
                          value={this.props.dialogdata.paymentMethod}
                          onChange={this.handleChange}
                          inputProps={{
                            name: "paymentMethod",
                            id: "paymentMethod"
                          }}
                        >
                          {billPaymentMethods.map(option => (
                            <option key={option.value} value={option.value}>
                              {option.label}
                            </option>
                          ))}
                        </Select>
                      </FormControl>
                    </GridItem>
                    <GridItem xs={12} sm={12} md={6}>
                      <Typography variant="caption">
                        <b>Policy Data Source:</b>
                      </Typography>
                    </GridItem>
                    <GridItem xs={12} sm={12} md={6}>
                      <FormControlLabel
                        control={
                          <Radio
                            color="primary"
                            name="holdingInquiry"
                            value="true"
                            checked={
                              this.props.dialogdata.holdingInquiry === "true"
                            }
                            onChange={this.handleRadioChange}
                          />
                        }
                        label="ALIP"
                      />
                      <FormControlLabel
                        control={
                          <Radio
                            color="primary"
                            name="holdingInquiry"
                            value="false"
                            checked={
                              this.props.dialogdata.holdingInquiry === "false"
                            }
                            onChange={this.handleRadioChange}
                          />
                        }
                        label="Cassandra"
                      />
                    </GridItem>
                    <GridItem xs={12} sm={12} md={6}>
                      &nbsp;
                    </GridItem>
                    <GridItem xs={12} sm={12} md={6}>
                      &nbsp;
                    </GridItem>
                  </GridContainer>
                  <Typography variant="subheading" className={classes.title}>
                    <b>Select bulk reprocess apply option:</b>
                  </Typography>
                  <FormControlLabel
                    control={
                      <Radio
                        color="primary"
                        name="reprocessType"
                        value="allBills"
                        checked={
                          this.props.dialogdata.reprocessType === "allBills"
                        }
                        onChange={this.handleRadioChange}
                      />
                    }
                    label="Apply to all failed bills"
                  />
                  <FormControlLabel
                    control={
                      <Radio
                        color="primary"
                        name="reprocessType"
                        value="selectedBills"
                        checked={
                          this.props.dialogdata.reprocessType ===
                          "selectedBills"
                        }
                        onChange={this.handleRadioChange}
                      />
                    }
                    label="Apply to only a selected list of Bill Ids"
                  />
                  <CustomMultilineInput
                    id="selectedBillList"
                    name="selectedBillList"
                    label="Enter comma separated list of Bill Ids"
                    rowsMax="5"
                    value={this.props.dialogdata.selectedBillList}
                    onChange={this.handleChange}
                    className={classes.textField}
                    disabled={this.state.disableSelectedBillsFields}
                    style={{ width: 400, height: 100 }}
                    inputProps={{
                      maxLength: 4000
                    }}
                  />
                </FormControl>
              </div>
            </div>
          </DialogContent>
          <DialogActions>
            <Button onClick={this.handleReprocess} color="primary">
              ReProcess
            </Button>
            <Button onClick={() => this.handleClose("clear")} color="primary">
              Clear
            </Button>
            <Button
              onClick={() => this.handleClose("reprocess")}
              color="primary"
            >
              Close
            </Button>
          </DialogActions>
        </Dialog>
      </React.Fragment>
    );
  }
}

BulkReProcessBillDialog.defaultProps = {
  openReProcessDialog: false
};

const mapStateToProps = state => ({
  dialogdata: state.sidebar.bulkReprocessBillDialog
});

const mapDispatchToProps = dispatch =>
  bindActionCreators(
    {
      getBulkReProcessBillDialog,
      addBulkReProcessBillDialog,
      delBulkReProcessBillDialog
    },
    dispatch
  );

BulkReProcessBillDialog.propTypes = {
  getBulkReProcessBillDialog: PropTypes.func,
  addBulkReProcessBillDialog: PropTypes.func,
  delBulkReProcessBillDialog: PropTypes.func,
  handleClose: PropTypes.func,
  dialogdata: PropTypes.object,
  className: PropTypes.string,
  selectedId: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
  icon: PropTypes.bool,
  open: PropTypes.bool,
  title: PropTypes.string,
  stepNumber: PropTypes.number,
  showSuccessNotification: PropTypes.func,
  showErrorNotification: PropTypes.func,
  showInfoNotification: PropTypes.func
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withStyles(snackbarContentStyle)(BulkReProcessBillDialog));
