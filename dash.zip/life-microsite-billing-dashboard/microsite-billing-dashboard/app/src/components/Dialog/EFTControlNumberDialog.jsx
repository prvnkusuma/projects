import React, { Component } from "react";
import PropTypes from "prop-types";

import Dialog from "@material-ui/core/Dialog";
import { withStyles } from "@material-ui/core/styles";
import Button from "@material-ui/core/Button";
import TextField from "@material-ui/core/TextField";
import FormControl from "@material-ui/core/FormControl";
import Typography from "@material-ui/core/Typography";
import Tooltip from "@material-ui/core/Tooltip";
import FileCopyTwoTone from "@material-ui/icons/FileCopyTwoTone";
import InfoOutlined from "@material-ui/icons/InfoOutlined";

import Snackbar from "components/Snackbar/Snackbar.jsx";
import Overlay from "components/CustomWidgets/Overlay.jsx";
import GridItem from "components/Grid/GridItem.jsx";
import GridContainer from "components/Grid/GridContainer.jsx";
import requireAuth from "utils/AuthenticatedComponent.jsx";
import { postTableData, copyToClipboard } from "utils/CommonFunctions.jsx";
import APIURIs from "properties/APIURIs.jsx";

import customInputStyle from "assets/jss/material-dashboard-react/components/customInputStyle.jsx";

import {
  DialogTitle,
  DialogContent,
  DialogActions
} from "components/Dialog/CommonDialog.jsx";

function getControlNumber(polCont) {
  return postTableData(
    APIURIs.EFT_ACCOUNT_INQ_DETAILS_URI,
    APIURIs.EFT_ACCOUNT_INQ_DETAILS_APIKEY,
    20,
    0,
    [{ id: "polCont", desc: true }],
    0,
    { polCont: polCont }
  );
}

const defaultValues = {
  polCont: "",
  controlNum: "",
  loading: false,
  validationError: false,
  errorMsg: "No records found",
  successMsg: "",
  successElt: false,
  errorElt: false,
  successMessage: "Copying to clipboard was successful",
  failureMessage: "Failed to copy to clipboard"
};

class EFTControlNumberDialog extends Component {
  _isMounted = false;
  state = {
    ...defaultValues
  };

  componentDidMount() {
    this._isMounted = true;
  }

  componentWillUnmount() {
    this._isMounted = false;
  }

  handleSubmit = () => {
    if (this.state.polCont == "") {
      this.setState({
        controlNum: "",
        loading: false,
        validationError: true,
        errorMsg: "Invalid Policy Number",
        successMsg: ""
      });
      return;
    }
    if (this._isMounted) {
      this.setState({ loading: true });
    }
    getControlNumber(this.state.polCont)
      .then(res => {
        if (this._isMounted) {
          let controlNumTmp = "";
          let validationErrorTmp = false;
          let successMsgTmp = "";
          if (res.rows) {
            controlNumTmp = res.rows[0].controlNum;
            successMsgTmp = "Control Number: " + controlNumTmp;
          } else {
            validationErrorTmp = true;
          }
          this.setState({
            controlNum: controlNumTmp,
            loading: false,
            validationError: validationErrorTmp,
            successMsg: successMsgTmp
          });
        }
      })
      .catch(error => {
        console.warn(error);
        if (this._isMounted) {
          this.setState({
            validationError: true,
            loading: false
          });
        }
      });
  };

  handleCopyToClipboard = () => {
    let status = copyToClipboard(this.state.controlNum);
    if (status) {
      this.showNotification("successElt");
    } else {
      this.showNotification("errorElt");
    }
  };

  handleChange = event => {
    this.setState({ polCont: event.target.value });
  };

  handleClose = actionType => {
    this.setState({
      ...defaultValues
    });
    if (actionType === "") {
      this.props.handleClose();
    }
  };

  showNotification(place) {
    var x = [];
    x[place] = true;
    this.setState(x);
    this.alertTimeout = setTimeout(
      function() {
        x[place] = false;
        this.setState(x);
      }.bind(this),
      6000
    );
  }

  render() {
    const { classes } = this.props;
    const { errorMsg, successMsg, validationError } = this.state;
    return (
      <React.Fragment>
        <Dialog
          aria-labelledby="customized-dialog-title"
          open={this.props.open}
          onClose={() => this.handleClose("")}
        >
          <DialogTitle
            id="customized-dialog-title"
            onClose={() => this.handleClose("")}
          >
            <b>Get Control Number</b>
          </DialogTitle>
          <DialogContent>
            <Overlay active={this.state.loading}>
              <div style={{ width: "250px" }}>
                <FormControl
                  component="fieldset"
                  className={classes.formControl}
                  style={{
                    margin: "0px",
                    paddingBottom: "0px",
                    display: "block",
                    flexDirection: "row"
                  }}
                >
                  <GridContainer
                    style={{
                      margin: "0px",
                      display: "flex",
                      alignItems: "center"
                    }}
                  >
                    <GridItem xs={12} sm={12} md={6}>
                      <TextField
                        id="polCont"
                        name="polCont"
                        label="Policy Number"
                        type="search"
                        className={classes.textField}
                        onChange={this.handleChange}
                        value={this.state.polCont}
                        margin="none"
                      />
                    </GridItem>
                    <GridItem xs={12} sm={12} md={6}>
                      &nbsp;
                    </GridItem>
                  </GridContainer>
                </FormControl>
              </div>
              <div className="LeftActionBarStyle">
                <Button
                  variant="contained"
                  color="primary"
                  className={classes.button}
                  onClick={this.handleSubmit}
                >
                  Search
                </Button>
                &nbsp;
                <Button
                  variant="contained"
                  color="primary"
                  className={classes.button}
                  onClick={() => this.handleClose("clear")}
                >
                  Clear
                </Button>
              </div>
              <Typography
                variant="subheading"
                className={classes.title}
                style={{ margin: "0px" }}
              >
                {validationError == true ? (
                  <span className={classes.labelRootError}>{errorMsg}</span>
                ) : (
                  <span className={classes.labelRootSuccess}>
                    {successMsg != "" ? (
                      <React.Fragment>
                        <span style={{ color: "#3f51b5" }}>{successMsg}</span>
                        &nbsp;&nbsp;
                        <Tooltip title="Copy to Clipboard">
                          <a
                            role="button"
                            style={{
                              cursor: "pointer"
                            }}
                            onClick={() => {
                              this.handleCopyToClipboard();
                            }}
                          >
                            <FileCopyTwoTone
                              style={{ color: "#f1a92b", fontSize: "20px" }}
                            />
                          </a>
                        </Tooltip>
                      </React.Fragment>
                    ) : (
                      ""
                    )}
                  </span>
                )}
              </Typography>
            </Overlay>
          </DialogContent>
          <DialogActions>
            <Button onClick={() => this.handleClose("")} color="primary">
              Close
            </Button>
          </DialogActions>
        </Dialog>
        <Snackbar
          place="tr"
          color="success"
          icon={InfoOutlined}
          message={this.state.successMessage}
          open={this.state.successElt}
          closeNotification={() => this.setState({ successElt: false })}
          close
        />
        <Snackbar
          place="tr"
          color="danger"
          icon={InfoOutlined}
          message={this.state.failureMessage}
          open={this.state.errorElt}
          closeNotification={() => this.setState({ errorElt: false })}
          close
        />
      </React.Fragment>
    );
  }
}

EFTControlNumberDialog.propTypes = {
  classes: PropTypes.object.isRequired,
  handleClose: PropTypes.func,
  open: PropTypes.bool
};

export default withStyles(customInputStyle)(
  requireAuth(EFTControlNumberDialog, "mainContent")
);
