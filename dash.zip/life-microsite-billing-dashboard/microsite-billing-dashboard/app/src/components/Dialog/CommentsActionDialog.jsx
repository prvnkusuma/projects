import React from "react";
import PropTypes from "prop-types";

import Dialog from "@material-ui/core/Dialog";
import Tooltip from "@material-ui/core/Tooltip";
import CommentOutlined from "@material-ui/icons/CommentOutlined";
import InfoOutlined from "@material-ui/icons/InfoOutlined";
import Button from "@material-ui/core/Button";
import TextField from "@material-ui/core/TextField";
import FormControl from "@material-ui/core/FormControl";

import { DialogTitle, DialogContent, DialogActions } from "./CommonDialog.jsx";
import Snackbar from "components/Snackbar/Snackbar.jsx";
import requireAuth from "utils/AuthenticatedComponent.jsx";

class CommentsActionDialog extends React.Component {
  _isMounted = false;
  constructor(props) {
    super(props);
    this.state = {
      comments: this.props.value,
      openComments: false,
      successElt: false,
      errorElt: false,
      successMessage: "Comments updated successfully",
      failureMessage: "Comments updation failed"
    };
  }

  UNSAFE_componentWillReceiveProps() {
    this.setValue();
  }

  componentDidMount() {
    this._isMounted = true;
  }

  componentWillUnmount() {
    this._isMounted = false;
  }

  handleOpen = () => {
    if (this._isMounted) {
      this.setState({ openComments: true });
    }
  };

  handleClose = () => {
    if (this._isMounted) {
      this.setState({ openComments: false });
    }
  };

  handleChange = event => {
    if (this._isMounted) {
      this.setState({ comments: event.target.value });
    }
  };

  handleSubmit = () => {
    this.props.handleSubmit(this.state.comments);
    this.showNotification("successElt");
    this.handleClose();
  };

  showNotification(place) {
    var x = [];
    x[place] = true;
    this.setState(x);
    this.alertTimeout = setTimeout(
      function() {
        x[place] = false;
        this.setState(x);
      }.bind(this),
      6000
    );
  }

  setValue() {
    if (this._isMounted) {
      this.setState({ comments: this.props.value });
    }
  }

  render() {
    const {
      title,
      iconTitle,
      commentsPlaceholder,
      value,
      button1Title,
      button2Title,
      isEnabled
    } = this.props;
    return (
      <React.Fragment>
        <Tooltip title={iconTitle}>
          <a
            role="button"
            style={{
              cursor: "pointer"
            }}
            onClick={() => {
              if (isEnabled) {
                this.handleOpen();
              }
            }}
          >
            <CommentOutlined
              style={{
                color: isEnabled
                  ? value !== null && value !== undefined && value !== ""
                    ? "#3c9941"
                    : "#8d6e63"
                  : "#CCCCCC",
                transition: "all .3s ease"
              }}
            />
          </a>
        </Tooltip>
        <Dialog
          aria-labelledby="customized-dialog-title"
          open={this.state.openComments}
          onClose={this.handleClose}
        >
          <DialogTitle id="customized-dialog-title" onClose={this.handleClose}>
            {title}
          </DialogTitle>
          <DialogContent>
            <div>
              <FormControl style={{ flexDirection: "row" }}>
                {button1Title ? (
                  <TextField
                    id="comments"
                    name="comments"
                    label={commentsPlaceholder}
                    type="search"
                    onChange={this.handleChange}
                    value={this.state.comments}
                    margin="none"
                    multiline
                    rowsMax={4}
                    style={{ width: 350 }}
                    autoFocus={true}
                  />
                ) : (
                  <span style={{ width: 350 }}>
                    {value !== null && value !== undefined && value !== ""
                      ? value
                      : "No comments available"}
                  </span>
                )}
              </FormControl>
            </div>
          </DialogContent>
          <DialogActions>
            {button1Title ? (
              <Button color="primary" onClick={this.handleSubmit} autoFocus>
                {button1Title}
              </Button>
            ) : (
              ""
            )}
            <Button color="primary" onClick={this.handleClose}>
              {button2Title}
            </Button>
          </DialogActions>
        </Dialog>
        <Snackbar
          place="tr"
          color="success"
          icon={InfoOutlined}
          message={this.state.successMessage}
          open={this.state.successElt}
          closeNotification={() => this.setState({ successElt: false })}
          close
        />
        <Snackbar
          place="tr"
          color="danger"
          icon={InfoOutlined}
          message={this.state.failureMessage}
          open={this.state.errorElt}
          closeNotification={() => this.setState({ errorElt: false })}
          close
        />
      </React.Fragment>
    );
  }
}

CommentsActionDialog.propTypes = {
  title: PropTypes.string,
  iconTitle: PropTypes.string,
  commentsPlaceholder: PropTypes.string,
  value: PropTypes.string,
  button1Title: PropTypes.string,
  button2Title: PropTypes.string,
  handleSubmit: PropTypes.func,
  isEnabled: PropTypes.any
};

export default requireAuth(CommentsActionDialog, "mainContent");
