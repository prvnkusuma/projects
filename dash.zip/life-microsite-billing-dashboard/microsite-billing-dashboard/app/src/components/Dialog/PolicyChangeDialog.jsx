import React from "react";
import { connect } from "react-redux";
import { bindActionCreators } from "redux";
import PropTypes from "prop-types";

import { withStyles } from "@material-ui/core/styles";
import FormControl from "@material-ui/core/FormControl";
import FormControlLabel from "@material-ui/core/FormControlLabel";
import InfoOutlined from "@material-ui/icons/InfoOutlined";
import Chip from "@material-ui/core/Chip";
import Dialog from "@material-ui/core/Dialog";
import Button from "@material-ui/core/Button";
import Typography from "@material-ui/core/Typography";
import Radio from "@material-ui/core/Radio";
import DatePickerInput from "components/DatePickerInput/DatePickerInput.jsx";

import snackbarContentStyle from "assets/jss/material-dashboard-react/components/snackbarContentStyle.jsx";
import APIURIs from "properties/APIURIs.jsx";
import { DialogTitle, DialogContent, DialogActions } from "./CommonDialog.jsx";
import {
  formatStringToDate,
  postData,
  formatDate,
  convertStringToList,
  getFromLocalStorage
} from "utils/CommonFunctions.jsx";

//Import actions
import {
  getReProcessPolicyChangeDialog,
  addReProcessPolicyChangeDialog,
  delReProcessPolicyChangeDialog
} from "actions/ReProcessPolicyChangeDialogAction.jsx";

function reprocess(transRefGUID, cycleDate, holdingInquiry) {
  // Call reprocess API
  return postData(
    APIURIs.POL_CHANGE_REPROCESS_URI,
    APIURIs.POL_CHANGE_REPROCESS_APIKEY,
    {
      transRefGuids:
        transRefGUID == null ? [] : convertStringToList(transRefGUID),
      isBulk: false,
      cycleDate: cycleDate,
      holdingInquiry: holdingInquiry,
      userName: getFromLocalStorage("userId")
    }
  );
}

class PolicyChangeDialog extends React.Component {
  constructor(props) {
    super(props);
  }

  handleRadioChange = event => {
    let reprocessFieldsTmp = Object.assign({}, this.props.dialogdata);
    reprocessFieldsTmp[event.target.name] = event.target.value;
    this.props.addReProcessPolicyChangeDialog(reprocessFieldsTmp);
  };

  handleReProcDialogEntering = cycleDate => {
    // get ReProcess Data
    let reprocessFieldsTmp = Object.assign({}, this.props.dialogdata);
    reprocessFieldsTmp.cycleDate = cycleDate;
    this.props.addReProcessPolicyChangeDialog(reprocessFieldsTmp);
  };

  handleChange = event => {
    let reprocessFieldsTmp = Object.assign({}, this.props.dialogdata);
    reprocessFieldsTmp[event.target.name] = event.target.value;
    this.props.addReProcessPolicyChangeDialog(reprocessFieldsTmp);
  };

  handleDateChange = (dateName, dateValue) => {
    let reprocessFieldsTmp = Object.assign({}, this.props.dialogdata);
    reprocessFieldsTmp[dateName] = formatDate(dateValue);
    this.props.addReProcessPolicyChangeDialog(reprocessFieldsTmp);
  };

  handleClose = () => {
    this.props.handleClose("reprocess");
    this.props.delReProcessPolicyChangeDialog();
  };

  handleReprocess = () => {
    // If Reporting Reprocess
    reprocess(
      this.props.selectedId,
      this.props.dialogdata.cycleDate,
      this.props.dialogdata.holdingInquiry
    ).then(response => {
      if (response.status === 200) {
        this.props.showSuccessNotification();
      } else {
        this.props.showErrorNotification();
      }
      this.props.handleClose("reprocess");
    });
  };

  render() {
    const { cycleDate } = this.props;
    return (
      <React.Fragment>
        <Dialog
          aria-labelledby="customized-dialog-title"
          open={this.props.open}
          onClose={this.handleClose}
          onEntering={() => {
            this.handleReProcDialogEntering(cycleDate);
          }}
        >
          <DialogTitle
            id="customized-dialog-title"
            onClose={() => this.handleClose("reprocess")}
          >
            <b>{this.props.button2Name}</b>
          </DialogTitle>
          <DialogContent>
            <div style={{ height: "200px", width: "300px" }}>
              <Chip
                icon={<InfoOutlined />}
                label="Edit the fields and click REPROCESS"
                color="primary"
              />

              <table width="100%" border="0px" cellPadding="0" cellSpacing="0">
                <tbody>
                  <tr>
                    <td>&nbsp;</td>
                  </tr>
                  <tr>
                    <td className="VerticalAlignBottom">
                      <FormControl style={{ flexDirection: "row" }}>
                        <Typography variant="caption">
                          <DatePickerInput
                            id="cycleDate"
                            name="cycleDate"
                            placeholderText="Cycle Date"
                            selected={formatStringToDate(
                              this.props.dialogdata.cycleDate
                            )}
                            onChange={dateValue => {
                              this.handleDateChange("cycleDate", dateValue);
                            }}
                            withPortal
                          />
                        </Typography>
                      </FormControl>
                    </td>
                  </tr>
                  <tr>
                    <td>&nbsp;</td>
                    <td>&nbsp;</td>
                    <td>&nbsp;</td>
                  </tr>
                  <tr>
                    <td className="VerticalAlignBottom">
                      <Typography variant="caption">
                        Policy Data Source
                      </Typography>
                      <FormControlLabel
                        control={
                          <Radio
                            color="primary"
                            name="holdingInquiry"
                            value="true"
                            checked={
                              this.props.dialogdata.holdingInquiry == "true"
                            }
                            onChange={this.handleRadioChange}
                          />
                        }
                        label="ALIP"
                      />
                      <FormControlLabel
                        control={
                          <Radio
                            color="primary"
                            name="holdingInquiry"
                            value="false"
                            checked={
                              this.props.dialogdata.holdingInquiry == "false"
                            }
                            onChange={this.handleRadioChange}
                          />
                        }
                        label="Cassandra"
                      />
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </DialogContent>
          <DialogActions>
            <Button onClick={this.handleReprocess} color="primary">
              ReProcess
            </Button>
            <Button
              onClick={() => this.handleClose("reprocess")}
              color="primary"
            >
              Close
            </Button>
          </DialogActions>
        </Dialog>
      </React.Fragment>
    );
  }
}

PolicyChangeDialog.defaultProps = {
  openReProcessDialog: false
};

const mapStateToProps = state => ({
  dialogdata: state.sidebar.reprocessPolicyChangeDialog
});

const mapDispatchToProps = dispatch =>
  bindActionCreators(
    {
      getReProcessPolicyChangeDialog,
      addReProcessPolicyChangeDialog,
      delReProcessPolicyChangeDialog
    },
    dispatch
  );

PolicyChangeDialog.propTypes = {
  getReProcessPolicyChangeDialog: PropTypes.func,
  addReProcessPolicyChangeDialog: PropTypes.func,
  delReProcessPolicyChangeDialog: PropTypes.func,
  handleClose: PropTypes.func,
  showSuccessNotification: PropTypes.func,
  showErrorNotification: PropTypes.func,
  showInfoNotification: PropTypes.func,
  dialogdata: PropTypes.object,
  className: PropTypes.string,
  button1Name: PropTypes.string,
  button2Name: PropTypes.string,
  selectedId: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
  stepNumber: PropTypes.number,
  holdingInquiry: PropTypes.bool,
  icon: PropTypes.bool,
  open: PropTypes.bool,
  cycleDate: PropTypes.string
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withStyles(snackbarContentStyle)(PolicyChangeDialog));
