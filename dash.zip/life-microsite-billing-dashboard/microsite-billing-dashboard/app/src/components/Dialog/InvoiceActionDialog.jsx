import React from "react";
import PropTypes from "prop-types";

import Button from "@material-ui/core/Button";
import Dialog from "@material-ui/core/Dialog";
import Tooltip from "@material-ui/core/Tooltip";
import PageviewTwoTone from "@material-ui/icons/PageviewTwoTone";
import SaveAltTwoTone from "@material-ui/icons/SaveAltTwoTone";
import PrintTwoTone from "@material-ui/icons/PrintTwoTone";
import EmailTwoTone from "@material-ui/icons/EmailTwoTone";
import InfoOutlined from "@material-ui/icons/InfoOutlined";

import Snackbar from "components/Snackbar/Snackbar.jsx";
import PDFViewer from "utils/PDFViewer.jsx";
import EmailSender from "utils/EmailSender.jsx";
import PrintSender from "utils/PrintSender.jsx";
import { DialogTitle, DialogContent, DialogActions } from "./CommonDialog.jsx";
import {
  getData,
  postData,
  getBinaryData,
  formatDateWithPattern,
  isUserAuthorized,
  getFromLocalStorage
} from "utils/CommonFunctions.jsx";
import APIURIs from "properties/APIURIs.jsx";
import requireAuth from "utils/AuthenticatedComponent.jsx";

function getDocument(billId, polCont, transRefGUID) {
  //billId = "0001";
  //polCont = "05E119";
  return getBinaryData(
    APIURIs.BILL_INVOICE_GETDOC_URI,
    APIURIs.BILL_INVOICE_GETDOC_APIKEY,
    {
      billId,
      polCont,
      transRefGUID
    },
    "Invoice.pdf",
    ""
  );
}

function getDocumentAsText(billId, polCont, transRefGUID) {
  //billId = "0001";
  //polCont = "05E119";
  return postData(
    APIURIs.BILL_INVOICE_GETDOC_URI +
      "billId=" +
      billId +
      "&polCont=" +
      polCont +
      "&transRefGUID=" +
      transRefGUID,
    APIURIs.BILL_INVOICE_GETDOC_APIKEY,
    {},
    "Invoice.pdf",
    ""
  );
}

function isAuthorized() {
  return isUserAuthorized("invoice", "print");
}

function printDocument(transRefGUID, location) {
  let printDestFlag = "N";
  if (location == "reprint") {
    printDestFlag = "R";
  }
  return getData(
    APIURIs.BILL_INVOICE_PRINTDOC_URI,
    APIURIs.BILL_INVOICE_PRINTDOC_APIKEY,
    {
      transRefGUID,
      printDest: printDestFlag,
      userName: getFromLocalStorage("userId")
    }
  );
}

class InvoiceActionDialog extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      openPreview: false,
      openPrint: false,
      openEmail: false,
      openPrintPreview: false,
      openDownload: false,
      fullWidth: true,
      maxWidth: "sm",
      numPages: null,
      file: "",
      successElt: false,
      errorElt: false,
      infoElt: false,
      successMessage: "",
      failureMessage: "",
      infoMessage: "",
      emailPreview:
        "As requested, attached is the premium notice for your AIG " +
        "policy <b>[policyCont]</b> for the payment due <b>[billDueDate]" +
        "</b>. If you did not " +
        "request this, please contact us immediately at <b>844-452-3832</b>." +
        "<br/><br/><b>Note:</b> To view your invoice, you require 14 digit password. The first 10 " +
        "digits of your password are the 10 digits of policy number, followed by the " +
        "Insured's month and date of birth (in MMDD format)." +
        "<br/><br/>For example, if your policy number is 7788777123 and the Insured’s DOB " +
        "is March 23<sup>rd</sup> then your password would be 77887771230323." +
        "<br/><br/><i>Please do not reply to this email. Any questions you have " +
        "related to this policy or premium notice should be directed " +
        "to our Customer Service team at</i> <b>844-452-3832</b>.<br/><br/>Thank you,<br/><br/>AIG " +
        "Customer Service"
    };
  }

  onDocumentLoadSuccess = ({ numPages }) => {
    this.setState({ numPages });
  };

  handleDownload = type => {
    this.props.showLoading();
    if (type == "email") {
      this.emailSenderRef.setLoading(true);
    }
    getDocument(
      this.props.billId,
      this.props.policyCont,
      this.props.transRefGUID
    )
      .then(res => {
        if (res.status === 200) {
          this.setState({
            successMessage: "Invoice successfully downloaded"
          });
          this.showNotification("successElt");
        } else if (res.data === "No records found!") {
          this.setState({
            infoMessage: "No invoice found!"
          });
          this.showNotification("infoElt");
        } else {
          this.setState({
            failureMessage: "Error downloading invoice!"
          });
          this.showNotification("errorElt");
        }
        this.props.hideLoading();
        if (type == "email") {
          this.emailSenderRef.setLoading(false);
        }
      })
      .catch(error => {
        console.warn(error);
        this.props.hideLoading();
        if (type == "email") {
          this.emailSenderRef.setLoading(false);
        }
      });
  };

  handleOpen = actionType => {
    switch (actionType) {
      case "preview":
        this.setState({ openPreview: true });
        break;
      case "print":
        this.setState({ openPrint: true });
        break;
      case "download":
        this.setState(
          {
            openDownload: true
          },
          () => {
            this.handleDownload();
          }
        );
        break;
      case "email":
        this.setState({ openEmail: true });
        break;
    }
  };

  handleClose = actionType => {
    switch (actionType) {
      case "preview":
        this.setState({ openPreview: false });
        break;
      case "print":
        this.setState({ openPrint: false });
        break;
      case "email":
        this.setState({ openEmail: false });
        break;
      case "printPreview":
        this.setState({ openPrintPreview: false });
        break;
    }
  };

  handlePrint = location => {
    this.props.showLoading();
    printDocument(this.props.transRefGUID, location)
      .then(res => {
        if (res.status === 200) {
          this.handleNotification(
            "success",
            "Print request successfully sent",
            "print"
          );
        } else if (res.data === "No records found!") {
          this.handleNotification("info", "No invoice found!", "print");
        } else {
          this.handleNotification(
            "failure",
            "Failed to send print request!",
            "print"
          );
        }
        this.props.hideLoading();
      })
      .catch(error => {
        console.warn(error);
        this.handleNotification(
          "failure",
          "Failed to send print request!",
          "print"
        );
        this.handleClose("print");
        this.props.hideLoading();
      });
  };

  handlePreviewDialogEntering = (billId, polCont, transRefGUID) => {
    this.props.showLoading();
    getDocumentAsText(billId, polCont, transRefGUID)
      .then(res => {
        if (res.status === 200) {
          this.setState({ file: atob(res.data.content) });
          this.handleOpen("preview");
        } else if (res.data === "No records found!") {
          this.setState({
            infoMessage: "No invoice found!"
          });
          this.showNotification("infoElt");
        } else {
          this.setState({
            failureMessage: "Error pre-viewing invoice!"
          });
          this.showNotification("errorElt");
        }
        this.props.hideLoading();
      })
      .catch(error => {
        console.warn(error);
        this.props.hideLoading();
      });
  };

  handleNotification = (messageType, message, dialogType) => {
    if (messageType == "success") {
      this.setState(
        {
          successMessage: message
        },
        () => {
          this.showNotification("successElt");
        }
      );
      this.handleClose(dialogType);
    } else if (messageType == "info") {
      this.setState(
        {
          infoMessage: message
        },
        () => {
          this.showNotification("infoElt");
        }
      );
      this.handleClose(dialogType);
    } else {
      this.setState(
        {
          failureMessage: message
        },
        () => {
          this.showNotification("errorElt");
        }
      );
      this.handleClose(dialogType);
    }
  };

  handleMaxWidthChange = event => {
    this.setState({ maxWidth: event.target.value });
  };

  handleFullWidthChange = event => {
    this.setState({ fullWidth: event.target.checked });
  };

  showNotification(place) {
    var x = [];
    x[place] = true;
    this.setState(x);
    this.alertTimeout = setTimeout(
      function() {
        x[place] = false;
        this.setState(x);
      }.bind(this),
      6000
    );
  }

  render() {
    return (
      <React.Fragment>
        <Tooltip title="Preview">
          <a
            role="button"
            style={{
              cursor: "pointer"
            }}
            onClick={() => {
              if (this.props.status == "completed") {
                return this.handlePreviewDialogEntering(
                  this.props.billId,
                  this.props.policyCont,
                  this.props.transRefGUID
                );
              }
            }}
          >
            <b>
              <PageviewTwoTone
                style={{
                  color:
                    this.props.status == "completed" ? "#8d6e63" : "#CCCCCC",
                  transition: "all .3s ease"
                }}
              />
            </b>
          </a>
        </Tooltip>
        <Tooltip title="Download">
          <a
            role="button"
            style={{
              cursor: "pointer"
            }}
            onClick={() => {
              if (this.props.status == "completed") {
                this.handleOpen("download");
              }
            }}
          >
            <b>
              <SaveAltTwoTone
                style={{
                  color:
                    this.props.status == "completed" ? "#006064" : "#CCCCCC",
                  transition: "all .3s ease"
                }}
              />
            </b>
          </a>
        </Tooltip>
        {isAuthorized() ? (
          <Tooltip title="Print">
            <a
              role="button"
              style={{
                cursor: "pointer"
              }}
              onClick={() => {
                if (
                  this.props.status == "completed" &&
                  this.props.billCommType != "E"
                ) {
                  this.handleOpen("print");
                }
              }}
            >
              <b>
                <PrintTwoTone
                  style={{
                    color:
                      this.props.status == "completed" &&
                      this.props.billCommType != "E"
                        ? "#1565c0"
                        : "#CCCCCC",
                    transition: "all .3s ease"
                  }}
                />
              </b>
            </a>
          </Tooltip>
        ) : (
          ""
        )}
        <Tooltip title="Email">
          <a
            role="button"
            style={{
              cursor: "pointer"
            }}
            onClick={() => {
              if (this.props.status == "completed" && this.props.isEmail) {
                this.handleOpen("email");
              }
            }}
          >
            <b>
              <EmailTwoTone
                style={{
                  color:
                    this.props.status == "completed" && this.props.isEmail
                      ? "#e57373"
                      : "#CCCCCC",
                  transition: "all .3s ease"
                }}
              />
            </b>
          </a>
        </Tooltip>
        {/* Preview Dialog */}
        <Dialog
          aria-labelledby="customized-dialog-title"
          open={this.state.openPreview}
          onClose={() => this.handleClose("preview")}
          maxWidth="lg"
          modal="true"
        >
          <DialogTitle
            id="customized-dialog-title"
            onClose={() => this.handleClose("preview")}
          >
            <b>Preview</b>
          </DialogTitle>
          <DialogContent style={{ padding: "0 0px 0px", overflowX: "hidden" }}>
            <div style={{ height: "730px", width: "825px" }}>
              <PDFViewer file={this.state.file} disableFontFace={true} />
            </div>
          </DialogContent>
          <DialogActions>
            <Button onClick={() => this.handleClose("preview")} color="primary">
              Close
            </Button>
          </DialogActions>
        </Dialog>
        {/* Print Dialog */}
        <Dialog
          open={this.state.openPrint}
          onClose={() => this.handleClose("print")}
          aria-labelledby="customized-dialog-title"
        >
          <PrintSender
            handleClose={() => this.handleClose("print")}
            handlePrint={location => this.handlePrint(location)}
          />
        </Dialog>
        <Snackbar
          place="tr"
          color="success"
          icon={InfoOutlined}
          message={this.state.successMessage}
          open={this.state.successElt}
          closeNotification={() => this.setState({ successElt: false })}
          close
        />
        <Snackbar
          place="tr"
          color="danger"
          icon={InfoOutlined}
          message={this.state.failureMessage}
          open={this.state.errorElt}
          closeNotification={() => this.setState({ errorElt: false })}
          close
        />
        <Snackbar
          place="tr"
          color="info"
          icon={InfoOutlined}
          message={this.state.infoMessage}
          open={this.state.infoElt}
          closeNotification={() => this.setState({ infoElt: false })}
          close
        />
        {/* Email Dialog */}
        <Dialog
          fullWidth={this.state.fullWidth}
          maxWidth="sm"
          open={this.state.openEmail}
          onClose={() => this.handleClose("email")}
          aria-labelledby="customized-dialog-title"
        >
          <EmailSender
            onRef={emailSender => {
              this.emailSenderRef = emailSender;
            }}
            subject={"Bill Invoice Statement - " + this.props.policyCont}
            fileName="Invoice.pdf"
            params={{
              billId: this.props.billId,
              polCont: this.props.policyCont,
              billDueDate: this.props.billDueDate,
              transRefGUID: this.props.transRefGUID
            }}
            emailPreview={this.state.emailPreview
              .toString()
              .replace("[policyCont]", this.props.policyCont)
              .replace(
                "[billDueDate]",
                formatDateWithPattern(this.props.billDueDate, "MM/DD/YYYY")
              )}
            openDownload={() => this.handleOpen("download")}
            handleClose={() => this.handleClose("email")}
            handleDownload={() => this.handleDownload("email")}
            uri={APIURIs.BILL_INVOICE_EMAIL_URI}
          />
        </Dialog>
        {/* PrintPreview Dialog */}
        <Dialog
          fullWidth={this.state.fullWidth}
          maxWidth="md"
          open={this.state.openPrintPreview}
          onClose={() => this.handleClose("printPreview")}
          aria-labelledby="customized-dialog-title"
        >
          <DialogTitle
            id="customized-dialog-title"
            onClose={() => this.handleClose("email")}
          >
            <b>Print Preview</b>
          </DialogTitle>
          <DialogContent>
            <b>Print</b>
          </DialogContent>
          <DialogActions>
            <Button
              onClick={() => this.handleClose("printPreview")}
              color="primary"
            >
              Close
            </Button>
          </DialogActions>
        </Dialog>
      </React.Fragment>
    );
  }
}

InvoiceActionDialog.propTypes = {
  data: PropTypes.string,
  title: PropTypes.string,
  stepNumber: PropTypes.number,
  processType: PropTypes.string,
  selectedId: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
  billId: PropTypes.string,
  policyCont: PropTypes.string,
  transRefGUID: PropTypes.string,
  status: PropTypes.string,
  showLoading: PropTypes.func,
  hideLoading: PropTypes.func,
  billDueDate: PropTypes.string,
  isEmail: PropTypes.bool,
  billCommType: PropTypes.string
};

export default requireAuth(InvoiceActionDialog, "mainContent");
