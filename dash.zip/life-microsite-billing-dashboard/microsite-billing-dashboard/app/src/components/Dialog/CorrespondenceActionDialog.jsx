import React from "react";
import PropTypes from "prop-types";

import Button from "@material-ui/core/Button";
import Dialog from "@material-ui/core/Dialog";
import Tooltip from "@material-ui/core/Tooltip";
import PageviewTwoTone from "@material-ui/icons/PageviewTwoTone";
import SaveAltTwoTone from "@material-ui/icons/SaveAltTwoTone";
import EmailTwoTone from "@material-ui/icons/EmailTwoTone";
import InfoOutlined from "@material-ui/icons/InfoOutlined";

import Snackbar from "components/Snackbar/Snackbar.jsx";
import PDFViewer from "utils/PDFViewer.jsx";
import EmailSender from "utils/EmailSender.jsx";
import { DialogTitle, DialogContent, DialogActions } from "./CommonDialog.jsx";
import {
  postData,
  getBinaryData,
  formatDateWithPattern
} from "utils/CommonFunctions.jsx";
import APIURIs from "properties/APIURIs.jsx";
import requireAuth from "utils/AuthenticatedComponent.jsx";

function getDocument(transRefGUID) {
  return getBinaryData(
    APIURIs.CORRESPONDENCE_GETDOC_URI,
    APIURIs.CORRESPONDENCE_GETDOC_APIKEY,
    {
      transRefGUID
    },
    "Correspondence.pdf",
    ""
  );
}

function getDocumentAsText(transRefGUID) {
  return postData(
    APIURIs.CORRESPONDENCE_GETDOC_URI + "transRefGUID=" + transRefGUID,
    APIURIs.CORRESPONDENCE_GETDOC_APIKEY,
    {},
    "Correspondence.pdf",
    ""
  );
}

class CorrespondenceActionDialog extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      openPreview: false,
      openPrint: false,
      openEmail: false,
      openPrintPreview: false,
      openDownload: false,
      fullWidth: true,
      maxWidth: "sm",
      numPages: null,
      file: "",
      successElt: false,
      errorElt: false,
      infoElt: false,
      successMessage: "",
      failureMessage: "",
      infoMessage: "",
      emailPreview:
        "As requested, attached please find a copy of the <b> " +
        "[eventCodeType]</b> that was generated on <b>[cycleDate]" +
        "</b> and sent to <b>[payorName]</b> through mail." +
        "<br/><br/><i>Please do not reply to this email. If you haven't " +
        "requested for a copy of this letter or have any questions, please " +
        "call the Customer Service team at</i> <b>844-452-3832</b>.<br/><br/>Thank you,<br/><br/>AIG " +
        "Customer Service"
    };
  }

  onDocumentLoadSuccess = ({ numPages }) => {
    this.setState({ numPages });
  };

  handleDownload = type => {
    this.props.showLoading();
    if (type == "email") {
      this.emailSenderRef.setLoading(true);
    }
    getDocument(this.props.transRefGUID)
      .then(res => {
        if (res.status === 200) {
          this.setState({
            successMessage: "Correspondence successfully downloaded"
          });
          this.showNotification("successElt");
        } else if (res.data === "No records found!") {
          this.setState({
            infoMessage: "No correspondence found!"
          });
          this.showNotification("infoElt");
        } else {
          this.setState({
            failureMessage: "Error downloading correspondence!"
          });
          this.showNotification("errorElt");
        }
        this.props.hideLoading();
        if (type == "email") {
          this.emailSenderRef.setLoading(false);
        }
      })
      .catch(error => {
        console.warn(error);
        this.props.hideLoading();
        if (type == "email") {
          this.emailSenderRef.setLoading(false);
        }
      });
  };

  handleOpen = actionType => {
    switch (actionType) {
      case "preview":
        this.setState({ openPreview: true });
        break;
      case "print":
        this.setState({ openPrint: true });
        break;
      case "download":
        this.setState(
          {
            openDownload: true
          },
          () => {
            this.handleDownload();
          }
        );
        break;
      case "email":
        this.setState({ openEmail: true });
        break;
    }
  };

  handleClose = actionType => {
    switch (actionType) {
      case "preview":
        this.setState({ openPreview: false });
        break;
      case "print":
        this.setState({ openPrint: false });
        break;
      case "email":
        this.setState({ openEmail: false });
        break;
      case "printPreview":
        this.setState({ openPrintPreview: false });
        break;
    }
  };

  handlePreviewDialogEntering = transRefGUID => {
    this.props.showLoading();
    getDocumentAsText(transRefGUID)
      .then(res => {
        if (res.status === 200) {
          this.setState({ file: atob(res.data.content) });
          this.handleOpen("preview");
        } else if (res.data === "No records found!") {
          this.setState({
            infoMessage: "No correspondence found!"
          });
          this.showNotification("infoElt");
        } else {
          this.setState({
            failureMessage: "Error pre-viewing correspondence!"
          });
          this.showNotification("errorElt");
        }
        this.props.hideLoading();
      })
      .catch(error => {
        console.warn(error);
        this.props.hideLoading();
      });
  };

  handleNotification = (messageType, message, dialogType) => {
    if (messageType == "success") {
      this.setState(
        {
          successMessage: message
        },
        () => {
          this.showNotification("successElt");
        }
      );
      this.handleClose(dialogType);
    } else if (messageType == "info") {
      this.setState(
        {
          infoMessage: message
        },
        () => {
          this.showNotification("infoElt");
        }
      );
      this.handleClose(dialogType);
    } else {
      this.setState(
        {
          failureMessage: message
        },
        () => {
          this.showNotification("errorElt");
        }
      );
      this.handleClose(dialogType);
    }
  };

  handleMaxWidthChange = event => {
    this.setState({ maxWidth: event.target.value });
  };

  handleFullWidthChange = event => {
    this.setState({ fullWidth: event.target.checked });
  };

  showNotification(place) {
    var x = [];
    x[place] = true;
    this.setState(x);
    this.alertTimeout = setTimeout(
      function() {
        x[place] = false;
        this.setState(x);
      }.bind(this),
      6000
    );
  }

  render() {
    return (
      <React.Fragment>
        <Tooltip title="Preview">
          <a
            role="button"
            style={{
              cursor: "pointer"
            }}
            onClick={() => {
              if (this.props.status == "completed") {
                return this.handlePreviewDialogEntering(
                  this.props.transRefGUID
                );
              }
            }}
          >
            <b>
              <PageviewTwoTone
                style={{
                  color:
                    this.props.status == "completed" ? "#8d6e63" : "#CCCCCC",
                  transition: "all .3s ease"
                }}
              />
            </b>
          </a>
        </Tooltip>
        <Tooltip title="Download">
          <a
            role="button"
            style={{
              cursor: "pointer"
            }}
            onClick={() => {
              if (this.props.status == "completed") {
                this.handleOpen("download");
              }
            }}
          >
            <b>
              <SaveAltTwoTone
                style={{
                  color:
                    this.props.status == "completed" ? "#006064" : "#CCCCCC",
                  transition: "all .3s ease"
                }}
              />
            </b>
          </a>
        </Tooltip>
        <Tooltip title="Email">
          <a
            role="button"
            style={{
              cursor: "pointer"
            }}
            onClick={() => {
              if (this.props.status == "completed") {
                this.handleOpen("email");
              }
            }}
          >
            <b>
              <EmailTwoTone
                style={{
                  color:
                    this.props.status == "completed" ? "#e57373" : "#CCCCCC",
                  transition: "all .3s ease"
                }}
              />
            </b>
          </a>
        </Tooltip>
        {/* Preview Dialog */}
        <Dialog
          aria-labelledby="customized-dialog-title"
          open={this.state.openPreview}
          onClose={() => this.handleClose("preview")}
          maxWidth="lg"
          modal="true"
        >
          <DialogTitle
            id="customized-dialog-title"
            onClose={() => this.handleClose("preview")}
          >
            <b>Preview</b>
          </DialogTitle>
          <DialogContent style={{ padding: "0 0px 0px", overflowX: "hidden" }}>
            <div style={{ height: "730px", width: "825px" }}>
              <PDFViewer file={this.state.file} disableFontFace={true} />
            </div>
          </DialogContent>
          <DialogActions>
            <Button onClick={() => this.handleClose("preview")} color="primary">
              Close
            </Button>
          </DialogActions>
        </Dialog>
        <Snackbar
          place="tr"
          color="success"
          icon={InfoOutlined}
          message={this.state.successMessage}
          open={this.state.successElt}
          closeNotification={() => this.setState({ successElt: false })}
          close
        />
        <Snackbar
          place="tr"
          color="danger"
          icon={InfoOutlined}
          message={this.state.failureMessage}
          open={this.state.errorElt}
          closeNotification={() => this.setState({ errorElt: false })}
          close
        />
        <Snackbar
          place="tr"
          color="info"
          icon={InfoOutlined}
          message={this.state.infoMessage}
          open={this.state.infoElt}
          closeNotification={() => this.setState({ infoElt: false })}
          close
        />
        {/* Email Dialog */}
        <Dialog
          fullWidth={this.state.fullWidth}
          maxWidth="sm"
          open={this.state.openEmail}
          onClose={() => this.handleClose("email")}
          aria-labelledby="customized-dialog-title"
        >
          <EmailSender
            onRef={emailSender => {
              this.emailSenderRef = emailSender;
            }}
            subject={this.props.eventCodeType}
            fileName="Correspondence.pdf"
            params={{
              transRefGUID: this.props.transRefGUID,
              letterType: this.props.eventCodeType
                .replace("Bank Draft ", "")
                .replace("EBill ", ""),
              payorName: this.props.payorName,
              cycleDate: this.props.cycleDate
            }}
            emailPreview={this.state.emailPreview
              .toString()
              .replace("[eventCodeType]", this.props.eventCodeType)
              .replace("[payorName]", this.props.payorName)
              .replace(
                "[cycleDate]",
                formatDateWithPattern(this.props.cycleDate, "MM/DD/YYYY")
              )}
            openDownload={() => this.handleOpen("download")}
            handleClose={() => this.handleClose("email")}
            handleDownload={() => this.handleDownload("email")}
            uri={APIURIs.CORRESPONDENCE_EMAIL_URI}
          />
        </Dialog>
        {/* PrintPreview Dialog */}
        <Dialog
          fullWidth={this.state.fullWidth}
          maxWidth="md"
          open={this.state.openPrintPreview}
          onClose={() => this.handleClose("printPreview")}
          aria-labelledby="customized-dialog-title"
        >
          <DialogTitle
            id="customized-dialog-title"
            onClose={() => this.handleClose("email")}
          >
            <b>Print Preview</b>
          </DialogTitle>
          <DialogContent>
            <b>Print</b>
          </DialogContent>
          <DialogActions>
            <Button
              onClick={() => this.handleClose("printPreview")}
              color="primary"
            >
              Close
            </Button>
          </DialogActions>
        </Dialog>
      </React.Fragment>
    );
  }
}

CorrespondenceActionDialog.propTypes = {
  data: PropTypes.string,
  title: PropTypes.string,
  stepNumber: PropTypes.number,
  processType: PropTypes.string,
  selectedId: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
  controlNum: PropTypes.string,
  policyCont: PropTypes.string,
  transRefGUID: PropTypes.string,
  status: PropTypes.string,
  showLoading: PropTypes.func,
  hideLoading: PropTypes.func,
  cycleDate: PropTypes.string,
  payorName: PropTypes.string,
  eventCodeType: PropTypes.string
};

export default requireAuth(CorrespondenceActionDialog, "mainContent");
