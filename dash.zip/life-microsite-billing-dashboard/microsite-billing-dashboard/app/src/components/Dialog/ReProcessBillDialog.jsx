import React from "react";
import { connect } from "react-redux";
import { bindActionCreators } from "redux";
import PropTypes from "prop-types";

import { withStyles } from "@material-ui/core/styles";
import FormControl from "@material-ui/core/FormControl";
import FormControlLabel from "@material-ui/core/FormControlLabel";
import Select from "@material-ui/core/Select";
import InputLabel from "@material-ui/core/InputLabel";
import InfoOutlined from "@material-ui/icons/InfoOutlined";
import Chip from "@material-ui/core/Chip";
import Dialog from "@material-ui/core/Dialog";
import Button from "@material-ui/core/Button";
import Typography from "@material-ui/core/Typography";
import Radio from "@material-ui/core/Radio";
import DatePickerInput from "components/DatePickerInput/DatePickerInput.jsx";
import paymentMethods, {
  billPaymentMethods
} from "properties/BillPaymentMethods.jsx";

import snackbarContentStyle from "assets/jss/material-dashboard-react/components/snackbarContentStyle.jsx";
import APIURIs from "properties/APIURIs.jsx";
import { DialogTitle, DialogContent, DialogActions } from "./CommonDialog.jsx";
import {
  formatStringToDate,
  postData,
  formatDate,
  convertStringToList,
  getFromLocalStorage
} from "utils/CommonFunctions.jsx";

//Import actions
import {
  getReProcessBillDialog,
  addReProcessBillDialog,
  delReProcessBillDialog
} from "actions/ReProcessBillDialogAction.jsx";

function reprocess(
  billId,
  stepNumber,
  billDueDate,
  holdingInquiry,
  transRefGUID
) {
  // Call Reporting reprocess API
  if (stepNumber === undefined || stepNumber == null) {
    return postData(
      APIURIs.REPORTING_REPROCESS_URI,
      APIURIs.REPORTING_REPROCESS_APIKEY,
      {
        billIds: convertStringToList(billId),
        billDueDate,
        holdingInquiry,
        transRefGuids:
          transRefGUID == null ? [] : convertStringToList(transRefGUID),
        isBulk: false,
        userName: getFromLocalStorage("userId")
      }
    );
  } else {
    // Call Bill reprocess API
    return postData(APIURIs.REPROCESSBILL_URI, APIURIs.REPROCESSBILL_APIKEY, {
      billIds: convertStringToList(billId),
      stepNumber,
      billDueDate,
      holdingInquiry,
      isBulk: false,
      userName: getFromLocalStorage("userId")
    });
  }
}

class ReProcessBillDialog extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      paymentMethods:
        this.props.stepNumber === undefined || this.props.stepNumber == null
          ? paymentMethods
          : billPaymentMethods
    };
  }

  handleRadioChange = event => {
    let reprocessFieldsTmp = Object.assign({}, this.props.dialogdata);
    reprocessFieldsTmp[event.target.name] = event.target.value;
    this.props.addReProcessBillDialog(reprocessFieldsTmp);
  };

  handleReProcDialogEntering = (
    billDueDate,
    paymentMethod,
    paidDate,
    isBusinessError
  ) => {
    // get ReProcess Data
    let reprocessFieldsTmp = Object.assign({}, this.props.dialogdata);
    reprocessFieldsTmp.billDueDate = billDueDate;
    reprocessFieldsTmp.paymentMethod = paymentMethod;
    reprocessFieldsTmp.paidDate = paidDate;
    reprocessFieldsTmp.isBusinessError = isBusinessError;
    this.props.addReProcessBillDialog(reprocessFieldsTmp);
  };

  handleChange = event => {
    let reprocessFieldsTmp = Object.assign({}, this.props.dialogdata);
    reprocessFieldsTmp[event.target.name] = event.target.value;
    this.props.addReProcessBillDialog(reprocessFieldsTmp);
  };

  handleDateChange = (dateName, dateValue) => {
    let reprocessFieldsTmp = Object.assign({}, this.props.dialogdata);
    reprocessFieldsTmp[dateName] = formatDate(dateValue);
    this.props.addReProcessBillDialog(reprocessFieldsTmp);
  };

  handleClose = () => {
    this.props.handleClose("reprocess");
  };

  handleReprocess = () => {
    // If Reporting Reprocess
    if (this.props.stepNumber === undefined || this.props.stepNumber == null) {
      // If not a business error
      if (this.props.dialogdata.reprocessFlag == "N") {
        this.props.showInfoNotification();
        this.props.handleClose("reprocess");
        return;
      }
    } else {
      // If Bill Reprocess and is a business error
      if (this.props.dialogdata.isBusinessError == "Y") {
        this.props.showInfoNotification();
        this.props.handleClose("reprocess");
        return;
      }
    }
    reprocess(
      this.props.selectedId,
      this.props.stepNumber,
      this.props.dialogdata.billDueDate,
      this.props.dialogdata.holdingInquiry,
      this.props.transRefGUID
    ).then(response => {
      if (response.status === 200) {
        this.props.showSuccessNotification();
      } else {
        this.props.showErrorNotification();
      }
      this.props.handleClose("reprocess");
    });
  };

  render() {
    const {
      billDueDate,
      paymentMethod,
      paidDate,
      isBusinessError
    } = this.props;
    return (
      <React.Fragment>
        <Dialog
          aria-labelledby="customized-dialog-title"
          open={this.props.open}
          onClose={this.handleClose}
          onEntering={() => {
            this.handleReProcDialogEntering(
              billDueDate,
              paymentMethod,
              paidDate,
              isBusinessError
            );
          }}
        >
          <DialogTitle
            id="customized-dialog-title"
            onClose={() => this.handleClose("reprocess")}
          >
            <b>{this.props.button2Name}</b>
          </DialogTitle>
          <DialogContent>
            <div style={{ height: "300px", width: "400px" }}>
              <Chip
                icon={<InfoOutlined />}
                label="Edit the fields and click REPROCESS"
                color="primary"
              />

              <table width="100%" border="0px" cellPadding="0" cellSpacing="0">
                <tbody>
                  <tr>
                    <td>&nbsp;</td>
                  </tr>
                  <tr>
                    <td className="VerticalAlignBottom">
                      <FormControl style={{ flexDirection: "row" }}>
                        <Typography variant="caption">
                          <DatePickerInput
                            id="billDueDate"
                            name="billDueDate"
                            placeholderText="Bill Due Date"
                            selected={formatStringToDate(
                              this.props.dialogdata.billDueDate
                            )}
                            onChange={dateValue => {
                              this.handleDateChange("billDueDate", dateValue);
                            }}
                            withPortal
                          />
                        </Typography>
                      </FormControl>
                    </td>
                    <td>&nbsp;</td>
                    <td className="VerticalAlignBottom">
                      <FormControl style={{ flexDirection: "row" }}>
                        <Typography variant="caption">
                          <DatePickerInput
                            id="paidDate"
                            name="paidDate"
                            placeholderText="Paid Date"
                            selected={formatStringToDate(
                              this.props.dialogdata.paidDate
                            )}
                            onChange={dateValue => {
                              this.handleDateChange("paidDate", dateValue);
                            }}
                            withPortal
                            disabled={true}
                          />
                        </Typography>
                      </FormControl>
                    </td>
                  </tr>
                  <tr>
                    <td>&nbsp;</td>
                    <td>&nbsp;</td>
                    <td>&nbsp;</td>
                  </tr>
                  <tr>
                    <td className="VerticalAlignBottom">
                      <FormControl>
                        <InputLabel htmlFor="paymentMethod">
                          Payment Method
                        </InputLabel>
                        <Select
                          native
                          autoWidth={false}
                          style={{ width: 180 }}
                          value={this.props.dialogdata.paymentMethod}
                          onChange={this.handleChange}
                          inputProps={{
                            name: "paymentMethod",
                            id: "paymentMethod"
                          }}
                          disabled={true}
                        >
                          <option value="" />
                          {this.state.paymentMethods.map(option => (
                            <option key={option.value} value={option.value}>
                              {option.label}
                            </option>
                          ))}
                        </Select>
                      </FormControl>
                    </td>
                  </tr>
                  <tr>
                    <td>&nbsp;</td>
                    <td>&nbsp;</td>
                    <td>&nbsp;</td>
                  </tr>
                  <tr>
                    <td className="VerticalAlignBottom">
                      <Typography variant="caption">
                        Policy Data Source
                      </Typography>
                      <FormControlLabel
                        control={
                          <Radio
                            color="primary"
                            name="holdingInquiry"
                            value="true"
                            checked={
                              this.props.dialogdata.holdingInquiry == "true"
                            }
                            onChange={this.handleRadioChange}
                          />
                        }
                        label="ALIP"
                      />
                      <FormControlLabel
                        control={
                          <Radio
                            color="primary"
                            name="holdingInquiry"
                            value="false"
                            checked={
                              this.props.dialogdata.holdingInquiry == "false"
                            }
                            onChange={this.handleRadioChange}
                          />
                        }
                        label="Cassandra"
                      />
                    </td>
                    <td>&nbsp;</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </DialogContent>
          <DialogActions>
            <Button onClick={this.handleReprocess} color="primary">
              ReProcess
            </Button>
            <Button
              onClick={() => this.handleClose("reprocess")}
              color="primary"
            >
              Close
            </Button>
          </DialogActions>
        </Dialog>
      </React.Fragment>
    );
  }
}

ReProcessBillDialog.defaultProps = {
  openReProcessDialog: false
};

const mapStateToProps = state => ({
  dialogdata: state.sidebar.reprocessBillDialog
});

const mapDispatchToProps = dispatch =>
  bindActionCreators(
    {
      getReProcessBillDialog,
      addReProcessBillDialog,
      delReProcessBillDialog
    },
    dispatch
  );

ReProcessBillDialog.propTypes = {
  getReProcessBillDialog: PropTypes.func,
  addReProcessBillDialog: PropTypes.func,
  delReProcessBillDialog: PropTypes.func,
  handleClose: PropTypes.func,
  showSuccessNotification: PropTypes.func,
  showErrorNotification: PropTypes.func,
  showInfoNotification: PropTypes.func,
  dialogdata: PropTypes.object,
  className: PropTypes.string,
  button1Name: PropTypes.string,
  button2Name: PropTypes.string,
  selectedId: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
  stepNumber: PropTypes.number,
  holdingInquiry: PropTypes.bool,
  icon: PropTypes.bool,
  open: PropTypes.bool,
  billDueDate: PropTypes.string,
  paidDate: PropTypes.string,
  paymentMethod: PropTypes.string,
  isBusinessError: PropTypes.string,
  transRefGUID: PropTypes.string
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withStyles(snackbarContentStyle)(ReProcessBillDialog));
