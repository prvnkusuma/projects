import React from "react";
import { connect } from "react-redux";
import { bindActionCreators } from "redux";
import PropTypes from "prop-types";

import { withStyles } from "@material-ui/core/styles";
import InfoOutlined from "@material-ui/icons/InfoOutlined";
import WarningOutlined from "@material-ui/icons/WarningOutlined";
import Chip from "@material-ui/core/Chip";
import Dialog from "@material-ui/core/Dialog";
import Button from "@material-ui/core/Button";
import Typography from "@material-ui/core/Typography";
import Radio from "@material-ui/core/Radio";
import Select from "@material-ui/core/Select";
import FormControl from "@material-ui/core/FormControl";
import FormControlLabel from "@material-ui/core/FormControlLabel";

import GridItem from "components/Grid/GridItem.jsx";
import GridContainer from "components/Grid/GridContainer.jsx";
import DatePickerInput from "components/DatePickerInput/DatePickerInput.jsx";
import CustomMultilineInput from "components/CustomInput/CustomMultilineInput.jsx";

import snackbarContentStyle from "assets/jss/material-dashboard-react/components/snackbarContentStyle.jsx";
import { DialogTitle, DialogContent, DialogActions } from "./CommonDialog.jsx";
import APIURIs from "properties/APIURIs.jsx";
import rejectionTypes from "properties/RejectionTypes.jsx";
import {
  formatStringToDate,
  postData,
  formatDate,
  validateCommaSepList,
  convertStringToList,
  getFromLocalStorage
} from "utils/CommonFunctions.jsx";

//Import actions
import {
  getBulkReProcessEFTReturnsDialog,
  addBulkReProcessEFTReturnsDialog,
  delBulkReProcessEFTReturnsDialog
} from "actions/BulkReProcessEFTReturnsDialogAction.jsx";

const classes = theme => ({
  root: {
    ...theme.mixins.gutters(),
    paddingTop: theme.spacing.unit * 2,
    paddingBottom: theme.spacing.unit * 2
  },
  formControl: {
    margin: theme.spacing.unit,
    minWidth: 120,
    display: "flex",
    wrap: "nowrap"
  },
  group: {
    margin: `${theme.spacing.unit}px 0`
  },
  textField: {
    marginLeft: theme.spacing.unit,
    marginRight: theme.spacing.unit,
    width: 200,
    display: "flex",
    flexWrap: "wrap"
  },
  button: {
    margin: theme.spacing.unit
  },
  InputClasses: {
    fullWidth: true
  }
});

function reprocess(
  cycleDate,
  rejectionType,
  selectedReturnsList,
  reprocessType
) {
  return postData(
    APIURIs.BULKEFTRETURNS_REPROCESS_URI,
    APIURIs.BULKEFTRETURNS_REPROCESS_APIKEY,
    {
      cycleDate: cycleDate,
      eftRejType: rejectionType,
      transRefGuids: reprocessType === "allReturns" ? [] : selectedReturnsList,
      isBulk: true,
      userName: getFromLocalStorage("userId")
    }
  );
}

const defaultValues = {
  disableAllReturnsFields: false,
  disableSelectedReturnsFields: true,
  validationError: false,
  errorCodes: []
};

class BulkReProcessEFTReturnsDialog extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      ...defaultValues
    };
  }

  handleReprocess = () => {
    if (
      this.props.dialogdata.reprocessType === "allReturns" ||
      (this.props.dialogdata.reprocessType === "selectedReturns" &&
        validateCommaSepList(this.props.dialogdata.selectedReturnsList))
    ) {
      let cycleDateToSend = formatDate(this.props.dialogdata.cycleDate);
      let billsStrToSend = this.props.dialogdata.selectedReturnsList;
      if (this.props.dialogdata.reprocessType === "allReturns") {
        billsStrToSend = "";
      } else {
        cycleDateToSend = "";
      }
      var billsListToSend = convertStringToList(billsStrToSend);
      reprocess(
        cycleDateToSend,
        this.props.dialogdata.rejectionType,
        billsListToSend,
        this.props.dialogdata.reprocessType
      ).then(response => {
        if (response) {
          if (response.status === 200) {
            this.props.showSuccessNotification();
          } else if (response.data === "No records found!") {
            this.props.showInfoNotification();
          } else {
            this.props.showErrorNotification();
          }
        } else {
          this.props.showErrorNotification();
        }
        let reprocessFieldsTmp = Object.assign({}, this.props.dialogdata);
        this.props.delBulkReProcessEFTReturnsDialog(reprocessFieldsTmp);
        this.setState({
          ...defaultValues
        });
        this.props.handleClose("reprocess");
      });
    } else {
      this.setState({
        validationError: true
      });
      return;
    }
  };

  handleRadioChange = event => {
    let reprocessFieldsTmp = Object.assign({}, this.props.dialogdata);
    if (event.target.value === "selectedReturns") {
      this.setState({
        disableAllReturnsFields: true,
        disableSelectedReturnsFields: false
      });
      reprocessFieldsTmp[event.target.name] = event.target.value;
    } else if (event.target.value === "allReturns") {
      this.setState({
        disableAllReturnsFields: false,
        disableSelectedReturnsFields: true
      });
      reprocessFieldsTmp.selectedReturnsList = "";
      reprocessFieldsTmp[event.target.name] = event.target.value;
    } else {
      reprocessFieldsTmp[event.target.name] = event.target.value;
    }
    this.props.addBulkReProcessEFTReturnsDialog(reprocessFieldsTmp);
  };

  handleChange = event => {
    let reprocessFieldsTmp = Object.assign({}, this.props.dialogdata);
    reprocessFieldsTmp[event.target.name] = event.target.value;
    this.props.addBulkReProcessEFTReturnsDialog(reprocessFieldsTmp);
  };

  handleDateChange = (dateName, dateValue) => {
    let reprocessFieldsTmp = Object.assign({}, this.props.dialogdata);
    reprocessFieldsTmp[dateName] = formatDate(dateValue);
    this.props.addBulkReProcessEFTReturnsDialog(reprocessFieldsTmp);
  };

  handleClose = actionType => {
    if (actionType === "reprocess") {
      this.setState({
        ...defaultValues
      });
      this.props.handleClose();
    }
    let reprocessFieldsTmp = Object.assign({}, this.props.dialogdata);
    this.props.delBulkReProcessEFTReturnsDialog(reprocessFieldsTmp);
    this.setState({
      ...defaultValues
    });
  };

  render() {
    return (
      <React.Fragment>
        <Dialog
          aria-labelledby="customized-dialog-title"
          open={this.props.open}
          onClose={this.handleClose}
        >
          <DialogTitle
            id="customized-dialog-title"
            onClose={() => this.handleClose("reprocess")}
          >
            <b>{this.props.title}</b>
          </DialogTitle>
          <DialogContent style={{ overflowX: "hidden", overflowY: "hidden" }}>
            <div style={{ height: "400px", width: "400px" }}>
              {this.state.validationError ? (
                <Chip
                  icon={<WarningOutlined />}
                  label="Validation Failed. Please enter bills in valid format and try again."
                  color="secondary"
                />
              ) : (
                <Chip
                  icon={<InfoOutlined />}
                  label="Select the appropriate fields and click REPROCESS"
                  color="primary"
                />
              )}
              <div style={{ paddingTop: "20px" }}>
                <FormControl
                  component="fieldset"
                  className={classes.formControl}
                >
                  <GridContainer
                    style={{ display: "flex", alignItems: "center" }}
                  >
                    <GridItem xs={12} sm={12} md={6}>
                      <Typography variant="caption">
                        <b>Rejection Type:</b>
                      </Typography>
                    </GridItem>
                    <GridItem xs={12} sm={12} md={6}>
                      <FormControl>
                        <Select
                          native
                          autoWidth={false}
                          style={{ width: 150 }}
                          value={this.props.dialogdata.rejectionType}
                          onChange={this.handleChange}
                          inputProps={{
                            name: "rejectionType",
                            id: "rejectionType"
                          }}
                        >
                          {rejectionTypes.map(option => (
                            <option key={option.value} value={option.value}>
                              {option.label}
                            </option>
                          ))}
                        </Select>
                      </FormControl>
                    </GridItem>
                    <GridItem xs={12} sm={12} md={6}>
                      &nbsp;
                    </GridItem>
                    <GridItem xs={12} sm={12} md={6}>
                      &nbsp;
                    </GridItem>
                  </GridContainer>
                  <Typography variant="subheading" className={classes.title}>
                    <b>Select bulk reprocess apply option:</b>
                  </Typography>
                  <FormControlLabel
                    control={
                      <Radio
                        color="primary"
                        name="reprocessType"
                        value="allReturns"
                        checked={
                          this.props.dialogdata.reprocessType === "allReturns"
                        }
                        onChange={this.handleRadioChange}
                      />
                    }
                    label="Apply to all failed returns"
                  />
                  <GridContainer
                    style={{ display: "flex", alignItems: "center" }}
                  >
                    <GridItem xs={12} sm={12} md={6}>
                      <Typography variant="caption">
                        <b>Cycle Date:</b>
                      </Typography>
                    </GridItem>
                    <GridItem xs={12} sm={12} md={6}>
                      <DatePickerInput
                        id="cycleDate"
                        name="cycleDate"
                        placeholderText=""
                        selected={formatStringToDate(
                          this.props.dialogdata.cycleDate
                        )}
                        onChange={dateValue => {
                          this.handleDateChange("cycleDate", dateValue);
                        }}
                        disabled={this.state.disableAllReturnsFields}
                        withPortal
                      />
                    </GridItem>
                    <GridItem xs={12} sm={12} md={6}>
                      &nbsp;
                    </GridItem>
                  </GridContainer>
                  <FormControlLabel
                    control={
                      <Radio
                        color="primary"
                        name="reprocessType"
                        value="selectedReturns"
                        checked={
                          this.props.dialogdata.reprocessType ===
                          "selectedReturns"
                        }
                        onChange={this.handleRadioChange}
                      />
                    }
                    label="Apply to only a selected list of TransRefGUIDs"
                  />
                  <CustomMultilineInput
                    id="selectedReturnsList"
                    name="selectedReturnsList"
                    label="Enter comma separated list of TransRefGUIDs"
                    rowsMax="5"
                    value={this.props.dialogdata.selectedReturnsList}
                    onChange={this.handleChange}
                    className={classes.textField}
                    disabled={this.state.disableSelectedReturnsFields}
                    style={{ width: 400, height: 100 }}
                    inputProps={{
                      maxLength: 4000
                    }}
                  />
                </FormControl>
              </div>
            </div>
          </DialogContent>
          <DialogActions>
            <Button onClick={this.handleReprocess} color="primary">
              ReProcess
            </Button>
            <Button onClick={() => this.handleClose("clear")} color="primary">
              Clear
            </Button>
            <Button
              onClick={() => this.handleClose("reprocess")}
              color="primary"
            >
              Close
            </Button>
          </DialogActions>
        </Dialog>
      </React.Fragment>
    );
  }
}

BulkReProcessEFTReturnsDialog.defaultProps = {
  openReProcessDialog: false
};

const mapStateToProps = state => ({
  dialogdata: state.sidebar.bulkReprocessEFTReturnsDialog
});

const mapDispatchToProps = dispatch =>
  bindActionCreators(
    {
      getBulkReProcessEFTReturnsDialog,
      addBulkReProcessEFTReturnsDialog,
      delBulkReProcessEFTReturnsDialog
    },
    dispatch
  );

BulkReProcessEFTReturnsDialog.propTypes = {
  getBulkReProcessEFTReturnsDialog: PropTypes.func,
  addBulkReProcessEFTReturnsDialog: PropTypes.func,
  delBulkReProcessEFTReturnsDialog: PropTypes.func,
  handleClose: PropTypes.func,
  dialogdata: PropTypes.object,
  className: PropTypes.string,
  selectedId: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
  icon: PropTypes.bool,
  open: PropTypes.bool,
  title: PropTypes.string,
  stepNumber: PropTypes.number,
  showSuccessNotification: PropTypes.func,
  showErrorNotification: PropTypes.func,
  showInfoNotification: PropTypes.func
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withStyles(snackbarContentStyle)(BulkReProcessEFTReturnsDialog));
