import React from "react";
import { connect } from "react-redux";
import { bindActionCreators } from "redux";
import PropTypes from "prop-types";

import { withStyles } from "@material-ui/core/styles";
import InfoOutlined from "@material-ui/icons/InfoOutlined";
import WarningOutlined from "@material-ui/icons/WarningOutlined";
import Chip from "@material-ui/core/Chip";
import Dialog from "@material-ui/core/Dialog";
import Button from "@material-ui/core/Button";
import Typography from "@material-ui/core/Typography";
import Radio from "@material-ui/core/Radio";
import FormControl from "@material-ui/core/FormControl";
import FormControlLabel from "@material-ui/core/FormControlLabel";

import GridItem from "components/Grid/GridItem.jsx";
import GridContainer from "components/Grid/GridContainer.jsx";
import DatePickerInput from "components/DatePickerInput/DatePickerInput.jsx";
import CustomMultilineInput from "components/CustomInput/CustomMultilineInput.jsx";

import snackbarContentStyle from "assets/jss/material-dashboard-react/components/snackbarContentStyle.jsx";
import { DialogTitle, DialogContent, DialogActions } from "./CommonDialog.jsx";
import APIURIs from "properties/APIURIs.jsx";
import {
  formatStringToDate,
  postData,
  formatDate,
  validateCommaSepList,
  convertStringToList,
  getFromLocalStorage
} from "utils/CommonFunctions.jsx";

//Import actions
import {
  getBulkReProcessInvoiceDialog,
  addBulkReProcessInvoiceDialog,
  delBulkReProcessInvoiceDialog
} from "actions/BulkReProcessInvoiceDialogAction.jsx";

const classes = theme => ({
  root: {
    ...theme.mixins.gutters(),
    paddingTop: theme.spacing.unit * 2,
    paddingBottom: theme.spacing.unit * 2
  },
  formControl: {
    margin: theme.spacing.unit,
    minWidth: 120,
    display: "flex",
    wrap: "nowrap"
  },
  group: {
    margin: `${theme.spacing.unit}px 0`
  },
  textField: {
    marginLeft: theme.spacing.unit,
    marginRight: theme.spacing.unit,
    width: 200,
    display: "flex",
    flexWrap: "wrap"
  },
  button: {
    margin: theme.spacing.unit
  },
  InputClasses: {
    fullWidth: true
  }
});

function reprocess(cycleDate, selectedInvoiceList, reprocessType) {
  return postData(
    APIURIs.BULKINVOICE_REPROCESS_URI,
    APIURIs.BULKINVOICE_REPROCESS_APIKEY,
    {
      cycleDate: cycleDate,
      transRefGuids: reprocessType === "allInvoices" ? [] : selectedInvoiceList,
      isBulk: true,
      userName: getFromLocalStorage("userId")
    }
  );
}

const defaultValues = {
  disableAllBillsFields: false,
  disableSelectedBillsFields: true,
  validationError: false
};

class BulkReProcessInvoiceDialog extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      ...defaultValues
    };
  }

  handleReprocess = () => {
    let reprocessType = this.props.dialogdata.reprocessType;
    if (
      reprocessType === "allInvoices" ||
      (reprocessType === "selectedInvoices" &&
        validateCommaSepList(this.props.dialogdata.selectedInvoiceList))
    ) {
      let cycleDateToSend = formatDate(this.props.dialogdata.cycleDate);
      let invoicesStrToSend = this.props.dialogdata.selectedInvoiceList;
      if (this.props.dialogdata.reprocessType === "allInvoices") {
        invoicesStrToSend = "";
      } else {
        cycleDateToSend = "";
      }
      var invoicesListToSend = convertStringToList(invoicesStrToSend);
      reprocess(cycleDateToSend, invoicesListToSend, reprocessType).then(
        response => {
          if (response) {
            if (response.status === 200) {
              this.props.showSuccessNotification();
            } else if (response.data === "No records found!") {
              this.props.showInfoNotification();
            } else {
              this.props.showErrorNotification();
            }
          } else {
            this.props.showErrorNotification();
          }
          let reprocessFieldsTmp = Object.assign({}, this.props.dialogdata);
          this.props.delBulkReProcessInvoiceDialog(reprocessFieldsTmp);
          this.setState({
            ...defaultValues
          });
          this.props.handleClose("reprocess");
        }
      );
    } else {
      this.setState({
        validationError: true
      });
      return;
    }
  };

  handleRadioChange = event => {
    let reprocessFieldsTmp = Object.assign({}, this.props.dialogdata);
    if (event.target.value === "selectedInvoices") {
      this.setState({
        disableAllBillsFields: true,
        disableSelectedBillsFields: false
      });
    } else {
      this.setState({
        disableAllBillsFields: false,
        disableSelectedBillsFields: true
      });
      reprocessFieldsTmp.selectedInvoiceList = "";
    }
    reprocessFieldsTmp[event.target.name] = event.target.value;
    this.props.addBulkReProcessInvoiceDialog(reprocessFieldsTmp);
  };

  handleChange = event => {
    let reprocessFieldsTmp = Object.assign({}, this.props.dialogdata);
    reprocessFieldsTmp[event.target.name] = event.target.value;
    this.props.addBulkReProcessInvoiceDialog(reprocessFieldsTmp);
  };

  handleDateChange = (dateName, dateValue) => {
    let reprocessFieldsTmp = Object.assign({}, this.props.dialogdata);
    reprocessFieldsTmp[dateName] = formatDate(dateValue);
    this.props.addBulkReProcessInvoiceDialog(reprocessFieldsTmp);
  };

  handleClose = actionType => {
    if (actionType === "reprocess") {
      this.setState({
        ...defaultValues
      });
      this.props.handleClose();
    }
    let reprocessFieldsTmp = Object.assign({}, this.props.dialogdata);
    this.props.delBulkReProcessInvoiceDialog(reprocessFieldsTmp);
    this.setState({
      ...defaultValues
    });
  };

  render() {
    return (
      <React.Fragment>
        <Dialog
          aria-labelledby="customized-dialog-title"
          open={this.props.open}
          onClose={this.handleClose}
        >
          <DialogTitle
            id="customized-dialog-title"
            onClose={() => this.handleClose("reprocess")}
          >
            <b>{this.props.title}</b>
          </DialogTitle>
          <DialogContent>
            <div style={{ height: "380px", width: "400px" }}>
              {this.state.validationError ? (
                <Chip
                  icon={<WarningOutlined />}
                  label="Validation Failed. Please enter bills in valid format and try again."
                  color="secondary"
                />
              ) : (
                <Chip
                  icon={<InfoOutlined />}
                  label="Select the appropriate fields and click REPROCESS"
                  color="primary"
                />
              )}
              <div style={{ paddingTop: "20px" }}>
                <FormControl
                  component="fieldset"
                  className={classes.formControl}
                >
                  <Typography variant="subheading" className={classes.title}>
                    <b>Select bulk reprocess apply option:</b>
                  </Typography>
                  <FormControlLabel
                    control={
                      <Radio
                        color="primary"
                        name="reprocessType"
                        value="allInvoices"
                        checked={
                          this.props.dialogdata.reprocessType === "allInvoices"
                        }
                        onChange={this.handleRadioChange}
                      />
                    }
                    label="Apply to all failed Invoices"
                  />
                  <GridContainer
                    style={{ display: "flex", alignItems: "center" }}
                  >
                    <GridItem xs={12} sm={12} md={6}>
                      <Typography variant="caption">
                        <b>Cycle Date:</b>
                      </Typography>
                    </GridItem>
                    <GridItem xs={12} sm={12} md={6}>
                      <DatePickerInput
                        id="cycleDate"
                        name="cycleDate"
                        placeholderText=""
                        selected={formatStringToDate(
                          this.props.dialogdata.cycleDate
                        )}
                        onChange={dateValue => {
                          this.handleDateChange("cycleDate", dateValue);
                        }}
                        disabled={this.state.disableAllBillsFields}
                        withPortal
                      />
                    </GridItem>
                    <GridItem xs={12} sm={12} md={6}>
                      &nbsp;
                    </GridItem>
                    <GridItem xs={12} sm={12} md={6}>
                      &nbsp;
                    </GridItem>
                  </GridContainer>
                  <FormControlLabel
                    control={
                      <Radio
                        color="primary"
                        name="reprocessType"
                        value="selectedInvoices"
                        checked={
                          this.props.dialogdata.reprocessType ===
                          "selectedInvoices"
                        }
                        onChange={this.handleRadioChange}
                      />
                    }
                    label="Apply to only a selected list of TransRefGUIDs"
                  />
                  <CustomMultilineInput
                    id="selectedInvoiceList"
                    name="selectedInvoiceList"
                    label="Enter comma separated list of TransRefGUIDs"
                    rowsMax="5"
                    value={this.props.dialogdata.selectedInvoiceList}
                    onChange={this.handleChange}
                    className={classes.textField}
                    disabled={this.state.disableSelectedBillsFields}
                    style={{ width: 400, height: 100 }}
                    inputProps={{
                      maxLength: 4000
                    }}
                  />
                </FormControl>
              </div>
            </div>
          </DialogContent>
          <DialogActions>
            <Button onClick={this.handleReprocess} color="primary">
              ReProcess
            </Button>
            <Button onClick={() => this.handleClose("clear")} color="primary">
              Clear
            </Button>
            <Button
              onClick={() => this.handleClose("reprocess")}
              color="primary"
            >
              Close
            </Button>
          </DialogActions>
        </Dialog>
      </React.Fragment>
    );
  }
}

BulkReProcessInvoiceDialog.defaultProps = {
  openReProcessDialog: false
};

const mapStateToProps = state => ({
  dialogdata: state.sidebar.bulkReprocessInvoiceDialog
});

const mapDispatchToProps = dispatch =>
  bindActionCreators(
    {
      getBulkReProcessInvoiceDialog,
      addBulkReProcessInvoiceDialog,
      delBulkReProcessInvoiceDialog
    },
    dispatch
  );

BulkReProcessInvoiceDialog.propTypes = {
  getBulkReProcessInvoiceDialog: PropTypes.func,
  addBulkReProcessInvoiceDialog: PropTypes.func,
  delBulkReProcessInvoiceDialog: PropTypes.func,
  handleClose: PropTypes.func,
  dialogdata: PropTypes.object,
  className: PropTypes.string,
  selectedId: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
  icon: PropTypes.bool,
  open: PropTypes.bool,
  title: PropTypes.string,
  stepNumber: PropTypes.number,
  showSuccessNotification: PropTypes.func,
  showErrorNotification: PropTypes.func,
  showInfoNotification: PropTypes.func
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withStyles(snackbarContentStyle)(BulkReProcessInvoiceDialog));
