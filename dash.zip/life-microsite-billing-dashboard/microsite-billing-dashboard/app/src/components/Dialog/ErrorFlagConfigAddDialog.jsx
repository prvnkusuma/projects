import React from "react";
import { connect } from "react-redux";
import { bindActionCreators } from "redux";
import PropTypes from "prop-types";
import SimpleReactValidator from "simple-react-validator";

import TextField from "@material-ui/core/TextField";
import { withStyles } from "@material-ui/core/styles";
import InfoOutlined from "@material-ui/icons/InfoOutlined";
import WarningOutlined from "@material-ui/icons/WarningOutlined";
import Chip from "@material-ui/core/Chip";
import Dialog from "@material-ui/core/Dialog";
import Button from "@material-ui/core/Button";
import Typography from "@material-ui/core/Typography";
import FormControl from "@material-ui/core/FormControl";
import Checkbox from "@material-ui/core/Checkbox";
import InputAdornment from "@material-ui/core/InputAdornment";

import GridItem from "components/Grid/GridItem.jsx";
import GridContainer from "components/Grid/GridContainer.jsx";
import Overlay from "components/CustomWidgets/Overlay.jsx";
import snackbarContentStyle from "assets/jss/material-dashboard-react/components/snackbarContentStyle.jsx";
import { DialogTitle, DialogContent, DialogActions } from "./CommonDialog.jsx";
import APIURIs from "properties/APIURIs.jsx";
import { postData, getFromLocalStorage } from "utils/CommonFunctions.jsx";

//Import actions
import {
  getErrorFlagConfigAddDialog,
  addErrorFlagConfigAddDialog,
  delErrorFlagConfigAddDialog
} from "actions/ErrorFlagConfigAddDialogAction.jsx";

const classes = theme => ({
  root: {
    ...theme.mixins.gutters(),
    paddingTop: theme.spacing.unit * 2,
    paddingBottom: theme.spacing.unit * 2
  },
  formControl: {
    margin: theme.spacing.unit,
    minWidth: 120,
    display: "flex",
    wrap: "nowrap"
  },
  group: {
    margin: `${theme.spacing.unit}px 0`
  },
  textField: {
    marginLeft: theme.spacing.unit,
    marginRight: theme.spacing.unit,
    width: 200,
    display: "flex",
    flexWrap: "wrap"
  },
  button: {
    margin: theme.spacing.unit
  },
  InputClasses: {
    fullWidth: true
  }
});

function createErrorData(dialogdata) {
  return postData(
    APIURIs.ADMIN_ERRORDATA_UPDATE_URI + "/" + dialogdata.errorCode,
    APIURIs.ADMIN_ERRORDATA_UPDATE_APIKEY,
    {
      errorSource: dialogdata.errorSource,
      errorDesc: dialogdata.errorDesc,
      errorOwner: dialogdata.errorOwner,
      insertUser: getFromLocalStorage("userId"),
      awdWorkItem: dialogdata.awdWorkItem,
      reprocessFlag: dialogdata.reprocessFlag,
      awdFlag: dialogdata.awdFlag,
      notificationFlag: dialogdata.notificationFlag
    }
  );
}

const defaultValues = {
  validationError: false,
  validationMsg:
    "Validation Failed. Please enter valid information and try again."
};

class ErrorFlagConfigAddDialog extends React.Component {
  _isMounted = false;
  constructor(props) {
    super(props);

    this.state = {
      ...defaultValues,
      loading: false
    };
    this.validator = new SimpleReactValidator();
  }

  componentDidMount() {
    this._isMounted = true;
  }

  componentWillUnmount() {
    this._isMounted = false;
  }

  handleChange = event => {
    let errorFlagConfigTmp = Object.assign({}, this.props.dialogdata);
    errorFlagConfigTmp[event.target.name] = event.target.value;
    this.props.addErrorFlagConfigAddDialog(errorFlagConfigTmp);
  };

  handleToggle = event => {
    let errorFlagConfigTmp = Object.assign({}, this.props.dialogdata);
    errorFlagConfigTmp[event.target.name] = event.target.checked ? "Y" : "N";
    this.props.addErrorFlagConfigAddDialog(errorFlagConfigTmp);
  };

  handleAddNew = () => {
    let isValidationError = false;
    let validationMsg = "";

    if (!this.validator.fieldValid("errorCode")) {
      isValidationError = true;
      validationMsg = "Validation Failed. Please enter valid Error Code!";
    } else if (!this.validator.fieldValid("errorSource")) {
      isValidationError = true;
      validationMsg = "Validation Failed. Please enter valid Error Source!";
    } else if (!this.validator.fieldValid("errorDesc")) {
      isValidationError = true;
      validationMsg =
        "Validation Failed. Please enter valid Error Description!";
    } else if (!this.validator.fieldValid("errorOwner")) {
      isValidationError = true;
      validationMsg = "Validation Failed. Please enter valid Error Owner!";
    }
    if (this._isMounted) {
      this.setState({
        validationError: isValidationError,
        validationMsg: validationMsg
      });
    }
    if (isValidationError) {
      return;
    }

    createErrorData(this.props.dialogdata)
      .then(response => {
        if (this._isMounted) {
          this.setState({ loading: false });
        }
        if (response && response.status === 200) {
          this.props.showSuccessNotification();
          this.handleClose("close");
        } else {
          this.props.showErrorNotification();
        }
      })
      .catch(error => {
        console.warn(error);
        if (this._isMounted) {
          this.setState({
            loading: false
          });
        }
      });
  };

  handleClose = actionType => {
    if (actionType === "close") {
      this.setState({
        ...defaultValues
      });
      this.props.handleClose();
    }
    this.props.delErrorFlagConfigAddDialog();
    this.setState({
      ...defaultValues
    });
  };

  render() {
    return (
      <React.Fragment>
        <Dialog
          aria-labelledby="customized-dialog-title"
          open={this.props.open}
          onClose={this.handleClose}
        >
          <DialogTitle
            id="customized-dialog-title"
            onClose={() => this.handleClose("close")}
          >
            <b>{this.props.title}</b>
          </DialogTitle>
          <DialogContent>
            <div style={{ height: "470px", width: "550px" }}>
              {this.state.validationError ? (
                <Chip
                  icon={<WarningOutlined />}
                  label={this.state.validationMsg}
                  color="secondary"
                />
              ) : (
                <Chip
                  icon={<InfoOutlined />}
                  label="Input appropriate fields and click Add"
                  color="primary"
                />
              )}
              <div style={{ paddingTop: "20px" }}>
                <Overlay active={this.state.loading} marginTop="150px">
                  <FormControl
                    component="fieldset"
                    className={classes.formControl}
                    style={{ flexDirection: "row" }}
                  >
                    <GridContainer
                      style={{ display: "flex", alignItems: "center" }}
                    >
                      <GridItem xs={12} sm={12} md={6}>
                        <Typography variant="caption">
                          <b>Error Code:</b>
                        </Typography>
                      </GridItem>
                      <GridItem xs={12} sm={12} md={6}>
                        <TextField
                          id="errorCode"
                          name="errorCode"
                          type="search"
                          className={classes.textField}
                          onChange={this.handleChange}
                          value={this.props.dialogdata.errorCode}
                          margin="none"
                          InputProps={{
                            endAdornment: (
                              <InputAdornment position="end">
                                <span style={{ color: "red" }}>*</span>
                              </InputAdornment>
                            )
                          }}
                        />
                        {this.validator.message(
                          "errorCode",
                          this.props.dialogdata.errorCode,
                          "required"
                        )}
                      </GridItem>
                      <GridItem xs={12} sm={12} md={6}>
                        &nbsp;
                      </GridItem>
                      <GridItem xs={12} sm={12} md={6}>
                        &nbsp;
                      </GridItem>
                      <GridItem xs={12} sm={12} md={6}>
                        <Typography variant="caption">
                          <b>Error Source:</b>
                        </Typography>
                      </GridItem>
                      <GridItem xs={12} sm={12} md={6}>
                        <TextField
                          id="errorSource"
                          name="errorSource"
                          type="search"
                          className={classes.textField}
                          onChange={this.handleChange}
                          value={this.props.dialogdata.errorSource}
                          margin="none"
                          InputProps={{
                            endAdornment: (
                              <InputAdornment position="end">
                                <span style={{ color: "red" }}>*</span>
                              </InputAdornment>
                            )
                          }}
                        />
                        {this.validator.message(
                          "errorSource",
                          this.props.dialogdata.errorSource,
                          "required"
                        )}
                      </GridItem>
                      <GridItem xs={12} sm={12} md={6}>
                        &nbsp;
                      </GridItem>
                      <GridItem xs={12} sm={12} md={6}>
                        &nbsp;
                      </GridItem>
                      <GridItem xs={12} sm={12} md={6}>
                        <Typography variant="caption">
                          <b>Error Description:</b>
                        </Typography>
                      </GridItem>
                      <GridItem xs={12} sm={12} md={6}>
                        <TextField
                          id="errorDesc"
                          name="errorDesc"
                          type="search"
                          className={classes.textField}
                          onChange={this.handleChange}
                          value={this.props.dialogdata.errorDesc}
                          margin="none"
                          InputProps={{
                            endAdornment: (
                              <InputAdornment position="end">
                                <span style={{ color: "red" }}>*</span>
                              </InputAdornment>
                            )
                          }}
                        />
                        {this.validator.message(
                          "errorDesc",
                          this.props.dialogdata.errorDesc,
                          "required"
                        )}
                      </GridItem>
                      <GridItem xs={12} sm={12} md={6}>
                        &nbsp;
                      </GridItem>
                      <GridItem xs={12} sm={12} md={6}>
                        &nbsp;
                      </GridItem>
                      <GridItem xs={12} sm={12} md={6}>
                        <Typography variant="caption">
                          <b>AWD Work Item:</b>
                        </Typography>
                      </GridItem>
                      <GridItem xs={12} sm={12} md={6}>
                        <TextField
                          id="awdWorkItem"
                          name="awdWorkItem"
                          type="search"
                          className={classes.textField}
                          onChange={this.handleChange}
                          value={this.props.dialogdata.awdWorkItem}
                          margin="none"
                        />
                      </GridItem>
                      <GridItem xs={12} sm={12} md={6}>
                        &nbsp;
                      </GridItem>
                      <GridItem xs={12} sm={12} md={6}>
                        &nbsp;
                      </GridItem>
                      <GridItem xs={12} sm={12} md={6}>
                        <Typography variant="caption">
                          <b>Error Owner:</b>
                        </Typography>
                      </GridItem>
                      <GridItem xs={12} sm={12} md={6}>
                        <TextField
                          id="errorOwner"
                          name="errorOwner"
                          type="search"
                          className={classes.textField}
                          onChange={this.handleChange}
                          value={this.props.dialogdata.errorOwner}
                          margin="none"
                          InputProps={{
                            endAdornment: (
                              <InputAdornment position="end">
                                <span style={{ color: "red" }}>*</span>
                              </InputAdornment>
                            )
                          }}
                        />
                        {this.validator.message(
                          "errorOwner",
                          this.props.dialogdata.errorOwner,
                          "required"
                        )}
                      </GridItem>
                      <GridItem xs={12} sm={12} md={6}>
                        &nbsp;
                      </GridItem>
                      <GridItem xs={12} sm={12} md={6}>
                        &nbsp;
                      </GridItem>
                      <GridItem xs={12} sm={12} md={6}>
                        <Typography variant="caption">
                          <b>Reprocess Flag:</b>
                        </Typography>
                      </GridItem>
                      <GridItem xs={12} sm={12} md={6}>
                        <Checkbox
                          name="reprocessFlag"
                          style={{ padding: "0px" }}
                          checked={
                            this.props.dialogdata.reprocessFlag == "Y"
                              ? true
                              : false
                          }
                          value={this.props.dialogdata.reprocessFlag}
                          onChange={this.handleToggle}
                          color="primary"
                        />
                      </GridItem>
                      <GridItem xs={12} sm={12} md={6}>
                        &nbsp;
                      </GridItem>
                      <GridItem xs={12} sm={12} md={6}>
                        &nbsp;
                      </GridItem>
                      <GridItem xs={12} sm={12} md={6}>
                        <Typography variant="caption">
                          <b>AWD Flag:</b>
                        </Typography>
                      </GridItem>
                      <GridItem xs={12} sm={12} md={6}>
                        <Checkbox
                          name="awdFlag"
                          style={{ padding: "0px" }}
                          checked={
                            this.props.dialogdata.awdFlag == "Y" ? true : false
                          }
                          value={this.props.dialogdata.awdFlag}
                          onChange={this.handleToggle}
                          color="primary"
                        />
                      </GridItem>
                      <GridItem xs={12} sm={12} md={6}>
                        &nbsp;
                      </GridItem>
                      <GridItem xs={12} sm={12} md={6}>
                        &nbsp;
                      </GridItem>
                      <GridItem xs={12} sm={12} md={6}>
                        <Typography variant="caption">
                          <b>Notification Flag:</b>
                        </Typography>
                      </GridItem>
                      <GridItem xs={12} sm={12} md={6}>
                        <Checkbox
                          name="notificationFlag"
                          style={{ padding: "0px" }}
                          checked={
                            this.props.dialogdata.notificationFlag == "Y"
                              ? true
                              : false
                          }
                          value={this.props.dialogdata.notificationFlag}
                          onChange={this.handleToggle}
                          color="primary"
                        />
                      </GridItem>
                    </GridContainer>
                  </FormControl>
                </Overlay>
              </div>
            </div>
          </DialogContent>
          <DialogActions>
            <Button onClick={this.handleAddNew} color="primary">
              Add
            </Button>
            <Button onClick={() => this.handleClose("clear")} color="primary">
              Clear
            </Button>
            <Button onClick={() => this.handleClose("close")} color="primary">
              Close
            </Button>
          </DialogActions>
        </Dialog>
      </React.Fragment>
    );
  }
}

ErrorFlagConfigAddDialog.defaultProps = {
  openReProcessDialog: false
};

const mapStateToProps = state => ({
  dialogdata: state.sidebar.errorDataConfigAdd
});

const mapDispatchToProps = dispatch =>
  bindActionCreators(
    {
      getErrorFlagConfigAddDialog,
      addErrorFlagConfigAddDialog,
      delErrorFlagConfigAddDialog
    },
    dispatch
  );

ErrorFlagConfigAddDialog.propTypes = {
  getErrorFlagConfigAddDialog: PropTypes.func,
  addErrorFlagConfigAddDialog: PropTypes.func,
  delErrorFlagConfigAddDialog: PropTypes.func,
  handleClose: PropTypes.func,
  dialogdata: PropTypes.object,
  className: PropTypes.string,
  selectedId: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
  icon: PropTypes.bool,
  open: PropTypes.bool,
  title: PropTypes.string,
  stepNumber: PropTypes.number,
  showSuccessNotification: PropTypes.func,
  showErrorNotification: PropTypes.func,
  showInfoNotification: PropTypes.func
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withStyles(snackbarContentStyle)(ErrorFlagConfigAddDialog));
