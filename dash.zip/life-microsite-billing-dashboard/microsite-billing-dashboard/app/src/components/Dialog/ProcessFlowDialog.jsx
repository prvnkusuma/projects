import React from "react";
import Button from "@material-ui/core/Button";
import Dialog from "@material-ui/core/Dialog";
import DialogActions from "@material-ui/core/DialogActions";
import DialogContent from "@material-ui/core/DialogContent";
import DialogTitle from "@material-ui/core/DialogTitle";
import Tooltip from "@material-ui/core/Tooltip";
import PolicyFlowStepper from "components/Stepper/PolicyFlowStepper.jsx";
import PropTypes from "prop-types";
import requireAuth from "utils/AuthenticatedComponent.jsx";

class ProcessFlowDialog extends React.Component {
  state = {
    open: false,
    fullWidth: true,
    maxWidth: "sm"
  };

  handleClickOpen = () => {
    this.setState({ open: true });
  };

  handleClose = () => {
    this.setState({ open: false });
  };

  handleMaxWidthChange = event => {
    this.setState({ maxWidth: event.target.value });
  };

  handleFullWidthChange = event => {
    this.setState({ fullWidth: event.target.checked });
  };

  render() {
    return (
      <React.Fragment>
        <Tooltip title="Click for more information">
          <a
            role="button"
            style={{
              cursor: "pointer",
              color:
                this.props.status === "completed"
                  ? "#57d500"
                  : this.props.status === "failed"
                    ? "#ff2e00"
                    : "#ffbf00",
              transition: "all .3s ease"
            }}
            onClick={this.handleClickOpen}
          >
            <b>
              {this.props.status === "completed"
                ? "Completed"
                : this.props.status === "pending"
                  ? "Pending"
                  : this.props.status === "failed"
                    ? "Failed"
                    : "In Progress"}
            </b>
          </a>
        </Tooltip>
        <Dialog
          fullWidth={this.state.fullWidth}
          maxWidth="md"
          open={this.state.open}
          onClose={this.handleClose}
          aria-labelledby="max-width-dialog-title"
          PaperProps={{
            style: {
              overflowY: "visible"
            }
          }}
        >
          <DialogTitle id="max-width-dialog-title">
            {this.props.title}
          </DialogTitle>
          <DialogContent>
            <PolicyFlowStepper {...this.props} />
          </DialogContent>
          <DialogActions>
            <Button onClick={this.handleClose} color="primary">
              Close
            </Button>
          </DialogActions>
        </Dialog>
      </React.Fragment>
    );
  }
}

ProcessFlowDialog.propTypes = {
  status: PropTypes.string,
  title: PropTypes.string,
  stepNumber: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
  processType: PropTypes.string,
  selectedId: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
  billDueDate: PropTypes.string
};

export default requireAuth(ProcessFlowDialog, "mainContent");
