import React from "react";
import { connect } from "react-redux";
import { bindActionCreators } from "redux";
import PropTypes from "prop-types";

import Button from "@material-ui/core/Button";
import Dialog from "@material-ui/core/Dialog";
import { DialogTitle, DialogContent, DialogActions } from "./CommonDialog.jsx";

//Import actions
import {
  getReProcessRemitDialog,
  addReProcessRemitDialog,
  delReProcessRemitDialog
} from "actions/ReProcessRemitDialogAction.jsx";

import "assets/css/bits-react-datepicker-override.css";
import APIURIs from "properties/APIURIs.jsx";
import InfoOutlined from "@material-ui/icons/InfoOutlined";
import Snackbar from "components/Snackbar/Snackbar.jsx";
import {
  getData,
  postData,
  convertStringToList,
  getFromLocalStorage
} from "utils/CommonFunctions.jsx";

function getErrorLogData(transRefGUID) {
  return getData(
    APIURIs.REMITTANCE_ERRLOGDATA_URI + transRefGUID + "/errors",
    APIURIs.REMITTANCE_ERRLOGDATA_APIKEY,
    {}
  );
}

function reprocess(transRefGUID) {
  return postData(APIURIs.REPROCESS_REMIT_URI, APIURIs.REPROCESS_REMIT_APIKEY, {
    transRefGuids:
      transRefGUID == null ? [] : convertStringToList(transRefGUID),
    isBulk: false,
    userName: getFromLocalStorage("userId")
  });
}

class RemittanceStepDialog extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      openErrorDialog: false,
      openReProcessDialog: false,
      successElt: false,
      errorElt: false
    };
  }

  handleErrorDialogEntering = () => {
    //get Error Log Data
    getErrorLogData(this.props.selectedId).then(response => {
      let reprocessFieldsTmp = Object.assign({}, this.props.dialogdata);
      reprocessFieldsTmp.errorLog = response.data.error;
      this.props.addReProcessRemitDialog(reprocessFieldsTmp);
    });
  };

  handleClickOpen = dialogType => {
    if (dialogType === "error") {
      this.setState({ openErrorDialog: true });
    } else {
      //Reprocess
      reprocess(this.props.selectedId).then(response => {
        if (response.status === 200) {
          this.showNotification("successElt");
        } else {
          this.showNotification("errorElt");
        }
      });
    }
  };

  handleClose = dialogType => {
    if (dialogType === "error") {
      this.setState({ openErrorDialog: false });
    } else {
      this.setState({ openReProcessDialog: false });
    }
  };

  showNotification(place) {
    var x = [];
    x[place] = true;
    this.setState(x);
    this.alertTimeout = setTimeout(
      function() {
        x[place] = false;
        this.setState(x);
      }.bind(this),
      6000
    );
  }

  componentWillUnmount() {
    this.props.delReProcessRemitDialog();

    var id = window.setTimeout(null, 0);
    while (id--) {
      window.clearTimeout(id);
    }
  }

  render() {
    return (
      <React.Fragment>
        {this.props.status === "failed" ? (
          <div>
            <Button
              variant="contained"
              color="secondary"
              onClick={() => this.handleClickOpen("error")}
            >
              {this.props.button1Name}
            </Button>
            {this.props.stepNumber === 1 ? (
              <span>
                &nbsp;
                <Button
                  variant="contained"
                  color="primary"
                  onClick={() => this.handleClickOpen("reprocess")}
                >
                  {this.props.button2Name}
                </Button>
              </span>
            ) : (
              ""
            )}
            <Snackbar
              place="tr"
              color="success"
              icon={InfoOutlined}
              message="Reprocess successfully initiated!"
              open={this.state.successElt}
              closeNotification={() => this.setState({ successElt: false })}
              close
            />
            <Snackbar
              place="tr"
              color="danger"
              icon={InfoOutlined}
              message="Reprocess initiation failed!"
              open={this.state.errorElt}
              closeNotification={() => this.setState({ errorElt: false })}
              close
            />
          </div>
        ) : (
          ""
        )}
        {/* Error Dialog */}
        <Dialog
          aria-labelledby="customized-dialog-title"
          open={this.state.openErrorDialog}
          onClose={this.handleClose}
          onEntering={this.handleErrorDialogEntering}
        >
          <DialogTitle
            id="customized-dialog-title"
            onClose={() => this.handleClose("error")}
          >
            <b>{this.props.button1Name}</b>
          </DialogTitle>
          <DialogContent>
            <div
              dangerouslySetInnerHTML={{
                __html: this.props.dialogdata.errorLog
              }}
              style={{ height: "300px", width: "500px" }}
            />
          </DialogContent>
          <DialogActions>
            <Button onClick={() => this.handleClose("error")} color="primary">
              Close
            </Button>
          </DialogActions>
        </Dialog>
      </React.Fragment>
    );
  }
}

RemittanceStepDialog.defaultProps = {
  openErrorDialog: false
};

const mapStateToProps = state => ({
  dialogdata: state.sidebar.reprocessRemitDialog
});

const mapDispatchToProps = dispatch =>
  bindActionCreators(
    {
      getReProcessRemitDialog,
      addReProcessRemitDialog,
      delReProcessRemitDialog
    },
    dispatch
  );

RemittanceStepDialog.propTypes = {
  getReProcessRemitDialog: PropTypes.func,
  addReProcessRemitDialog: PropTypes.func,
  delReProcessRemitDialog: PropTypes.func,
  dialogdata: PropTypes.object,
  className: PropTypes.string,
  button1Name: PropTypes.string,
  button2Name: PropTypes.string,
  selectedId: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
  icon: PropTypes.bool,
  status: PropTypes.string,
  stepNumber: PropTypes.number
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(RemittanceStepDialog);
