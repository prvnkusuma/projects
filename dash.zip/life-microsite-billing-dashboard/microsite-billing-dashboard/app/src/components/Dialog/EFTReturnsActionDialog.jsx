import React from "react";
import PropTypes from "prop-types";

import Button from "@material-ui/core/Button";
import Dialog from "@material-ui/core/Dialog";
import Tooltip from "@material-ui/core/Tooltip";
import PageviewTwoTone from "@material-ui/icons/PageviewTwoTone";
import InfoOutlined from "@material-ui/icons/InfoOutlined";

import Snackbar from "components/Snackbar/Snackbar.jsx";
import PDFViewer from "utils/PDFViewer.jsx";
import { DialogTitle, DialogContent, DialogActions } from "./CommonDialog.jsx";
import { postData } from "utils/CommonFunctions.jsx";
import APIURIs from "properties/APIURIs.jsx";
import requireAuth from "utils/AuthenticatedComponent.jsx";

function getDocumentAsText(transRefGUID) {
  //transRefGUID = "ALIP-386F3BF1-8ED8-4EC8-904F-7D5DBC430BC2";
  return postData(
    APIURIs.EFTRETURNS_GETDOC_URI + "transRefGUID=" + transRefGUID,
    APIURIs.EFTRETURNS_GETDOC_APIKEY,
    {},
    "EFTReturns.pdf",
    ""
  );
}

class EFTReturnsActionDialog extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      openPreview: false,
      fullWidth: true,
      maxWidth: "sm",
      numPages: null,
      file: "",
      successElt: false,
      errorElt: false,
      infoElt: false,
      successMessage: "",
      failureMessage: "",
      infoMessage: ""
    };
  }

  onDocumentLoadSuccess = ({ numPages }) => {
    this.setState({ numPages });
  };

  handleOpen = actionType => {
    switch (actionType) {
      case "preview":
        this.setState({ openPreview: true });
        break;
    }
  };

  handleClose = actionType => {
    switch (actionType) {
      case "preview":
        this.setState({ openPreview: false });
        break;
    }
  };

  handlePreviewDialogEntering = transRefGUID => {
    this.props.showLoading();
    getDocumentAsText(transRefGUID)
      .then(res => {
        if (res.status === 200) {
          this.setState({ file: atob(res.data.content) });
          this.handleOpen("preview");
        } else if (res.data === "No records found!") {
          this.setState({
            infoMessage: "No return found!"
          });
          this.showNotification("infoElt");
        } else {
          this.setState({
            failureMessage: "Error pre-viewing return!"
          });
          this.showNotification("errorElt");
        }
        this.props.hideLoading();
      })
      .catch(error => {
        console.warn(error);
        this.props.hideLoading();
      });
  };

  handleNotification = (messageType, message, dialogType) => {
    if (messageType == "success") {
      this.setState(
        {
          successMessage: message
        },
        () => {
          this.showNotification("successElt");
        }
      );
      this.handleClose(dialogType);
    } else if (messageType == "info") {
      this.setState(
        {
          infoMessage: message
        },
        () => {
          this.showNotification("infoElt");
        }
      );
      this.handleClose(dialogType);
    } else {
      this.setState(
        {
          failureMessage: message
        },
        () => {
          this.showNotification("errorElt");
        }
      );
      this.handleClose(dialogType);
    }
  };

  handleMaxWidthChange = event => {
    this.setState({ maxWidth: event.target.value });
  };

  handleFullWidthChange = event => {
    this.setState({ fullWidth: event.target.checked });
  };

  showNotification(place) {
    var x = [];
    x[place] = true;
    this.setState(x);
    this.alertTimeout = setTimeout(
      function() {
        x[place] = false;
        this.setState(x);
      }.bind(this),
      6000
    );
  }

  render() {
    return (
      <React.Fragment>
        <Tooltip title="Preview">
          <a
            role="button"
            style={{
              cursor: "pointer"
            }}
            onClick={() => {
              if (
                this.props.status == "completed" &&
                this.props.type != "MAN_ALIP_RETURN"
              ) {
                return this.handlePreviewDialogEntering(
                  this.props.transRefGUID
                );
              }
            }}
          >
            <b>
              <PageviewTwoTone
                style={{
                  color:
                    this.props.status == "completed" &&
                    this.props.type != "MAN_ALIP_RETURN"
                      ? "#8d6e63"
                      : "#CCCCCC",
                  transition: "all .3s ease"
                }}
              />
            </b>
          </a>
        </Tooltip>
        {/* Preview Dialog */}
        <Dialog
          aria-labelledby="customized-dialog-title"
          open={this.state.openPreview}
          onClose={() => this.handleClose("preview")}
          maxWidth="lg"
          modal="true"
        >
          <DialogTitle
            id="customized-dialog-title"
            onClose={() => this.handleClose("preview")}
          >
            <b>Preview</b>
          </DialogTitle>
          <DialogContent style={{ padding: "0 0px 0px", overflowX: "hidden" }}>
            <div style={{ height: "730px", width: "825px" }}>
              <PDFViewer file={this.state.file} disableFontFace={false} />
            </div>
          </DialogContent>
          <DialogActions>
            <Button onClick={() => this.handleClose("preview")} color="primary">
              Close
            </Button>
          </DialogActions>
        </Dialog>
        <Snackbar
          place="tr"
          color="success"
          icon={InfoOutlined}
          message={this.state.successMessage}
          open={this.state.successElt}
          closeNotification={() => this.setState({ successElt: false })}
          close
        />
        <Snackbar
          place="tr"
          color="danger"
          icon={InfoOutlined}
          message={this.state.failureMessage}
          open={this.state.errorElt}
          closeNotification={() => this.setState({ errorElt: false })}
          close
        />
        <Snackbar
          place="tr"
          color="info"
          icon={InfoOutlined}
          message={this.state.infoMessage}
          open={this.state.infoElt}
          closeNotification={() => this.setState({ infoElt: false })}
          close
        />
      </React.Fragment>
    );
  }
}

EFTReturnsActionDialog.propTypes = {
  data: PropTypes.string,
  title: PropTypes.string,
  stepNumber: PropTypes.number,
  selectedId: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
  billId: PropTypes.string,
  policyCont: PropTypes.string,
  type: PropTypes.string,
  transRefGUID: PropTypes.string,
  status: PropTypes.string,
  showLoading: PropTypes.func,
  hideLoading: PropTypes.func
};

export default requireAuth(EFTReturnsActionDialog, "mainContent");
