import React from "react";
import PropTypes from "prop-types";

import Tooltip from "@material-ui/core/Tooltip";
import AutorenewTwoTone from "@material-ui/icons/AutorenewTwoTone";
import InfoOutlined from "@material-ui/icons/InfoOutlined";

import Snackbar from "components/Snackbar/Snackbar.jsx";
import { formatDate } from "utils/CommonFunctions.jsx";
import requireAuth from "utils/AuthenticatedComponent.jsx";
import ReProcessBillDialog from "components/Dialog/ReProcessBillDialog.jsx";

class ReportingActionDialog extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      openReprocess: false,
      successElt: false,
      errorElt: false,
      successMessage: "Reprocess initiated successfully",
      failureMessage: "Reprocess failed",
      infoMessage:
        "This is not a business error. Please reprocess from Bill screen"
    };
  }

  handleOpen = actionType => {
    switch (actionType) {
      case "reprocess":
        this.setState({ openReprocess: true });
        break;
    }
  };

  handleClose = actionType => {
    switch (actionType) {
      case "reprocess":
        this.setState({ openReprocess: false });
        break;
    }
  };

  showNotification(place) {
    var x = [];
    x[place] = true;
    this.setState(x);
    this.alertTimeout = setTimeout(
      function() {
        x[place] = false;
        this.setState(x);
      }.bind(this),
      6000
    );
  }

  render() {
    const tempProps = {
      billDueDate:
        this.props.billDueDate == null
          ? formatDate(new Date())
          : this.props.billDueDate,
      paymentMethod:
        this.props.paymentMethod == null ? " " : this.props.paymentMethod,
      paidDate: this.props.paidDate == null ? "" : this.props.paidDate,
      selectedId: this.props.selectedId,
      reprocessFlag: this.props.reprocessFlag,
      transRefGUID: this.props.transRefGUID
    };
    return (
      <React.Fragment>
        <Tooltip title="Reprocess">
          <a
            role="button"
            style={{
              cursor: "pointer"
            }}
            onClick={() => {
              if (tempProps.reprocessFlag == "Y") {
                this.handleOpen("reprocess");
              }
            }}
          >
            <b>
              <AutorenewTwoTone
                style={{
                  color: tempProps.reprocessFlag == "Y" ? "#00b40b" : "#CCCCCC",
                  transition: "all .3s ease"
                }}
              />
            </b>
          </a>
        </Tooltip>
        {/* Reprocess Dialog */}
        <ReProcessBillDialog
          open={this.state.openReprocess}
          handleClose={() => this.handleClose("reprocess")}
          {...tempProps}
          showSuccessNotification={() => this.showNotification("successElt")}
          showErrorNotification={() => this.showNotification("errorElt")}
          showInfoNotification={() => this.showNotification("infoElt")}
        />
        <Snackbar
          place="tr"
          color="success"
          icon={InfoOutlined}
          message={this.state.successMessage}
          open={this.state.successElt}
          closeNotification={() => this.setState({ successElt: false })}
          close
        />
        <Snackbar
          place="tr"
          color="danger"
          icon={InfoOutlined}
          message={this.state.failureMessage}
          open={this.state.errorElt}
          closeNotification={() => this.setState({ errorElt: false })}
          close
        />
        <Snackbar
          place="tr"
          color="info"
          icon={InfoOutlined}
          message={this.state.infoMessage}
          open={this.state.infoElt}
          closeNotification={() => this.setState({ infoElt: false })}
          close
        />
      </React.Fragment>
    );
  }
}

ReportingActionDialog.propTypes = {
  data: PropTypes.string,
  title: PropTypes.string,
  stepNumber: PropTypes.number,
  processType: PropTypes.string,
  selectedId: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
  billId: PropTypes.string,
  policyCont: PropTypes.string,
  transRefGUID: PropTypes.string,
  status: PropTypes.string,
  showLoading: PropTypes.func,
  hideLoading: PropTypes.func
};

export default requireAuth(ReportingActionDialog, "mainContent");
