import React from "react";
import { connect } from "react-redux";
import { bindActionCreators } from "redux";
import PropTypes from "prop-types";
import SimpleReactValidator from "simple-react-validator";

import { withStyles } from "@material-ui/core/styles";
import InfoOutlined from "@material-ui/icons/InfoOutlined";
import WarningOutlined from "@material-ui/icons/WarningOutlined";
import Chip from "@material-ui/core/Chip";
import Dialog from "@material-ui/core/Dialog";
import Button from "@material-ui/core/Button";
import Typography from "@material-ui/core/Typography";
import FormControl from "@material-ui/core/FormControl";

import GridItem from "components/Grid/GridItem.jsx";
import GridContainer from "components/Grid/GridContainer.jsx";
import Overlay from "components/CustomWidgets/Overlay.jsx";
import DatePickerInput from "components/DatePickerInput/DatePickerInput.jsx";
import snackbarContentStyle from "assets/jss/material-dashboard-react/components/snackbarContentStyle.jsx";
import { DialogTitle, DialogContent, DialogActions } from "./CommonDialog.jsx";
import APIURIs from "properties/APIURIs.jsx";
import {
  postData,
  formatDate,
  formatStringToDate,
  getFromLocalStorage
} from "utils/CommonFunctions.jsx";

//Import actions
import {
  getHolidayConfigAddDialog,
  addHolidayConfigAddDialog,
  delHolidayConfigAddDialog
} from "actions/HolidayConfigAddDialogAction.jsx";

const classes = theme => ({
  root: {
    ...theme.mixins.gutters(),
    paddingTop: theme.spacing.unit * 2,
    paddingBottom: theme.spacing.unit * 2
  },
  formControl: {
    margin: theme.spacing.unit,
    minWidth: 120,
    display: "flex",
    wrap: "nowrap"
  },
  group: {
    margin: `${theme.spacing.unit}px 0`
  },
  textField: {
    marginLeft: theme.spacing.unit,
    marginRight: theme.spacing.unit,
    width: 200,
    display: "flex",
    flexWrap: "wrap"
  },
  button: {
    margin: theme.spacing.unit
  },
  InputClasses: {
    fullWidth: true
  }
});

function createHolidayData(dialogdata) {
  return postData(APIURIs.ADMIN_HOLIDAY_URI, APIURIs.ADMIN_HOLIDAY_APIKEY, {
    holidays: [
      {
        date: dialogdata.date,
        insertUser: getFromLocalStorage("userId")
      }
    ]
  });
}

const defaultValues = {
  validationError: false,
  validationMsg:
    "Validation Failed. Please enter valid information and try again."
};

class HolidayConfigAddDialog extends React.Component {
  _isMounted = false;
  constructor(props) {
    super(props);

    this.state = {
      ...defaultValues,
      loading: false
    };
    this.validator = new SimpleReactValidator();
  }

  componentDidMount() {
    this._isMounted = true;
  }

  componentWillUnmount() {
    this._isMounted = false;
  }

  handleDateChange = (dateName, dateValue) => {
    let formattedDate = formatDate(dateValue);
    let holidayConfigTmp = Object.assign({}, this.props.dialogdata);
    holidayConfigTmp[dateName] = formattedDate;
    this.props.addHolidayConfigAddDialog(holidayConfigTmp);
  };

  handleChange = event => {
    let holidayConfigTmp = Object.assign({}, this.props.dialogdata);
    holidayConfigTmp[event.target.name] = event.target.value;
    this.props.addHolidayConfigAddDialog(holidayConfigTmp);
  };

  handleToggle = event => {
    let holidayConfigTmp = Object.assign({}, this.props.dialogdata);
    holidayConfigTmp[event.target.name] = event.target.checked ? "Y" : "N";
    this.props.addHolidayConfigAddDialog(holidayConfigTmp);
  };

  handleAddNew = () => {
    createHolidayData(this.props.dialogdata)
      .then(response => {
        if (this._isMounted) {
          this.setState({ loading: false });
        }
        this.props.refreshHolidayList();
        if (response && response.status === 200) {
          this.props.showSuccessNotification();
          this.handleClose("close");
        } else {
          this.props.showErrorNotification();
        }
      })
      .catch(error => {
        console.warn(error);
        if (this._isMounted) {
          this.setState({
            loading: false
          });
        }
      });
  };

  handleClose = actionType => {
    if (actionType === "close") {
      this.setState({
        ...defaultValues
      });
      this.props.handleClose();
    }
    this.props.delHolidayConfigAddDialog();
    this.setState({
      ...defaultValues
    });
  };

  render() {
    return (
      <React.Fragment>
        <Dialog
          aria-labelledby="customized-dialog-title"
          open={this.props.open}
          onClose={this.handleClose}
        >
          <DialogTitle
            id="customized-dialog-title"
            onClose={() => this.handleClose("close")}
          >
            <b>{this.props.title}</b>
          </DialogTitle>
          <DialogContent>
            <div style={{ height: "200px", width: "500px" }}>
              {this.state.validationError ? (
                <Chip
                  icon={<WarningOutlined />}
                  label={this.state.validationMsg}
                  color="secondary"
                />
              ) : (
                <Chip
                  icon={<InfoOutlined />}
                  label="Input appropriate fields and click Add"
                  color="primary"
                />
              )}
              <div style={{ paddingTop: "20px" }}>
                <Overlay active={this.state.loading} marginTop="150px">
                  <FormControl
                    component="fieldset"
                    className={classes.formControl}
                    style={{ flexDirection: "row" }}
                  >
                    <GridContainer
                      style={{ display: "flex", alignItems: "center" }}
                    >
                      <GridItem xs={12} sm={12} md={6}>
                        <Typography variant="caption">
                          <b>Date:</b>
                        </Typography>
                      </GridItem>
                      <GridItem xs={12} sm={12} md={6}>
                        <FormControl style={{ flexDirection: "row" }}>
                          <Typography variant="caption">
                            <br />
                            <DatePickerInput
                              id="date"
                              name="date"
                              placeholderText="Date"
                              selected={formatStringToDate(
                                this.props.dialogdata.date
                              )}
                              onChange={dateValue => {
                                this.handleDateChange("date", dateValue);
                              }}
                              withPortal
                            />
                          </Typography>
                        </FormControl>
                      </GridItem>
                      <GridItem xs={12} sm={12} md={6}>
                        &nbsp;
                      </GridItem>
                      <GridItem xs={12} sm={12} md={6}>
                        &nbsp;
                      </GridItem>
                      <GridItem xs={12} sm={12} md={6}>
                        <Typography variant="caption">
                          <b>Insert User:</b>
                        </Typography>
                      </GridItem>
                      <GridItem xs={12} sm={12} md={6}>
                        {getFromLocalStorage("userId")}
                      </GridItem>
                      <GridItem xs={12} sm={12} md={6}>
                        &nbsp;
                      </GridItem>
                      <GridItem xs={12} sm={12} md={6}>
                        &nbsp;
                      </GridItem>
                    </GridContainer>
                  </FormControl>
                </Overlay>
              </div>
            </div>
          </DialogContent>
          <DialogActions>
            <Button onClick={this.handleAddNew} color="primary">
              Add
            </Button>
            <Button onClick={() => this.handleClose("clear")} color="primary">
              Reset
            </Button>
            <Button onClick={() => this.handleClose("close")} color="primary">
              Close
            </Button>
          </DialogActions>
        </Dialog>
      </React.Fragment>
    );
  }
}

HolidayConfigAddDialog.defaultProps = {
  openReProcessDialog: false
};

const mapStateToProps = state => ({
  dialogdata: state.sidebar.holidayAdd
});

const mapDispatchToProps = dispatch =>
  bindActionCreators(
    {
      getHolidayConfigAddDialog,
      addHolidayConfigAddDialog,
      delHolidayConfigAddDialog
    },
    dispatch
  );

HolidayConfigAddDialog.propTypes = {
  getHolidayConfigAddDialog: PropTypes.func,
  addHolidayConfigAddDialog: PropTypes.func,
  delHolidayConfigAddDialog: PropTypes.func,
  handleClose: PropTypes.func,
  dialogdata: PropTypes.object,
  className: PropTypes.string,
  selectedId: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
  icon: PropTypes.bool,
  open: PropTypes.bool,
  title: PropTypes.string,
  stepNumber: PropTypes.number,
  refreshHolidayList: PropTypes.func,
  showSuccessNotification: PropTypes.func,
  showErrorNotification: PropTypes.func,
  showInfoNotification: PropTypes.func
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withStyles(snackbarContentStyle)(HolidayConfigAddDialog));
