import React from "react";
import { connect } from "react-redux";
import { bindActionCreators } from "redux";
import PropTypes from "prop-types";

import Button from "@material-ui/core/Button";
import Dialog from "@material-ui/core/Dialog";
import InfoOutlined from "@material-ui/icons/InfoOutlined";
import { DialogTitle, DialogContent, DialogActions } from "./CommonDialog.jsx";

//Import actions
import {
  getReProcessBillDialog,
  addReProcessBillDialog,
  delReProcessBillDialog
} from "actions/ReProcessBillDialogAction.jsx";

import Snackbar from "components/Snackbar/Snackbar.jsx";
import PolicyChangeDialog from "components/Dialog/PolicyChangeDialog.jsx";
import "assets/css/bits-react-datepicker-override.css";
import APIURIs from "properties/APIURIs.jsx";
import { getData } from "utils/CommonFunctions.jsx";

function getErrorLogData(transRefGUID, stepNumber) {
  return getData(
    APIURIs.POL_CHANGE_ERRLOGDATA_URI +
      transRefGUID +
      "/errors/steps/" +
      stepNumber,
    APIURIs.POL_CHANGE_ERRLOGDATA_APIKEY,
    {}
  );
}

class PolicyChangeStepDialog extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      openErrorDialog: false,
      openReProcessDialog: false,
      successElt: false,
      errorElt: false
    };
  }

  handleErrorDialogEntering = () => {
    //get Error Log Data
    getErrorLogData(this.props.selectedId, this.props.stepNumber).then(
      response => {
        let reprocessFieldsTmp = Object.assign({}, this.props.dialogdata);
        reprocessFieldsTmp.errorLog = response.data.error;
        this.props.addReProcessBillDialog(reprocessFieldsTmp);
      }
    );
  };

  handleClickOpen = dialogType => {
    if (dialogType === "error") {
      this.setState({ openErrorDialog: true });
    } else {
      this.setState({ openReProcessDialog: true });
    }
  };

  handleClose = dialogType => {
    if (dialogType === "error") {
      this.setState({ openErrorDialog: false });
    } else {
      this.setState({ openReProcessDialog: false });
    }
  };

  componentWillUnmount() {
    this.props.delReProcessBillDialog();

    var id = window.setTimeout(null, 0);
    while (id--) {
      window.clearTimeout(id);
    }
  }

  showNotification(place) {
    var x = [];
    x[place] = true;
    this.setState(x);
    this.alertTimeout = setTimeout(
      function() {
        x[place] = false;
        this.setState(x);
      }.bind(this),
      6000
    );
  }

  render() {
    return (
      <React.Fragment>
        {this.props.status === "failed" ? (
          <div>
            <Button
              variant="contained"
              color="secondary"
              onClick={() => this.handleClickOpen("error")}
            >
              {this.props.button1Name}
            </Button>
            {this.props.stepNumber === 1 || this.props.stepNumber === 2 ? (
              <span>
                &nbsp;
                <Button
                  variant="contained"
                  color="primary"
                  onClick={() => this.handleClickOpen("reprocess")}
                >
                  {this.props.button2Name}
                </Button>
              </span>
            ) : (
              ""
            )}
          </div>
        ) : (
          ""
        )}
        {/* Error Dialog */}
        <Dialog
          aria-labelledby="customized-dialog-title"
          open={this.state.openErrorDialog}
          onClose={() => this.handleClose("error")}
          scroll="paper"
          onEntering={this.handleErrorDialogEntering}
        >
          <DialogTitle
            id="customized-dialog-title"
            onClose={() => this.handleClose("error")}
          >
            <b>{this.props.button1Name}</b>
          </DialogTitle>
          <DialogContent>
            <div
              dangerouslySetInnerHTML={{
                __html: this.props.dialogdata.errorLog
              }}
              style={{ height: "300px", width: "500px" }}
            />
          </DialogContent>
          <DialogActions>
            <Button onClick={() => this.handleClose("error")} color="primary">
              Close
            </Button>
          </DialogActions>
        </Dialog>
        {/* ReProcess Dialog */}
        <PolicyChangeDialog
          open={this.state.openReProcessDialog}
          handleClose={this.handleClose}
          {...this.props}
          showSuccessNotification={() => this.showNotification("successElt")}
          showErrorNotification={() => this.showNotification("errorElt")}
          showInfoNotification={() => this.showNotification("infoElt")}
        />
        <Snackbar
          place="tr"
          color="success"
          icon={InfoOutlined}
          message="Reprocess successfully initiated!"
          open={this.state.successElt}
          closeNotification={() => this.setState({ successElt: false })}
          close
        />
        <Snackbar
          place="tr"
          color="danger"
          icon={InfoOutlined}
          message="Reprocess initiation failed!"
          open={this.state.errorElt}
          closeNotification={() => this.setState({ errorElt: false })}
          close
        />
        <Snackbar
          place="tr"
          color="info"
          icon={InfoOutlined}
          message="This is a business error. Please reprocess from Business Errors screen"
          open={this.state.infoElt}
          closeNotification={() => this.setState({ infoElt: false })}
          close
        />
      </React.Fragment>
    );
  }
}

PolicyChangeStepDialog.defaultProps = {
  openErrorDialog: false
};

const mapStateToProps = state => ({
  dialogdata: state.sidebar.reprocessBillDialog
});

const mapDispatchToProps = dispatch =>
  bindActionCreators(
    {
      getReProcessBillDialog,
      addReProcessBillDialog,
      delReProcessBillDialog
    },
    dispatch
  );

PolicyChangeStepDialog.propTypes = {
  getReProcessBillDialog: PropTypes.func,
  addReProcessBillDialog: PropTypes.func,
  delReProcessBillDialog: PropTypes.func,
  dialogdata: PropTypes.object,
  className: PropTypes.string,
  button1Name: PropTypes.string,
  button2Name: PropTypes.string,
  selectedId: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
  icon: PropTypes.bool,
  status: PropTypes.string,
  stepNumber: PropTypes.number
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(PolicyChangeStepDialog);
