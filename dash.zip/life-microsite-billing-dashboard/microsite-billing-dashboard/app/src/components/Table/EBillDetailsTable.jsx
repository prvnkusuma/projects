import React from "react";
import PropTypes from "prop-types";

// Import React Table
import ReactTable from "react-table";
import { ReactTableDefaults } from "react-table";

import "react-table/react-table.css";
import "assets/css/bits-styles-override.css";

import APIURIs from "properties/APIURIs.jsx";
import ExcelDownload from "components/CustomWidgets/ExcelDownload.jsx";
import LoadingSpinner from "components/CustomWidgets/LoadingSpinner.jsx";
import Overlay from "components/CustomWidgets/Overlay.jsx";
import {
  postTableDataWithSearchParams,
  commonExcelDownload,
  getColumnWidth
} from "utils/CommonFunctions.jsx";
import requireAuth from "utils/AuthenticatedComponent.jsx";
import RecordCount from "components/CustomWidgets/RecordCount.jsx";

//Set default values of React Table
Object.assign(ReactTableDefaults, {
  multiSort: false,
  LoadingComponent: LoadingSpinner
});

function getEBillDetailsData(pageSize, page, sorted, filtered, polCont) {
  return postTableDataWithSearchParams(
    APIURIs.EBILL_DET_DATA_URI,
    APIURIs.EBILL_DET_DATA_APIKEY,
    pageSize,
    page,
    sorted,
    filtered,
    { polCont: polCont }
  );
}

class EBillDetailsTable extends React.Component {
  _isMounted = false;
  constructor(props) {
    super(props);

    this.state = {
      data: [],
      pages: null,
      loading: true,
      downloadExcelLoading: false,
      totalRecords: null
    };
  }

  componentDidMount() {
    this._isMounted = true;
  }

  componentWillUnmount() {
    this._isMounted = false;
  }

  handleExcelDownload = () => {
    commonExcelDownload(
      this,
      APIURIs.EBILL_DET_XLSDATA_URI,
      APIURIs.EBILL_DET_XLSDATA_APIKEY,
      { polCont: this.props.polCont },
      "EBillDetailsRecords.xlsx"
    ).then(response => {
      if (response.status == 200 && response.message == "email") {
        this.props.showNotification("excelDownloadElt");
      }
    });
  };

  fetchData = state => {
    getEBillDetailsData(
      state.pageSize,
      state.page,
      state.sorted,
      state.filtered,
      this.props.polCont
    )
      .then(res => {
        if (this._isMounted) {
          this.setState({
            data: res.rows,
            pages: res.pages == undefined ? 0 : res.pages,
            totalRecords: res.totalRecords,
            loading: false
          });
        }
      })
      .catch(error => {
        console.warn(error);
        if (this._isMounted) {
          this.setState({ loading: false });
        }
      });
  };

  render() {
    const { data, pages, loading } = this.state;
    return (
      <React.Fragment>
        <span>
          <ExcelDownload enabled="true" onClick={this.handleExcelDownload} />
        </span>
        <p />
        <Overlay active={this.state.downloadExcelLoading} marginTop="150px">
          <ReactTable
            ref={reactEBillDetTable => (this.selectTable = reactEBillDetTable)}
            columns={[
              {
                Header: "Record Type",
                accessor: "recordType",
                headerClassName: "BoldText ColoredText"
              },
              {
                Header: "Record Action",
                accessor: "recordAction",
                headerClassName: "BoldText ColoredText"
              },
              {
                Header: "Trans Type Code",
                accessor: "transTypeCode",
                headerClassName: "BoldText ColoredText"
              },
              {
                Header: "Trans Type Desc",
                accessor: "transDescription",
                sortable: false,
                width: getColumnWidth(
                  data,
                  "transDescription",
                  "Trans Type Desc"
                ),
                headerClassName: "BoldText ColoredText"
              },
              {
                Header: "Trans Timestamp",
                accessor: "insertTmStamp",
                headerClassName: "BoldText ColoredText"
              },
              {
                Header: "Status",
                accessor: "status",
                headerClassName: "BoldText ColoredText"
              }
            ]}
            defaultSorted={[
              {
                id: "insertTmStamp",
                desc: true
              }
            ]}
            manual // Forces table not to paginate or sort automatically, so we can handle it server-side
            data={data}
            pages={pages} // Display the total number of pages
            loading={loading} // Display the loading overlay when we need it
            onFetchData={this.fetchData} // Request new data when things change
            defaultPageSize={5}
            className="-striped -highlight"
          >
            {(state, makeTable) => {
              return (
                <RecordCount
                  state={state}
                  makeTable={makeTable}
                  totalRecords={this.state.totalRecords}
                />
              );
            }}
          </ReactTable>
        </Overlay>
      </React.Fragment>
    );
  }
}

EBillDetailsTable.propTypes = {
  dialogdata: PropTypes.object,
  polCont: PropTypes.string,
  showNotification: PropTypes.func
};

export default requireAuth(EBillDetailsTable, "mainContent");
