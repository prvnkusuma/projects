import React, { lazy, Suspense } from "react";
import { connect } from "react-redux";
import { bindActionCreators } from "redux";

import PropTypes from "prop-types";

// Import React Table
import ReactTable from "react-table";
import { ReactTableDefaults } from "react-table";

import TextField from "@material-ui/core/TextField";
import Select from "@material-ui/core/Select";
import InputLabel from "@material-ui/core/InputLabel";
import FormControl from "@material-ui/core/FormControl";
import Button from "@material-ui/core/Button";
import Typography from "@material-ui/core/Typography";
import InfoOutlined from "@material-ui/icons/InfoOutlined";

import { upload } from "react-icons-kit/feather/upload";

//Import actions
import {
  initPolicyChangeSearch,
  getPolicyChangeSearch,
  addPolicyChangeSearch,
  delPolicyChangeSearch
} from "actions/PolicyChangeSearchAction.jsx";

import "react-table/react-table.css";
import "assets/css/bits-styles-override.css";

import Snackbar from "components/Snackbar/Snackbar.jsx";
import DatePickerInput from "components/DatePickerInput/DatePickerInput.jsx";
import ProcessFlowDialog from "components/Dialog/ProcessFlowDialog.jsx";
import APIURIs from "properties/APIURIs.jsx";
import statusTypes from "properties/StatusTypes.jsx";
import BulkReProcessPolicyChangeDialog from "components/Dialog/BulkReProcessPolicyChangeDialog.jsx";
import LoadingSpinner from "components/CustomWidgets/LoadingSpinner.jsx";
import ExcelDownload from "components/CustomWidgets/ExcelDownload.jsx";
import CustomIcon from "components/CustomWidgets/CustomIcon.jsx";
import Refresh from "components/CustomWidgets/Refresh.jsx";
import Overlay from "components/CustomWidgets/Overlay.jsx";
import RecordCount from "components/CustomWidgets/RecordCount.jsx";
import {
  addDays,
  diffDays,
  formatDate,
  formatStringToDate,
  getTableData,
  commonExcelDownload
} from "utils/CommonFunctions.jsx";
import requireAuth from "utils/AuthenticatedComponent.jsx";

//Set default values of React Table
Object.assign(ReactTableDefaults, {
  multiSort: false,
  LoadingComponent: LoadingSpinner
});

const classes = theme => ({
  formControl: {
    margin: theme.spacing.unit,
    minWidth: 120,
    display: "flex",
    wrap: "nowrap"
  },
  textField: {
    marginLeft: theme.spacing.unit,
    marginRight: theme.spacing.unit,
    width: 200
  },
  button: {
    margin: theme.spacing.unit
  }
});

const PolicyChangeCSVUploadDialog = lazy(() =>
  import("components/Dialog/PolicyChangeCSVUploadDialog.jsx")
);

function getPolicyChangeData(
  pageSize,
  page,
  sorted,
  filtered,
  policyChangeSearch
) {
  return getTableData(
    APIURIs.POL_CHANGE_DATA_URI,
    APIURIs.POL_CHANGE_APIKEY,
    pageSize,
    page,
    sorted,
    filtered,
    policyChangeSearch
  );
}

class PolicyChangeTable extends React.Component {
  _isMounted = false;
  constructor(props) {
    super(props);

    this.state = {
      data: [],
      pages: null,
      loading: true,
      openBulkReprocessDialog: false,
      successElt: false,
      successMsg: "",
      errorElt: false,
      errorMsg: "",
      infoElt: false,
      excelDownloadElt: false,
      infoMsg: "",
      downloadExcelLoading: false,
      openCSVUploadDialog: false,
      totalRecords: null
    };
    this.props.initPolicyChangeSearch();
  }

  componentDidMount() {
    this._isMounted = true;
  }

  componentWillUnmount() {
    this._isMounted = false;
    this.props.initPolicyChangeSearch();
  }

  showNotificationWithMessage(messageElt, message) {
    let messageVar =
      messageElt == "successElt"
        ? "successMsg"
        : messageElt == "errorElt"
          ? "errorMsg"
          : "infoMsg";
    if (this._isMounted) {
      this.setState(
        {
          [messageVar]: message
        },
        function() {
          this.showNotification(messageElt);
        }
      );
    }
  }

  showNotification(place) {
    var x = [];
    x[place] = true;
    if (this._isMounted) {
      this.setState(x);
    }
    this.alertTimeout = setTimeout(
      function() {
        x[place] = false;
        if (this._isMounted) {
          this.setState(x);
        }
      }.bind(this),
      6000
    );
  }

  handleRefresh = event => {
    this.handleSubmit(event);
  };

  handleSubmit = event => {
    event.preventDefault();
    this.selectTable.fireFetchData();
  };

  handleClear = () => {
    this.props.delPolicyChangeSearch();
  };

  handleBulkReprocess = () => {
    if (this._isMounted) {
      this.setState({ openBulkReprocessDialog: true });
    }
  };

  handleClose = () => {
    if (this._isMounted) {
      this.setState({
        openBulkReprocessDialog: false,
        openCSVUploadDialog: false
      });
    }
  };

  handleCSVUpload = () => {
    if (this._isMounted) {
      this.setState({ openCSVUploadDialog: true });
    }
  };

  handleChange = event => {
    let policyChangeSearchTmp = Object.assign(
      {},
      this.props.sidebar.policyChangeSearch
    );
    policyChangeSearchTmp[event.target.name] = event.target.value;
    this.props.addPolicyChangeSearch(policyChangeSearchTmp);
  };

  handleDateChange = (dateName, dateValue) => {
    let policyChangeSearchTmp = Object.assign(
      {},
      this.props.sidebar.policyChangeSearch
    );
    policyChangeSearchTmp[dateName] = formatDate(dateValue);

    if (
      diffDays(dateValue, this.props.sidebar.policyChangeSearch.toCycleDate) >
      30
    ) {
      policyChangeSearchTmp["toCycleDate"] = formatDate(dateValue);
    }

    this.props.addPolicyChangeSearch(policyChangeSearchTmp);
  };

  handleDateChangeRaw = e => {
    e.preventDefault();
  };

  handleExcelDownload = () => {
    commonExcelDownload(
      this,
      APIURIs.POL_CHANGE_XLSDATA_URI,
      APIURIs.POL_CHANGE_XLSDATA_APIKEY,
      { ...this.props.sidebar.policyChangeSearch },
      "PolicyChangeRecords.xlsx"
    ).then(response => {
      if (response.status == 200 && response.message == "email") {
        this.showNotification("excelDownloadElt");
      }
    });
  };

  addDateFieldsToStore = () => {
    if (this._isMounted) {
      this.setState({ loading: true });
    }

    let policyChangeSearchTmp = Object.assign(
      {},
      this.props.sidebar.policyChangeSearch
    );
    policyChangeSearchTmp.fromCycleDate = formatDate(
      this.props.sidebar.policyChangeSearch.fromCycleDate
    );
    policyChangeSearchTmp.toCycleDate = formatDate(
      this.props.sidebar.policyChangeSearch.toCycleDate
    );
    this.props.addPolicyChangeSearch(policyChangeSearchTmp);
  };

  fetchSearchData = () => {
    this.addDateFieldsToStore();
    getPolicyChangeData(
      10,
      0,
      true,
      false,
      this.props.sidebar.policyChangeSearch
    )
      .then(res => {
        if (this._isMounted) {
          this.setState({
            data: res.rows,
            pages: res.pages == undefined ? 0 : res.pages,
            totalRecords: res.totalRecords,
            loading: false
          });
        }
      })
      .catch(error => {
        console.warn(error);
        if (this._isMounted) {
          this.setState({ loading: false });
        }
      });
  };

  fetchData = state => {
    this.addDateFieldsToStore();
    getPolicyChangeData(
      state.pageSize,
      state.page,
      state.sorted,
      state.filtered,
      this.props.sidebar.policyChangeSearch
    )
      .then(res => {
        if (this._isMounted) {
          this.setState({
            data: res.rows,
            pages: res.pages == undefined ? 0 : res.pages,
            totalRecords: res.totalRecords,
            loading: false
          });
        }
      })
      .catch(error => {
        console.warn(error);
        if (this._isMounted) {
          this.setState({ loading: false });
        }
      });
  };

  render() {
    const { data, pages, loading } = this.state;
    return (
      <React.Fragment>
        <Overlay active={this.state.downloadExcelLoading} marginTop="150px">
          <table border="0px" cellPadding="0" cellSpacing="0">
            <tbody>
              <tr>
                <td className="VerticalAlignBottom">
                  <TextField
                    id="transRefGUID"
                    name="transRefGUID"
                    label="Trans Ref GUID"
                    type="search"
                    className={classes.textField}
                    onChange={this.handleChange}
                    value={this.props.sidebar.policyChangeSearch.transRefGUID}
                    margin="none"
                  />
                </td>
                <td>&nbsp;</td>
                <td className="VerticalAlignBottom">
                  <TextField
                    id="polCont"
                    name="polCont"
                    label="Policy Number"
                    type="search"
                    className={classes.textField}
                    onChange={this.handleChange}
                    value={this.props.sidebar.policyChangeSearch.polCont}
                    margin="none"
                  />
                </td>
                <td>&nbsp;</td>
                <td className="VerticalAlignBottom">
                  <FormControl>
                    <InputLabel htmlFor="status">Status</InputLabel>
                    <Select
                      native
                      autoWidth={false}
                      style={{ width: 120 }}
                      value={this.props.sidebar.policyChangeSearch.status}
                      onChange={this.handleChange}
                      inputProps={{
                        name: "status",
                        id: "status"
                      }}
                    >
                      <option value="" />
                      {statusTypes.map(option => (
                        <option key={option.value} value={option.value}>
                          {option.label}
                        </option>
                      ))}
                    </Select>
                  </FormControl>
                </td>
                <td>&nbsp;</td>
                <td className="VerticalAlignBottom">
                  <FormControl style={{ flexDirection: "row" }}>
                    <Typography variant="caption">
                      <br />
                      <DatePickerInput
                        id="fromCycleDate"
                        name="fromCycleDate"
                        placeholderText="From Cycle Date"
                        onChangeRaw={this.handleDateChangeRaw}
                        selected={formatStringToDate(
                          this.props.sidebar.policyChangeSearch.fromCycleDate
                        )}
                        onChange={dateValue => {
                          this.handleDateChange("fromCycleDate", dateValue);
                        }}
                      />
                    </Typography>
                  </FormControl>
                </td>
                <td>&nbsp;</td>
                <td className="VerticalAlignBottom">
                  <FormControl style={{ flexDirection: "row" }}>
                    <Typography variant="caption">
                      <br />
                      <DatePickerInput
                        id="toCycleDate"
                        name="toCycleDate"
                        placeholderText="To Cycle Date"
                        onChangeRaw={this.handleDateChangeRaw}
                        selected={formatStringToDate(
                          this.props.sidebar.policyChangeSearch.toCycleDate
                        )}
                        minDate={
                          this.props.sidebar.policyChangeSearch.fromCycleDate !=
                          null
                            ? formatStringToDate(
                                this.props.sidebar.policyChangeSearch
                                  .fromCycleDate
                              )
                            : ""
                        }
                        maxDate={
                          this.props.sidebar.policyChangeSearch.fromCycleDate !=
                          null
                            ? addDays(
                                this.props.sidebar.policyChangeSearch
                                  .fromCycleDate,
                                30
                              )
                            : ""
                        }
                        onChange={dateValue => {
                          this.handleDateChange("toCycleDate", dateValue);
                        }}
                      />
                    </Typography>
                  </FormControl>
                </td>
              </tr>
            </tbody>
          </table>
          <div className="LeftActionBarStyle">
            <Button
              variant="contained"
              color="primary"
              className={classes.button}
              onClick={this.handleSubmit}
            >
              Search
            </Button>
            &nbsp;
            <Button
              variant="contained"
              color="primary"
              className={classes.button}
              onClick={this.handleClear}
            >
              Clear
            </Button>
            &nbsp;
            <Button
              variant="contained"
              color="primary"
              className={classes.button}
              onClick={this.handleBulkReprocess}
            >
              Bulk Reprocess
            </Button>
            <span className="RightActionBarStyle">
              <CustomIcon
                icon={upload}
                size="24"
                toolTip="Upload CSV"
                color="#00838f"
                onClick={this.handleCSVUpload}
              />
            </span>
            <span className="RightActionBarStyle">
              <ExcelDownload
                enabled="true"
                onClick={this.handleExcelDownload}
              />
            </span>
            <span className="RightActionBarStyle">
              <Refresh onClick={this.handleRefresh} />
            </span>
          </div>
          <ReactTable
            ref={reactPolicyChangeTable =>
              (this.selectTable = reactPolicyChangeTable)
            }
            columns={[
              {
                Header: "Trans Ref GUID",
                accessor: "transRefGUID",
                headerClassName: "BoldText ColoredText"
              },
              {
                Header: "Policy Number",
                accessor: "polCont",
                headerClassName: "BoldText ColoredText"
              },
              {
                Header: "Cycle Date",
                accessor: "cycleDate",
                headerClassName: "BoldText ColoredText"
              },
              {
                Header: "Status",
                id: "status",
                accessor: "status",
                sortable: false,
                headerClassName: "BoldText ColoredText",
                Cell: ({ row, original }) => {
                  return (
                    <span>
                      <span
                        style={{
                          color:
                            row.status === "completed"
                              ? "#ff2e00"
                              : row.status === "failed"
                                ? "#ffbf00"
                                : "#57d500",
                          transition: "all .3s ease"
                        }}
                      >
                        {" "}
                        <ProcessFlowDialog
                          title="Process Flow"
                          status={row.status}
                          processType="policyChange"
                          stepNumber={original.stepNumber}
                          selectedId={original.transRefGUID}
                          cycleDate={original.cycleDate}
                        />
                      </span>
                    </span>
                  );
                }
              }
            ]}
            defaultSorted={[
              {
                id: "cycleDate",
                desc: true
              }
            ]}
            manual // Forces table not to paginate or sort automatically, so we can handle it server-side
            data={data}
            pages={pages} // Display the total number of pages
            loading={loading} // Display the loading overlay when we need it
            onFetchData={this.fetchData} // Request new data when things change
            defaultPageSize={10}
            className="-striped -highlight"
          >
            {(state, makeTable) => {
              return (
                <RecordCount
                  state={state}
                  makeTable={makeTable}
                  totalRecords={this.state.totalRecords}
                />
              );
            }}
          </ReactTable>
          <br />
          {/* Bulk ReProcess Dialog */}
          <BulkReProcessPolicyChangeDialog
            open={this.state.openBulkReprocessDialog}
            handleClose={this.handleClose}
            title="Bulk Reprocess"
            showSuccessNotification={() =>
              this.showNotificationWithMessage(
                "successElt",
                "Reprocess successfully initiated!"
              )
            }
            showErrorNotification={() =>
              this.showNotificationWithMessage(
                "errorElt",
                "Reprocess initiation failed!"
              )
            }
            showInfoNotification={() =>
              this.showNotificationWithMessage("infoElt", "No bills found!")
            }
          />
          {/* Upload CSV Dialog */}
          {this.state.openCSVUploadDialog ? (
            <Suspense fallback={<p>Loading...</p>}>
              <PolicyChangeCSVUploadDialog
                open={this.state.openCSVUploadDialog}
                handleClose={this.handleClose}
                title="CSV Upload"
                showSuccessNotification={() =>
                  this.showNotificationWithMessage(
                    "successElt",
                    "CSV file upload successful"
                  )
                }
                showErrorNotification={() =>
                  this.showNotificationWithMessage(
                    "errorElt",
                    "Failed to upload CSV file"
                  )
                }
              />
            </Suspense>
          ) : (
            ""
          )}
          <Snackbar
            place="tr"
            color="success"
            icon={InfoOutlined}
            message={this.state.successMsg}
            open={this.state.successElt}
            closeNotification={() =>
              this._isMounted ? this.setState({ successElt: false }) : null
            }
            close
          />
          <Snackbar
            place="tr"
            color="danger"
            icon={InfoOutlined}
            message={this.state.errorMsg}
            open={this.state.errorElt}
            closeNotification={() =>
              this._isMounted ? this.setState({ errorElt: false }) : null
            }
            close
          />
          <Snackbar
            place="tr"
            color="info"
            icon={InfoOutlined}
            message={this.state.infoMsg}
            open={this.state.infoElt}
            closeNotification={() =>
              this._isMounted ? this.setState({ infoElt: false }) : null
            }
            close
          />
          <Snackbar
            place="tr"
            color="success"
            icon={InfoOutlined}
            message="Since the number of records are more than 10K, Excel report will be emailed to your email address."
            open={this.state.excelDownloadElt}
            closeNotification={() =>
              this._isMounted
                ? this.setState({ excelDownloadElt: false })
                : null
            }
            close
          />
        </Overlay>
      </React.Fragment>
    );
  }
}

const mapStateToProps = state => state;

const mapDispatchToProps = dispatch =>
  bindActionCreators(
    {
      initPolicyChangeSearch,
      getPolicyChangeSearch,
      addPolicyChangeSearch,
      delPolicyChangeSearch
    },
    dispatch
  );

PolicyChangeTable.propTypes = {
  initPolicyChangeSearch: PropTypes.func,
  getPolicyChangeSearch: PropTypes.func,
  addPolicyChangeSearch: PropTypes.func,
  delPolicyChangeSearch: PropTypes.func,
  className: PropTypes.string,
  sidebar: PropTypes.object,
  stats: PropTypes.bool,
  icon: PropTypes.bool
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(requireAuth(PolicyChangeTable, "mainContent"));
