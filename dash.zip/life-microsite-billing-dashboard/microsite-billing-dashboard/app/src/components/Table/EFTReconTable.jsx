import React from "react";
import PropTypes from "prop-types";
import { connect } from "react-redux";
import { bindActionCreators } from "redux";
import { withStyles } from "@material-ui/core/styles";

import FormControl from "@material-ui/core/FormControl";
import Button from "@material-ui/core/Button";
import Typography from "@material-ui/core/Typography";
// Import React Table
import ReactTable from "react-table";
import { ReactTableDefaults } from "react-table";
import LoadingSpinner from "components/CustomWidgets/LoadingSpinner.jsx";

import "react-table/react-table.css";
import "assets/css/bits-styles-override.css";

import {
  initReconciliationSearch,
  getReconciliationSearch,
  addReconciliationSearch,
  delEFTReconciliationSearch
} from "actions/ReconciliationSearchAction.jsx";

import {
  formatDate,
  formatStringToDate,
  getTableData
} from "utils/CommonFunctions.jsx";
import DatePickerInput from "components/DatePickerInput/DatePickerInput.jsx";
import APIURIs from "properties/APIURIs.jsx";
import Refresh from "components/CustomWidgets/Refresh.jsx";
import requireAuth from "utils/AuthenticatedComponent.jsx";
import RecordCount from "components/CustomWidgets/RecordCount.jsx";

//Set default values of React Table
Object.assign(ReactTableDefaults, {
  multiSort: false,
  LoadingComponent: LoadingSpinner
});

const classes = theme => ({
  root: {
    flexGrow: 1,
    backgroundColor: theme.palette.background.paper
  },
  indicator: {
    backgroundColor: "#009688"
  },
  button: {
    margin: 0
  }
});

function TabContainer(props) {
  return <div style={{ padding: 0 }}>{props.children}</div>;
}

TabContainer.propTypes = {
  children: PropTypes.node.isRequired
};

function getReconciliationData(
  pageSize,
  page,
  sorted,
  filtered,
  reconciliationSearch,
  type
) {
  let reconTypeCode = "SAP_RETURN";
  if (type === "SAPReturn") {
    reconTypeCode = "SAP_RETURN";
  } else {
    reconTypeCode = "ALIP_REVERSAL";
  }

  return getTableData(
    APIURIs.HIST_BILLRECON_DATA_URI,
    APIURIs.HIST_BILLRECON_DATA_APIKEY,
    pageSize,
    page,
    sorted,
    filtered,
    {
      reconType: reconTypeCode,
      cycleDate:
        type !== "SAPReturn"
          ? reconciliationSearch.secondaryCycleDate
          : reconciliationSearch.cycleDate
    }
  );
}

class EFTReconTable extends React.Component {
  _isMounted = false;
  constructor(props) {
    super(props);

    this.state = {
      sapData: [],
      alipData: [],
      sapPages: null,
      alipPages: null,
      sapLoading: true,
      alipLoading: true,
      sapTotalRecords: null,
      alipTotalRecords: null
    };
    this.props.initReconciliationSearch();
  }

  componentDidMount() {
    this._isMounted = true;
  }

  componentWillUnmount() {
    this._isMounted = false;
    this.props.initReconciliationSearch();
  }

  handleRefresh = (event, type) => {
    this.handleSubmit(event, type);
  };

  handleSubmit = (event, type) => {
    event.preventDefault();
    if (type === "SAPReturn") {
      this.selectSAPReturnTable.fireFetchData();
    } else {
      this.selectALIPReversalTable.fireFetchData();
    }
  };

  handleClear = type => {
    let reconciliationSearchTmp = Object.assign({}, this.props.dialogdata);
    if (type === "SAPReturn") {
      reconciliationSearchTmp.cycleDate = "";
    } else {
      reconciliationSearchTmp.secondaryCycleDate = "";
    }
    this.props.delEFTReconciliationSearch(reconciliationSearchTmp);
  };

  handleChange = event => {
    let reconciliationSearchTmp = Object.assign({}, this.props.dialogdata);
    reconciliationSearchTmp[event.target.name] = event.target.value;
    this.props.addReconciliationSearch(reconciliationSearchTmp);
  };

  handleDateChange = (dateName, dateValue) => {
    let reconciliationSearchTmp = Object.assign({}, this.props.dialogdata);
    reconciliationSearchTmp[dateName] = formatDate(dateValue);
    this.props.addReconciliationSearch(reconciliationSearchTmp);
  };

  addDateFieldsToStore = type => {
    let loading = type == "SAPReturn" ? "sapLoading" : "alipLoading";
    if (this._isMounted) {
      this.setState({ [loading]: true });
    }

    let reconciliationSearchTmp = Object.assign({}, this.props.dialogdata);
    reconciliationSearchTmp.cycleDate = formatDate(
      this.props.dialogdata.cycleDate
    );

    this.props.addReconciliationSearch(reconciliationSearchTmp);
  };

  fetchData = (state, type) => {
    let loading = type == "SAPReturn" ? "sapLoading" : "alipLoading";
    let data = type == "SAPReturn" ? "sapData" : "alipData";
    let pages = type == "SAPReturn" ? "sapPages" : "alipPages";
    let totalRecords =
      type == "SAPReturn" ? "sapTotalRecords" : "alipTotalRecords";
    this.addDateFieldsToStore(type);
    getReconciliationData(
      state.pageSize,
      state.page,
      state.sorted,
      state.filtered,
      this.props.dialogdata,
      type
    )
      .then(res => {
        if (this._isMounted) {
          this.setState({
            [data]: res.historicCounts,
            [pages]: res.pages == undefined ? 0 : res.pages,
            [totalRecords]: res.totalRecords,
            [loading]: false
          });
        }
      })
      .catch(error => {
        console.warn(error);
        if (this._isMounted) {
          this.setState({ [loading]: false });
        }
      });
  };

  render() {
    const {
      sapData,
      alipData,
      sapPages,
      alipPages,
      sapLoading,
      alipLoading,
      sapTotalRecords,
      alipTotalRecords
    } = this.state;
    return (
      <React.Fragment>
        <div>
          <p />
          <Typography variant="body2">SAP Return:</Typography>
          <table border="0px" cellPadding="0" cellSpacing="0">
            <tbody>
              <tr>
                <td className="VerticalAlignBottom">
                  <FormControl style={{ flexDirection: "row" }}>
                    <Typography variant="caption">
                      <br />
                      <DatePickerInput
                        id="cycleDate"
                        name="cycleDate"
                        placeholderText="Cycle Date"
                        selected={formatStringToDate(
                          this.props.dialogdata.cycleDate
                        )}
                        onChange={dateValue =>
                          this.handleDateChange("cycleDate", dateValue)
                        }
                      />
                    </Typography>
                  </FormControl>
                </td>
              </tr>
            </tbody>
          </table>
          <div className="LeftActionBarStyle">
            <Button
              variant="contained"
              color="primary"
              className={classes.button}
              onClick={event => this.handleSubmit(event, "SAPReturn")}
            >
              Search
            </Button>
            &nbsp;
            <Button
              variant="contained"
              color="primary"
              className={classes.button}
              onClick={() => this.handleClear("SAPReturn")}
            >
              Clear
            </Button>
            <span className="RightActionBarStyle">
              <Refresh
                onClick={event => this.handleRefresh(event, "SAPReturn")}
              />
            </span>
          </div>
          <TabContainer>
            <ReactTable
              ref={reactReconSAPReturnTable =>
                (this.selectSAPReturnTable = reactReconSAPReturnTable)
              }
              columns={[
                {
                  Header: "Cycle Date",
                  accessor: "cycleDate",
                  headerClassName: "BoldText ColoredText"
                },
                {
                  Header: "SAP",
                  accessor: "sapCount",
                  headerClassName: "BoldText ColoredText",
                  sortable: false
                },
                {
                  Header: "BITS Returns",
                  accessor: "bitsReturnsCount",
                  headerClassName: "BoldText ColoredText",
                  sortable: false
                },
                {
                  Header: "BITS NOC",
                  accessor: "bitsNOCCount",
                  headerClassName: "BoldText ColoredText",
                  sortable: false
                },
                {
                  Header: "BITS AWD",
                  accessor: "bitsAWDCount",
                  headerClassName: "BoldText ColoredText",
                  sortable: false
                },
                {
                  Header: "ALIP Returns",
                  accessor: "alipReturnsCount",
                  headerClassName: "BoldText ColoredText",
                  sortable: false
                },
                {
                  Header: "Payment Method",
                  accessor: "paymentMethod",
                  headerClassName: "BoldText ColoredText",
                  sortable: false
                }
              ]}
              defaultSorted={[
                {
                  id: "cycleDate",
                  desc: true
                }
              ]}
              manual // Forces table not to paginate or sort automatically, so we can handle it server-side
              data={sapData}
              pages={sapPages} // Display the total number of pages
              loading={sapLoading} // Display the loading overlay when we need it
              onFetchData={state => this.fetchData(state, "SAPReturn")} // Request new data when things change
              defaultPageSize={5}
              className="-striped -highlight"
            >
              {(state, makeTable) => {
                return (
                  <RecordCount
                    state={state}
                    makeTable={makeTable}
                    totalRecords={sapTotalRecords}
                  />
                );
              }}
            </ReactTable>
          </TabContainer>
          <p />
          <Typography variant="body2">ALIP Reversal:</Typography>
          <table border="0px" cellPadding="0" cellSpacing="0">
            <tbody>
              <tr>
                <td className="VerticalAlignBottom">
                  <FormControl style={{ flexDirection: "row" }}>
                    <Typography variant="caption">
                      <br />
                      <DatePickerInput
                        id="secondaryCycleDate"
                        name="secondaryCycleDate"
                        placeholderText="Cycle Date"
                        selected={formatStringToDate(
                          this.props.dialogdata.secondaryCycleDate
                        )}
                        onChange={dateValue => {
                          this.handleDateChange(
                            "secondaryCycleDate",
                            dateValue
                          );
                        }}
                      />
                    </Typography>
                  </FormControl>
                </td>
              </tr>
            </tbody>
          </table>
          <div className="LeftActionBarStyle">
            <Button
              variant="contained"
              color="primary"
              className={classes.button}
              onClick={event => this.handleSubmit(event, "ALIPReversal")}
            >
              Search
            </Button>
            &nbsp;
            <Button
              variant="contained"
              color="primary"
              className={classes.button}
              onClick={() => this.handleClear("ALIPReversal")}
            >
              Clear
            </Button>
            <span className="RightActionBarStyle">
              <Refresh
                onClick={event => this.handleRefresh(event, "ALIPReversal")}
              />
            </span>
          </div>
          <TabContainer>
            <ReactTable
              ref={reactReconALIPReversalTable =>
                (this.selectALIPReversalTable = reactReconALIPReversalTable)
              }
              columns={[
                {
                  Header: "Cycle Date",
                  accessor: "cycleDate",
                  headerClassName: "BoldText ColoredText"
                },
                {
                  Header: "ALIP Returns",
                  accessor: "alipReturnsCount",
                  headerClassName: "BoldText ColoredText",
                  sortable: false
                },
                {
                  Header: "ALIP Manual",
                  accessor: "alipManCount",
                  headerClassName: "BoldText ColoredText",
                  sortable: false
                },
                {
                  Header: "BITS Returns",
                  accessor: "bitsReturnsCount",
                  headerClassName: "BoldText ColoredText",
                  sortable: false
                },
                {
                  Header: "BITS AWD",
                  accessor: "bitsAWDCount",
                  headerClassName: "BoldText ColoredText",
                  sortable: false
                },
                {
                  Header: "XPRESSION",
                  accessor: "xpressionCount",
                  headerClassName: "BoldText ColoredText",
                  sortable: false
                }
              ]}
              defaultSorted={[
                {
                  id: "cycleDate",
                  desc: true
                }
              ]}
              manual // Forces table not to paginate or sort automatically, so we can handle it server-side
              data={alipData}
              pages={alipPages} // Display the total number of pages
              loading={alipLoading} // Display the loading overlay when we need it
              onFetchData={state => this.fetchData(state, "ALIPReversal")} // Request new data when things change
              defaultPageSize={5}
              className="-striped -highlight"
            >
              {(state, makeTable) => {
                return (
                  <RecordCount
                    state={state}
                    makeTable={makeTable}
                    totalRecords={alipTotalRecords}
                  />
                );
              }}
            </ReactTable>
          </TabContainer>
        </div>
      </React.Fragment>
    );
  }
}

const mapStateToProps = state => ({
  dialogdata: state.sidebar.reconciliationSearch
});

const mapDispatchToProps = dispatch =>
  bindActionCreators(
    {
      initReconciliationSearch,
      getReconciliationSearch,
      addReconciliationSearch,
      delEFTReconciliationSearch
    },
    dispatch
  );

EFTReconTable.propTypes = {
  dialogdata: PropTypes.object,
  initReconciliationSearch: PropTypes.func,
  addReconciliationSearch: PropTypes.func,
  getReconciliationSearch: PropTypes.func,
  delEFTReconciliationSearch: PropTypes.func
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withStyles(classes)(requireAuth(EFTReconTable, "mainContent")));
