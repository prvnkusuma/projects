import React from "react";
import { connect } from "react-redux";
import { bindActionCreators } from "redux";
import Icon from "react-icons-kit";

import PropTypes from "prop-types";

// Import React Table
import ReactTable from "react-table";
import { ReactTableDefaults } from "react-table";
import InfoOutlined from "@material-ui/icons/InfoOutlined";

import TextField from "@material-ui/core/TextField";
import Button from "@material-ui/core/Button";
import Tooltip from "@material-ui/core/Tooltip";
import { arrowLeftB } from "react-icons-kit/ionicons/arrowLeftB";
import { arrowDownB } from "react-icons-kit/ionicons/arrowDownB";

//Import actions
import {
  initAccountInquiry,
  getAccountInquiry,
  addAccountInquiry,
  delAccountInquiry
} from "actions/EFTAccountInquiryAction.jsx";

import "react-table/react-table.css";
import "assets/css/bits-styles-override.css";

import Snackbar from "components/Snackbar/Snackbar.jsx";
import APIURIs from "properties/APIURIs.jsx";
import LoadingSpinner from "components/CustomWidgets/LoadingSpinner.jsx";
import Refresh from "components/CustomWidgets/Refresh.jsx";
import EFTAIDetailsTable from "components/Table/EFTAIDetailsTable.jsx";
import { postTableData } from "utils/CommonFunctions.jsx";
import requireAuth from "utils/AuthenticatedComponent.jsx";
import RecordCount from "components/CustomWidgets/RecordCount.jsx";

//Set default values of React Table
Object.assign(ReactTableDefaults, {
  multiSort: false,
  LoadingComponent: LoadingSpinner
});

const classes = theme => ({
  formControl: {
    margin: theme.spacing.unit,
    minWidth: 120,
    display: "flex",
    wrap: "nowrap"
  },
  textField: {
    marginLeft: theme.spacing.unit,
    marginRight: theme.spacing.unit,
    width: 200
  },
  button: {
    margin: theme.spacing.unit
  }
});

function getAccountInquiryData(
  pageSize,
  page,
  sorted,
  filtered,
  accountInquiry
) {
  return postTableData(
    APIURIs.EFT_ACCOUNT_INQUIRY_URI,
    APIURIs.EFT_ACCOUNT_INQUIRY_APIKEY,
    pageSize,
    page,
    sorted,
    filtered,
    accountInquiry
  );
}

class EFTAccountInquiryTable extends React.Component {
  _isMounted = false;
  constructor(props) {
    super(props);

    this.state = {
      data: [],
      pages: null,
      excelDownloadElt: false,
      loading: true,
      totalRecords: null
    };
    this.props.initAccountInquiry();
  }

  componentDidMount() {
    this._isMounted = true;
  }

  componentWillUnmount() {
    this._isMounted = false;
    this.props.initAccountInquiry();
  }

  showNotification(place) {
    var x = [];
    x[place] = true;
    if (this._isMounted) {
      this.setState(x);
    }
    this.alertTimeout = setTimeout(
      function() {
        x[place] = false;
        if (this._isMounted) {
          this.setState(x);
        }
      }.bind(this),
      6000
    );
  }

  handleRefresh = event => {
    this.handleSubmit(event);
  };

  handleSubmit = event => {
    event.preventDefault();
    this.selectTable.fireFetchData();
  };

  handleClear = () => {
    this.props.delAccountInquiry();
  };

  handleChange = event => {
    let accountInquiryTmp = Object.assign({}, this.props.accountInquiry);
    accountInquiryTmp[event.target.name] = event.target.value;
    this.props.addAccountInquiry(accountInquiryTmp);
  };

  fetchData = state => {
    if (this._isMounted) {
      this.setState({ loading: true });
    }
    getAccountInquiryData(
      state.pageSize,
      state.page,
      state.sorted,
      state.filtered,
      this.props.accountInquiry
    )
      .then(res => {
        if (this._isMounted) {
          this.setState({
            data: res.rows,
            pages: res.pages == undefined ? 0 : res.pages,
            totalRecords: res.totalRecords,
            loading: false
          });
        }
      })
      .catch(error => {
        console.warn(error);
        if (this._isMounted) {
          this.setState({ loading: false });
        }
      });
  };

  render() {
    const { data, pages, loading } = this.state;
    return (
      <React.Fragment>
        <p />
        <table border="0px" cellPadding="0" cellSpacing="0">
          <tbody>
            <tr>
              <td className="VerticalAlignBottom">
                <TextField
                  id="payorName"
                  name="payorName"
                  label="Full Name"
                  type="search"
                  className={classes.textField}
                  onChange={this.handleChange}
                  value={this.props.accountInquiry.payorName}
                  margin="none"
                />
              </td>
              <td>&nbsp;</td>
              <td className="VerticalAlignBottom">
                <TextField
                  id="controlNum"
                  name="controlNum"
                  label="Control Number"
                  type="search"
                  className={classes.textField}
                  onChange={this.handleChange}
                  value={this.props.accountInquiry.controlNum}
                  margin="none"
                />
              </td>
            </tr>
          </tbody>
        </table>
        <div className="LeftActionBarStyle">
          <Button
            variant="contained"
            color="primary"
            className={classes.button}
            onClick={this.handleSubmit}
          >
            Search
          </Button>
          &nbsp;
          <Button
            variant="contained"
            color="primary"
            className={classes.button}
            onClick={this.handleClear}
          >
            Clear
          </Button>
          &nbsp;
          <span className="RightActionBarStyle">
            <Refresh onClick={this.handleRefresh} />
          </span>
        </div>
        <ReactTable
          ref={reactEFTAccountInquiry =>
            (this.selectTable = reactEFTAccountInquiry)
          }
          columns={[
            {
              Header: "Full Name",
              accessor: "payorName",
              headerClassName: "BoldText ColoredText"
            },
            {
              Header: "Control Number",
              accessor: "controlNum",
              headerClassName: "BoldText ColoredText"
            },
            {
              expander: true,
              width: 65,
              Expander: ({ isExpanded }) => (
                <div>
                  {isExpanded ? (
                    <span>
                      <Icon
                        style={{
                          cursor: "pointer",
                          color: "#3f51b5",
                          paddingTop: 10
                        }}
                        size={24}
                        icon={arrowDownB}
                      />
                    </span>
                  ) : (
                    <span>
                      <Tooltip title="Expand for more details">
                        <Icon
                          style={{
                            cursor: "pointer",
                            color: "#3f51b5",
                            paddingTop: 10
                          }}
                          size={24}
                          icon={arrowLeftB}
                        />
                      </Tooltip>
                    </span>
                  )}
                </div>
              ),
              style: {
                cursor: "pointer",
                fontSize: 25,
                padding: "0",
                textAlign: "center",
                userSelect: "none",
                color: "green"
              },
              Footer: () => <span>&nbsp;</span>
            }
          ]}
          defaultSorted={[
            {
              id: "payorName",
              desc: false
            }
          ]}
          manual // Forces table not to paginate or sort automatically, so we can handle it server-side
          data={data}
          pages={pages} // Display the total number of pages
          loading={loading} // Display the loading overlay when we need it
          onFetchData={this.fetchData} // Request new data when things change
          defaultPageSize={10}
          className="-striped -highlight"
          SubComponent={row => {
            return (
              <div style={{ padding: "10px" }}>
                <EFTAIDetailsTable
                  controlNum={row.original.controlNum}
                  showNotification={() =>
                    this.showNotification("excelDownloadElt")
                  }
                />
              </div>
            );
          }}
        >
          {(state, makeTable) => {
            return (
              <RecordCount
                state={state}
                makeTable={makeTable}
                totalRecords={this.state.totalRecords}
              />
            );
          }}
        </ReactTable>
        <Snackbar
          place="tr"
          color="success"
          icon={InfoOutlined}
          message="Since the number of records are more than 10K, Excel report will be emailed to your email address."
          open={this.state.excelDownloadElt}
          closeNotification={() =>
            this._isMounted ? this.setState({ excelDownloadElt: false }) : null
          }
          close
        />
      </React.Fragment>
    );
  }
}

const mapStateToProps = state => ({
  accountInquiry: state.sidebar.eftAccountInquiry
});

const mapDispatchToProps = dispatch =>
  bindActionCreators(
    {
      initAccountInquiry,
      getAccountInquiry,
      addAccountInquiry,
      delAccountInquiry
    },
    dispatch
  );

EFTAccountInquiryTable.propTypes = {
  initAccountInquiry: PropTypes.func,
  getAccountInquiry: PropTypes.func,
  addAccountInquiry: PropTypes.func,
  delAccountInquiry: PropTypes.func,
  className: PropTypes.string,
  sidebar: PropTypes.object,
  stats: PropTypes.bool,
  icon: PropTypes.bool,
  accountInquiry: PropTypes.object
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(requireAuth(EFTAccountInquiryTable, "mainContent"));
