import React from "react";
import { connect } from "react-redux";
import { bindActionCreators } from "redux";

import PropTypes from "prop-types";

// Import React Table
import ReactTable from "react-table";
import { ReactTableDefaults } from "react-table";

import TextField from "@material-ui/core/TextField";
import Select from "@material-ui/core/Select";
import InputLabel from "@material-ui/core/InputLabel";
import FormControl from "@material-ui/core/FormControl";
import Button from "@material-ui/core/Button";
import Typography from "@material-ui/core/Typography";
import InfoOutlined from "@material-ui/icons/InfoOutlined";

//Import actions
import {
  initBillSearch,
  getBillSearch,
  addBillSearch,
  delBillSearch
} from "actions/BillSearchAction.jsx";

import "react-table/react-table.css";
import "assets/css/bits-styles-override.css";

import Snackbar from "components/Snackbar/Snackbar.jsx";
import DatePickerInput from "components/DatePickerInput/DatePickerInput.jsx";
import ProcessFlowDialog from "components/Dialog/ProcessFlowDialog.jsx";
import APIURIs from "properties/APIURIs.jsx";
import { billPaymentMethods } from "properties/BillPaymentMethods.jsx";
import statusTypes from "properties/StatusTypes.jsx";
import billCommTypes from "properties/BillCommTypes.jsx";
import BulkReProcessBillDialog from "components/Dialog/BulkReProcessBillDialog.jsx";
import LoadingSpinner from "components/CustomWidgets/LoadingSpinner.jsx";
import ExcelDownload from "components/CustomWidgets/ExcelDownload.jsx";
import Refresh from "components/CustomWidgets/Refresh.jsx";
import Overlay from "components/CustomWidgets/Overlay.jsx";
import RecordCount from "components/CustomWidgets/RecordCount.jsx";
import {
  addDays,
  diffDays,
  formatDate,
  formatStringToDate,
  getTableData,
  commonExcelDownload
} from "utils/CommonFunctions.jsx";
import requireAuth from "utils/AuthenticatedComponent.jsx";

//Set default values of React Table
Object.assign(ReactTableDefaults, {
  multiSort: false,
  LoadingComponent: LoadingSpinner
});

const classes = theme => ({
  formControl: {
    margin: theme.spacing.unit,
    minWidth: 120,
    display: "flex",
    wrap: "nowrap"
  },
  textField: {
    marginLeft: theme.spacing.unit,
    marginRight: theme.spacing.unit,
    width: 200
  },
  button: {
    margin: theme.spacing.unit
  }
});

function getBillData(pageSize, page, sorted, filtered, billSearch) {
  return getTableData(
    APIURIs.BILLS_DATA_URI,
    APIURIs.BILLS_DATA_APIKEY,
    pageSize,
    page,
    sorted,
    filtered,
    billSearch
  );
}

class BillsTable extends React.Component {
  _isMounted = false;
  constructor(props) {
    super(props);

    this.state = {
      data: [],
      pages: null,
      loading: true,
      openBulkReprocessDialog: false,
      successElt: false,
      errorElt: false,
      infoElt: false,
      excelDownloadElt: false,
      downloadExcelLoading: false,
      totalRecords: null
    };
    this.props.initBillSearch();
  }

  componentDidMount() {
    this._isMounted = true;
  }

  componentWillUnmount() {
    this._isMounted = false;
    this.props.initBillSearch();
  }

  showNotification(place) {
    var x = [];
    x[place] = true;
    if (this._isMounted) {
      this.setState(x);
    }
    this.alertTimeout = setTimeout(
      function() {
        x[place] = false;
        if (this._isMounted) {
          this.setState(x);
        }
      }.bind(this),
      6000
    );
  }

  handleRefresh = event => {
    this.handleSubmit(event);
  };

  handleSubmit = event => {
    event.preventDefault();
    this.selectTable.fireFetchData();
  };

  handleClear = () => {
    this.props.delBillSearch();
  };

  handleBulkReprocess = () => {
    if (this._isMounted) {
      this.setState({ openBulkReprocessDialog: true });
    }
  };

  handleClose = () => {
    if (this._isMounted) {
      this.setState({ openBulkReprocessDialog: false });
    }
  };

  handleChange = event => {
    let billSearchTmp = Object.assign({}, this.props.dialogdata);
    billSearchTmp[event.target.name] = event.target.value;
    this.props.addBillSearch(billSearchTmp);
  };

  handleDateChange = (dateName, dateValue) => {
    let billSearchTmp = Object.assign({}, this.props.dialogdata);
    billSearchTmp[dateName] = formatDate(dateValue);

    if (
      dateName === "fromCycleDate" &&
      diffDays(dateValue, this.props.dialogdata.toCycleDate) > 30
    ) {
      billSearchTmp["toCycleDate"] = formatDate(dateValue);
    }

    this.props.addBillSearch(billSearchTmp);
  };

  handleDateChangeRaw = e => {
    e.preventDefault();
  };

  handleExcelDownload = () => {
    commonExcelDownload(
      this,
      APIURIs.BILL_XLSDATA_URI,
      APIURIs.BILL_XLSDATA_APIKEY,
      { ...this.props.dialogdata },
      "BillRecords.xlsx"
    ).then(response => {
      if (response.status == 200 && response.message == "email") {
        this.showNotification("excelDownloadElt");
      }
    });
  };

  addDateFieldsToStore = () => {
    if (this._isMounted) {
      this.setState({ loading: true });
    }

    let billSearchTmp = Object.assign({}, this.props.dialogdata);

    billSearchTmp.billDueDate = formatDate(this.props.dialogdata.billDueDate);
    billSearchTmp.fromCycleDate = formatDate(
      this.props.dialogdata.fromCycleDate
    );
    billSearchTmp.toCycleDate = formatDate(this.props.dialogdata.toCycleDate);
    this.props.addBillSearch(billSearchTmp);
  };

  fetchSearchData = () => {
    this.addDateFieldsToStore();
    getBillData(10, 0, true, false, this.props.dialogdata)
      .then(res => {
        if (this._isMounted) {
          this.setState({
            data: res.rows,
            pages: res.pages == undefined ? 0 : res.pages,
            totalRecords: res.totalRecords,
            loading: false
          });
        }
      })
      .catch(error => {
        console.warn(error);
        if (this._isMounted) {
          this.setState({ loading: false });
        }
      });
  };

  fetchData = state => {
    this.addDateFieldsToStore();
    getBillData(
      state.pageSize,
      state.page,
      state.sorted,
      state.filtered,
      this.props.dialogdata
    )
      .then(res => {
        if (this._isMounted) {
          this.setState({
            data: res.rows,
            pages: res.pages == undefined ? 0 : res.pages,
            totalRecords: res.totalRecords,
            loading: false
          });
        }
      })
      .catch(error => {
        console.warn(error);
        if (this._isMounted) {
          this.setState({ loading: false });
        }
      });
  };

  render() {
    const { data, pages, loading } = this.state;
    return (
      <React.Fragment>
        <Overlay active={this.state.downloadExcelLoading} marginTop="150px">
          <table border="0px" cellPadding="0" cellSpacing="0">
            <tbody>
              <tr>
                <td className="VerticalAlignBottom">
                  <TextField
                    id="polCont"
                    name="polCont"
                    label="Policy Number"
                    type="search"
                    className={classes.textField}
                    onChange={this.handleChange}
                    value={this.props.dialogdata.polCont}
                    margin="none"
                  />
                </td>
                <td>&nbsp;</td>
                <td className="VerticalAlignBottom">
                  <TextField
                    id="transRefGUID"
                    name="transRefGUID"
                    label="Trans Ref GUID"
                    type="search"
                    className={classes.textField}
                    onChange={this.handleChange}
                    value={this.props.dialogdata.transRefGUID}
                    margin="none"
                  />
                </td>
                <td>&nbsp;</td>
                <td className="VerticalAlignBottom">
                  <TextField
                    id="billId"
                    name="billId"
                    label="Bill Id"
                    type="search"
                    className={classes.textField}
                    onChange={this.handleChange}
                    value={this.props.dialogdata.billId}
                    margin="none"
                  />
                </td>
                <td>&nbsp;</td>
                <td className="VerticalAlignBottom">
                  <FormControl style={{ flexDirection: "row" }}>
                    <Typography variant="caption">
                      <br />
                      <DatePickerInput
                        id="billDueDate"
                        name="billDueDate"
                        placeholderText="Bill Due Date"
                        selected={formatStringToDate(
                          this.props.dialogdata.billDueDate
                        )}
                        onChange={dateValue => {
                          this.handleDateChange("billDueDate", dateValue);
                        }}
                      />
                    </Typography>
                  </FormControl>
                </td>
              </tr>
            </tbody>
          </table>
          <table border="0px" cellPadding="0" cellSpacing="0">
            <tbody>
              <tr>
                <td>&nbsp;</td>
                <td className="VerticalAlignBottom">
                  <FormControl>
                    <InputLabel htmlFor="paymentMethod">
                      Payment Method
                    </InputLabel>
                    <Select
                      native
                      autoWidth={true}
                      value={this.props.dialogdata.paymentMethod}
                      onChange={this.handleChange}
                      inputProps={{
                        name: "paymentMethod",
                        id: "paymentMethod"
                      }}
                    >
                      <option value="" />
                      {billPaymentMethods.map(option => (
                        <option key={option.value} value={option.value}>
                          {option.label}
                        </option>
                      ))}
                    </Select>
                  </FormControl>
                </td>
                <td>&nbsp;</td>
                <td className="VerticalAlignBottom">
                  <FormControl>
                    <InputLabel htmlFor="billCommType">
                      Bill Comm Type
                    </InputLabel>
                    <Select
                      native
                      autoWidth={false}
                      style={{ width: 120 }}
                      value={this.props.dialogdata.billCommType}
                      onChange={this.handleChange}
                      inputProps={{
                        name: "billCommType",
                        id: "billCommType"
                      }}
                    >
                      <option value="" />
                      {billCommTypes.map(option => (
                        <option key={option.value} value={option.value}>
                          {option.label}
                        </option>
                      ))}
                    </Select>
                  </FormControl>
                </td>
                <td>&nbsp;</td>
                <td className="VerticalAlignBottom">
                  <FormControl style={{ flexDirection: "row" }}>
                    <Typography variant="caption">
                      <br />
                      <DatePickerInput
                        id="fromCycleDate"
                        name="fromCycleDate"
                        placeholderText="From Cycle Date"
                        onChangeRaw={this.handleDateChangeRaw}
                        selected={formatStringToDate(
                          this.props.dialogdata.fromCycleDate
                        )}
                        onChange={dateValue => {
                          this.handleDateChange("fromCycleDate", dateValue);
                        }}
                      />
                    </Typography>
                  </FormControl>
                </td>
                <td>&nbsp;</td>
                <td className="VerticalAlignBottom">
                  <FormControl style={{ flexDirection: "row" }}>
                    <Typography variant="caption">
                      <br />
                      <DatePickerInput
                        id="toCycleDate"
                        name="toCycleDate"
                        placeholderText="To Cycle Date"
                        onChangeRaw={this.handleDateChangeRaw}
                        selected={formatStringToDate(
                          this.props.dialogdata.toCycleDate
                        )}
                        minDate={
                          this.props.dialogdata.fromCycleDate != null
                            ? formatStringToDate(
                                this.props.dialogdata.fromCycleDate
                              )
                            : ""
                        }
                        maxDate={
                          this.props.dialogdata.fromCycleDate != null
                            ? addDays(this.props.dialogdata.fromCycleDate, 30)
                            : ""
                        }
                        onChange={dateValue => {
                          this.handleDateChange("toCycleDate", dateValue);
                        }}
                      />
                    </Typography>
                  </FormControl>
                </td>
                <td>&nbsp;</td>
                <td className="VerticalAlignBottom">
                  <FormControl>
                    <InputLabel htmlFor="status">Status</InputLabel>
                    <Select
                      native
                      autoWidth={false}
                      style={{ width: 120 }}
                      value={this.props.dialogdata.status}
                      onChange={this.handleChange}
                      inputProps={{
                        name: "status",
                        id: "status"
                      }}
                    >
                      <option value="" />
                      {statusTypes.map(option => (
                        <option key={option.value} value={option.value}>
                          {option.label}
                        </option>
                      ))}
                    </Select>
                  </FormControl>
                </td>
              </tr>
            </tbody>
          </table>
          <div className="LeftActionBarStyle">
            <Button
              variant="contained"
              color="primary"
              className={classes.button}
              onClick={this.handleSubmit}
            >
              Search
            </Button>
            &nbsp;
            <Button
              variant="contained"
              color="primary"
              className={classes.button}
              onClick={this.handleClear}
            >
              Clear
            </Button>
            &nbsp;
            <Button
              variant="contained"
              color="primary"
              className={classes.button}
              onClick={this.handleBulkReprocess}
            >
              Bulk Reprocess
            </Button>
            <span className="RightActionBarStyle">
              <ExcelDownload
                enabled="true"
                onClick={this.handleExcelDownload}
              />
            </span>
            <span className="RightActionBarStyle">
              <Refresh onClick={this.handleRefresh} />
            </span>
          </div>
          <ReactTable
            ref={reactBillsTable => (this.selectTable = reactBillsTable)}
            columns={[
              {
                Header: "Policy Number",
                accessor: "polCont",
                headerClassName: "BoldText ColoredText"
              },
              {
                Header: "Trans Ref GUID",
                accessor: "transRefGUID",
                headerClassName: "BoldText ColoredText"
              },
              {
                Header: "Bill Id",
                id: "billId",
                accessor: d => d.billId,
                headerClassName: "BoldText ColoredText"
              },
              {
                Header: "Control Number",
                accessor: "controlNum",
                sortable: false,
                headerClassName: "BoldText ColoredText"
              },
              {
                Header: "Bill Due/WDL Date",
                accessor: "billDueDate",
                headerClassName: "BoldText ColoredText"
              },
              {
                Header: "Payment Method",
                accessor: "paymentMethod",
                headerClassName: "BoldText ColoredText"
              },
              {
                Header: "Premium Amount",
                accessor: "amount",
                headerClassName: "BoldText ColoredText"
              },
              {
                Header: "Net Payment Amount",
                accessor: "netPaymentAmt",
                headerClassName: "BoldText ColoredText"
              },
              {
                Header: "Bill Comm Type",
                id: "billCommType",
                sortable: false,
                Cell: ({ original }) => {
                  return (
                    <span>
                      {original.billCommType == "P"
                        ? "Paper"
                        : original.billCommType == "E"
                          ? "E-Bill"
                          : ""}
                    </span>
                  );
                },
                headerClassName: "BoldText ColoredText"
              },
              {
                Header: "Cycle Date",
                accessor: "cycleDate",
                headerClassName: "BoldText ColoredText"
              },
              {
                Header: "Status",
                id: "status",
                accessor: "status",
                sortable: false,
                headerClassName: "BoldText ColoredText",
                Cell: ({ row, original }) => {
                  return (
                    <span>
                      <span
                        style={{
                          color:
                            row.status === "completed"
                              ? "#ff2e00"
                              : row.status === "failed"
                                ? "#ffbf00"
                                : "#57d500",
                          transition: "all .3s ease"
                        }}
                      >
                        {" "}
                        <ProcessFlowDialog
                          title="Process Flow"
                          status={row.status}
                          processType="bill"
                          stepNumber={original.stepNumber}
                          selectedId={original.billId}
                          billDueDate={original.billDueDate}
                          paymentMethod={original.paymentMethod}
                          isBusinessError={original.isBusinessError}
                          paidDate={
                            original.paidDate === undefined
                              ? ""
                              : original.paidDate
                          }
                        />
                      </span>
                    </span>
                  );
                }
              }
            ]}
            defaultSorted={[
              {
                id: "cycleDate",
                desc: true
              }
            ]}
            manual // Forces table not to paginate or sort automatically, so we can handle it server-side
            data={data}
            pages={pages} // Display the total number of pages
            loading={loading} // Display the loading overlay when we need it
            onFetchData={this.fetchData} // Request new data when things change
            defaultPageSize={10}
            className="-striped -highlight"
          >
            {(state, makeTable) => {
              return (
                <RecordCount
                  state={state}
                  makeTable={makeTable}
                  totalRecords={this.state.totalRecords}
                />
              );
            }}
          </ReactTable>
          <br />
          {/* Bulk ReProcess Dialog */}
          <BulkReProcessBillDialog
            open={this.state.openBulkReprocessDialog}
            handleClose={this.handleClose}
            title="Bulk Reprocess"
            showSuccessNotification={() => this.showNotification("successElt")}
            showErrorNotification={() => this.showNotification("errorElt")}
            showInfoNotification={() => this.showNotification("infoElt")}
          />
          <Snackbar
            place="tr"
            color="success"
            icon={InfoOutlined}
            message="Reprocess successfully initiated!"
            open={this.state.successElt}
            closeNotification={() =>
              this._isMounted ? this.setState({ successElt: false }) : null
            }
            close
          />
          <Snackbar
            place="tr"
            color="danger"
            icon={InfoOutlined}
            message="Reprocess initiation failed!"
            open={this.state.errorElt}
            closeNotification={() =>
              this._isMounted ? this.setState({ errorElt: false }) : null
            }
            close
          />
          <Snackbar
            place="tr"
            color="info"
            icon={InfoOutlined}
            message="No bills found!"
            open={this.state.infoElt}
            closeNotification={() =>
              this._isMounted ? this.setState({ infoElt: false }) : null
            }
            close
          />
          <Snackbar
            place="tr"
            color="success"
            icon={InfoOutlined}
            message="Since the number of records are more than 10K, Excel report will be emailed to your email address."
            open={this.state.excelDownloadElt}
            closeNotification={() =>
              this._isMounted
                ? this.setState({ excelDownloadElt: false })
                : null
            }
            close
          />
        </Overlay>
      </React.Fragment>
    );
  }
}

const mapStateToProps = state => ({
  dialogdata: state.sidebar.billSearch
});

const mapDispatchToProps = dispatch =>
  bindActionCreators(
    {
      initBillSearch,
      getBillSearch,
      addBillSearch,
      delBillSearch
    },
    dispatch
  );

BillsTable.propTypes = {
  initBillSearch: PropTypes.func,
  getBillSearch: PropTypes.func,
  addBillSearch: PropTypes.func,
  delBillSearch: PropTypes.func,
  className: PropTypes.string,
  sidebar: PropTypes.object,
  stats: PropTypes.bool,
  icon: PropTypes.bool,
  dialogdata: PropTypes.object
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(requireAuth(BillsTable, "mainContent"));
