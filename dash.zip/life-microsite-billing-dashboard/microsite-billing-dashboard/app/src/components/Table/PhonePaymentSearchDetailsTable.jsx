import React from "react";
import PropTypes from "prop-types";

// Import React Table
import ReactTable from "react-table";
import { ReactTableDefaults } from "react-table";

import "react-table/react-table.css";
import "assets/css/bits-styles-override.css";

import APIURIs from "properties/APIURIs.jsx";
import ExcelDownload from "components/CustomWidgets/ExcelDownload.jsx";
import LoadingSpinner from "components/CustomWidgets/LoadingSpinner.jsx";
import Overlay from "components/CustomWidgets/Overlay.jsx";
import {
  postTableDataWithSearchParams,
  commonExcelDownload
} from "utils/CommonFunctions.jsx";
import requireAuth from "utils/AuthenticatedComponent.jsx";
import RecordCount from "components/CustomWidgets/RecordCount.jsx";
import CommentsActionDialog from "components/Dialog/CommentsActionDialog.jsx";

//Set default values of React Table
Object.assign(ReactTableDefaults, {
  multiSort: false,
  LoadingComponent: LoadingSpinner
});

function getPhonePaymentSearchDetailsData(
  pageSize,
  page,
  sorted,
  filtered,
  trackingNumber
) {
  return postTableDataWithSearchParams(
    APIURIs.PHONE_PMT_POLSEARCH_URI,
    APIURIs.PHONE_PMT_POLSEARCH_APIKEY,
    pageSize,
    page,
    sorted,
    filtered,
    {
      trackingNumber: trackingNumber,
      action: "search"
    }
  );
}

class PhonePaymentSearchDetailsTable extends React.Component {
  _isMounted = false;
  constructor(props) {
    super(props);

    this.state = {
      data: [],
      pages: null,
      loading: true,
      downloadExcelLoading: false,
      totalRecords: null
    };
  }

  componentDidMount() {
    this._isMounted = true;
  }

  componentWillUnmount() {
    this._isMounted = false;
  }

  handleExcelDownload = () => {
    commonExcelDownload(
      this,
      APIURIs.PHONE_PMT_POLSEARCH_XLSDATA_URI,
      APIURIs.PHONE_PMT_POLSEARCH_XLSDATA_APIKEY,
      { trackingNumber: this.props.trackingNumber },
      "PhonePaymentDetailsRecords.xlsx"
    ).then(response => {
      if (response.status == 200 && response.message == "email") {
        this.props.showNotification("excelDownloadElt");
      }
    });
  };

  fetchData = state => {
    getPhonePaymentSearchDetailsData(
      state.pageSize,
      state.page,
      state.sorted,
      state.filtered,
      this.props.trackingNumber
    )
      .then(res => {
        if (this._isMounted) {
          this.setState({
            data: res.rows,
            pages: res.pages == undefined ? 0 : res.pages,
            totalRecords: res.totalRecords,
            loading: false
          });
        }
      })
      .catch(error => {
        console.warn(error);
        if (this._isMounted) {
          this.setState({ loading: false });
        }
      });
  };

  render() {
    const { data, pages, loading } = this.state;
    return (
      <React.Fragment>
        <span>
          <ExcelDownload enabled="true" onClick={this.handleExcelDownload} />
        </span>
        <p />
        <Overlay active={this.state.downloadExcelLoading} marginTop="150px">
          <ReactTable
            ref={reactEBillDetTable => (this.selectTable = reactEBillDetTable)}
            columns={[
              {
                Header: "Policy Number",
                accessor: "policyNumber",
                headerClassName: "BoldText ColoredText"
              },
              {
                Header: "Bill Id",
                accessor: "billId",
                headerClassName: "BoldText ColoredText"
              },
              {
                Header: "Carrier Code",
                accessor: "carrierCode",
                headerClassName: "BoldText ColoredText"
              },
              {
                Header: "Insured Name",
                accessor: "insuredName",
                headerClassName: "BoldText ColoredText"
              },
              {
                Header: "Amount",
                id: "draftAmnt",
                accessor: d =>
                  d.draftAmnt !== undefined && d.draftAmnt !== ""
                    ? "$" + Number.parseFloat(d.draftAmnt).toFixed(2)
                    : "",
                headerClassName: "BoldText ColoredText"
              },
              {
                Header: "Payment Type",
                accessor: "paymentType",
                headerClassName: "BoldText ColoredText"
              },
              {
                Header: "Policy Status",
                accessor: "policyStatus",
                sortable: false,
                headerClassName: "BoldText ColoredText"
              },
              {
                Header: "Current Bill Method",
                accessor: "currentBillingMethod",
                sortable: false,
                headerClassName: "BoldText ColoredText"
              },
              {
                Header: "Is Recurring EFT",
                id: "isRecurringEFT",
                accessor: d => (d.isRecurringEFT ? "TRUE" : "FALSE"),
                headerClassName: "BoldText ColoredText"
              },
              {
                Header: "Actions",
                id: "actions",
                accessor: "actions",
                sortable: false,
                className: "Centered",
                headerClassName: "BoldText ColoredText",
                Cell: ({ original }) => {
                  return (
                    <span style={{ textAlign: "center" }}>
                      <CommentsActionDialog
                        open={this.state.showComments}
                        title="Policy Comments"
                        iconTitle="View Comments"
                        commentsPlaceholder="Comments"
                        value={original.comment}
                        isEnabled={true}
                        button1Title=""
                        button2Title="Close"
                      />
                    </span>
                  );
                }
              }
            ]}
            defaultSorted={[
              {
                id: "policyNumber",
                desc: true
              }
            ]}
            manual // Forces table not to paginate or sort automatically, so we can handle it server-side
            data={data}
            pages={pages} // Display the total number of pages
            loading={loading} // Display the loading overlay when we need it
            onFetchData={this.fetchData} // Request new data when things change
            defaultPageSize={5}
            className="-striped -highlight"
          >
            {(state, makeTable) => {
              return (
                <RecordCount
                  state={state}
                  makeTable={makeTable}
                  totalRecords={this.state.totalRecords}
                />
              );
            }}
          </ReactTable>
        </Overlay>
      </React.Fragment>
    );
  }
}

PhonePaymentSearchDetailsTable.propTypes = {
  trackingNumber: PropTypes.string,
  showNotification: PropTypes.func
};

export default requireAuth(PhonePaymentSearchDetailsTable, "mainContent");
