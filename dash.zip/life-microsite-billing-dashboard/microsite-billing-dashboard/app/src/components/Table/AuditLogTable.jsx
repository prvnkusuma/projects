import React from "react";
import { connect } from "react-redux";
import { bindActionCreators } from "redux";

import PropTypes from "prop-types";
import SimpleReactValidator from "simple-react-validator";

// Import React Table
import ReactTable from "react-table";
import { ReactTableDefaults } from "react-table";

import TextField from "@material-ui/core/TextField";
import Select from "@material-ui/core/Select";
import InputLabel from "@material-ui/core/InputLabel";
import FormControl from "@material-ui/core/FormControl";
import Button from "@material-ui/core/Button";
import Typography from "@material-ui/core/Typography";
import Chip from "@material-ui/core/Chip";

import WarningOutlined from "@material-ui/icons/WarningOutlined";

// Import actions
import {
  initAuditLogSearch,
  getAuditLogSearch,
  addAuditLogSearch,
  delAuditLogSearch
} from "actions/AuditLogSearchAction.jsx";

import "react-table/react-table.css";
import "assets/css/bits-styles-override.css";

import DatePickerInput from "components/DatePickerInput/DatePickerInput.jsx";
import APIURIs from "properties/APIURIs.jsx";
import auditLogTypes from "properties/AuditLogTypes.jsx";
import paymentMethods from "properties/BillPaymentMethods.jsx";
import LoadingSpinner from "components/CustomWidgets/LoadingSpinner.jsx";
import Refresh from "components/CustomWidgets/Refresh.jsx";
import {
  addDays,
  diffDays,
  formatDate,
  formatStringToDate,
  postTableDataWithSearchParams
} from "utils/CommonFunctions.jsx";
import requireAuth from "utils/AuthenticatedComponent.jsx";
import Overlay from "components/CustomWidgets/Overlay.jsx";
import RecordCount from "components/CustomWidgets/RecordCount.jsx";

//Set default values of React Table
Object.assign(ReactTableDefaults, {
  multiSort: false,
  LoadingComponent: LoadingSpinner
});

const classes = theme => ({
  button: {
    margin: theme.spacing.unit
  }
});

function getCycleDate(fromCycleDate, toCycleDate) {
  if (fromCycleDate === "" && toCycleDate === "") {
    return "";
  } else {
    return "start:" + fromCycleDate + ", " + "end:" + toCycleDate;
  }
}

function getAuditLogData(
  pageSize,
  page,
  sorted,
  filtered,
  auditLogSearch,
  isAdmin
) {
  return postTableDataWithSearchParams(
    auditLogSearch.auditLogType === "Manual Bill" ||
    auditLogSearch.auditLogType === "Phone Payment"
      ? APIURIs.AUDITLOG_DATA_INQUIRY_URI
      : APIURIs.AUDITLOG_DATA_URI,
    APIURIs.AUDITLOG_DATA_APIKEY,
    pageSize,
    page,
    sorted,
    filtered,
    {
      insertUser: auditLogSearch.userName,
      cycleDate: !isAdmin
        ? getCycleDate(auditLogSearch.fromCycleDate, auditLogSearch.toCycleDate)
        : "",
      insertTstampFrom:
        auditLogSearch.insertTstampFrom == ""
          ? null
          : auditLogSearch.insertTstampFrom,
      insertTstampTo:
        auditLogSearch.insertTstampTo == ""
          ? null
          : auditLogSearch.insertTstampTo,
      paymentMethod:
        auditLogSearch.paymentMethod == ""
          ? null
          : auditLogSearch.paymentMethod,
      holdingInquiryFlg: auditLogSearch.holdingInquiry,
      identifiers:
        auditLogSearch.identifier == "" ? null : auditLogSearch.identifier,
      acordType: auditLogSearch.auditLogType,
      action: auditLogSearch.actionType
    }
  );
}

const defaultIdLabel = {
  idLabel: "Trans Ref GUID"
};

class AuditLogTable extends React.Component {
  _isMounted = false;
  constructor(props) {
    super(props);

    this.state = {
      data: [],
      pages: null,
      loading: true,
      openBulkReprocessDialog: false,
      downloadExcelLoading: false,
      validationError: false,
      validationMsg: "",
      isAdmin: false,
      ...defaultIdLabel,
      totalRecords: null,
      showAction: false
    };
    this.props.initAuditLogSearch();
    this.validator = new SimpleReactValidator();
  }

  componentDidMount() {
    this._isMounted = true;
  }

  componentWillUnmount() {
    this._isMounted = false;
    this.props.initAuditLogSearch();
  }

  showNotification(place) {
    var x = [];
    x[place] = true;
    if (this._isMounted) {
      this.setState(x);
    }
    this.alertTimeout = setTimeout(
      function() {
        x[place] = false;
        if (this._isMounted) {
          this.setState(x);
        }
      }.bind(this),
      6000
    );
  }
  setLoading(status) {
    if (this._isMounted) {
      this.setState({ downloadExcelLoading: status });
    }
  }

  handleRefresh = event => {
    this.handleSubmit(event);
  };

  handleSubmit = event => {
    let isValidationError = false;
    let validationMsg = "";
    if (!this.validator.fieldValid("auditLogType")) {
      isValidationError = true;
      validationMsg = "Validation Failed. Audit Log Type is mandatory!";
    } else if (!this.validator.fieldValid("actionType")) {
      isValidationError = true;
      validationMsg = "Validation Failed. Action Type is mandatory!";
    }

    if (this._isMounted) {
      this.setState({
        validationError: isValidationError,
        validationMsg: validationMsg
      });
    }
    if (isValidationError) {
      return;
    } else {
      event.preventDefault();
      this.selectTable.fireFetchData();
    }
  };

  handleClear = () => {
    this.setState({ validationError: false });
    this.props.delAuditLogSearch();
    this.clearState();
  };

  clearState() {
    if (this._isMounted) {
      this.setState({
        ...defaultIdLabel,
        showAction: false,
        data: [],
        pages: 0,
        totalRecords: 0,
        loading: false
      });
    }
  }

  handleClose = () => {
    if (this._isMounted) {
      this.setState({ openBulkReprocessDialog: false });
    }
  };

  handleChange = event => {
    if (event.target.name === "auditLogType") {
      this.clearState();
      let idLabelTmp = defaultIdLabel.idLabel;
      let isAdminTmp = false;
      let showActionTmp = false;
      if (["1801", "400", "Manual Bill"].indexOf(event.target.value) != -1) {
        idLabelTmp = "Bill Id";
      }
      if (event.target.value === "EBill Indicator Change") {
        idLabelTmp = "Policy Number";
        showActionTmp = true;
      }
      if (event.target.value === "Admin") {
        idLabelTmp = "Rule Name";
        isAdminTmp = true;
      }
      if (event.target.value === "Error Code") {
        idLabelTmp = "Error Code";
        isAdminTmp = true;
      }
      if (this._isMounted) {
        this.setState({
          idLabel: idLabelTmp,
          isAdmin: isAdminTmp,
          showAction: showActionTmp
        });
      }
    }
    let auditLogSearchTmp = Object.assign({}, this.props.dialogdata);
    auditLogSearchTmp[event.target.name] = event.target.value;
    if (event.target.name == "auditLogType") {
      auditLogSearchTmp["actionType"] = "";
    }
    this.props.addAuditLogSearch(auditLogSearchTmp);
  };

  handleDateChange = (dateName, dateValue) => {
    let auditLogSearchTmp = Object.assign({}, this.props.dialogdata);
    auditLogSearchTmp[dateName] = formatDate(dateValue);
    if (dateName === "fromCycleDate") {
      if (diffDays(dateValue, this.props.dialogdata.toCycleDate) > 30) {
        auditLogSearchTmp["toCycleDate"] = formatDate(dateValue);
      }
    }
    if (dateName === "insertTstampFrom") {
      if (diffDays(dateValue, this.props.dialogdata.insertTstampTo) > 30) {
        auditLogSearchTmp["insertTstampTo"] = formatDate(dateValue);
      }
    }

    this.props.addAuditLogSearch(auditLogSearchTmp);
  };

  addDateFieldsToStore = () => {
    if (this._isMounted) {
      this.setState({ loading: true });
    }

    let auditLogSearchTmp = Object.assign({}, this.props.dialogdata);
    auditLogSearchTmp.fromCycleDate = formatDate(
      this.props.dialogdata.fromCycleDate
    );
    auditLogSearchTmp.toCycleDate = formatDate(
      this.props.dialogdata.toCycleDate
    );
    auditLogSearchTmp.insertTstampFrom = formatDate(
      this.props.dialogdata.insertTstampFrom
    );
    auditLogSearchTmp.insertTstampTo = formatDate(
      this.props.dialogdata.insertTstampTo
    );
    this.props.addAuditLogSearch(auditLogSearchTmp);
  };

  fetchData = state => {
    this.addDateFieldsToStore();
    getAuditLogData(
      state.pageSize,
      state.page,
      state.sorted,
      state.filtered,
      this.props.dialogdata,
      this.state.isAdmin
    )
      .then(res => {
        if (this._isMounted) {
          this.setState({
            data: res.rows,
            pages: res.pages == undefined ? 0 : res.pages,
            totalRecords: res.totalRecords,
            loading: false
          });
        }
      })
      .catch(error => {
        console.warn(error);
        if (this._isMounted) {
          this.setState({ loading: false });
        }
      });
  };

  render() {
    const { data, pages, loading } = this.state;
    return (
      <React.Fragment>
        <Overlay active={this.state.downloadExcelLoading} marginTop="150px">
          <p />
          {this.state.validationError ? (
            <Chip
              icon={<WarningOutlined />}
              label={this.state.validationMsg}
              color="secondary"
            />
          ) : (
            ""
          )}
          <table border="0px" cellPadding="0" cellSpacing="0">
            <tbody>
              <tr>
                <td className="VerticalAlignBottom">
                  <FormControl>
                    <InputLabel htmlFor="auditLogType">
                      Audit Log Type
                    </InputLabel>
                    <Select
                      native
                      autoWidth={true}
                      value={this.props.dialogdata.auditLogType}
                      onChange={this.handleChange}
                      inputProps={{
                        name: "auditLogType",
                        id: "auditLogType"
                      }}
                    >
                      <option value="" />
                      {auditLogTypes.map(option => (
                        <option key={option.accordId} value={option.accordId}>
                          {option.accordType}
                        </option>
                      ))}
                    </Select>
                    {this.validator.message(
                      "auditLogType",
                      this.props.dialogdata.auditLogType,
                      "required"
                    )}
                  </FormControl>
                </td>
                <td>&nbsp;</td>
                <td className="VerticalAlignBottom">
                  <FormControl>
                    <InputLabel htmlFor="actionType">Action Type</InputLabel>
                    <Select
                      native
                      autoWidth={true}
                      style={{ minWidth: 165 }}
                      value={this.props.dialogdata.actionType}
                      onChange={this.handleChange}
                      inputProps={{
                        name: "actionType",
                        id: "actionType"
                      }}
                    >
                      <option value="" />
                      {auditLogTypes
                        .filter(
                          auditLogType =>
                            auditLogType.accordId ==
                            this.props.dialogdata.auditLogType
                        )
                        .map(auditLogType =>
                          auditLogType.actions.map(option => (
                            <option key={option.value} value={option.value}>
                              {option.label}
                            </option>
                          ))
                        )}
                    </Select>
                    {this.validator.message(
                      "actionType",
                      this.props.dialogdata.actionType,
                      "required"
                    )}
                  </FormControl>
                </td>
                <td>&nbsp;</td>
                <td className="VerticalAlignBottom">
                  <FormControl>
                    <InputLabel htmlFor="paymentMethod">
                      Payment Method
                    </InputLabel>
                    <Select
                      native
                      autoWidth={true}
                      value={this.props.dialogdata.paymentMethod}
                      disabled={this.state.isAdmin ? true : false}
                      onChange={this.handleChange}
                      inputProps={{
                        name: "paymentMethod",
                        id: "paymentMethod"
                      }}
                    >
                      <option value="" />
                      {paymentMethods.map(option => (
                        <option key={option.value} value={option.value}>
                          {option.label}
                        </option>
                      ))}
                    </Select>
                  </FormControl>
                </td>
                <td>&nbsp;</td>
                <td className="VerticalAlignBottom">
                  <FormControl>
                    <InputLabel htmlFor="holdingInquiry">
                      Policy Data Source
                    </InputLabel>
                    <Select
                      native
                      autoWidth={false}
                      style={{ width: 140 }}
                      value={this.props.dialogdata.holdingInquiry}
                      disabled={this.state.isAdmin ? true : false}
                      onChange={this.handleChange}
                      inputProps={{
                        name: "holdingInquiry",
                        id: "holdingInquiry"
                      }}
                    >
                      <option key="" value="" />
                      <option key="true" value="true">
                        ALIP
                      </option>
                      <option key="false" value="false">
                        Cassandra
                      </option>
                    </Select>
                  </FormControl>
                </td>
              </tr>
            </tbody>
          </table>
          <table border="0px" cellPadding="0" cellSpacing="0">
            <tbody>
              <tr>
                <td className="VerticalAlignBottom">
                  <TextField
                    id="userName"
                    name="userName"
                    label="User Name"
                    type="search"
                    className={classes.textField}
                    onChange={this.handleChange}
                    value={this.props.dialogdata.userName}
                    margin="none"
                  />
                </td>
                <td>&nbsp;</td>
                <td className="VerticalAlignBottom">
                  <FormControl style={{ flexDirection: "row" }}>
                    <Typography variant="caption">
                      <br />
                      <DatePickerInput
                        id="fromCycleDate"
                        name="fromCycleDate"
                        placeholderText="From Cycle Date"
                        selected={formatStringToDate(
                          this.props.dialogdata.fromCycleDate
                        )}
                        onChange={dateValue => {
                          this.handleDateChange("fromCycleDate", dateValue);
                        }}
                      />
                      {this.validator.message(
                        "fromCycleDate",
                        this.props.dialogdata.fromCycleDate,
                        "required"
                      )}
                    </Typography>
                  </FormControl>
                </td>
                <td>&nbsp;</td>
                <td className="VerticalAlignBottom">
                  <FormControl style={{ flexDirection: "row" }}>
                    <Typography variant="caption">
                      <br />
                      <DatePickerInput
                        id="toCycleDate"
                        name="toCycleDate"
                        placeholderText="To Cycle Date"
                        selected={formatStringToDate(
                          this.props.dialogdata.toCycleDate
                        )}
                        minDate={
                          this.props.dialogdata.fromCycleDate != null
                            ? formatStringToDate(
                                this.props.dialogdata.fromCycleDate
                              )
                            : ""
                        }
                        maxDate={
                          this.props.dialogdata.fromCycleDate != null
                            ? addDays(this.props.dialogdata.fromCycleDate, 30)
                            : ""
                        }
                        onChange={dateValue => {
                          this.handleDateChange("toCycleDate", dateValue);
                        }}
                      />
                      {this.validator.message(
                        "toCycleDate",
                        this.props.dialogdata.toCycleDate,
                        "required"
                      )}
                    </Typography>
                  </FormControl>
                </td>
                <td>&nbsp;</td>
                <td className="VerticalAlignBottom">
                  <TextField
                    id="identifier"
                    name="identifier"
                    label={this.state.idLabel}
                    type="search"
                    className={classes.textField}
                    onChange={this.handleChange}
                    value={this.props.dialogdata.identifier}
                    margin="none"
                  />
                </td>
              </tr>
            </tbody>
          </table>
          <table border="0px" cellPadding="0" cellSpacing="0">
            <tbody>
              <tr>
                <td className="VerticalAlignBottom">
                  <FormControl style={{ flexDirection: "row" }}>
                    <Typography variant="caption">
                      <br />
                      <DatePickerInput
                        id="insertTstampFrom"
                        name="insertTstampFrom"
                        onChangeRaw={this.handleDateChangeRaw}
                        placeholderText="From Insert Date"
                        selected={formatStringToDate(
                          this.props.dialogdata.insertTstampFrom
                        )}
                        onChange={dateValue => {
                          this.handleDateChange("insertTstampFrom", dateValue);
                        }}
                      />
                    </Typography>
                  </FormControl>
                </td>
                <td>&nbsp;</td>
                <td className="VerticalAlignBottom">
                  <FormControl style={{ flexDirection: "row" }}>
                    <Typography variant="caption">
                      <br />
                      <DatePickerInput
                        id="insertTstampTo"
                        name="insertTstampTo"
                        onChangeRaw={this.handleDateChangeRaw}
                        placeholderText="To Insert Date"
                        selected={formatStringToDate(
                          this.props.dialogdata.insertTstampTo
                        )}
                        minDate={
                          this.props.dialogdata.insertTstampFrom != null
                            ? formatStringToDate(
                                this.props.dialogdata.insertTstampFrom
                              )
                            : ""
                        }
                        maxDate={
                          this.props.dialogdata.insertTstampFrom != null
                            ? addDays(
                                this.props.dialogdata.insertTstampFrom,
                                30
                              )
                            : ""
                        }
                        onChange={dateValue => {
                          this.handleDateChange("insertTstampTo", dateValue);
                        }}
                      />
                    </Typography>
                  </FormControl>
                </td>
              </tr>
            </tbody>
          </table>
          <div className="LeftActionBarStyle">
            <Button
              variant="contained"
              color="primary"
              className={classes.button}
              onClick={this.handleSubmit}
            >
              Search
            </Button>
            &nbsp;
            <Button
              variant="contained"
              color="primary"
              className={classes.button}
              onClick={this.handleClear}
            >
              Clear
            </Button>
            <span className="RightActionBarStyle">
              <Refresh onClick={this.handleRefresh} />
            </span>
          </div>
          <ReactTable
            ref={reactAuditLogTable => (this.selectTable = reactAuditLogTable)}
            columns={[
              {
                Header: "Payment Method",
                accessor: "paymentMethod",
                sortable: false,
                headerClassName: "BoldText ColoredText"
              },
              {
                Header: "Policy Data Source",
                id: "holdingInquiryFlg",
                accessor: p =>
                  p.holdingInquiryFlg == true
                    ? "ALIP"
                    : p.holdingInquiryFlg == false
                      ? "Cassandra"
                      : "",
                sortable: false,
                headerClassName: "BoldText ColoredText"
              },
              {
                Header: "Action",
                id: "ebillIndicator",
                accessor: a =>
                  a.ebillIndicator == "X" ? "Reactivate" : "Deactivate",
                show: this.state.showAction,
                headerClassName: "BoldText ColoredText"
              },
              {
                Header: "User Name",
                accessor: "insertUser",
                headerClassName: "BoldText ColoredText"
              },
              {
                Header: "Cycle Date",
                accessor: "cycleDate",
                sortable: false,
                headerClassName: "BoldText ColoredText"
              },
              {
                Header: () => this.state.idLabel,
                accessor: "identifiers",
                headerClassName: "BoldText ColoredText"
              },
              {
                Header: "Insert Date",
                accessor: "insertTstamp",
                headerClassName: "BoldText ColoredText"
              }
            ]}
            defaultSorted={[
              {
                id: "insertTstamp",
                desc: true
              }
            ]}
            manual // Forces table not to paginate or sort automatically, so we can handle it server-side
            data={data}
            pages={pages} // Display the total number of pages
            loading={loading} // Display the loading overlay when we need it
            onFetchData={this.fetchData} // Request new data when things change
            defaultPageSize={10}
            className="-striped -highlight"
          >
            {(state, makeTable) => {
              return (
                <RecordCount
                  state={state}
                  makeTable={makeTable}
                  totalRecords={this.state.totalRecords}
                />
              );
            }}
          </ReactTable>
        </Overlay>
      </React.Fragment>
    );
  }
}

const mapStateToProps = state => ({
  dialogdata: state.sidebar.auditLogSearch
});

const mapDispatchToProps = dispatch =>
  bindActionCreators(
    {
      initAuditLogSearch,
      getAuditLogSearch,
      addAuditLogSearch,
      delAuditLogSearch
    },
    dispatch
  );

AuditLogTable.propTypes = {
  initAuditLogSearch: PropTypes.func,
  addAuditLogSearch: PropTypes.func,
  getAuditLogSearch: PropTypes.func,
  delAuditLogSearch: PropTypes.func,
  className: PropTypes.string,
  sidebar: PropTypes.object,
  stats: PropTypes.bool,
  icon: PropTypes.bool,
  dialogdata: PropTypes.object
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(requireAuth(AuditLogTable, "mainContent"));
