import React from "react";
import { connect } from "react-redux";
import { bindActionCreators } from "redux";

import PropTypes from "prop-types";
import SimpleReactValidator from "simple-react-validator";

// Import React Table
import ReactTable from "react-table";
import { ReactTableDefaults } from "react-table";
import FormControl from "@material-ui/core/FormControl";
import TextField from "@material-ui/core/TextField";
import Button from "@material-ui/core/Button";
import Typography from "@material-ui/core/Typography";
import Chip from "@material-ui/core/Chip";

import InfoOutlined from "@material-ui/icons/InfoOutlined";
import WarningOutlined from "@material-ui/icons/WarningOutlined";

//Import actions
import {
  initHistAccountInquiry,
  getHistAccountInquiry,
  addHistAccountInquiry,
  delHistAccountInquiry
} from "actions/EFTHistAccountInquiryAction.jsx";

import "react-table/react-table.css";
import "assets/css/bits-styles-override.css";

import Snackbar from "components/Snackbar/Snackbar.jsx";
import DatePickerInput from "components/DatePickerInput/DatePickerInput.jsx";
import EFTControlNumberDialog from "components/Dialog/EFTControlNumberDialog.jsx";
import APIURIs from "properties/APIURIs.jsx";
import LoadingSpinner from "components/CustomWidgets/LoadingSpinner.jsx";
import Refresh from "components/CustomWidgets/Refresh.jsx";
import Overlay from "components/CustomWidgets/Overlay.jsx";
import ExcelDownload from "components/CustomWidgets/ExcelDownload.jsx";
import RecordCount from "components/CustomWidgets/RecordCount.jsx";
import {
  addDays,
  diffDays,
  formatDate,
  postTableDataWithSearchParams,
  commonExcelDownload,
  formatStringToDate
} from "utils/CommonFunctions.jsx";
import requireAuth from "utils/AuthenticatedComponent.jsx";

var validationMsg = "Control Number is mandatory for any search criteria!";
//Set default values of React Table
Object.assign(ReactTableDefaults, {
  multiSort: false,
  LoadingComponent: LoadingSpinner
});

const classes = theme => ({
  formControl: {
    margin: theme.spacing.unit,
    minWidth: 120,
    display: "flex",
    wrap: "nowrap"
  },
  textField: {
    marginLeft: theme.spacing.unit,
    marginRight: theme.spacing.unit,
    width: 200
  },
  button: {
    margin: theme.spacing.unit
  }
});

function getHistAccountInquiryData(
  pageSize,
  page,
  sorted,
  filtered,
  histAccountInquiry
) {
  return postTableDataWithSearchParams(
    APIURIs.EFT_ACCOUNTHIST_INQUIRY_URI,
    APIURIs.EFT_ACCOUNTHIST_INQUIRY_APIKEY,
    pageSize,
    page,
    sorted,
    filtered,
    histAccountInquiry
  );
}

class EFTAccountHistoryInquiryTable extends React.Component {
  _isMounted = false;
  constructor(props) {
    super(props);

    this.state = {
      data: [],
      pages: null,
      loading: false,
      successElt: false,
      errorElt: false,
      infoElt: false,
      excelDownloadElt: false,
      downloadExcelLoading: false,
      validationError: true,
      openControlNumDialog: false,
      totalRecords: null
    };
    this.props.initHistAccountInquiry();
    this.validator = new SimpleReactValidator();
  }

  componentDidMount() {
    this._isMounted = true;
  }

  componentWillUnmount() {
    this._isMounted = false;
    this.props.initHistAccountInquiry();
  }

  showNotification(place) {
    var x = [];
    x[place] = true;
    if (this._isMounted) {
      this.setState(x);
    }
    this.alertTimeout = setTimeout(
      function() {
        x[place] = false;
        if (this._isMounted) {
          this.setState(x);
        }
      }.bind(this),
      6000
    );
  }

  handleRefresh = event => {
    this.handleSubmit(event);
  };

  handleGetControlNumber = () => {
    if (this._isMounted) {
      this.setState({ openControlNumDialog: true });
    }
  };

  handleClose = () => {
    if (this._isMounted) {
      this.setState({ openControlNumDialog: false });
    }
  };

  handleSubmit = event => {
    if (!this.validator.fieldValid("controlNum")) {
      this.setState({ validationError: true });
    }
    if (!this.state.validationError) {
      event.preventDefault();
      this.selectTable.fireFetchData();
    }
  };

  handleClear = () => {
    this.setState({ validationError: true });
    this.props.delHistAccountInquiry();
  };

  handleExcelDownload = () => {
    commonExcelDownload(
      this,
      APIURIs.EFT_ACCOUNTHIST_XLSDATA_URI,
      APIURIs.EFT_ACCOUNTHIST_XLSDATA_APIKEY,
      { ...this.props.histAccountInquiry },
      "EFTHistoricalRecords.xlsx"
    ).then(response => {
      if (response.status == 200 && response.message == "email") {
        this.showNotification("excelDownloadElt");
      }
    });
  };

  handleChange = event => {
    if (event.target.name == "controlNum") {
      if (event.target.value == "") {
        this.setState({ validationError: true });
      } else {
        this.setState({ validationError: false });
      }
    }
    let histAccountInquiryTmp = Object.assign(
      {},
      this.props.histAccountInquiry
    );
    histAccountInquiryTmp[event.target.name] = event.target.value;
    this.props.addHistAccountInquiry(histAccountInquiryTmp);
  };

  handleDateChange = (dateName, dateValue) => {
    let histAccountInquiryTmp = Object.assign(
      {},
      this.props.histAccountInquiry
    );
    histAccountInquiryTmp[dateName] = formatDate(dateValue);

    if (diffDays(dateValue, this.props.histAccountInquiry.toCycleDate) > 30) {
      histAccountInquiryTmp["toCycleDate"] = formatDate(dateValue);
    }

    this.props.addHistAccountInquiry(histAccountInquiryTmp);
  };

  handleDateChangeRaw = e => {
    e.preventDefault();
  };

  fetchData = state => {
    if (this._isMounted) {
      this.setState({ loading: true });
    }
    getHistAccountInquiryData(
      state.pageSize,
      state.page,
      state.sorted,
      state.filtered,
      this.props.histAccountInquiry
    )
      .then(res => {
        if (this._isMounted) {
          this.setState({
            data: res.rows,
            pages: res.pages == undefined ? 0 : res.pages,
            totalRecords: res.totalRecords,
            loading: false
          });
        }
      })
      .catch(error => {
        console.warn(error);
        if (this._isMounted) {
          this.setState({ loading: false });
        }
      });
  };

  render() {
    const { data, pages, loading } = this.state;
    return (
      <React.Fragment>
        <Overlay active={this.state.downloadExcelLoading} marginTop="150px">
          <p />
          {this.state.validationError ? (
            <Chip
              icon={<WarningOutlined />}
              label={validationMsg}
              color="secondary"
            />
          ) : (
            ""
          )}
          <table border="0px" cellPadding="0" cellSpacing="0">
            <tbody>
              <tr>
                <td className="VerticalAlignBottom">
                  <TextField
                    id="controlNum"
                    name="controlNum"
                    label="Control Number"
                    type="search"
                    className={classes.textField}
                    onChange={this.handleChange}
                    value={this.props.histAccountInquiry.controlNum}
                    margin="none"
                  />
                  {this.validator.message(
                    "controlNum",
                    this.props.histAccountInquiry.controlNum,
                    "required"
                  )}
                </td>
                <td>&nbsp;</td>
                <td className="VerticalAlignBottom">
                  <TextField
                    id="polCont"
                    name="polCont"
                    label="Policy Number"
                    type="search"
                    className={classes.textField}
                    onChange={this.handleChange}
                    value={this.props.histAccountInquiry.polCont}
                    margin="none"
                  />
                </td>
                <td>&nbsp;</td>
                <td className="VerticalAlignBottom">
                  <TextField
                    id="bankAcctNum"
                    name="bankAcctNum"
                    label="Bank Account No"
                    type="search"
                    className={classes.textField}
                    onChange={this.handleChange}
                    value={this.props.histAccountInquiry.bankAcctNum}
                    margin="none"
                  />
                </td>
                <td>&nbsp;</td>
                <td className="VerticalAlignBottom">
                  <TextField
                    id="transitNum"
                    name="transitNum"
                    label="Transit Number"
                    type="search"
                    className={classes.textField}
                    onChange={this.handleChange}
                    value={this.props.histAccountInquiry.transitNum}
                    margin="none"
                  />
                </td>
              </tr>
            </tbody>
          </table>
          <table border="0px" cellPadding="0" cellSpacing="0">
            <tbody>
              <tr>
                <td>&nbsp;</td>
                <td className="VerticalAlignBottom">
                  <FormControl style={{ flexDirection: "row" }}>
                    <Typography variant="caption">
                      <br />
                      <DatePickerInput
                        id="fromCycleDate"
                        name="fromCycleDate"
                        placeholderText="From Cycle Date"
                        onChangeRaw={this.handleDateChangeRaw}
                        selected={formatStringToDate(
                          this.props.histAccountInquiry.fromCycleDate
                        )}
                        onChange={dateValue => {
                          this.handleDateChange("fromCycleDate", dateValue);
                        }}
                      />
                    </Typography>
                  </FormControl>
                </td>
                <td>&nbsp;</td>
                <td className="VerticalAlignBottom">
                  <FormControl style={{ flexDirection: "row" }}>
                    <Typography variant="caption">
                      <br />
                      <DatePickerInput
                        id="toCycleDate"
                        name="toCycleDate"
                        placeholderText="To Cycle Date"
                        onChangeRaw={this.handleDateChangeRaw}
                        selected={formatStringToDate(
                          this.props.histAccountInquiry.toCycleDate
                        )}
                        minDate={
                          this.props.histAccountInquiry.fromCycleDate != null
                            ? formatStringToDate(
                                this.props.histAccountInquiry.fromCycleDate
                              )
                            : ""
                        }
                        maxDate={
                          this.props.histAccountInquiry.fromCycleDate != null
                            ? addDays(
                                this.props.histAccountInquiry.fromCycleDate,
                                30
                              )
                            : ""
                        }
                        onChange={dateValue => {
                          this.handleDateChange("toCycleDate", dateValue);
                        }}
                      />
                    </Typography>
                  </FormControl>
                </td>
              </tr>
            </tbody>
          </table>
          <div className="LeftActionBarStyle">
            <Button
              variant="contained"
              color="primary"
              className={classes.button}
              onClick={this.handleSubmit}
            >
              Search
            </Button>
            &nbsp;
            <Button
              variant="contained"
              color="primary"
              className={classes.button}
              onClick={this.handleClear}
            >
              Clear
            </Button>
            &nbsp;
            <Button
              variant="contained"
              color="primary"
              className={classes.button}
              onClick={this.handleGetControlNumber}
            >
              Get Control Number
            </Button>
            <span className="RightActionBarStyle">
              <ExcelDownload
                enabled="true"
                onClick={this.handleExcelDownload}
              />
            </span>
            <span className="RightActionBarStyle">
              <Refresh onClick={this.handleRefresh} />
            </span>
          </div>
          <ReactTable
            ref={reactEFTAccountInquiry =>
              (this.selectTable = reactEFTAccountInquiry)
            }
            columns={[
              {
                Header: "TXN Code",
                accessor: "txnCode",
                headerClassName: "BoldText ColoredText"
              },
              {
                Header: "Transit Number",
                accessor: "transitNum",
                headerClassName: "BoldText ColoredText"
              },
              {
                Header: "Bank Account No",
                accessor: "bankAcctNum",
                headerClassName: "BoldText ColoredText"
              },
              {
                Header: "Acct. Holder's Name",
                accessor: "payorName",
                headerClassName: "BoldText ColoredText"
              },
              {
                Header: "Account Type",
                accessor: "bankAcctType",
                headerClassName: "BoldText ColoredText"
              },
              {
                Header: "Co.ID",
                accessor: "companyCd",
                headerClassName: "BoldText ColoredText"
              },
              {
                Header: "Policy Number",
                accessor: "polCont",
                headerClassName: "BoldText ColoredText"
              },
              {
                Header: "ALIP Cycle Date",
                accessor: "cycleDate",
                headerClassName: "BoldText ColoredText"
              },
              {
                Header: "Paid To Date",
                accessor: "paidToDate",
                headerClassName: "BoldText ColoredText"
              },
              {
                Header: "Amount",
                accessor: "amount",
                headerClassName: "BoldText ColoredText"
              },
              {
                Header: "P/L",
                accessor: "premiumLoanInd",
                headerClassName: "BoldText ColoredText"
              },
              {
                Header: "Frequency",
                accessor: "frequency",
                headerClassName: "BoldText ColoredText"
              },
              {
                Header: "TXN Type",
                accessor: "txnType",
                headerClassName: "BoldText ColoredText"
              },
              {
                Header: "Withdrawal Day",
                accessor: "withdrawDay",
                headerClassName: "BoldText ColoredText"
              },
              {
                Header: "Prev Control Number",
                accessor: "prevControlNum",
                headerClassName: "BoldText ColoredText"
              }
            ]}
            defaultSorted={[
              {
                id: "cycleDate",
                desc: false
              }
            ]}
            manual // Forces table not to paginate or sort automatically, so we can handle it server-side
            data={data}
            pages={pages} // Display the total number of pages
            loading={loading} // Display the loading overlay when we need it
            onFetchData={this.fetchData} // Request new data when things change
            defaultPageSize={10}
            className="-striped -highlight"
          >
            {(state, makeTable) => {
              return (
                <RecordCount
                  state={state}
                  makeTable={makeTable}
                  totalRecords={this.state.totalRecords}
                />
              );
            }}
          </ReactTable>
          <br />
          {/* Control Number Dialog */}
          <EFTControlNumberDialog
            open={this.state.openControlNumDialog}
            handleClose={this.handleClose}
            title="Control Number Search"
          />
          <Snackbar
            place="tr"
            color="success"
            icon={InfoOutlined}
            message="Reprocess successfully initiated!"
            open={this.state.successElt}
            closeNotification={() =>
              this._isMounted ? this.setState({ successElt: false }) : null
            }
            close
          />
          <Snackbar
            place="tr"
            color="danger"
            icon={InfoOutlined}
            message="Reprocess initiation failed!"
            open={this.state.errorElt}
            closeNotification={() =>
              this._isMounted ? this.setState({ errorElt: false }) : null
            }
            close
          />
          <Snackbar
            place="tr"
            color="info"
            icon={InfoOutlined}
            message="No bills found!"
            open={this.state.infoElt}
            closeNotification={() =>
              this._isMounted ? this.setState({ infoElt: false }) : null
            }
            close
          />
          <Snackbar
            place="tr"
            color="success"
            icon={InfoOutlined}
            message="Since the number of records are more than 10K, Excel report will be emailed to your email address."
            open={this.state.excelDownloadElt}
            closeNotification={() =>
              this._isMounted
                ? this.setState({ excelDownloadElt: false })
                : null
            }
            close
          />
        </Overlay>
      </React.Fragment>
    );
  }
}

const mapStateToProps = state => ({
  histAccountInquiry: state.sidebar.eftHistAccountInquiry
});

const mapDispatchToProps = dispatch =>
  bindActionCreators(
    {
      initHistAccountInquiry,
      getHistAccountInquiry,
      addHistAccountInquiry,
      delHistAccountInquiry
    },
    dispatch
  );

EFTAccountHistoryInquiryTable.propTypes = {
  initHistAccountInquiry: PropTypes.func,
  getHistAccountInquiry: PropTypes.func,
  addHistAccountInquiry: PropTypes.func,
  delHistAccountInquiry: PropTypes.func,
  className: PropTypes.string,
  sidebar: PropTypes.object,
  stats: PropTypes.bool,
  icon: PropTypes.bool,
  histAccountInquiry: PropTypes.object
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(requireAuth(EFTAccountHistoryInquiryTable, "mainContent"));
