import React from "react";
import moment from "moment";
import { connect } from "react-redux";
import { bindActionCreators } from "redux";
import PropTypes from "prop-types";
import SimpleReactValidator from "simple-react-validator";

import TextField from "@material-ui/core/TextField";
import Select from "@material-ui/core/Select";
import Button from "@material-ui/core/Button";
import Typography from "@material-ui/core/Typography";
import FormControl from "@material-ui/core/FormControl";
import InfoOutlined from "@material-ui/icons/InfoOutlined";
import FormControlLabel from "@material-ui/core/FormControlLabel";
import Chip from "@material-ui/core/Chip";
import WarningOutlined from "@material-ui/icons/WarningOutlined";
import Radio from "@material-ui/core/Radio";
import InputAdornment from "@material-ui/core/InputAdornment";

// Import actions
import {
  initManualBillSearch,
  getManualBillSearch,
  addManualBillSearch,
  delManualBillSearch
} from "actions/ManualBillSearchAction.jsx";

import "react-table/react-table.css";
import "assets/css/bits-styles-override.css";
import Snackbar from "components/Snackbar/Snackbar.jsx";
import GridItem from "components/Grid/GridItem.jsx";
import GridContainer from "components/Grid/GridContainer.jsx";
import APIURIs from "properties/APIURIs.jsx";
import {
  formatDate,
  getData,
  postData,
  addDays,
  formatStringToDate,
  getObjectFromJSONByValue,
  getFromLocalStorage
} from "utils/CommonFunctions.jsx";
import DatePickerInput from "components/DatePickerInput/DatePickerInput.jsx";
import requireAuth from "utils/AuthenticatedComponent.jsx";
import Overlay from "components/CustomWidgets/Overlay.jsx";
import states from "properties/States.jsx";
import paymentFrequencies from "properties/PaymentFrequencies.jsx";

const classes = theme => ({
  button: {
    margin: theme.spacing.unit
  }
});

const GridRow = props => {
  return (
    <React.Fragment>
      <GridItem xs={12} sm={12} md={6}>
        &nbsp;
      </GridItem>
      <GridItem xs={12} sm={12} md={6}>
        &nbsp;
      </GridItem>
      <GridItem xs={12} sm={12} md={6}>
        <Typography variant="caption">
          <b>{props.label}:</b>
        </Typography>
      </GridItem>
      {props.value !== undefined ? <GridItem>{props.value}</GridItem> : ""}
    </React.Fragment>
  );
};

GridRow.propTypes = {
  label: PropTypes.string,
  value: PropTypes.string
};

function getManualBillData(policyContract) {
  return getData(
    APIURIs.MAN_BILL_DATA_URI + policyContract + "/001/ALIP?billInfo=true",
    APIURIs.MAN_BILL_DATA_APIKEY,
    {}
  );
}

function generateBill(params) {
  return postData(
    APIURIs.MAN_BILL_GEN_URI,
    APIURIs.MAN_BILL_GEN_APIKEY,
    params
  );
}

let defaultValues = {
  payorName: "",
  payorAddrLine1: "",
  payorAddrLine2: "",
  payorCity: "",
  payorState: "",
  payorZip: "",
  premiumDueBillDate: addDays(moment(new Date(), "YYYY-MM-DD").toDate(), 1),
  cycleDate: moment(new Date(), "YYYY-MM-DD").toDate(),
  premiumLoanInd: "P",
  premiumAmnt: "",
  billFrequency: "",
  netBilledAmnt: ""
};

class ManualBillTable extends React.PureComponent {
  _isMounted = false;
  constructor(props) {
    super(props);

    this.state = {
      loading: false,
      billId: "",
      partyType: "",
      policyContract: "",
      showBillDetails: false,
      searchValidationError: false,
      searchValidationMsg: "",
      validationError: false,
      validationMsg: "",
      successElt: false,
      successMsg: "",
      errorElt: false,
      errorMsg: ""
    };
    this.validator = new SimpleReactValidator();
    this.props.initManualBillSearch();
  }

  componentDidMount() {
    this._isMounted = true;
  }

  componentWillUnmount() {
    this._isMounted = false;
    this.props.initManualBillSearch();
  }

  showNotification(place) {
    var x = [];
    x[place] = true;
    if (this._isMounted) {
      this.setState(x);
    }
    this.alertTimeout = setTimeout(
      function() {
        x[place] = false;
        if (this._isMounted) {
          this.setState(x);
        }
      }.bind(this),
      6000
    );
  }

  handleSubmit = () => {
    //Clear all the fields first
    if (this._isMounted) {
      this.setState({ billId: "" });
    }
    this.props.delManualBillSearch();
    let isValidationError = false;
    let validationMsg = "";
    if (!this.validator.fieldValid("policyContract")) {
      isValidationError = true;
      validationMsg = "Validation Failed. Policy Number is mandatory!";
    }
    if (this._isMounted) {
      this.setState({
        searchValidationError: isValidationError,
        searchValidationMsg: validationMsg
      });
    }
    if (isValidationError) {
      return;
    } else {
      this.setState({
        loading: true,
        showBillDetails: true
      });
      getManualBillData(this.state.policyContract)
        .then(res => {
          if (res) {
            var personDetails = getObjectFromJSONByValue(
              res.data.policy.persons,
              "lifeParticipantRoleCode",
              "PAYOR"
            );
            let manBillSearchTmp = Object.assign({}, this.props.dialogdata);
            let personDetail = personDetails[0];
            this.setState({ partyType: personDetail.partyType });

            let nameFromAPI = personDetail.fullName;
            let nameToShow =
              nameFromAPI.indexOf(",") > 0
                ? nameFromAPI.split(",")[1] !== ""
                  ? nameFromAPI.split(",")[1] + " " + nameFromAPI.split(",")[0]
                  : nameFromAPI.split(",")[0]
                : nameFromAPI;
            manBillSearchTmp["payorName"] = nameToShow;
            manBillSearchTmp["payorAddrLine1"] =
              personDetail.addresses[0].line1;
            if (personDetail.addresses[0].line2) {
              manBillSearchTmp["payorAddrLine2"] =
                personDetail.addresses[0].line2;
            }
            manBillSearchTmp["payorCity"] = personDetail.addresses[0].city;
            manBillSearchTmp["payorState"] = personDetail.addresses[0].state;
            manBillSearchTmp["payorZip"] = personDetail.addresses[0].zip;
            manBillSearchTmp["billFrequency"] =
              res.data.policy.billingFrequencyMode;
            // Extra data
            manBillSearchTmp["carrierCode"] = res.data.policy.carrierName;
            let billDetail = res.data.billInfo;
            if (billDetail !== null && billDetail !== undefined) {
              manBillSearchTmp["premiumAmnt"] = billDetail.premiumAmnt;
              manBillSearchTmp["netBilledAmnt"] = billDetail.premiumAmnt;
              // Extra data
              manBillSearchTmp["policyNumber"] = billDetail.alipPolNum;
              manBillSearchTmp["addressInd"] = billDetail.addressInd;
            }
            manBillSearchTmp[
              "payThisAmnt"
            ] = this.props.dialogdata.netBilledAmnt;
            this.props.addManualBillSearch(manBillSearchTmp);
            defaultValues = Object.assign({}, manBillSearchTmp);
          }
          if (this._isMounted) {
            this.setState({
              loading: false
            });
          }
        })
        .catch(error => {
          console.warn(error);
          if (this._isMounted) {
            this.setState({ loading: false });
          }
        });
    }
  };

  handleAction = actionType => {
    if (actionType === "reset") {
      this.props.addManualBillSearch(defaultValues);
      if (this._isMounted) {
        this.setState({
          validationError: false,
          validationMsg: "",
          billId: ""
        });
      }
    } else {
      if (this._isMounted) {
        this.setState({ loading: true });
      }
      let isValidationError = false;
      let validationMsg = "";

      if (!this.validator.fieldValid("payorName")) {
        isValidationError = true;
        validationMsg = "Validation Failed. Please enter valid Payor Name!";
      } else if (!this.validator.fieldValid("payorAddrLine1")) {
        isValidationError = true;
        validationMsg = "Validation Failed. Please enter valid Address Line 1!";
      } else if (!this.validator.fieldValid("payorCity")) {
        isValidationError = true;
        validationMsg = "Validation Failed. Please enter valid City!";
      } else if (!this.validator.fieldValid("payorState")) {
        isValidationError = true;
        validationMsg = "Validation Failed. Please select valid State!";
      } else if (!this.validator.fieldValid("payorZip")) {
        isValidationError = true;
        validationMsg = "Validation Failed. Please enter valid Zip!";
      } else if (!this.validator.fieldValid("billFrequency")) {
        isValidationError = true;
        validationMsg =
          "Validation Failed. Please select valid Payable Frequency!";
      } else if (!this.validator.fieldValid("premiumAmnt")) {
        isValidationError = true;
        validationMsg =
          "Validation Failed. Please enter valid Premium/Loan Amount!";
      } else if (!this.validator.fieldValid("netBilledAmnt")) {
        isValidationError = true;
        validationMsg = "Validation Failed. Please enter valid Net Amount!";
      }
      if (this._isMounted) {
        this.setState({
          validationError: isValidationError,
          validationMsg: validationMsg,
          loading: false
        });
      }
      if (isValidationError) {
        return;
      } else {
        let dataTmp = this.props.dialogdata;
        let params = {
          payorName: dataTmp.payorName,
          payorAddrLine1: dataTmp.payorAddrLine1,
          payorAddrLine2: dataTmp.payorAddrLine2,
          payorCity: dataTmp.payorCity,
          payorState: dataTmp.payorState,
          payorZip: dataTmp.payorZip,
          payorEmail: "",
          emailInd: false,
          phoneNumber: "",
          cycleDate: formatDate(dataTmp.cycleDate),
          printable: true,
          paymentMethod: dataTmp.paymentMethod,
          policies: [
            {
              policyNumber: dataTmp.policyNumber,
              policyContract: this.state.policyContract,
              premiumLoanInd: dataTmp.premiumLoanInd,
              billFrequency: dataTmp.billFrequency,
              premiumAmnt: dataTmp.premiumAmnt,
              netBilledAmnt: dataTmp.netBilledAmnt,
              carrierCode: dataTmp.carrierCode,
              payThisAmnt: dataTmp.netBilledAmnt,
              paymentType: "",
              premiumDueBillDate: formatDate(dataTmp.premiumDueBillDate),
              insuredName: ""
            }
          ],
          insertUserId: getFromLocalStorage("userId"),
          insertUserName:
            getFromLocalStorage("firstName") +
            " " +
            getFromLocalStorage("lastName"),
          phoneBillDetail: {
            accountName: "",
            accountNumber: "",
            accountType: "",
            routingNumber: "",
            comment: ""
          }
        };
        generateBill(params)
          .then(response => {
            if (this._isMounted) {
              this.setState({ loading: false });
            }
            if (response && response.status === 200) {
              if (this._isMounted) {
                this.setState(
                  {
                    successMsg: "Successfully generated the bill!",
                    billId: response.data.billId
                  },
                  function() {
                    this.showNotification("successElt");
                  }
                );
              }
            } else {
              if (this._isMounted) {
                this.setState(
                  {
                    errorMsg: "Failed to generate the bill!"
                  },
                  function() {
                    this.showNotification("errorElt");
                  }
                );
              }
            }
          })
          .catch(error => {
            console.warn(error);
            if (this._isMounted) {
              this.setState({
                loading: false
              });
            }
          });
      }
    }
  };

  handleClear = () => {
    if (this._isMounted) {
      this.setState({
        billId: "",
        policyContract: "",
        showBillDetails: false,
        searchValidationError: false,
        validationError: false
      });
    }
    this.props.delManualBillSearch();
  };

  handleDateChangeRaw = e => {
    e.preventDefault();
  };

  handleStateVarChange = event => {
    this.setState({
      [event.target.name]: event.target.value
    });
  };

  handleChange = event => {
    let manBillSearchTmp = Object.assign({}, this.props.dialogdata);
    manBillSearchTmp[event.target.name] = event.target.value;
    this.props.addManualBillSearch(manBillSearchTmp);
  };

  handleDateChange = (dateName, dateValue) => {
    let eBillSearchTmp = Object.assign({}, this.props.dialogdata);
    eBillSearchTmp[dateName] = formatDate(dateValue);
    this.props.addManualBillSearch(eBillSearchTmp);
  };

  render() {
    return (
      <React.Fragment>
        <p />
        {this.state.searchValidationError ? (
          <Chip
            icon={<WarningOutlined />}
            label={this.state.searchValidationMsg}
            color="secondary"
          />
        ) : (
          ""
        )}
        <table border="0px" cellPadding="0" cellSpacing="0">
          <tbody>
            <tr>
              <td className="VerticalAlignBottom">
                <TextField
                  id="policyContract"
                  name="policyContract"
                  label="Enter Policy Number"
                  type="search"
                  className={classes.textField}
                  onChange={this.handleStateVarChange}
                  value={this.state.policyContract}
                  margin="none"
                  InputProps={{
                    endAdornment: (
                      <InputAdornment position="end">
                        <span style={{ color: "red" }}>*</span>
                      </InputAdornment>
                    )
                  }}
                />
                {this.validator.message(
                  "policyContract",
                  this.state.policyContract,
                  "required"
                )}
              </td>
            </tr>
          </tbody>
        </table>
        <div className="LeftActionBarStyle">
          <Button
            variant="contained"
            color="primary"
            className={classes.button}
            onClick={this.handleSubmit}
          >
            Search
          </Button>
          &nbsp;
          <Button
            variant="contained"
            color="primary"
            className={classes.button}
            onClick={this.handleClear}
          >
            Clear
          </Button>
        </div>
        <div align="center">
          {this.state.validationError ? (
            <Chip
              icon={<WarningOutlined />}
              label={this.state.validationMsg}
              color="secondary"
            />
          ) : (
            ""
          )}
        </div>
        {this.state.showBillDetails ? (
          <React.Fragment>
            <Overlay active={this.state.loading} marginTop="150px">
              <FormControl
                component="fieldset"
                style={{ width: "100%" }}
                className={classes.formControl}
              >
                <GridContainer
                  style={{
                    display: "flex",
                    alignItems: "center",
                    textAlign: "right"
                  }}
                >
                  <GridRow label="Bill Id" />
                  <GridItem>
                    <span className="BoldText ColoredText">
                      {this.state.billId}
                    </span>
                  </GridItem>
                  <GridRow
                    label="Policy Number"
                    value={this.state.policyContract}
                  />
                  <GridRow label="Payor Name" />
                  <GridItem>
                    <TextField
                      id="payorName"
                      name="payorName"
                      label="Payor Name"
                      type="search"
                      className={classes.textField}
                      onChange={this.handleChange}
                      value={this.props.dialogdata.payorName}
                      margin="none"
                      InputProps={{
                        endAdornment: (
                          <InputAdornment position="end">
                            <span style={{ color: "red" }}>*</span>
                          </InputAdornment>
                        )
                      }}
                    />
                    {this.validator.message(
                      "payorName",
                      this.props.dialogdata.payorName,
                      "required"
                    )}
                  </GridItem>
                  <GridItem xs={12} sm={12} md={6}>
                    &nbsp;
                  </GridItem>
                  <GridItem
                    xs={12}
                    sm={12}
                    md={6}
                    style={{ padding: "0px", textAlign: "left" }}
                  >
                    {this.state.partyType == "IN" ? (
                      <span>
                        {" "}
                        <strong>
                          (Format as it will appear in the letter: FIRSTNAME
                          MIDDLENAME LASTNAME)
                        </strong>
                      </span>
                    ) : (
                      ""
                    )}
                  </GridItem>
                  <GridRow label="Address Line 1" />
                  <GridItem>
                    <TextField
                      id="payorAddrLine1"
                      name="payorAddrLine1"
                      label="Address Line 1"
                      style={{ width: 300 }}
                      type="search"
                      className={classes.textField}
                      onChange={this.handleChange}
                      value={this.props.dialogdata.payorAddrLine1}
                      margin="none"
                      InputProps={{
                        endAdornment: (
                          <InputAdornment position="end">
                            <span style={{ color: "red" }}>*</span>
                          </InputAdornment>
                        )
                      }}
                    />
                    {this.validator.message(
                      "payorAddrLine1",
                      this.props.dialogdata.payorAddrLine1,
                      "required"
                    )}
                  </GridItem>
                  <GridRow label="Address Line 2" />
                  <GridItem>
                    <TextField
                      id="payorAddrLine2"
                      name="payorAddrLine2"
                      label="Address Line 2"
                      style={{ width: 300 }}
                      type="search"
                      className={classes.textField}
                      onChange={this.handleChange}
                      value={this.props.dialogdata.payorAddrLine2}
                      margin="none"
                    />
                  </GridItem>
                  <GridRow label="City" />
                  <GridItem>
                    <TextField
                      id="payorCity"
                      name="payorCity"
                      label="City"
                      type="search"
                      className={classes.textField}
                      onChange={this.handleChange}
                      value={this.props.dialogdata.payorCity}
                      margin="none"
                      InputProps={{
                        endAdornment: (
                          <InputAdornment position="end">
                            <span style={{ color: "red" }}>*</span>
                          </InputAdornment>
                        )
                      }}
                    />
                    {this.validator.message(
                      "payorCity",
                      this.props.dialogdata.payorCity,
                      "required"
                    )}
                  </GridItem>
                  <GridRow label="State" />
                  <GridItem>
                    <FormControl style={{ display: "inline" }}>
                      <Select
                        native
                        autoWidth={true}
                        value={this.props.dialogdata.payorState}
                        onChange={this.handleChange}
                        inputProps={{
                          name: "payorState",
                          id: "payorState"
                        }}
                      >
                        <option value="" />
                        {states.map(option => (
                          <option key={option.value} value={option.value}>
                            {option.label}
                          </option>
                        ))}
                      </Select>
                      {this.validator.message(
                        "payorState",
                        this.props.dialogdata.payorState,
                        "required"
                      )}
                      <span style={{ color: "red" }}>*</span>
                    </FormControl>
                  </GridItem>
                  <GridRow label="Zip" />
                  <GridItem>
                    <TextField
                      id="payorZip"
                      name="payorZip"
                      label="Zip"
                      type="search"
                      className={classes.textField}
                      onChange={this.handleChange}
                      value={this.props.dialogdata.payorZip}
                      margin="none"
                      InputProps={{
                        endAdornment: (
                          <InputAdornment position="end">
                            <span style={{ color: "red" }}>*</span>
                          </InputAdornment>
                        )
                      }}
                    />
                    {this.validator.message(
                      "payorZip",
                      this.props.dialogdata.payorZip,
                      "required|numeric"
                    )}
                  </GridItem>
                  <GridRow label="Due Date" />
                  <GridItem>
                    <table>
                      <tbody>
                        <tr>
                          <td>
                            <DatePickerInput
                              id="premiumDueBillDate"
                              name="premiumDueBillDate"
                              placeholderText=""
                              onChangeRaw={this.handleDateChangeRaw}
                              selected={formatStringToDate(
                                this.props.dialogdata.premiumDueBillDate
                              )}
                              onChange={dateValue => {
                                this.handleDateChange(
                                  "premiumDueBillDate",
                                  dateValue
                                );
                              }}
                            />
                          </td>
                          <td>
                            <span style={{ color: "red" }}>*</span>
                          </td>
                        </tr>
                      </tbody>
                    </table>
                  </GridItem>
                  <GridRow label="Premium/Loan Indicator" />
                  <GridItem>
                    <FormControlLabel
                      control={
                        <Radio
                          color="primary"
                          name="premiumLoanInd"
                          value="P"
                          checked={this.props.dialogdata.premiumLoanInd === "P"}
                          onChange={this.handleChange}
                        />
                      }
                      label="Premium"
                    />
                    <FormControlLabel
                      control={
                        <Radio
                          color="primary"
                          name="premiumLoanInd"
                          value="L"
                          checked={this.props.dialogdata.premiumLoanInd === "L"}
                          onChange={this.handleChange}
                        />
                      }
                      label="Loan"
                    />
                  </GridItem>
                  <GridRow label="Payable Frequency" />
                  <GridItem>
                    <FormControl style={{ display: "inline" }}>
                      <Select
                        native
                        autoWidth={true}
                        value={this.props.dialogdata.billFrequency}
                        onChange={this.handleChange}
                        inputProps={{
                          name: "billFrequency",
                          id: "billFrequency"
                        }}
                      >
                        <option value="" />
                        {paymentFrequencies.map(option => (
                          <option key={option.value} value={option.value}>
                            {option.label}
                          </option>
                        ))}
                        {this.validator.message(
                          "billFrequency",
                          this.props.dialogdata.billFrequency,
                          "required"
                        )}
                      </Select>
                      <span style={{ color: "red" }}>*</span>
                    </FormControl>
                  </GridItem>
                  <GridRow label="Premium/Loan Amount" />
                  <GridItem>
                    <TextField
                      id="premiumAmnt"
                      name="premiumAmnt"
                      label="Premium/Loan Amount"
                      type="search"
                      className={classes.textField}
                      onChange={this.handleChange}
                      value={this.props.dialogdata.premiumAmnt}
                      margin="none"
                      InputProps={{
                        endAdornment: (
                          <InputAdornment position="end">
                            <span style={{ color: "red" }}>*</span>
                          </InputAdornment>
                        )
                      }}
                    />
                    {this.validator.message(
                      "premiumAmnt",
                      this.props.dialogdata.premiumAmnt,
                      "required|numeric"
                    )}
                  </GridItem>
                  <GridRow label="Net Amount" />
                  <GridItem>
                    <TextField
                      id="netBilledAmnt"
                      name="netBilledAmnt"
                      label="Net Amount"
                      type="search"
                      className={classes.textField}
                      onChange={this.handleChange}
                      value={this.props.dialogdata.netBilledAmnt}
                      margin="none"
                      InputProps={{
                        endAdornment: (
                          <InputAdornment position="end">
                            <span style={{ color: "red" }}>*</span>
                          </InputAdornment>
                        )
                      }}
                    />
                    {this.validator.message(
                      "netBilledAmnt",
                      this.props.dialogdata.netBilledAmnt,
                      "required|numeric"
                    )}
                  </GridItem>
                  <GridItem xs={12} sm={12} md={6}>
                    &nbsp;
                  </GridItem>
                  <GridItem xs={12} sm={12} md={6}>
                    &nbsp;
                  </GridItem>
                </GridContainer>
              </FormControl>
              <div style={{ textAlign: "center" }}>
                <Button
                  className={classes.button}
                  variant="contained"
                  color="primary"
                  onClick={() => this.handleAction("reset")}
                >
                  Reset
                </Button>
                &nbsp;
                <Button
                  className={classes.button}
                  variant="contained"
                  color="primary"
                  disabled={this.state.billId != "" ? true : false}
                  onClick={() => this.handleAction("save")}
                >
                  Generate
                </Button>
              </div>
              <Snackbar
                place="tr"
                color="success"
                icon={InfoOutlined}
                message={this.state.successMsg}
                open={this.state.successElt}
                closeNotification={() => this.setState({ successElt: false })}
                close
              />
              <Snackbar
                place="tr"
                color="danger"
                icon={InfoOutlined}
                message={this.state.errorMsg}
                open={this.state.errorElt}
                closeNotification={() => this.setState({ errorElt: false })}
                close
              />
            </Overlay>
          </React.Fragment>
        ) : (
          ""
        )}
      </React.Fragment>
    );
  }
}

const mapStateToProps = state => ({
  dialogdata: state.sidebar.manualBillSearch
});

const mapDispatchToProps = dispatch =>
  bindActionCreators(
    {
      initManualBillSearch,
      getManualBillSearch,
      addManualBillSearch,
      delManualBillSearch
    },
    dispatch
  );

ManualBillTable.propTypes = {
  initManualBillSearch: PropTypes.func,
  addManualBillSearch: PropTypes.func,
  getManualBillSearch: PropTypes.func,
  delManualBillSearch: PropTypes.func,
  className: PropTypes.string,
  sidebar: PropTypes.object,
  stats: PropTypes.bool,
  icon: PropTypes.bool,
  dialogdata: PropTypes.object
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(requireAuth(ManualBillTable, "mainContent"));
