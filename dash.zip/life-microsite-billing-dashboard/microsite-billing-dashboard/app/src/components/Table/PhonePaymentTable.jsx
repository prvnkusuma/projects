import React from "react";

import requireAuth from "utils/AuthenticatedComponent.jsx";
import PhonePaymentSearchTable from "components/Table/PhonePaymentSearchTable.jsx";
import PhonePaymentEntryTable from "components/Table/PhonePaymentEntryTable.jsx";

class PhonePaymentTable extends React.Component {
  _isMounted = false;
  constructor(props) {
    super(props);

    this.state = {
      mode: "search",
      params: {},
      action: ""
    };
  }

  componentDidMount() {
    this._isMounted = true;
  }

  componentWillUnmount() {
    this._isMounted = false;
  }

  handleModeChange(mode, params, action) {
    this.setState({
      mode: mode,
      params: params,
      action: action
    });
  }

  render() {
    return (
      <React.Fragment>
        {this.state.mode === "search" ? (
          <PhonePaymentSearchTable
            handleModeChange={(mode, params, action) =>
              this.handleModeChange(mode, params, action)
            }
          />
        ) : (
          <PhonePaymentEntryTable
            handleModeChange={(mode, params, action) =>
              this.handleModeChange(mode, params, action)
            }
            params={this.state.params}
            action={this.state.action}
          />
        )}
      </React.Fragment>
    );
  }
}

export default requireAuth(PhonePaymentTable, "mainContent");
