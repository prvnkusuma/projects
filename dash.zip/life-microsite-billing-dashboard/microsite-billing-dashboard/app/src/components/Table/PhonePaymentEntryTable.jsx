import React from "react";
import moment from "moment";
import PropTypes from "prop-types";
import { connect } from "react-redux";
import { bindActionCreators } from "redux";
import MaskedInput from "react-text-mask";
import SimpleReactValidator from "simple-react-validator";

// Import React Table
import ReactTable from "react-table";
import { ReactTableDefaults } from "react-table";

import Tooltip from "@material-ui/core/Tooltip";
import TextField from "@material-ui/core/TextField";
import Button from "@material-ui/core/Button";
import InfoOutlined from "@material-ui/icons/InfoOutlined";
import AddCircleOutlineOutlined from "@material-ui/icons/AddCircleOutlineOutlined";
import Radio from "@material-ui/core/Radio";
import Checkbox from "@material-ui/core/Checkbox";
import Input from "@material-ui/core/Input";
import FormControl from "@material-ui/core/FormControl";
import FormControlLabel from "@material-ui/core/FormControlLabel";
import Chip from "@material-ui/core/Chip";
import WarningOutlined from "@material-ui/icons/WarningOutlined";
import Select from "@material-ui/core/Select";
import InputLabel from "@material-ui/core/InputLabel";
import Typography from "@material-ui/core/Typography";
import Dialog from "@material-ui/core/Dialog";

// Import actions
import {
  initPhonePaymentEntry,
  getPhonePaymentEntry,
  addPhonePaymentEntry,
  delPhonePaymentEntry
} from "actions/PhonePaymentEntryAction.jsx";

import "react-table/react-table.css";
import "assets/css/bits-styles-override.css";
import "assets/css/bits-styles-hrtext.css";

import Snackbar from "components/Snackbar/Snackbar.jsx";
import DatePickerInput from "components/DatePickerInput/DatePickerInput.jsx";
import APIURIs from "properties/APIURIs.jsx";
import countries from "properties/Countries.jsx";
import states from "properties/States.jsx";
import LoadingSpinner from "components/CustomWidgets/LoadingSpinner.jsx";
import {
  postData,
  getObjectFromJSONByValue,
  getTableDataFromJSONObject,
  getData,
  getDataWithNoErrorHandling,
  formatDate,
  formatStringToDate,
  getFromLocalStorage,
  postTableDataWithSearchParams,
  getNewGuid,
  addDays,
  pad,
  isUserRole,
  formatCurrency,
  validateEmailList,
  getNextWorkingDay,
  getLastWorkingDayForGivenDate,
  trim,
  diffWeekendDays,
  getCSTDate
} from "utils/CommonFunctions.jsx";
import requireAuth from "utils/AuthenticatedComponent.jsx";
import Refresh from "components/CustomWidgets/Refresh.jsx";
import Overlay from "components/CustomWidgets/Overlay.jsx";
import CommonEditActions from "views/Other/CommonEditActions.jsx";
import RecordCount from "components/CustomWidgets/RecordCount.jsx";
import InlineCustomConfirmation from "components/CustomWidgets/InlineCustomConfirmation.jsx";
import CommentsActionDialog from "components/Dialog/CommentsActionDialog.jsx";
import InputAdornment from "@material-ui/core/InputAdornment";
import paymentTypes from "properties/PhonePaymentTypes.jsx";
import {
  DialogTitle,
  DialogContent,
  DialogActions
} from "components/Dialog/CommonDialog.jsx";

//Set default values of React Table
Object.assign(ReactTableDefaults, {
  multiSort: false,
  LoadingComponent: LoadingSpinner
});

const allowedDay = date => {
  const day = moment(date).day();
  return day !== 0 && day !== 6;
};

const classes = theme => ({
  formControl: {
    margin: theme.spacing.unit,
    minWidth: 120,
    display: "flex",
    wrap: "nowrap"
  },
  textField: {
    marginLeft: theme.spacing.unit,
    marginRight: theme.spacing.unit,
    width: 200
  },
  button: {
    margin: theme.spacing.unit
  }
});

let defaultEntryData = {
  rows: [
    {
      policies: []
    }
  ],
  pages: 1,
  totalRecords: 1
};

let entryData = defaultEntryData;

function phoneMaskCustom(props) {
  const { inputRef, ...other } = props;

  return (
    <MaskedInput
      {...other}
      ref={ref => {
        inputRef(ref ? ref.inputElement : null);
      }}
      mask={[
        "(",
        /[1-9]/,
        /\d/,
        /\d/,
        ")",
        " ",
        /\d/,
        /\d/,
        /\d/,
        "-",
        /\d/,
        /\d/,
        /\d/,
        /\d/
      ]}
      guide="true"
      pipe="null"
      keepCharPositions="false"
      placeholderChar={"\u2000"}
      style={{ textAlign: "left" }}
      showMask
    />
  );
}

function trimChars(input) {
  return input
    .replace(/\s+/g, "")
    .replace(/\(/g, "")
    .replace(/\)/g, "")
    .replace(/-/g, "");
}

function getPaddedPolicyNumber(policyNumber) {
  var result = policyNumber;
  var firstTimeFlag = true;
  while (result.length < 10) {
    if (firstTimeFlag) {
      result = pad("*********", policyNumber, true);
      firstTimeFlag = false;
    }
    if (result.length < 10) {
      result = pad("**********", result, false);
    }
  }
  return result;
}

function getPhonePmtData(pageSize, page, sorted) {
  return getTableDataFromJSONObject(
    entryData.rows[0].policies,
    pageSize,
    page,
    sorted,
    "policies"
  );
}

function allowNewRow() {
  if (entryData && entryData.rows[0] && entryData.rows[0].policies) {
    let length = entryData.rows[0].policies.length;
    let lastRow = entryData.rows[0].policies[length - 1];
    return lastRow && lastRow.isDraft ? false : true;
  } else {
    return true;
  }
}

function getInquiryHoldingData(policyNumber) {
  return getDataWithNoErrorHandling(
    APIURIs.MAN_BILL_DATA_URI +
      policyNumber.toUpperCase() +
      "/001/ALIP?billInfo=true",
    APIURIs.MAN_BILL_DATA_APIKEY,
    {}
  );
}

function validateDate(dateTmp) {
  return getData(
    APIURIs.PHONE_PMT_DATE_URI + "?date=" + dateTmp,
    APIURIs.PHONE_PMT_DATE_APIKEY,
    {}
  );
}

function updateStatus(trackingNumber, status, suppressCorrespondence, action) {
  return postData(
    APIURIs.PHONE_PMT_ENTRY_STATUS_URI + trackingNumber,
    APIURIs.PHONE_PMT_ENTRY_STATUS_APIKEY,
    {
      trackingNumber: trackingNumber,
      status: status,
      suppressCorrespondence: suppressCorrespondence,
      userName: getFromLocalStorage("userId"),
      action: action
    }
  );
}

function createPayment(params) {
  return postData(
    APIURIs.MAN_BILL_GEN_URI,
    APIURIs.MAN_BILL_GEN_APIKEY,
    params
  );
}

function addNewPolicy(
  policyNumber,
  carrierCode,
  insuredName,
  draftAmnt,
  paymentType,
  isRecurringEFT
) {
  let entryDataTmp = entryData.rows[0].policies;
  let id = getNewGuid();
  let newPolicy = {
    id: id,
    isDraft: true,
    policyNumber: policyNumber,
    carrierCode: carrierCode,
    insuredName: insuredName,
    draftAmnt: draftAmnt,
    paymentType: paymentType,
    isRecurringEFT: isRecurringEFT
  };
  entryDataTmp.splice(entryDataTmp.length, 0, newPolicy);
  entryData.rows[0].policies = entryDataTmp;
  return id;
}

function savePolicy(
  id,
  policyNumber,
  carrierCode,
  insuredName,
  draftAmnt,
  paymentType,
  premiumAmount,
  policyStatus,
  currentBillingMethod,
  isRecurringEFT
) {
  carrierCode = carrierCode === "" ? "001" : carrierCode;
  paymentType = paymentType === "" ? "Premium" : paymentType;
  isRecurringEFT = isRecurringEFT === "" ? false : isRecurringEFT;
  let paymentTypeTmp = getObjectFromJSONByValue(
    paymentTypes,
    "label",
    paymentType
  );
  let policyToSave = {
    id: id,
    policyNumber: trim(policyNumber),
    carrierCode: carrierCode,
    insuredName: insuredName,
    draftAmnt: draftAmnt,
    paymentType:
      paymentTypeTmp && paymentTypeTmp.length > 0
        ? paymentTypeTmp[0].label
        : "",
    premiumAmount: premiumAmount,
    policyStatus: policyStatus,
    currentBillingMethod: currentBillingMethod,
    isRecurringEFT: isRecurringEFT
  };
  let entryDataTmp = entryData.rows[0].policies;
  let i = entryDataTmp.length;
  while (i--) {
    if (entryDataTmp[i].id == id) {
      entryDataTmp[i] = policyToSave;
    }
  }
  entryData.rows[0].policies = entryDataTmp;
}

function deletePolicy(id) {
  let entryDataTmp = entryData.rows[0].policies;
  let i = entryDataTmp.length;
  while (i--) {
    if (entryDataTmp[i].id == id) {
      entryDataTmp.splice(i, 1);
    }
  }
  entryData.rows[0].policies = entryDataTmp;
}

function getTotalDraftAmt(policies, id) {
  let i = policies.length;
  let totalAmt = 0.0;
  while (i--) {
    if (id !== null && policies[i].id == id) {
      continue;
    }
    totalAmt = Number(totalAmt) + Number(policies[i].draftAmnt);
  }
  return totalAmt;
}

function addGUIDs(policies) {
  let entryDataTmp = policies;
  let i = entryDataTmp.length;
  while (i--) {
    entryDataTmp[i].id = getNewGuid();
    // Transform the payment type as per UI value
    let paymentTypeTmp = getObjectFromJSONByValue(
      paymentTypes,
      "value",
      entryDataTmp[i].paymentType
    );
    entryDataTmp[i].paymentType =
      paymentTypeTmp && paymentTypeTmp.length > 0
        ? paymentTypeTmp[0].label
        : "";
    // Clear the comments
    entryDataTmp[i].comment = "";
  }
  entryData.rows[0].policies = entryDataTmp;
}

function updatePolicyComments(id, comments) {
  let entryDataTmp = entryData.rows[0].policies;
  let i = entryDataTmp.length;
  while (i--) {
    if (entryDataTmp[i].id === id) {
      entryDataTmp[i].comment = comments;
      break;
    }
  }
  entryData.rows[0].policies = entryDataTmp;
}

function getBankName(routingNumber) {
  let sorted = [];
  sorted.push({
    id: "bankName",
    desc: false
  });
  return postTableDataWithSearchParams(
    APIURIs.EFT_BANKHDR_INQUIRY_URI,
    APIURIs.EFT_BANKHDR_INQUIRY_APIKEY,
    10,
    0,
    sorted,
    [],
    {
      transitNum: routingNumber,
      bankName: ""
    }
  );
}

class PhonePaymentEntryTable extends React.Component {
  _isMounted = false;
  constructor(props) {
    super(props);

    this.state = {
      data: [],
      pages: null,
      loading: true,
      editMode: false,
      selectedId: "",
      accountName: "",
      carrierCode: "",
      policyNumber: "",
      insuredName: "",
      paymentType: "Premium",
      draftAmnt: "",
      premiumAmount: "",
      policyStatus: "",
      currentBillingMethod: "",
      isRecurringEFT: false,
      status: "",
      confirmationTitle: "",
      confirmationDesc: "",
      submitConfirmationAction: "",
      successElt: false,
      successMsg: "",
      errorElt: false,
      errorMsg: "",
      totalRecords: null,
      openMessageDialog: false,
      forceComments: false,
      premiumMismatchComments: false,
      polStatusComments: false,
      showConfirmPayment: false,
      nameForAlert: "",
      showComments: false,
      searchValidationError: false,
      searchValidationMsg: "",
      validationError: false,
      validationMsg: "",
      messageTitle: "Reinstatement Rules",
      messageDesc:
        "REMINDERS<br/><br/>" +
        "To accept payments for lapsed policies, you must pay all past due and currently due " +
        "premiums (and any outstanding loan interest where applicable)*. Depending on the " +
        "current date vs. the paid to date, it may be in the best interest to also collect for the " +
        "next month.<br/><br/>" +
        "Refer to the appropriate reinstatement guidelines for additional information and review " +
        "the latest grace notice in AWD. If the policy qualifies for formal reinstatement, phone " +
        "payments can only be accepted if there is signed and approved reinstatement application in AWD. The " +
        "required premiums will be reflected in the AWD comments.<br/><br/>" +
        "The discounted ABC premium can only be accepted if there is a signed ABC form in AWD authorizing " +
        "the policy(ies) to be placed back on an active ABC draft."
    };
    // Create Refs for focus when validation failed
    this.nameRef = React.createRef();
    this.lastNameRef = React.createRef();
    this.emailRef = React.createRef();
    this.telephoneNumberRef = React.createRef();
    this.addr1Ref = React.createRef();
    this.cityRef = React.createRef();
    this.stateRef = React.createRef();
    this.zipRef = React.createRef();
    this.accountNumberRef = React.createRef();
    this.accountNumberReenterRef = React.createRef();
    this.routingNumberRef = React.createRef();
    // policy refs
    this.policyNumberRef = React.createRef();
    this.carrierCodeRef = React.createRef();
    this.insuredNameRef = React.createRef();
    this.premiumAmountRef = React.createRef();
    this.policyStatusRef = React.createRef();
    this.draftAmntRef = React.createRef();
    this.currentBillingMethodRef = React.createRef();
    this.commentsRef = React.createRef();
    this.validator = new SimpleReactValidator();
    this.props.initPhonePaymentEntry();
    // If Clone
    if (this.props.action === "clone") {
      this.initializeValuesForClone();
    } else {
      // If Add New
      this.handleDateValidation(getCSTDate()).then(res => {
        let phonePaymentTemp = Object.assign({}, this.props.dialogdata);
        phonePaymentTemp["status"] = "OPEN";
        phonePaymentTemp["enteredBy"] = getFromLocalStorage("userId");
        phonePaymentTemp["draftDate"] = res;
        phonePaymentTemp["selectedDraftDate"] = res;
        this.props.addPhonePaymentEntry(phonePaymentTemp);
      });
      entryData.rows[0].policies = [];
    }
  }

  initializeValuesForClone() {
    let allProps = this.props.params;
    let phonePaymentTmp = Object.assign({}, this.props.dialogdata);
    phonePaymentTmp["name"] = allProps.payorFirstName;
    phonePaymentTmp["mi"] =
      !allProps.payorPartyType && allProps.payorMiddleInitial
        ? allProps.payorMiddleInitial
        : "";
    phonePaymentTmp["lastName"] = !allProps.payorPartyType
      ? allProps.payorLastName
      : "";
    phonePaymentTmp["orgIndicator"] = allProps.payorPartyType;
    phonePaymentTmp["addr1"] = allProps.addr1;
    phonePaymentTmp["addr2"] = allProps.addr2;
    phonePaymentTmp["accountNumber"] = allProps.accountNumber;
    phonePaymentTmp["accountType"] = allProps.accountType;
    phonePaymentTmp["country"] = allProps.country ? allProps.country : "US";
    phonePaymentTmp["city"] = allProps.city;
    phonePaymentTmp["state"] = allProps.state;
    phonePaymentTmp["zip"] = allProps.zip;
    phonePaymentTmp["telephoneNumber"] = allProps.phoneNumber;
    phonePaymentTmp["routingNumber"] = allProps.routingNumber;
    // Populate Bank Name
    this.setBankName(allProps.routingNumber);
    this.handleDateValidation(getCSTDate()).then(res => {
      let phonePaymentTemp = Object.assign({}, this.props.dialogdata);
      phonePaymentTemp["draftDate"] = res;
      phonePaymentTemp["selectedDraftDate"] = res;
      this.props.addPhonePaymentEntry(phonePaymentTemp);
    });
    phonePaymentTmp["email"] = allProps.email;
    phonePaymentTmp["emailIndicator"] = allProps.emailIndicator;
    phonePaymentTmp["suppressCorrespondence"] = allProps.suppressCorrespondence;
    phonePaymentTmp["status"] = "OPEN";
    phonePaymentTmp["totalDraftAmt"] = getTotalDraftAmt(
      allProps.policies,
      null
    );
    phonePaymentTmp["enteredBy"] = getFromLocalStorage("userId");
    // Populate guids for each of the policies and assign to entryData
    addGUIDs(allProps.policies);
    this.props.addPhonePaymentEntry(phonePaymentTmp);
  }

  componentDidMount() {
    this._isMounted = true;
  }

  componentWillUnmount() {
    this._isMounted = false;
    this.props.initPhonePaymentEntry();
  }

  showNotification(place) {
    var x = [];
    x[place] = true;
    if (this._isMounted) {
      this.setState(x);
    }
    this.alertTimeout = setTimeout(
      function() {
        x[place] = false;
        if (this._isMounted) {
          this.setState(x);
        }
      }.bind(this),
      6000
    );
  }

  setBankName(value) {
    let accountNameTmp = "invalid";
    if (value.length === 9) {
      if (this._isMounted) {
        this.setState({ loading: true });
      }
      getBankName(value)
        .then(res => {
          if (res && res.data !== "No records found!") {
            accountNameTmp = res.rows[0].bankName;
          } else {
            this.showOKDialog(
              "Invalid Routing Number",
              "Routing Number validation failed. Please re-enter"
            );
          }
          if (this._isMounted) {
            this.setState({
              accountName: accountNameTmp,
              loading: false
            });
          }
        })
        .catch(error => {
          console.warn(error);
          if (this._isMounted) {
            this.setState({ loading: false });
          }
        });
    } else {
      if (this._isMounted) {
        this.setState(
          {
            accountName: accountNameTmp
          },
          () => {
            this.showOKDialog(
              "Invalid Routing Number",
              "Routing Number validation failed. Please enter 9 digit routing number"
            );
          }
        );
      }
    }
  }

  handleAddNew = () => {
    if (allowNewRow() && this.props.dialogdata.status === "OPEN") {
      if (this.handleSubmitValidations()) {
        return;
      }
      if (this._isMounted) {
        this.setState({
          editMode: false,
          selectedId: "",
          carrierCode: "",
          policyNumber: "",
          insuredName: "",
          draftAmnt: "",
          premiumAmount: "",
          policyStatus: "",
          currentBillingMethod: "",
          paymentType: "Premium",
          isRecurringEFT: false,
          forceComments: false,
          polStatusComments: false,
          premiumMismatchComments: false
        });
      }
      let id = addNewPolicy("", "", "", "", "Premium", false);
      if (this._isMounted) {
        this.setState({
          editMode: true,
          selectedId: id
        });
      }
      this.selectTable.fireFetchData();
    }
  };

  handleRefresh = event => {
    this.handleSubmit(event);
  };

  handleClose = dialogType => {
    if (dialogType === "message") {
      this.setState({ openMessageDialog: false });
    }
  };

  handleCreatePayment() {
    let propsTmp = this.props.dialogdata;
    let policiesTmp = entryData.rows[0].policies;
    let policiesToSend = [];
    for (let i = 0; i < policiesTmp.length; i++) {
      // Discard unsaved policies
      if (!policiesTmp[i].isDraft || !policiesTmp[i].isDraft) {
        let policyTmp = {
          policyNumber: getPaddedPolicyNumber(policiesTmp[i].policyNumber),
          policyContract: getPaddedPolicyNumber(policiesTmp[i].policyNumber),
          premiumLoanInd: "",
          billFrequency: "",
          premiumAmnt: policiesTmp[i].premiumAmount,
          netBilledAmnt: "",
          carrierCode: policiesTmp[i].carrierCode,
          payThisAmnt: policiesTmp[i].draftAmnt,
          paymentType: policiesTmp[i].paymentType,
          premiumDueBillDate: "",
          insuredName: policiesTmp[i].insuredName,
          policyStatus: policiesTmp[i].policyStatus,
          currentPaymentMethod: policiesTmp[i].currentBillingMethod,
          switchToEFT: policiesTmp[i].isRecurringEFT,
          comment: policiesTmp[i].comment
        };
        policiesToSend.push(policyTmp);
      }
    }
    let zip = propsTmp.zip;
    zip =
      zip.length === 6 && zip.indexOf("-") != -1 ? zip.substring(0, 5) : zip;
    let params = {
      payorName: "",
      payorAddrLine1: propsTmp.addr1,
      payorAddrLine2: propsTmp.addr2,
      payorCity: propsTmp.city,
      payorState: propsTmp.state,
      payorZip: zip,
      payorCountry: propsTmp.country,
      payorPartyType: propsTmp.orgIndicator ? "ORG" : "IN",
      payorEmail: propsTmp.email,
      emailInd: propsTmp.emailIndicator,
      phoneNumber: trimChars(propsTmp.telephoneNumber),
      cycleDate: formatDate(propsTmp.selectedDraftDate),
      processingDate: getLastWorkingDayForGivenDate(
        propsTmp.selectedDraftDate
      ).format("YYYY-MM-DD"),
      printable: true,
      paymentMethod: "PHONE",
      suppressCorrespondence: propsTmp.suppressCorrespondence,
      policies: policiesToSend,
      insertUserId: getFromLocalStorage("userId"),
      insertUserName:
        getFromLocalStorage("firstName") +
        " " +
        getFromLocalStorage("lastName"),
      phoneBillDetail: {
        accountFirstName: propsTmp.name,
        accountMiddleInitial: propsTmp.mi === null ? "" : propsTmp.mi,
        accountLastName: propsTmp.lastName,
        accountNumber: propsTmp.accountNumber,
        accountType: propsTmp.accountType,
        routingNumber: propsTmp.routingNumber,
        bankName: this.state.accountName,
        comment: propsTmp.comments,
        draftStatus: "SUBMITTED"
      }
    };
    let phoneDetail = params.phoneBillDetail;
    let nameForAlertTmp = phoneDetail.accountFirstName;
    if (!propsTmp.orgIndicator) {
      if (phoneDetail.accountMiddleInitial !== "") {
        nameForAlertTmp =
          nameForAlertTmp + " " + phoneDetail.accountMiddleInitial;
      }
      if (params.phoneBillDetail.accountLastName !== "") {
        nameForAlertTmp = nameForAlertTmp + " " + phoneDetail.accountLastName;
      }
    }
    if (this._isMounted) {
      this.setState({
        loading: true,
        nameForAlert: nameForAlertTmp
      });
    }
    createPayment(params)
      .then(response => {
        if (response && response.status === 200) {
          if (this._isMounted) {
            this.setState(
              {
                trackingNumber: response.data.transRefGuid,
                loading: false
              },
              function() {
                let phonePaymentTmp = Object.assign({}, this.props.dialogdata);
                phonePaymentTmp["status"] = "SUBMITTED";
                this.props.addPhonePaymentEntry(phonePaymentTmp);
                // Show confirmations and enable confirm Payment
                let accountName =
                  this.state.accountName !== "invalid"
                    ? this.state.accountName
                    : "";
                let accountTypeTmp =
                  this.props.dialogdata.accountType === "CHECKING"
                    ? "checking"
                    : "savings";
                let message =
                  "Script:<br/>" +
                  "Mr./Ms. " +
                  this.state.nameForAlert +
                  ", to confirm your payment, you authorize American General Life " +
                  "Insurance Company to electronically debit your " +
                  accountTypeTmp +
                  " account with " +
                  accountName +
                  " " +
                  "on or after " +
                  formatDate(this.props.dialogdata.draftDate) +
                  " in the amount of " +
                  formatCurrency(this.props.dialogdata.totalDraftAmt) +
                  ".<br/><br/>" +
                  "Do you agree to this payment ? Please respond with YES or NO.";
                this.showConfirmDialog("REMINDERS", message).then(result1 => {
                  if (result1) {
                    message =
                      "Script:<br/>" +
                      "Thank you Mr./Ms. " +
                      this.state.nameForAlert +
                      ". As a reminder, this is a single payment and this " +
                      "authorization is valid for this transaction only." +
                      "<br/><br/>" +
                      "The policy owner may continue to receive correspondence related to the payment " +
                      "until the payment has been applied to the policy. We apologize for the inconvenience." +
                      "<br/><br/>" +
                      "CSR Note:<br/>" +
                      "If the customer says NO, a payment cannot be taken over the phone.";
                    this.showConfirmDialog("REMINDERS", message).then(
                      result2 => {
                        if (result2) {
                          if (this._isMounted) {
                            this.setState({ showConfirmPayment: true });
                          }
                        } else {
                          if (this._isMounted) {
                            this.setState({ showConfirmPayment: false });
                          }
                          this.showDeclineDialog();
                        }
                      }
                    );
                  } else {
                    this.showDeclineDialog();
                  }
                });
              }
            );
          }
        } else {
          if (this._isMounted) {
            this.setState(
              {
                errorMsg: "Failed to create the phone payment!",
                loading: false
              },
              function() {
                this.showNotification("errorElt");
              }
            );
          }
        }
      })
      .catch(error => {
        console.warn(error);
        if (this._isMounted) {
          this.setState({ loading: false });
        }
      });
  }

  handleConfirmPayment = () => {
    updateStatus(
      this.state.trackingNumber,
      "PROCESSED",
      this.props.dialogdata.suppressCorrespondence,
      "status"
    ).then(res => {
      if (res && res.status === 200) {
        let phonePaymentTmp = Object.assign({}, this.props.dialogdata);
        phonePaymentTmp["status"] = "PROCESSED";
        this.props.addPhonePaymentEntry(phonePaymentTmp);
        if (this._isMounted) {
          this.setState(
            {
              successMsg: "Successfully confirmed phone payment!",
              loading: false
            },
            function() {
              this.showNotification("successElt");
              // Return back to the search screen once the notification has been shown
              this.closeWindow = setTimeout(
                function() {
                  this.props.handleModeChange("search", "");
                }.bind(this),
                2000
              );
            }
          );
        }
      } else {
        if (this._isMounted) {
          this.setState({
            errorMsg: "Failed to confirm phone payment!",
            loading: false
          });
          this.showNotification("errorElt");
        }
      }
    });
  };

  handleSubmitValidations() {
    let isValidationError = false;
    let validationMsg = "";
    let numericRegex = /^[0-9]+$/;
    let zipCodeRegex =
      this.props.dialogdata.country === "US"
        ? /^[0-9]{5}(?:-[0-9]{4})?$/
        : /^[a-zA-Z0-9\s]+$/;
    let accountTmp =
      this.props.dialogdata.accountNumber === undefined
        ? ""
        : this.props.dialogdata.accountNumber;
    let accountReenterTmp =
      this.props.dialogdata.accountNumberReenter === undefined
        ? ""
        : this.props.dialogdata.accountNumberReenter;
    if (!this.validator.fieldValid("name")) {
      isValidationError = true;
      if (this.props.dialogdata.orgIndicator) {
        validationMsg = "Validation Failed. Name is mandatory!";
      } else {
        validationMsg = "Validation Failed. First Name is mandatory!";
      }
      this.nameRef.current.focus();
    } else if (
      !this.validator.fieldValid("lastName") &&
      !this.props.dialogdata.orgIndicator
    ) {
      isValidationError = true;
      validationMsg = "Validation Failed. Last Name is mandatory!";
      this.lastNameRef.current.focus();
    } else if (
      this.props.dialogdata.emailIndicator &&
      !this.validator.fieldValid("email")
    ) {
      isValidationError = true;
      validationMsg = "Validation Failed. Email ID is mandatory!";
      this.emailRef.current.focus();
    } else if (
      this.props.dialogdata.email !== "" &&
      !validateEmailList(this.props.dialogdata.email)
    ) {
      isValidationError = true;
      validationMsg = "Validation Failed. Invalid Email ID format!";
      this.emailRef.current.focus();
    } else if (!this.validator.fieldValid("telephoneNumber")) {
      isValidationError = true;
      validationMsg =
        "Validation Failed. Phone number is mandatory and should be 10 digits!";
      this.telephoneNumberRef.current.focus();
    } else if (!this.validator.fieldValid("addr1")) {
      isValidationError = true;
      validationMsg = "Validation Failed. Address Line 1 is mandatory!";
      this.addr1Ref.current.focus();
    } else if (!this.validator.fieldValid("city")) {
      isValidationError = true;
      validationMsg = "Validation Failed. City is mandatory!";
      this.cityRef.current.focus();
    } else if (
      !this.validator.fieldValid("state") &&
      this.props.dialogdata.country === "US"
    ) {
      isValidationError = true;
      validationMsg = "Validation Failed. State is mandatory!";
      this.stateRef.current.focus();
    } else if (
      !this.validator.fieldValid("zip") ||
      !zipCodeRegex.test(this.props.dialogdata.zip)
    ) {
      isValidationError = true;
      if (this.props.dialogdata.country === "US") {
        validationMsg =
          "Validation Failed. Zip Code is mandatory and should be in either 5 digit (XXXXX) or 9 digit (XXXXX-XXXX) format!";
      } else {
        validationMsg = "Validation Failed. Zip Code is mandatory!";
      }
      this.zipRef.current.focus();
    } else if (
      !this.validator.fieldValid("accountNumber") ||
      !numericRegex.test(accountTmp)
    ) {
      isValidationError = true;
      validationMsg =
        "Validation Failed. Account Number is mandatory and should be numeric!";
      this.accountNumberRef.current.focus();
    } else if (
      !this.validator.fieldValid("accountNumberReenter") ||
      !numericRegex.test(accountReenterTmp)
    ) {
      isValidationError = true;
      validationMsg =
        "Validation Failed. Reenter Account Number is mandatory and should be numeric!";
      this.accountNumberReenterRef.current.focus();
    } else if (
      this.props.dialogdata.accountNumber !==
      this.props.dialogdata.accountNumberReenter
    ) {
      isValidationError = true;
      validationMsg =
        "Validation Failed. The Account Numbers entered do not match. Please re-enter!";
      this.accountNumberReenterRef.current.focus();
    } else if (
      !this.validator.fieldValid("routingNumber") ||
      this.props.dialogdata.routingNumber.length !== 9 ||
      this.state.accountName === "invalid"
    ) {
      isValidationError = true;
      validationMsg =
        "Validation Failed. Routing Number is mandatory and should be valid 9 digits!";
      this.routingNumberRef.current.focus();
    } else {
      this.handleDateValidation(this.props.dialogdata.draftDate);
    }
    if (this._isMounted) {
      this.setState({
        searchValidationError: isValidationError,
        searchValidationMsg: validationMsg
      });
    }
    return isValidationError;
  }

  handleSubmit = () => {
    if (this.handleSubmitValidations()) {
      return;
    }
    if (
      entryData.rows[0].policies.length === 0 ||
      (entryData.rows[0].policies.length === 1 &&
        entryData.rows[0].policies[0].isDraft)
    ) {
      this.showOKDialog(
        "Missing Policies",
        "Please add and save atleast one policy to submit."
      );
    } else {
      this.handleHolidayValidation(this.props.dialogdata.draftDate).then(
        res => {
          if (res) {
            let isValidationError = true;
            let validationMsg =
              "Validation Failed. Selected Date is a holiday!";
            if (this._isMounted) {
              this.setState({
                searchValidationError: isValidationError,
                searchValidationMsg: validationMsg
              });
            }
            return;
          } else {
            // call createPayment with SUBMITTED status
            this.handleCreatePayment();
          }
        }
      );
    }
  };

  showDeclineDialog() {
    let message =
      "Script:<br/>" +
      "Unfortunately, Mr./Ms. " +
      this.state.nameForAlert +
      ", because you have not agreed to the terms and " +
      "conditions, I cannot accept the payment by phone." +
      "<br/><br/>" +
      "CSR Note:<br/>" +
      "Click OK to decline the payment or CANCEL to go back and edit the draft (allows " +
      "you to go through these messages again).";
    this.showOkConfirmDialog("REMINDERS", message).then(result2 => {
      if (result2) {
        updateStatus(
          this.state.trackingNumber,
          "DECLINED",
          this.props.dialogdata.suppressCorrespondence,
          "status"
        ).then(res => {
          if (res && res.status === 200) {
            let phonePaymentTmp = Object.assign({}, this.props.dialogdata);
            phonePaymentTmp["status"] = "DECLINED";
            this.props.addPhonePaymentEntry(phonePaymentTmp);
            if (this._isMounted) {
              this.setState(
                {
                  successMsg: "Successfully Declined the phone payment!"
                },
                function() {
                  this.showNotification("successElt");
                  // Return back to the search screen once the notification has been shown
                  this.closeWindow = setTimeout(
                    function() {
                      this.props.handleModeChange("search", "");
                    }.bind(this),
                    2000
                  );
                }
              );
            }
          }
        });
      } else {
        // Change back to OPEN
        let phonePaymentTmp = Object.assign({}, this.props.dialogdata);
        phonePaymentTmp["status"] = "OPEN";
        this.props.addPhonePaymentEntry(phonePaymentTmp);
      }
    });
  }

  handlePolicyComments = (id, comments) => {
    event.preventDefault();
    updatePolicyComments(id, comments);
    this.selectTable.fireFetchData();
  };

  handleClear = () => {
    this.showConfirmDialog(
      "Confirm",
      "Are you sure you want to clear this policy ?"
    ).then(result => {
      if (result) {
        this.props.delPhonePaymentEntry();
        entryData = defaultEntryData;
        entryData.rows[0].policies = [];
        this.selectTable.fireFetchData();
        let phonePaymentTmp = Object.assign({}, this.props.dialogdata);
        phonePaymentTmp["status"] =
          phonePaymentTmp.status === "" ? "OPEN" : phonePaymentTmp.status;
        this.props.addPhonePaymentEntry(phonePaymentTmp);
        if (this._isMounted) {
          this.setState({
            selectedId: "",
            searchValidationError: false,
            validationError: false,
            showConfirmPayment: false,
            accountName: ""
          });
        }
      }
    });
  };

  handleBack = () => {
    if (this.props.dialogdata.status === "SUBMITTED") {
      let message =
        "Script:<br/>" +
        "The changes will be lost upon selecting the 'Back' button. Do you want to continue ? ";
      this.showConfirmDialog("REMINDERS", message).then(result => {
        if (result) {
          this.props.handleModeChange("search", "");
        } else {
          return;
        }
      });
    } else {
      this.props.handleModeChange("search", "");
    }
  };

  handleBlurRoutingNumber = event => {
    if (event.target.value !== "") {
      this.setBankName(event.target.value);
    } else {
      if (this._isMounted) {
        this.setState({
          accountName: ""
        });
      }
    }
  };

  showOKDialog(title, description) {
    return InlineCustomConfirmation.show({
      title: title,
      description: description,
      button1Title: "OK",
      button2Title: ""
    });
  }

  showPolicyMisMatchDialog() {
    return this.showConfirmDialog(
      "Policy Mismatch",
      "Unable to retrieve the ALIP policy details. Please enter the details in the required fields if you wish to continue with the payment."
    ).then(result => {
      if (result) {
        if (this._isMounted) {
          this.setState({ forceComments: true });
        }
        this.showOKDialog(
          "Justification",
          "Please enter your comments for justification"
        ).then(() => {
          this.focusIt = setTimeout(
            function() {
              this.carrierCodeRef.current.focus();
            }.bind(this),
            500
          );
          return true;
        });
        return false;
      } else {
        this.clearPolicyRowAndFocus();
        return false;
      }
    });
  }

  showPolicyNotFoundDialog() {
    this.showOKDialog(
      "Invalid Policy",
      "Not a valid ALIP Policy. Cannot submit Payment."
    ).then(() => {
      this.clearPolicyRowAndFocus();
      return;
    });
    return;
  }

  showPremiumMisMatchDialog() {
    this.showConfirmDialog(
      "Premiums Mismatch",
      "Draft Premium doesn’t match the Modal Premium. Do you want to continue with the transaction ?"
    ).then(result1 => {
      if (result1) {
        if (this._isMounted) {
          this.setState({ premiumMismatchComments: true });
        }
        this.showOKDialog(
          "Justification",
          "Please enter your comments for justification"
        ).then(() => {
          this.focusIt = setTimeout(
            function() {
              this.commentsRef.current.focus();
            }.bind(this),
            500
          );
          this.validatePremiumMisMatch();
        });
      }
    });
    return;
  }

  showLargePremiumDialog() {
    this.showConfirmDialog(
      "Large Premium Amount",
      "A premium amount of " +
        formatCurrency(this.state.draftAmnt) +
        " was entered. Is this correct ?"
    ).then(result => {
      if (result) {
        if (
          Number(this.state.premiumAmount) !== Number(this.state.draftAmnt) &&
          !this.state.premiumMismatchComments &&
          this.state.paymentType === "Premium"
        ) {
          this.showPremiumMisMatchDialog();
          return;
        } else {
          if (this._isMounted) {
            this.setState({ premiumMismatchComments: true });
          }
          // Save
          this.save();
        }
      }
    });
    return;
  }

  showInvalidPolicyStatusDialog() {
    this.showConfirmDialog(
      "Invalid Policy Status",
      "Invalid Policy Status for processing Reinstatement. Do you want to continue with the transaction ?"
    ).then(result1 => {
      if (result1) {
        if (this._isMounted) {
          this.setState({ polStatusComments: true });
        }
        this.showOKDialog(
          "Justification",
          "Please enter your comments for justification"
        ).then(() => {
          this.focusIt = setTimeout(
            function() {
              this.commentsRef.current.focus();
              this.validateLargePremium();
              return;
            }.bind(this),
            500
          );
        });
      }
    });
    return;
  }

  showConfirmDialog(title, description) {
    return InlineCustomConfirmation.show({
      title: title,
      description: description,
      button1Title: "YES",
      button2Title: "NO"
    });
  }

  showOkConfirmDialog(title, description) {
    return InlineCustomConfirmation.show({
      title: title,
      description: description,
      button1Title: "OK",
      button2Title: "CANCEL"
    });
  }

  resetCommentFlags() {
    if (this._isMounted) {
      this.setState({
        forceComments: false,
        polStatusComments: false,
        premiumMismatchComments: false
      });
    }
  }

  handleAction = (
    action,
    id,
    carrierCode,
    policyNumber,
    insuredName,
    draftAmnt,
    paymentType,
    policyStatus,
    currentBillingMethod,
    isRecurringEFT,
    premiumAmount
  ) => {
    if (action === "edit") {
      if (this._isMounted) {
        this.setState(
          {
            editMode: true,
            selectedId: id,
            carrierCode: carrierCode,
            policyNumber: policyNumber,
            insuredName: insuredName,
            premiumAmount:
              premiumAmount !== undefined && premiumAmount !== ""
                ? Number.parseFloat(premiumAmount).toFixed(2)
                : "",
            draftAmnt:
              draftAmnt !== undefined && draftAmnt !== ""
                ? Number.parseFloat(draftAmnt).toFixed(2)
                : "",
            paymentType: paymentType === "" ? "Premium" : paymentType,
            policyStatus: policyStatus !== null ? policyStatus : "",
            currentBillingMethod:
              currentBillingMethod !== null ? currentBillingMethod : "",
            isRecurringEFT: isRecurringEFT === "" ? false : isRecurringEFT
          },
          () => {
            this.policyNumberRef.current.focus();
          }
        );
      }
      return;
    }
    if (action === "cancel") {
      //wait for a second for the blur event to complete
      this.closeWindow = setTimeout(
        function() {
          if (this._isMounted) {
            this.setState({
              editMode: false,
              selectedId: "",
              policyNumber: "",
              forceComments: false,
              polStatusComments: false,
              premiumMismatchComments: false
            });
            this.clearPolicyRow();
          }
          let phonePaymentTmp = Object.assign({}, this.props.dialogdata);
          phonePaymentTmp["totalDraftAmt"] = getTotalDraftAmt(
            entryData.rows[0].policies,
            null
          );
          this.props.addPhonePaymentEntry(phonePaymentTmp);
          return;
        }.bind(this),
        1000
      );
    }
    if (action === "save") {
      if (this._isMounted) {
        this.setState({ selectedId: id });
      }
      let isValidationError = false;
      let validationMsg = "";
      let policyTmp = getObjectFromJSONByValue(
        entryData.rows[0].policies,
        "policyNumber",
        this.state.policyNumber
      );
      if (!this.validator.fieldValid("policyNumber")) {
        isValidationError = true;
        validationMsg = "Validation Failed. Policy Number is mandatory!";
        this.policyNumberRef.current.focus();
      } else if (
        policyTmp.length > 0 &&
        policyTmp[0].id !== id &&
        policyTmp[0].paymentType === this.state.paymentType
      ) {
        isValidationError = true;
        validationMsg =
          "Validation Failed. Policy Number and Payment Type combination already exists!";
        this.policyNumberRef.current.focus();
      } else if (!this.validator.fieldValid("insuredName")) {
        isValidationError = true;
        validationMsg = "Validation Failed. Insured Name is mandatory!";
        this.insuredNameRef.current.focus();
      } else if (!this.validator.fieldValid("premiumAmount")) {
        isValidationError = true;
        validationMsg = "Validation Failed. Premium is mandatory!";
        this.premiumAmountRef.current.focus();
      } else if (!this.validator.fieldValid("policyStatus")) {
        isValidationError = true;
        validationMsg = "Validation Failed. Policy Status is mandatory!";
        this.policyStatusRef.current.focus();
      } else if (!this.validator.fieldValid("draftAmnt")) {
        isValidationError = true;
        validationMsg = "Validation Failed. Draft Amount is mandatory!";
        this.draftAmntRef.current.focus();
      } else if (!this.validator.fieldValid("currentBillingMethod")) {
        isValidationError = true;
        validationMsg = "Validation Failed. Current Bill Method is mandatory!";
        this.currentBillingMethodRef.current.focus();
      }

      if (this._isMounted) {
        this.setState({
          validationError: isValidationError,
          validationMsg: validationMsg
        });
      }
      if (isValidationError) {
        return;
      }
      this.validatePolicy();
    }
    if (action === "delete") {
      this.showConfirmDialog(
        "Confirm",
        "Are you sure you want to delete this policy ?"
      ).then(result => {
        if (result) {
          deletePolicy(id);
          this.selectTable.fireFetchData();
          if (this._isMounted) {
            this.setState({
              editMode: false,
              selectedId: "",
              carrierCode: "",
              policyNumber: "",
              insuredName: "",
              draftAmnt: "",
              premiumAmount: "",
              paymentType: "",
              forceComments: false,
              polStatusComments: false,
              premiumMismatchComments: false,
              validationError: false,
              validationMsg: ""
            });
          }
          let phonePaymentTmp = Object.assign({}, this.props.dialogdata);
          phonePaymentTmp["totalDraftAmt"] = getTotalDraftAmt(
            entryData.rows[0].policies,
            null
          );
          this.props.addPhonePaymentEntry(phonePaymentTmp);
        }
      });
    }
  };

  validateInvalidPolicy = () => {
    if (
      this.state.paymentType === "Reinstatement" &&
      this.state.policyStatus !== "Lapsed" &&
      !this.state.polStatusComments
    ) {
      this.showInvalidPolicyStatusDialog();
      return;
    } else {
      if (this._isMounted) {
        this.setState({ polStatusComments: true });
      }
      this.validateLargePremium();
      return;
    }
  };

  validateLargePremium = () => {
    if (
      Number(this.state.draftAmnt) >= 500 &&
      !this.state.premiumMismatchComments
    ) {
      this.showLargePremiumDialog();
      return;
    } else {
      this.validatePremiumMisMatch();
    }
  };

  validatePremiumMisMatch = () => {
    if (
      Number(this.state.premiumAmount) !== Number(this.state.draftAmnt) &&
      !this.state.premiumMismatchComments &&
      this.state.paymentType === "Premium"
    ) {
      this.showPremiumMisMatchDialog();
      return;
    } else {
      if (this._isMounted) {
        this.setState({ premiumMismatchComments: true });
      }
      // Save
      this.save();
    }
  };

  validatePolicy = () => {
    if (this.state.polStatusComments && this.state.premiumMismatchComments) {
      this.save();
    } else {
      this.validateInvalidPolicy();
    }
  };

  save = () => {
    // If everything is fine, save the policy
    if (this._isMounted) {
      this.setState({
        loading: true
      });
    }
    savePolicy(
      this.state.selectedId,
      this.state.policyNumber,
      this.state.carrierCode,
      this.state.insuredName,
      this.state.draftAmnt,
      this.state.paymentType,
      this.state.premiumAmount,
      this.state.policyStatus,
      this.state.currentBillingMethod,
      this.state.isRecurringEFT
    );
    this.selectTable.fireFetchData();
    if (this._isMounted) {
      this.setState(
        {
          successMsg: "Successfully added/updated policy!",
          editMode: false,
          loading: false,
          forceComments: false,
          polStatusComments: false,
          premiumMismatchComments: false
        },
        function() {
          let phonePaymentTmp = Object.assign({}, this.props.dialogdata);
          phonePaymentTmp["totalDraftAmt"] = getTotalDraftAmt(
            entryData.rows[0].policies,
            null
          );
          this.props.addPhonePaymentEntry(phonePaymentTmp);
          this.showNotification("successElt");
        }
      );
    }
  };

  handleSelectChange = type => event => {
    if (this._isMounted) {
      if (type === "paymentType" && event.target.value === "Reinstatement") {
        this.setState({
          [type]: event.target.value,
          openMessageDialog: true
        });
      } else {
        this.setState({ [type]: event.target.value });
      }
    }
    this.resetCommentFlags();
  };

  handleHolidayValidation = dateValue => {
    if (this._isMounted) {
      this.setState({ loading: true });
    }
    // If current date is a holiday
    return validateDate(formatDate(dateValue))
      .then(res => {
        if (res) {
          if (res.data) {
            if (this._isMounted) {
              this.setState({ loading: false });
            }
            return res.data.isHoliday;
          }
        }
      })
      .catch(error => {
        console.warn(error);
        if (this._isMounted) {
          this.setState({ loading: false });
        }
        return false;
      });
  };

  handleDateValidation = dateValue => {
    if (this._isMounted) {
      this.setState({ loading: true });
    }
    let dateToShow = formatDate(getNextWorkingDay(dateValue));
    // If current date is selected, check if 1:30 PM CST has gone past
    return validateDate(formatDate(dateValue))
      .then(res => {
        if (res) {
          if (res.data) {
            // Date past 1:30 PM CST, Add current day + 2
            if (res.data.isBatchedProcessed) {
              dateToShow = formatDate(getNextWorkingDay(dateToShow));
            }
            if (this._isMounted) {
              this.setState({ loading: false });
            }
            // Else return next working day
            return dateToShow;
          }
        }
      })
      .catch(error => {
        console.warn(error);
        if (this._isMounted) {
          this.setState({ loading: false });
        }
        return dateToShow;
      });
  };

  handleDateChange = (dateName, dateValue) => {
    let formattedDate = formatDate(dateValue);
    let phonePaymentTmp = Object.assign({}, this.props.dialogdata);
    phonePaymentTmp[dateName] = formattedDate;
    this.props.addPhonePaymentEntry(phonePaymentTmp);
  };

  handleCheckboxChange = event => {
    let phonePaymentTmp = Object.assign({}, this.props.dialogdata);
    if (event.target.name === "orgIndicator" && event.target.checked == true) {
      phonePaymentTmp["mi"] = "";
      phonePaymentTmp["lastName"] = "";
    }
    phonePaymentTmp[event.target.name] = event.target.checked;
    this.props.addPhonePaymentEntry(phonePaymentTmp);
  };

  handleAmntChange = (name, id) => event => {
    if (this._isMounted) {
      this.setState({
        [name]: event.target.value,
        validationError: false,
        validationMsg: ""
      });
    }
    this.resetCommentFlags();
    // If Draft Amount is changed then update the Total Draft Amount
    if (name === "draftAmnt") {
      let phonePaymentTmp = Object.assign({}, this.props.dialogdata);
      phonePaymentTmp["totalDraftAmt"] =
        getTotalDraftAmt(entryData.rows[0].policies, id) +
        Number(event.target.value);
      this.props.addPhonePaymentEntry(phonePaymentTmp);
    }
  };

  clearPolicyRow() {
    if (this._isMounted) {
      this.setState({
        carrierCode: "",
        insuredName: "",
        policyStatus: "",
        currentBillingMethod: "",
        isRecurringEFT: "",
        premiumAmount: "",
        draftAmnt: "",
        paymentType: ""
      });
    }
  }

  clearPolicyRowAndFocus() {
    this.clearPolicyRow();
    if (this._isMounted) {
      this.setState({
        policyNumber: ""
      });
    }
    this.focusIt = setTimeout(
      function() {
        this.policyNumberRef.current.focus();
      }.bind(this),
      500
    );
  }

  handleTextKeyDown = event => {
    if (event.keyCode !== 9 && event.keyCode !== 13) {
      return;
    }
    event.preventDefault();
    // If Tab/Enter is pressed
    if (event.keyCode === 9 || event.keyCode === 13) {
      let policyNumber = event.target.value;
      let paddedPolicyNumber = getPaddedPolicyNumber(policyNumber);
      if (
        paddedPolicyNumber.trim() !== "" &&
        paddedPolicyNumber !== "**********"
      ) {
        if (this._isMounted) {
          this.setState({
            loading: true
          });
        }
        this.clearPolicyRow();
        getInquiryHoldingData(paddedPolicyNumber)
          .then(res => {
            if (res && res.status === 200) {
              var personDetails = getObjectFromJSONByValue(
                res.data.policy.persons,
                "lifeParticipantRoleCode",
                "INSURED"
              );
              let nameFromAPI = personDetails[0].fullName;
              let nameToShow =
                nameFromAPI.indexOf(",") > 0
                  ? nameFromAPI.split(",")[1] !== ""
                    ? nameFromAPI.split(",")[1] +
                      " " +
                      nameFromAPI.split(",")[0]
                    : nameFromAPI.split(",")[0]
                  : nameFromAPI;
              let billDetail = res.data.billInfo;
              let premiumAmount = "";
              if (billDetail !== null && billDetail !== undefined) {
                premiumAmount = billDetail.premiumAmnt;
                let phonePaymentTmp = Object.assign({}, this.props.dialogdata);
                phonePaymentTmp["totalDraftAmt"] =
                  getTotalDraftAmt(
                    entryData.rows[0].policies,
                    this.state.selectedId
                  ) + Number(premiumAmount);
                this.props.addPhonePaymentEntry(phonePaymentTmp);
              }

              if (this._isMounted) {
                let amount =
                  premiumAmount !== undefined && premiumAmount !== ""
                    ? Number.parseFloat(premiumAmount).toFixed(2)
                    : "";
                this.setState({
                  carrierCode: res.data.policy.carrierName,
                  insuredName: nameToShow,
                  policyStatus: res.data.policy.policyStatus
                    ? res.data.policy.policyStatus
                    : "",
                  currentBillingMethod: res.data.policy.paymentMethod
                    ? res.data.policy.paymentMethod
                    : "",
                  premiumAmount: amount,
                  draftAmnt: amount,
                  paymentType: "Premium",
                  isRecurringEFT: false,
                  validationError: "",
                  validationMsg: "",
                  searchValidationError: "",
                  searchValidationMsg: ""
                });
              }
              if (this._isMounted) {
                this.setState({
                  loading: false
                });
              }
            } else {
              if (this._isMounted) {
                this.setState({
                  loading: false
                });
              }
              // If the policyNumber is present but no valid response
              if (policyNumber && res.status.toString().indexOf("50") != -1) {
                this.showPolicyMisMatchDialog();
                return;
              } else {
                this.showPolicyNotFoundDialog();
                return;
              }
            }
            this.carrierCodeRef.current.focus();
          })
          .catch(error => {
            console.warn(error);
            if (this._isMounted) {
              this.setState({ loading: false });
            }
          });
      }
    }
  };

  handleTextChange = name => event => {
    var value = event.target.value;
    if (name === "policyNumber") {
      value = value.toUpperCase();
    }

    if (this._isMounted) {
      this.setState({
        [name]: value,
        validationError: false,
        validationMsg: ""
      });
    }
    this.resetCommentFlags();
  };

  handleBlur = event => {
    if (event.target.name === "accountNumber") {
      let phonePaymentTmp = Object.assign({}, this.props.dialogdata);
      phonePaymentTmp[event.target.name] = event.target.value;
      this.props.addPhonePaymentEntry(phonePaymentTmp);
    }
  };

  handleFocus = event => {
    event.preventDefault();
    if (event.target.name === "zip") {
      if (this.props.dialogdata.country === "US") {
        let phonePaymentTmp = Object.assign({}, this.props.dialogdata);
        let zip = event.target.value;
        zip =
          zip.length === 6 && zip.indexOf("-") != -1
            ? zip.substring(0, 5)
            : zip;
        zip =
          zip.length === 9 && zip.indexOf("-") == -1
            ? zip.substring(0, 5) + "-" + zip.substring(5, 9)
            : zip;
        phonePaymentTmp[event.target.name] = zip;
        this.props.addPhonePaymentEntry(phonePaymentTmp);
      }
    } else {
      this.telephoneNumberRef.current.selectionStart = 1;
      this.telephoneNumberRef.current.selectionEnd = 1;
    }
  };

  handleChange = event => {
    if (this._isMounted) {
      this.setState({
        searchValidationError: false,
        searchValidationMsg: ""
      });
    }
    let phonePaymentTmp = Object.assign({}, this.props.dialogdata);
    if (event.target.name === "zip" && this.props.dialogdata.country === "US") {
      let zip = event.target.value;
      zip = zip.replace(/\s+/g, "");
      zip =
        zip.length > 5 && zip.indexOf("-") == -1
          ? zip.substring(0, 5) + "-" + zip.substring(5, zip.length)
          : zip;
      phonePaymentTmp[event.target.name] = zip;
    } else {
      phonePaymentTmp[event.target.name] = event.target.value;
    }
    this.props.addPhonePaymentEntry(phonePaymentTmp);
  };

  handleRadioChange = event => {
    let phonePaymentTmp = Object.assign({}, this.props.dialogdata);
    phonePaymentTmp[event.target.name] = event.target.value;
    this.props.addPhonePaymentEntry(phonePaymentTmp);
  };

  fetchData = state => {
    if (this._isMounted) {
      this.setState({ loading: true });
    }
    getPhonePmtData(state.pageSize, state.page, state.sorted)
      .then(res => {
        if (this._isMounted) {
          this.setState({
            data: res.rows[0].policies,
            pages: res.pages == undefined ? 0 : res.pages,
            totalRecords: res.totalRecords,
            loading: false
          });
        }
      })
      .catch(error => {
        console.warn(error);
        if (this._isMounted) {
          this.setState({ loading: false });
        }
      });
  };

  render() {
    const { data, pages, loading } = this.state;
    return (
      <React.Fragment>
        <Overlay active={this.state.loading} marginTop="150px">
          <p />
          {this.state.searchValidationError ? (
            <Chip
              icon={<WarningOutlined />}
              label={this.state.searchValidationMsg}
              color="secondary"
            />
          ) : (
            ""
          )}
          <fieldset className="tableFieldset">
            <legend
              className="tableLegend BoldText ColoredText"
              style={{ marginBottom: "0px" }}
            >
              Payor Information
            </legend>
            <table border="0px" cellPadding="5" cellSpacing="0">
              <tbody>
                <tr>
                  <td className="VerticalAlignBottom">
                    <TextField
                      id="name"
                      name="name"
                      inputRef={this.nameRef}
                      label={
                        this.props.dialogdata.orgIndicator
                          ? "Name"
                          : "First Name"
                      }
                      type="search"
                      className={classes.textField}
                      onChange={this.handleChange}
                      value={this.props.dialogdata.name}
                      margin="none"
                    />
                    {this.validator.message(
                      "name",
                      this.props.dialogdata.name,
                      "required"
                    )}
                  </td>
                  <td>&nbsp;</td>
                  <td className="VerticalAlignBottom">
                    <TextField
                      id="mi"
                      name="mi"
                      label="MI"
                      type="search"
                      style={{ width: 60 }}
                      inputProps={{
                        maxLength: 1
                      }}
                      className={classes.textField}
                      onChange={this.handleChange}
                      value={this.props.dialogdata.mi}
                      disabled={this.props.dialogdata.orgIndicator}
                      margin="none"
                    />
                  </td>
                  <td>&nbsp;</td>
                  <td className="VerticalAlignBottom">
                    <TextField
                      id="lastName"
                      name="lastName"
                      label="Last Name"
                      inputRef={this.lastNameRef}
                      type="search"
                      className={classes.textField}
                      onChange={this.handleChange}
                      value={this.props.dialogdata.lastName}
                      disabled={this.props.dialogdata.orgIndicator}
                      margin="none"
                    />
                    {this.validator.message(
                      "lastName",
                      this.props.dialogdata.lastName,
                      "required"
                    )}
                  </td>
                  <td>&nbsp;</td>
                  <td className="VerticalAlignBottom">
                    <FormControl style={{ flexDirection: "row" }}>
                      <FormControlLabel
                        control={
                          <Checkbox
                            id="orgIndicator"
                            name="orgIndicator"
                            style={{ padding: "0px 5px 0px 15px" }}
                            checked={this.props.dialogdata.orgIndicator}
                            onChange={this.handleCheckboxChange}
                            disabled={false}
                            color="primary"
                          />
                        }
                        label="Is Organization/Trust ?"
                        labelPlacement="end"
                      />
                    </FormControl>
                  </td>
                </tr>
              </tbody>
            </table>
            <table border="0px" cellPadding="5" cellSpacing="0">
              <tbody>
                <tr>
                  <td className="VerticalAlignBottom">
                    <TextField
                      id="email"
                      name="email"
                      inputRef={this.emailRef}
                      label="Email ID"
                      type="search"
                      className={classes.textField}
                      onChange={this.handleChange}
                      value={this.props.dialogdata.email}
                      margin="none"
                    />
                    {this.validator.message(
                      "email",
                      this.props.dialogdata.email,
                      "required"
                    )}
                  </td>
                  <td>&nbsp;</td>
                  <td className="VerticalAlignBottom">
                    <div style={{ display: "table" }}>
                      <div style={{ display: "table-row" }}>
                        <FormControl style={{ flexDirection: "row" }}>
                          <FormControlLabel
                            control={
                              <Checkbox
                                id="emailIndicator"
                                name="emailIndicator"
                                style={{ padding: "0px 5px 0px 15px" }}
                                checked={this.props.dialogdata.emailIndicator}
                                onChange={this.handleCheckboxChange}
                                disabled={false}
                                color="primary"
                              />
                            }
                            label="Send Email"
                            labelPlacement="end"
                          />
                        </FormControl>
                      </div>
                      {isUserRole("business") ? (
                        <div style={{ display: "table-row" }}>
                          <FormControl style={{ flexDirection: "row" }}>
                            <FormControlLabel
                              control={
                                <Checkbox
                                  id="suppressCorrespondence"
                                  name="suppressCorrespondence"
                                  style={{ padding: "0px 5px 0px 15px" }}
                                  checked={
                                    this.props.dialogdata.suppressCorrespondence
                                  }
                                  onChange={this.handleCheckboxChange}
                                  disabled={false}
                                  color="primary"
                                />
                              }
                              label="Suppress Correspondence"
                              labelPlacement="end"
                            />
                          </FormControl>
                        </div>
                      ) : (
                        ""
                      )}
                    </div>
                  </td>
                  <td>&nbsp;</td>
                  <td className="VerticalAlignBottom">
                    <FormControl>
                      <TextField
                        id="telephoneNumber"
                        name="telephoneNumber"
                        inputRef={this.telephoneNumberRef}
                        label="Phone"
                        type="search"
                        className={classes.textField}
                        onChange={this.handleChange}
                        onFocus={this.handleFocus}
                        value={trim(this.props.dialogdata.telephoneNumber)}
                        margin="none"
                        InputProps={{
                          inputComponent: phoneMaskCustom,
                          value: trim(this.props.dialogdata.telephoneNumber)
                        }}
                      />
                      {this.validator.message(
                        "telephoneNumber",
                        this.props.dialogdata.telephoneNumber,
                        "required|phone"
                      )}
                    </FormControl>
                  </td>
                </tr>
              </tbody>
            </table>
            <table border="0px" cellPadding="5" cellSpacing="0">
              <tbody>
                <tr>
                  <td className="VerticalAlignBottom">
                    <TextField
                      id="addr1"
                      name="addr1"
                      inputRef={this.addr1Ref}
                      label="Address Line 1"
                      type="search"
                      className={classes.textField}
                      onChange={this.handleChange}
                      value={this.props.dialogdata.addr1}
                      margin="none"
                    />
                    {this.validator.message(
                      "addr1",
                      this.props.dialogdata.addr1,
                      "required"
                    )}
                  </td>
                  <td>&nbsp;</td>
                  <td className="VerticalAlignBottom">
                    <TextField
                      id="addr2"
                      name="addr2"
                      label="Address Line 2"
                      type="search"
                      className={classes.textField}
                      onChange={this.handleChange}
                      value={this.props.dialogdata.addr2}
                      margin="none"
                    />
                  </td>
                </tr>
              </tbody>
            </table>
            <table border="0px" cellPadding="5" cellSpacing="0">
              <tbody>
                <tr>
                  <td className="VerticalAlignBottom">
                    <TextField
                      id="city"
                      name="city"
                      inputRef={this.cityRef}
                      label="City"
                      type="search"
                      className={classes.textField}
                      onChange={this.handleChange}
                      value={this.props.dialogdata.city}
                      margin="none"
                    />
                    {this.validator.message(
                      "city",
                      this.props.dialogdata.city,
                      "required"
                    )}
                  </td>
                  <td>&nbsp;</td>
                  <td className="VerticalAlignBottom">
                    {this.props.dialogdata.country === "US" ? (
                      <FormControl>
                        <InputLabel htmlFor="state">State</InputLabel>
                        <Select
                          inputRef={this.stateRef}
                          native
                          autoWidth={false}
                          style={{ width: 120 }}
                          value={this.props.dialogdata.state}
                          onChange={this.handleChange}
                          inputProps={{
                            name: "state",
                            id: "state",
                            label: "State"
                          }}
                        >
                          <option value="" />
                          {states.map(option => (
                            <option key={option.value} value={option.value}>
                              {option.label}
                            </option>
                          ))}
                        </Select>
                        {this.validator.message(
                          "state",
                          this.props.dialogdata.state,
                          "required"
                        )}
                      </FormControl>
                    ) : (
                      <TextField
                        id="state"
                        name="state"
                        label="State"
                        type="search"
                        style={{ width: 120 }}
                        className={classes.textField}
                        onChange={this.handleChange}
                        value={this.props.dialogdata.state}
                        margin="none"
                      />
                    )}
                  </td>
                  <td className="VerticalAlignBottom">
                    <FormControl>
                      <InputLabel htmlFor="country">Country</InputLabel>
                      <Select
                        native
                        autoWidth={true}
                        value={this.props.dialogdata.country}
                        onChange={this.handleChange}
                        inputProps={{
                          name: "country",
                          id: "country",
                          label: "country"
                        }}
                      >
                        {countries.map(option => (
                          <option key={option.TypeCode} value={option.ISOCode}>
                            {option.Desc}
                          </option>
                        ))}
                      </Select>
                    </FormControl>
                  </td>
                  <td>&nbsp;</td>
                  <td className="VerticalAlignBottom">
                    <TextField
                      id="zip"
                      name="zip"
                      inputRef={this.zipRef}
                      label="Zip Code"
                      type="search"
                      style={{ width: 120 }}
                      className={classes.textField}
                      onChange={this.handleChange}
                      onBlur={this.handleFocus}
                      value={this.props.dialogdata.zip}
                      margin="none"
                    />
                    {this.validator.message(
                      "zip",
                      this.props.dialogdata.zip,
                      "required"
                    )}
                  </td>
                </tr>
              </tbody>
            </table>
          </fieldset>
          <fieldset className="tableFieldset">
            <legend
              className="tableLegend BoldText ColoredText"
              style={{ marginBottom: "0px" }}
            >
              Account Information
            </legend>
            <table border="0px" cellPadding="5" cellSpacing="0">
              <tbody>
                <tr>
                  <td className="VerticalAlignBottom">
                    <TextField
                      id="accountNumber"
                      name="accountNumber"
                      label="Account Number"
                      inputRef={this.accountNumberRef}
                      type="search"
                      className={classes.textField}
                      onChange={this.handleChange}
                      onBlur={this.handleBlur}
                      value={this.props.dialogdata.accountNumber}
                      margin="none"
                    />
                    {this.validator.message(
                      "accountNumber",
                      this.props.dialogdata.accountNumber,
                      "required"
                    )}
                  </td>
                  <td>&nbsp;</td>
                  <td className="VerticalAlignBottom">
                    <TextField
                      id="accountNumberReenter"
                      name="accountNumberReenter"
                      label="Renter Account Number"
                      inputRef={this.accountNumberReenterRef}
                      type="search"
                      className={classes.textField}
                      onChange={this.handleChange}
                      onBlur={this.handleBlur}
                      value={this.props.dialogdata.accountNumberReenter}
                      margin="none"
                    />
                    {this.validator.message(
                      "accountNumberReenter",
                      this.props.dialogdata.accountNumberReenter,
                      "required"
                    )}
                  </td>
                  <td>&nbsp;</td>
                  <td className="VerticalAlignBottom">
                    <FormControl style={{ flexDirection: "row" }}>
                      <FormControlLabel
                        control={
                          <Radio
                            style={{ padding: "0px 10px 0px 15px" }}
                            color="primary"
                            name="accountType"
                            value="CHECKING"
                            checked={
                              this.props.dialogdata.accountType === "CHECKING"
                            }
                            onChange={this.handleRadioChange}
                          />
                        }
                        label="Checking"
                      />
                      <FormControlLabel
                        control={
                          <Radio
                            style={{ padding: "0px 10px 0px 15px" }}
                            color="primary"
                            name="accountType"
                            value="SAVINGS"
                            checked={
                              this.props.dialogdata.accountType === "SAVINGS"
                            }
                            onChange={this.handleRadioChange}
                          />
                        }
                        label="Savings"
                      />
                    </FormControl>
                  </td>
                </tr>
              </tbody>
            </table>
            <table border="0px" cellPadding="5" cellSpacing="0">
              <tbody>
                <tr>
                  <td className="VerticalAlignBottom">
                    <TextField
                      id="routingNumber"
                      name="routingNumber"
                      label="Routing Number"
                      inputRef={this.routingNumberRef}
                      type="search"
                      className={classes.textField}
                      onChange={this.handleChange}
                      onBlur={this.handleBlurRoutingNumber}
                      value={this.props.dialogdata.routingNumber}
                      margin="none"
                    />
                    {this.validator.message(
                      "routingNumber",
                      this.props.dialogdata.routingNumber,
                      "required"
                    )}
                  </td>
                  <td>&nbsp;</td>
                  <td className="VerticalAlignBottom">
                    {this.state.accountName === "invalid" ? (
                      <span
                        style={{
                          fontWeight: "bold",
                          fontSize: 14,
                          color: "red"
                        }}
                      >
                        Invalid Routing Number
                      </span>
                    ) : (
                      <span className="BoldText ColoredText">
                        {this.state.accountName}
                      </span>
                    )}
                  </td>
                </tr>
              </tbody>
            </table>
            <table border="0px" cellPadding="5" cellSpacing="0">
              <tbody>
                <tr>
                  <td className="VerticalAlignBottom">
                    <FormControl style={{ flexDirection: "row" }}>
                      <Typography variant="caption">
                        <br />
                        <DatePickerInput
                          id="draftDate"
                          name="draftDate"
                          placeholderText="Draft Date"
                          minDate={formatStringToDate(
                            this.props.dialogdata.draftDate
                          )}
                          maxDate={addDays(
                            this.props.dialogdata.draftDate,
                            21 +
                              diffWeekendDays(
                                this.props.dialogdata.draftDate,
                                addDays(this.props.dialogdata.draftDate, 21)
                              ) +
                              1
                          )}
                          filterDate={allowedDay}
                          selected={formatStringToDate(
                            this.props.dialogdata.selectedDraftDate
                          )}
                          onChange={dateValue => {
                            this.handleDateChange(
                              "selectedDraftDate",
                              dateValue
                            );
                          }}
                        />
                      </Typography>
                    </FormControl>
                  </td>
                </tr>
              </tbody>
            </table>
          </fieldset>
          <div className="LeftActionBarStyle">
            <Button
              variant="contained"
              color="primary"
              className={classes.button}
              onClick={this.handleSubmit}
              disabled={
                this.props.dialogdata.status === "SUBMITTED" ||
                this.props.dialogdata.status === "DECLINED"
              }
            >
              Submit EFT Draft
            </Button>
            &nbsp;
            <Button
              variant="contained"
              color="primary"
              className={classes.button}
              onClick={this.handleConfirmPayment}
              disabled={!this.state.showConfirmPayment}
            >
              Confirm Payment
            </Button>
            &nbsp;
            <Button
              variant="contained"
              color="primary"
              className={classes.button}
              onClick={this.handleClear}
              disabled={
                this.props.dialogdata.status === "SUBMITTED" ||
                this.props.dialogdata.status === "DECLINED"
              }
            >
              Clear
            </Button>
            &nbsp;
            <Button
              variant="contained"
              color="primary"
              className={classes.button}
              onClick={this.handleBack}
            >
              Back
            </Button>
            &nbsp;
            <span className="RightActionBarStyle">
              <div
                style={{
                  textAlign: "right",
                  paddingTop: 10,
                  cursor: "pointer",
                  color:
                    this.props.dialogdata.status === "OPEN"
                      ? "#388e3c"
                      : "#CCCCCC"
                }}
              >
                <Tooltip title="Add New">
                  <AddCircleOutlineOutlined onClick={this.handleAddNew} />
                </Tooltip>
              </div>
            </span>
            <span className="RightActionBarStyle">
              <Refresh onClick={this.handleRefresh} />
            </span>
          </div>
          <div align="center">
            {this.state.validationError ? (
              <Chip
                icon={<WarningOutlined />}
                label={this.state.validationMsg}
                color="secondary"
              />
            ) : (
              ""
            )}
          </div>
          <div style={{ width: "100%" }}>
            <table style={{ width: "100%" }}>
              <thead>
                <tr>
                  <th style={{ textAlign: "left" }}>
                    <span className="BoldText ColoredText">Status:</span>
                    <span
                      style={{
                        fontWeight: "bold",
                        fontSize: 14,
                        color: "red"
                      }}
                    >
                      &nbsp;&nbsp;
                      {this.props.dialogdata.status}
                    </span>
                  </th>
                  <th>
                    <span className="BoldText ColoredText">Tracking #:</span>
                    <span
                      style={{
                        fontWeight: "bold",
                        fontSize: 14,
                        color: "red"
                      }}
                    >
                      &nbsp;&nbsp;
                      {this.state.trackingNumber}
                    </span>
                  </th>
                  <th>
                    <span className="BoldText ColoredText">Entered By:</span>
                    <span
                      style={{
                        fontWeight: "bold",
                        fontSize: 14,
                        color: "red"
                      }}
                    >
                      &nbsp;&nbsp;
                      {this.props.dialogdata.enteredBy}
                    </span>
                  </th>
                  <th style={{ textAlign: "right" }}>
                    <span className="BoldText ColoredText">Draft Total:</span>
                    <span
                      style={{
                        fontWeight: "bold",
                        fontSize: 14,
                        color: "red"
                      }}
                    >
                      &nbsp;
                      {this.props.dialogdata.totalDraftAmt
                        ? formatCurrency(this.props.dialogdata.totalDraftAmt)
                        : ""}
                    </span>
                  </th>
                </tr>
              </thead>
            </table>
          </div>
          <ReactTable
            ref={reactPhonePaymentEntryTable =>
              (this.selectTable = reactPhonePaymentEntryTable)
            }
            columns={[
              {
                Header: "Pol Number",
                accessor: "policyNumber",
                headerClassName: "BoldText ColoredText",
                Cell: ({ row, original }) => {
                  return (
                    <span style={{ textAlign: "center" }}>
                      {this.state.editMode &&
                      original.id == this.state.selectedId ? (
                        <FormControl style={{ flexDirection: "row" }}>
                          <Input
                            value={this.state.policyNumber}
                            name={"policyNumber" + row.index}
                            inputRef={this.policyNumberRef}
                            onChange={this.handleTextChange("policyNumber")}
                            onKeyDown={this.handleTextKeyDown}
                            autoFocus={true}
                          />
                          {this.validator.message(
                            "policyNumber",
                            this.state.policyNumber,
                            "required"
                          )}
                        </FormControl>
                      ) : (
                        row.policyNumber
                      )}
                    </span>
                  );
                }
              },
              {
                Header: "Co ID",
                accessor: "carrierCode",
                headerClassName: "BoldText ColoredText",
                width: 100,
                Cell: ({ row, original }) => {
                  return (
                    <span style={{ textAlign: "center" }}>
                      {this.state.editMode &&
                      original.id == this.state.selectedId ? (
                        <FormControl>
                          <Select
                            native
                            autoWidth={true}
                            value={this.state.carrierCode}
                            onChange={this.handleTextChange("carrierCode")}
                            inputRef={this.carrierCodeRef}
                            inputProps={{
                              name: "carrierCode" + row.index,
                              id: "carrierCode"
                            }}
                          >
                            <option key="001" value="001">
                              001
                            </option>
                            <option key="002" value="002">
                              002
                            </option>
                          </Select>
                        </FormControl>
                      ) : (
                        row.carrierCode
                      )}
                    </span>
                  );
                }
              },
              {
                Header: "Insured Name",
                accessor: "insuredName",
                headerClassName: "BoldText ColoredText",
                Cell: ({ row, original }) => {
                  return (
                    <span style={{ textAlign: "center" }}>
                      {this.state.editMode &&
                      original.id == this.state.selectedId ? (
                        <FormControl style={{ flexDirection: "row" }}>
                          <Input
                            value={this.state.insuredName}
                            name={"insuredName" + row.index}
                            inputRef={this.insuredNameRef}
                            onChange={this.handleTextChange("insuredName")}
                          />
                          {this.validator.message(
                            "insuredName",
                            this.state.insuredName,
                            "required"
                          )}
                        </FormControl>
                      ) : (
                        row.insuredName
                      )}
                    </span>
                  );
                }
              },
              {
                Header: "Premium",
                accessor: "premiumAmount",
                headerClassName: "BoldText ColoredText",
                Cell: ({ row, original }) => {
                  return (
                    <span style={{ textAlign: "center" }}>
                      {this.state.editMode &&
                      original.id == this.state.selectedId ? (
                        <FormControl style={{ flexDirection: "row" }}>
                          <Input
                            value={this.state.premiumAmount}
                            name={"premiumAmount" + row.index}
                            inputRef={this.premiumAmountRef}
                            style={{ width: 150 }}
                            onChange={this.handleAmntChange(
                              "premiumAmount",
                              original.id
                            )}
                            startAdornment={
                              <InputAdornment position="start">
                                $
                              </InputAdornment>
                            }
                          />
                          {this.validator.message(
                            "premiumAmount",
                            this.state.premiumAmount,
                            "required"
                          )}
                        </FormControl>
                      ) : row.premiumAmount === undefined ? (
                        ""
                      ) : (
                        "$" + Number.parseFloat(row.premiumAmount).toFixed(2)
                      )}
                    </span>
                  );
                }
              },
              {
                Header: "Policy Status",
                accessor: "policyStatus",
                headerClassName: "BoldText ColoredText",
                Cell: ({ row, original }) => {
                  return (
                    <span style={{ textAlign: "center" }}>
                      {this.state.editMode &&
                      original.id == this.state.selectedId ? (
                        <FormControl style={{ flexDirection: "row" }}>
                          <Input
                            value={this.state.policyStatus}
                            name={"policyStatus" + row.index}
                            inputRef={this.policyStatusRef}
                            onChange={this.handleTextChange("policyStatus")}
                          />
                          {this.validator.message(
                            "policyStatus",
                            this.state.policyStatus,
                            "required"
                          )}
                        </FormControl>
                      ) : row.policyStatus === null ? (
                        ""
                      ) : (
                        row.policyStatus
                      )}
                    </span>
                  );
                }
              },
              {
                Header: "Payment Type",
                accessor: "paymentType",
                headerClassName: "BoldText ColoredText",
                className: "Centered",
                sortable: false,
                Cell: ({ original }) => {
                  return (
                    <span style={{ textAlign: "center" }}>
                      {this.state.editMode &&
                      original.id == this.state.selectedId ? (
                        <FormControl>
                          <Select
                            native
                            autoWidth={true}
                            value={this.state.paymentType}
                            onChange={this.handleSelectChange("paymentType")}
                            inputProps={{
                              name: "paymentType",
                              id: "paymentType"
                            }}
                          >
                            {paymentTypes.map(option => (
                              <option key={option.value} value={option.value}>
                                {option.label}
                              </option>
                            ))}
                          </Select>
                        </FormControl>
                      ) : (
                        original.paymentType
                      )}
                    </span>
                  );
                }
              },
              {
                Header: "Draft Amount",
                accessor: "draftAmnt",
                headerClassName: "BoldText ColoredText",
                Cell: ({ row, original }) => {
                  return (
                    <span style={{ textAlign: "center" }}>
                      {this.state.editMode &&
                      original.id == this.state.selectedId ? (
                        <FormControl style={{ flexDirection: "row" }}>
                          <Input
                            value={this.state.draftAmnt}
                            name={"draftAmnt" + row.index}
                            inputRef={this.draftAmntRef}
                            style={{ width: 150 }}
                            onChange={this.handleAmntChange(
                              "draftAmnt",
                              original.id
                            )}
                            startAdornment={
                              <InputAdornment position="start">
                                $
                              </InputAdornment>
                            }
                          />
                          {this.validator.message(
                            "draftAmnt",
                            this.state.draftAmnt,
                            "required"
                          )}
                        </FormControl>
                      ) : row.draftAmnt !== undefined &&
                      row.draftAmnt !== "" ? (
                        "$" + Number.parseFloat(row.draftAmnt).toFixed(2)
                      ) : (
                        "$" + ""
                      )}
                    </span>
                  );
                }
              },
              {
                Header: "Current Bill Method",
                accessor: "currentBillingMethod",
                headerClassName: "BoldText ColoredText",
                Cell: ({ row, original }) => {
                  return (
                    <span style={{ textAlign: "center" }}>
                      {this.state.editMode &&
                      original.id == this.state.selectedId ? (
                        <FormControl style={{ flexDirection: "row" }}>
                          <Input
                            value={this.state.currentBillingMethod}
                            name={"currentBillingMethod" + row.index}
                            inputRef={this.currentBillingMethodRef}
                            onChange={this.handleTextChange(
                              "currentBillingMethod"
                            )}
                          />
                          {this.validator.message(
                            "currentBillingMethod",
                            this.state.currentBillingMethod,
                            "required"
                          )}
                        </FormControl>
                      ) : row.currentBillingMethod === null ? (
                        ""
                      ) : (
                        row.currentBillingMethod
                      )}
                    </span>
                  );
                }
              },
              {
                Header: "Switch to Recurring EFT",
                accessor: "isRecurringEFT",
                headerClassName: "BoldText ColoredText",
                className: "Centered",
                sortable: false,
                Cell: ({ row, original }) => {
                  return (
                    <span style={{ textAlign: "center" }}>
                      {this.state.editMode &&
                      original.id == this.state.selectedId ? (
                        <FormControl>
                          <Select
                            native
                            autoWidth={true}
                            value={this.state.isRecurringEFT}
                            onChange={this.handleSelectChange("isRecurringEFT")}
                            disabled={
                              this.state.currentBillingMethod === "Bank Draft"
                            }
                            inputProps={{
                              name: "isRecurringEFT",
                              id: "isRecurringEFT"
                            }}
                          >
                            <option key="false" value={false}>
                              No
                            </option>
                            <option key="true" value={true}>
                              Yes
                            </option>
                          </Select>
                        </FormControl>
                      ) : row.isRecurringEFT ? (
                        "Yes"
                      ) : (
                        "No"
                      )}
                    </span>
                  );
                }
              },
              {
                Header: "Actions",
                id: "actions",
                accessor: "actions",
                sortable: false,
                className: "Centered",
                headerClassName: "BoldText ColoredText",
                Cell: ({ original }) => {
                  return (
                    <span style={{ textAlign: "center" }}>
                      <CommonEditActions
                        editMode={this.state.editMode}
                        isDelete={true}
                        isEnabled={this.props.dialogdata.status === "OPEN"}
                        isSelected={original.id == this.state.selectedId}
                        handleEdit={() =>
                          this.handleAction(
                            "edit",
                            original.id,
                            original.carrierCode,
                            original.policyNumber,
                            original.insuredName,
                            original.draftAmnt,
                            original.paymentType,
                            original.policyStatus,
                            original.currentBillingMethod,
                            original.isRecurringEFT,
                            original.premiumAmount
                          )
                        }
                        handleSave={() =>
                          this.handleAction(
                            "save",
                            original.id,
                            original.carrierCode,
                            original.policyNumber,
                            original.insuredName,
                            original.draftAmnt,
                            original.paymentType,
                            original.policyStatus,
                            original.currentBillingMethod,
                            original.isRecurringEFT,
                            original.premiumAmount
                          )
                        }
                        handleCancel={() =>
                          this.handleAction(
                            "cancel",
                            original.id,
                            original.carrierCode,
                            original.policyNumber,
                            original.insuredName,
                            original.draftAmnt,
                            original.paymentType,
                            original.policyStatus,
                            original.currentBillingMethod,
                            original.isRecurringEFT,
                            original.premiumAmount
                          )
                        }
                        handleDelete={() =>
                          this.handleAction(
                            "delete",
                            original.id,
                            original.carrierCode,
                            original.policyNumber,
                            original.insuredName,
                            original.draftAmnt,
                            original.paymentType,
                            original.policyStatus,
                            original.currentBillingMethod,
                            original.isRecurringEFT,
                            original.premiumAmount
                          )
                        }
                      />
                      &nbsp;
                      <CommentsActionDialog
                        open={this.state.showComments}
                        title="Policy Comments"
                        iconTitle="Add Comments"
                        commentsPlaceholder="Enter Comments"
                        value={original.comment}
                        button1Title="Submit"
                        button2Title="Close"
                        isEnabled={this.props.dialogdata.status === "OPEN"}
                        handleSubmit={comments =>
                          this.handlePolicyComments(original.id, comments)
                        }
                      />
                    </span>
                  );
                }
              }
            ]}
            defaultSorted={[
              {
                id: "policyNumber",
                desc: true
              }
            ]}
            manual // Forces table not to paginate or sort automatically, so we can handle it server-side
            data={data}
            pages={pages} // Display the total number of pages
            loading={loading} // Display the loading overlay when we need it
            onFetchData={this.fetchData} // Request new data when things change
            defaultPageSize={10}
            className="-striped -highlight"
            getTdProps={() => {
              return {
                style: {
                  padding: 0
                }
              };
            }}
          >
            {(state, makeTable) => {
              return (
                <RecordCount
                  state={state}
                  makeTable={makeTable}
                  totalRecords={this.state.totalRecords}
                />
              );
            }}
          </ReactTable>
          <div>
            <FormControl style={{ flexDirection: "row" }}>
              <TextField
                id="comments"
                name="comments"
                label="Comments"
                inputRef={this.commentsRef}
                type="search"
                className={classes.textField}
                onChange={this.handleChange}
                value={this.props.dialogdata.comments}
                margin="none"
                style={{ width: 600 }}
              />
            </FormControl>
          </div>
          <br />
          <Snackbar
            place="tr"
            color="success"
            icon={InfoOutlined}
            message={this.state.successMsg}
            open={this.state.successElt}
            closeNotification={() => this.setState({ successElt: false })}
          />
          <Snackbar
            place="tr"
            color="danger"
            icon={InfoOutlined}
            message={this.state.errorMsg}
            open={this.state.errorElt}
            closeNotification={() => this.setState({ errorElt: false })}
            close
          />
        </Overlay>
        <Dialog
          aria-labelledby="customized-dialog-title"
          open={this.state.openMessageDialog}
          onClose={() => this.handleClose("message")}
        >
          <DialogTitle
            id="customized-dialog-title"
            onClose={() => this.handleClose("message")}
          >
            <b>{this.state.messageTitle}</b>
          </DialogTitle>
          <DialogContent>
            <div
              dangerouslySetInnerHTML={{
                __html: this.state.messageDesc
              }}
              style={{ height: "400px", width: "500px" }}
            />
          </DialogContent>
          <DialogActions>
            <Button onClick={() => this.handleClose("message")} color="primary">
              Close
            </Button>
          </DialogActions>
        </Dialog>
      </React.Fragment>
    );
  }
}

const mapStateToProps = state => ({
  dialogdata: state.sidebar.phonePaymentEntry
});

const mapDispatchToProps = dispatch =>
  bindActionCreators(
    {
      initPhonePaymentEntry,
      getPhonePaymentEntry,
      addPhonePaymentEntry,
      delPhonePaymentEntry
    },
    dispatch
  );

PhonePaymentEntryTable.propTypes = {
  initPhonePaymentEntry: PropTypes.func,
  addPhonePaymentEntry: PropTypes.func,
  getPhonePaymentEntry: PropTypes.func,
  delPhonePaymentEntry: PropTypes.func,
  handleModeChange: PropTypes.func,
  params: PropTypes.object,
  action: PropTypes.string,
  className: PropTypes.string,
  sidebar: PropTypes.object,
  stats: PropTypes.bool,
  icon: PropTypes.bool,
  dialogdata: PropTypes.object
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(requireAuth(PhonePaymentEntryTable, "mainContent"));
