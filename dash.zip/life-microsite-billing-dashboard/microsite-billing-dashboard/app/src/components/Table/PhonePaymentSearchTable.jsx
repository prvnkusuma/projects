import React from "react";
import { connect } from "react-redux";
import { bindActionCreators } from "redux";

import PropTypes from "prop-types";

// Import React Table
import ReactTable from "react-table";
import { ReactTableDefaults } from "react-table";

import Tooltip from "@material-ui/core/Tooltip";
import TextField from "@material-ui/core/TextField";
import Button from "@material-ui/core/Button";
import InfoOutlined from "@material-ui/icons/InfoOutlined";
import Icon from "react-icons-kit";
import FileCopyOutlined from "@material-ui/icons/FileCopyOutlined";
import CancelPresentation from "@material-ui/icons/CancelPresentation";
import UnsubscribeOutlined from "@material-ui/icons/UnsubscribeOutlined";
//import InsertChartOutlined from "@material-ui/icons/InsertChartOutlined";
import FormControl from "@material-ui/core/FormControl";
import Typography from "@material-ui/core/Typography";
import { arrowRightB } from "react-icons-kit/ionicons/arrowRightB";
import { arrowDownB } from "react-icons-kit/ionicons/arrowDownB";

// Import actions
import {
  initPhonePaymentSearch,
  getPhonePaymentSearch,
  addPhonePaymentSearch,
  delPhonePaymentSearch
} from "actions/PhonePaymentSearchAction.jsx";

import "react-table/react-table.css";
import "assets/css/bits-styles-override.css";

import Snackbar from "components/Snackbar/Snackbar.jsx";
import DatePickerInput from "components/DatePickerInput/DatePickerInput.jsx";
import APIURIs from "properties/APIURIs.jsx";
import LoadingSpinner from "components/CustomWidgets/LoadingSpinner.jsx";
import {
  getData,
  postData,
  postTableDataWithSearchParams,
  formatStringToDate,
  formatDate,
  diffDays,
  commonExcelDownload,
  getFromLocalStorage,
  isUserRole
} from "utils/CommonFunctions.jsx";
import requireAuth from "utils/AuthenticatedComponent.jsx";
import ExcelDownload from "components/CustomWidgets/ExcelDownload.jsx";
import Refresh from "components/CustomWidgets/Refresh.jsx";
import Overlay from "components/CustomWidgets/Overlay.jsx";
import RecordCount from "components/CustomWidgets/RecordCount.jsx";
import CommentsActionDialog from "components/Dialog/CommentsActionDialog.jsx";
import PhonePaymentSearchDetailsTable from "components/Table/PhonePaymentSearchDetailsTable.jsx";

//Set default values of React Table
Object.assign(ReactTableDefaults, {
  multiSort: false,
  LoadingComponent: LoadingSpinner
});

const classes = theme => ({
  formControl: {
    margin: theme.spacing.unit,
    minWidth: 120,
    display: "flex",
    wrap: "nowrap"
  },
  textField: {
    marginLeft: theme.spacing.unit,
    marginRight: theme.spacing.unit,
    width: 200
  },
  button: {
    margin: theme.spacing.unit
  }
});

function getAllPoliciesData(trackingNumber) {
  //fetch all records firsttime, pageSize should be a large value
  //to support multiple policies
  let pageSize = 1000;
  let page = 0;
  let sorted = [{ id: "policyNumber", desc: true }];
  let filtered = [];

  return postTableDataWithSearchParams(
    APIURIs.PHONE_PMT_POLSEARCH_URI,
    APIURIs.PHONE_PMT_POLSEARCH_APIKEY,
    pageSize,
    page,
    sorted,
    filtered,
    {
      trackingNumber: trackingNumber,
      action: "clone"
    }
  )
    .then(res => {
      return res.rows;
    })
    .catch(error => {
      console.warn(error);
      return [];
    });
}

function getPhonePmtData(pageSize, page, sorted, filtered, phonePaymentSearch) {
  return postTableDataWithSearchParams(
    APIURIs.PHONE_PMT_SEARCH_URI,
    APIURIs.PHONE_PMT_SEARCH_APIKEY,
    pageSize,
    page,
    sorted,
    filtered,
    phonePaymentSearch
  );
}

function updateStatus(trackingNumber, status, suppressCorrespondence, action) {
  return postData(
    APIURIs.PHONE_PMT_ENTRY_STATUS_URI + trackingNumber,
    APIURIs.PHONE_PMT_ENTRY_STATUS_APIKEY,
    {
      trackingNumber: trackingNumber,
      status: status,
      suppressCorrespondence: suppressCorrespondence,
      action: action,
      userName: getFromLocalStorage("userId")
    }
  );
}

function validateDate(dateTmp) {
  return getData(
    APIURIs.PHONE_PMT_DATE_URI + "?date=" + dateTmp,
    APIURIs.PHONE_PMT_DATE_APIKEY,
    {}
  );
}

function isEnableCancelAction(dateTmp) {
  return validateDate(formatDate(dateTmp))
    .then(res => {
      if (res) {
        if (res.data) {
          // Did date past 1:30 PM CST
          if (!res.data.isBatchedProcessed) {
            return true;
          } else {
            return false;
          }
        }
      }
    })
    .catch(error => {
      console.warn(error);
      return false;
    });
}

function populateIsEnableCancel(data) {
  return new Promise((resolve, reject) => {
    let dataTmp = data;
    let completed = 0;

    data.forEach((value, index) => {
      validateDate(formatDate(value.draftDate))
        .then(result => {
          if (result) {
            if (!result.data.isBatchedProcessed) {
              dataTmp[index]["enableCancel"] = true;
            } else {
              dataTmp[index]["enableCancel"] = false;
            }
          }
          completed += 1;

          if (completed == data.length) {
            resolve(dataTmp);
          }
        })
        .catch(err => reject(err));
    });
  });
}

class PhonePaymentSearchTable extends React.Component {
  _isMounted = false;
  dataToShow = [];
  constructor(props) {
    super(props);

    this.state = {
      data: [],
      pages: null,
      loading: true,
      editMode: false,
      selectedId: "",
      accountName: "",
      carrierCode: "",
      policyNumber: "",
      insuredName: "",
      draftAmnt: "",
      modeChange: false,
      openConfirmation: false,
      confirmationTitle: "",
      confirmationDesc: "",
      successElt: false,
      successMsg: "",
      errorElt: false,
      errorMsg: "",
      openAddNewDialog: false,
      totalRecords: null,
      downloadExcelLoading: false
    };
    this.props.initPhonePaymentSearch();
  }

  componentDidMount() {
    this._isMounted = true;
  }

  componentWillUnmount() {
    this._isMounted = false;
    this.props.initPhonePaymentSearch();
  }

  showNotification(place) {
    var x = [];
    x[place] = true;
    if (this._isMounted) {
      this.setState(x);
    }
    this.alertTimeout = setTimeout(
      function() {
        x[place] = false;
        if (this._isMounted) {
          this.setState(x);
        }
      }.bind(this),
      6000
    );
  }

  setLoading(status) {
    if (this._isMounted) {
      this.setState({ downloadExcelLoading: status });
    }
  }

  handleAddNew = () => {
    this.props.handleModeChange("entry", {}, "add");
  };

  handleClone = params => {
    if (this._isMounted) {
      this.setState({ downloadExcelLoading: true });
    }
    getAllPoliciesData(params.trackingNumber)
      .then(res => {
        if (res) {
          params.policies = res;
          if (this._isMounted) {
            this.setState({ downloadExcelLoading: false });
          }
          this.props.handleModeChange("entry", params, "clone");
        }
      })
      .catch(error => {
        console.warn(error);
        if (this._isMounted) {
          this.setState({ downloadExcelLoading: false });
        }
      });
  };

  handleCancelDraft = params => {
    if (this._isMounted) {
      this.setState({ downloadExcelLoading: true });
    }
    isEnableCancelAction(params.draftDate).then(res => {
      if (res) {
        updateStatus(params.trackingNumber, "CANCELLED", null, "status")
          .then(res => {
            if (res && res.status === 200) {
              if (this._isMounted) {
                this.setState(
                  {
                    successMsg: "Successfully cancelled the draft!",
                    downloadExcelLoading: false
                  },
                  function() {
                    this.showNotification("successElt");
                    this.selectTable.fireFetchData();
                  }
                );
              }
            } else {
              if (this._isMounted) {
                this.setState({
                  errorMsg: "Failed to cancel the draft!",
                  downloadExcelLoading: false
                });
                this.showNotification("errorElt");
              }
            }
          })
          .catch(error => {
            console.warn(error);
            if (this._isMounted) {
              this.setState({
                errorMsg: "Failed to cancel the draft!",
                downloadExcelLoading: false
              });
              this.showNotification("errorElt");
            }
          });
      } else {
        if (this._isMounted) {
          this.setState({
            errorMsg: "The current time is after allowed cutoff time!",
            downloadExcelLoading: false
          });
          this.showNotification("errorElt");
        }
      }
    });
  };

  handleCancelCorrespondence = params => {
    if (this._isMounted) {
      this.setState({ downloadExcelLoading: true });
    }
    isEnableCancelAction(params.draftDate).then(res => {
      if (res) {
        updateStatus(params.trackingNumber, "", true, "correspondence")
          .then(res => {
            if (res && res.status === 200) {
              if (this._isMounted) {
                this.setState(
                  {
                    successMsg: "Successfully cancelled the correspondence!",
                    downloadExcelLoading: false
                  },
                  function() {
                    this.showNotification("successElt");
                    this.selectTable.fireFetchData();
                  }
                );
              }
            } else {
              if (this._isMounted) {
                this.setState({
                  errorMsg: "Failed to cancel the correspondence!",
                  downloadExcelLoading: false
                });
                this.showNotification("errorElt");
              }
            }
          })
          .catch(error => {
            console.warn(error);
            if (this._isMounted) {
              this.setState({
                errorMsg: "Failed to cancel the correspondence!",
                downloadExcelLoading: false
              });
              this.showNotification("errorElt");
            }
          });
      } else {
        if (this._isMounted) {
          this.setState({
            errorMsg: "The current time is after allowed cutoff time!",
            downloadExcelLoading: false
          });
          this.showNotification("errorElt");
        }
      }
    });
  };

  handleClose = () => {
    if (this._isMounted) {
      this.setState({ openAddNewDialog: false });
    }
  };

  handleRefresh = event => {
    this.handleSubmit(event);
  };

  handleSubmit = event => {
    event.preventDefault();
    this.selectTable.fireFetchData();
  };

  handleClear = () => {
    this.props.delPhonePaymentSearch();
  };

  handleDateChange = (dateName, dateValue) => {
    let phonePaymentSearchTmp = Object.assign({}, this.props.dialogdata);
    phonePaymentSearchTmp[dateName] = formatDate(dateValue);

    if (
      dateName === "fromDraftDate" &&
      diffDays(dateValue, this.props.dialogdata.toDraftDate) > 30
    ) {
      phonePaymentSearchTmp["toDraftDate"] = formatDate(dateValue);
    }

    this.props.addPhonePaymentSearch(phonePaymentSearchTmp);
  };

  addDateFieldsToStore = () => {
    if (this._isMounted) {
      this.setState({ loading: true });
    }

    let phonePaymentSearchTmp = Object.assign({}, this.props.dialogdata);
    phonePaymentSearchTmp.fromDraftDate = formatDate(
      this.props.dialogdata.fromDraftDate
    );
    phonePaymentSearchTmp.toDraftDate = formatDate(
      this.props.dialogdata.toDraftDate
    );
    this.props.addPhonePaymentSearch(phonePaymentSearchTmp);
  };

  handleChange = event => {
    let phonePaymentSearchTmp = Object.assign({}, this.props.dialogdata);
    phonePaymentSearchTmp[event.target.name] = event.target.value;
    this.props.addPhonePaymentSearch(phonePaymentSearchTmp);
  };

  handleExcelDownload = () => {
    commonExcelDownload(
      this,
      APIURIs.PHONE_PMT_SEARCH_XLSDATA_URI,
      APIURIs.PHONE_PMT_SEARCH_XLSDATA_APIKEY,
      { ...this.props.dialogdata },
      "PhonePaymentRecords.xlsx"
    ).then(response => {
      if (response.status == 200 && response.message == "email") {
        this.showNotification("excelDownloadElt");
      }
    });
  };

  fetchData = state => {
    if (this._isMounted) {
      this.setState({ loading: true });
    }
    this.addDateFieldsToStore();
    getPhonePmtData(
      state.pageSize,
      state.page,
      state.sorted,
      state.filtered,
      this.props.dialogdata
    )
      .then(res => {
        if (res && res.rows) {
          Promise.all = populateIsEnableCancel(res.rows).then(result => {
            if (this._isMounted) {
              this.setState({
                data: result,
                loading: false
              });
            }
          });
          if (this._isMounted) {
            this.setState({
              pages: res.pages == undefined ? 0 : res.pages,
              totalRecords: res.totalRecords
            });
          }
        } else {
          if (this._isMounted) {
            this.setState({
              data: res.rows,
              pages: res.pages == undefined ? 0 : res.pages,
              totalRecords: res.totalRecords,
              loading: false
            });
          }
        }
      })
      .catch(error => {
        console.warn(error);
        if (this._isMounted) {
          this.setState({ loading: false });
        }
      });
  };

  render() {
    const { data, pages, loading } = this.state;
    return (
      <React.Fragment>
        <Overlay active={this.state.downloadExcelLoading} marginTop="150px">
          <p />
          <fieldset className="tableFieldset">
            <legend
              className="tableLegend BoldText ColoredText"
              style={{ marginBottom: "0px" }}
            >
              Search Criteria
            </legend>
            <table border="0px" cellPadding="5" cellSpacing="0">
              <tbody>
                <tr>
                  <td className="VerticalAlignBottom">
                    <TextField
                      id="trackingNumber"
                      name="trackingNumber"
                      label="Tracking Number"
                      type="search"
                      className={classes.textField}
                      onChange={this.handleChange}
                      value={this.props.dialogdata.trackingNumber}
                      margin="none"
                    />
                  </td>
                  <td>&nbsp;</td>
                  <td className="VerticalAlignBottom">
                    <TextField
                      id="policyNumber"
                      name="policyNumber"
                      label="Policy Number"
                      type="search"
                      className={classes.textField}
                      onChange={this.handleChange}
                      value={this.props.dialogdata.policyNumber}
                      margin="none"
                    />
                  </td>
                  <td>&nbsp;</td>
                  <td className="VerticalAlignBottom">
                    <TextField
                      id="accountName"
                      name="accountName"
                      label="Payor Name"
                      type="search"
                      className={classes.textField}
                      onChange={this.handleChange}
                      value={this.props.dialogdata.accountName}
                      margin="none"
                    />
                  </td>
                </tr>
                <tr>
                  <td className="VerticalAlignBottom">
                    <TextField
                      id="enteredBy"
                      name="enteredBy"
                      label="Entered By"
                      type="search"
                      className={classes.textField}
                      onChange={this.handleChange}
                      value={this.props.dialogdata.enteredBy}
                      margin="none"
                    />
                  </td>
                  <td>&nbsp;</td>
                  <td className="VerticalAlignBottom">
                    <FormControl style={{ flexDirection: "row" }}>
                      <Typography variant="caption">
                        <br />
                        <DatePickerInput
                          id="fromDraftDate"
                          name="fromDraftDate"
                          placeholderText="From Draft Date"
                          selected={formatStringToDate(
                            this.props.dialogdata.fromDraftDate
                          )}
                          onChange={dateValue => {
                            this.handleDateChange("fromDraftDate", dateValue);
                          }}
                        />
                      </Typography>
                    </FormControl>
                  </td>
                  <td>&nbsp;</td>
                  <td className="VerticalAlignBottom">
                    <FormControl style={{ flexDirection: "row" }}>
                      <Typography variant="caption">
                        <br />
                        <DatePickerInput
                          id="toDraftDate"
                          name="toDraftDate"
                          placeholderText="To Draft Date"
                          selected={formatStringToDate(
                            this.props.dialogdata.toDraftDate
                          )}
                          minDate={
                            this.props.dialogdata.fromDraftDate != null
                              ? formatStringToDate(
                                  this.props.dialogdata.fromDraftDate
                                )
                              : ""
                          }
                          onChange={dateValue => {
                            this.handleDateChange("toDraftDate", dateValue);
                          }}
                        />
                      </Typography>
                    </FormControl>
                  </td>
                </tr>
              </tbody>
            </table>
          </fieldset>
          <div className="LeftActionBarStyle">
            <Button
              variant="contained"
              color="primary"
              className={classes.button}
              onClick={this.handleSubmit}
            >
              Search
            </Button>
            &nbsp;
            <Button
              variant="contained"
              color="primary"
              className={classes.button}
              onClick={this.handleClear}
            >
              Clear
            </Button>
            &nbsp;
            <Button
              variant="contained"
              color="primary"
              className={classes.button}
              onClick={this.handleAddNew}
            >
              Add New
            </Button>
            &nbsp;
            {/*
            <span className="RightActionBarStyle">
              <div
                style={{
                  textAlign: "right",
                  paddingTop: 10,
                  cursor: "pointer",
                  color: "#8e263c"
                }}
              >
                <Tooltip title="Reports">
                  <InsertChartOutlined onClick={this.handleSubmit} />
                </Tooltip>
              </div>
            </span>
            */}
            <span className="RightActionBarStyle">
              <ExcelDownload
                enabled="true"
                onClick={this.handleExcelDownload}
              />
            </span>
            <span className="RightActionBarStyle">
              <Refresh onClick={this.handleRefresh} />
            </span>
          </div>
          <ReactTable
            ref={reactPhonePaymentEntryTable =>
              (this.selectTable = reactPhonePaymentEntryTable)
            }
            columns={[
              {
                expander: true,
                width: 65,
                Expander: ({ isExpanded }) => (
                  <div>
                    {isExpanded ? (
                      <span>
                        <Icon
                          style={{
                            cursor: "pointer",
                            color: "#3f51b5",
                            paddingTop: 10
                          }}
                          size={24}
                          icon={arrowDownB}
                        />
                      </span>
                    ) : (
                      <span>
                        <Tooltip title="Expand for more details">
                          <Icon
                            style={{
                              cursor: "pointer",
                              color: "#3f51b5",
                              paddingTop: 10
                            }}
                            size={24}
                            icon={arrowRightB}
                          />
                        </Tooltip>
                      </span>
                    )}
                  </div>
                ),
                style: {
                  cursor: "pointer",
                  fontSize: 25,
                  padding: "0",
                  textAlign: "center",
                  userSelect: "none",
                  color: "green"
                },
                Footer: () => <span>&nbsp;</span>
              },
              {
                Header: "Draft Tracking #",
                accessor: "trackingNumber",
                headerClassName: "BoldText ColoredText"
              },
              {
                Header: "Draft Date",
                accessor: "draftDate",
                headerClassName: "BoldText ColoredText"
              },
              {
                Header: "Payor Name",
                accessor: "accountName",
                headerClassName: "BoldText ColoredText"
              },
              {
                Header: "Address1",
                accessor: "addr1",
                headerClassName: "BoldText ColoredText"
              },
              {
                Header: "Address2",
                accessor: "addr2",
                headerClassName: "BoldText ColoredText"
              },
              {
                Header: "City",
                accessor: "city",
                headerClassName: "BoldText ColoredText"
              },
              {
                Header: "State",
                accessor: "state",
                headerClassName: "BoldText ColoredText"
              },
              {
                Header: "Zip Code",
                accessor: "zip",
                headerClassName: "BoldText ColoredText"
              },
              {
                Header: "Status",
                accessor: "status",
                sortable: false,
                headerClassName: "BoldText ColoredText"
              },
              {
                Header: "Entered By",
                accessor: "enteredBy",
                headerClassName: "BoldText ColoredText"
              },
              {
                Header: "Actions",
                id: "actions",
                accessor: "actions",
                sortable: false,
                className: "Centered",
                headerClassName: "BoldText ColoredText",
                Cell: ({ original }) => {
                  return (
                    <span style={{ textAlign: "center" }}>
                      <Tooltip title="Clone">
                        <a
                          role="button"
                          style={{
                            cursor: "pointer"
                          }}
                          onClick={() => {
                            this.handleClone(original);
                          }}
                        >
                          <FileCopyOutlined
                            style={{
                              color: "#00838f",
                              transition: "all .3s ease"
                            }}
                          />
                        </a>
                      </Tooltip>
                      &nbsp;
                      <Tooltip title="Cancel Draft">
                        <a
                          role="button"
                          style={{
                            cursor: "pointer"
                          }}
                          onClick={() => {
                            if (
                              (original.status === "SUBMITTED" ||
                                original.status === "PROCESSED") &&
                              original.enableCancel
                            ) {
                              this.handleCancelDraft(original);
                            }
                          }}
                        >
                          <b>
                            <CancelPresentation
                              style={{
                                color:
                                  (original.status === "SUBMITTED" ||
                                    original.status === "PROCESSED") &&
                                  original.enableCancel
                                    ? "#e54747"
                                    : "#CCCCCC",
                                transition: "all .3s ease"
                              }}
                            />
                          </b>
                        </a>
                      </Tooltip>
                      &nbsp;
                      {isUserRole("business") ? (
                        <Tooltip title="Cancel Correspondence">
                          <a
                            role="button"
                            style={{
                              cursor: "pointer"
                            }}
                            onClick={() => {
                              if (
                                (original.status === "SUBMITTED" ||
                                  original.status === "PROCESSED") &&
                                original.enableCancel &&
                                !original.suppressCorrespondence
                              ) {
                                this.handleCancelCorrespondence(original);
                              }
                            }}
                          >
                            <b>
                              <UnsubscribeOutlined
                                style={{
                                  color:
                                    (original.status === "SUBMITTED" ||
                                      original.status === "PROCESSED") &&
                                    original.enableCancel &&
                                    !original.suppressCorrespondence
                                      ? "#3f51b5"
                                      : "#CCCCCC",
                                  transition: "all .3s ease"
                                }}
                              />
                            </b>
                          </a>
                        </Tooltip>
                      ) : (
                        ""
                      )}
                      &nbsp;
                      <CommentsActionDialog
                        open={this.state.showComments}
                        title="Payment Comments"
                        iconTitle="View Comments"
                        commentsPlaceholder="Comments"
                        value={original.comment}
                        isEnabled={true}
                        button1Title=""
                        button2Title="Close"
                      />
                    </span>
                  );
                }
              }
            ]}
            defaultSorted={[
              {
                id: "draftDate",
                desc: true
              }
            ]}
            manual // Forces table not to paginate or sort automatically, so we can handle it server-side
            data={data}
            pages={pages} // Display the total number of pages
            loading={loading} // Display the loading overlay when we need it
            onFetchData={this.fetchData} // Request new data when things change
            defaultPageSize={10}
            className="-striped -highlight"
            SubComponent={row => {
              return (
                <div style={{ padding: "10px" }}>
                  <PhonePaymentSearchDetailsTable
                    trackingNumber={row.original.trackingNumber}
                    showNotification={() =>
                      this.showNotification("excelDownloadElt")
                    }
                  />
                </div>
              );
            }}
          >
            {(state, makeTable) => {
              return (
                <RecordCount
                  state={state}
                  makeTable={makeTable}
                  totalRecords={this.state.totalRecords}
                />
              );
            }}
          </ReactTable>
          <Snackbar
            place="tr"
            color="success"
            icon={InfoOutlined}
            message={this.state.successMsg}
            open={this.state.successElt}
            closeNotification={() => this.setState({ successElt: false })}
          />
          <Snackbar
            place="tr"
            color="danger"
            icon={InfoOutlined}
            message={this.state.errorMsg}
            open={this.state.errorElt}
            closeNotification={() => this.setState({ errorElt: false })}
            close
          />
        </Overlay>
      </React.Fragment>
    );
  }
}

const mapStateToProps = state => ({
  dialogdata: state.sidebar.phonePaymentSearch
});

const mapDispatchToProps = dispatch =>
  bindActionCreators(
    {
      initPhonePaymentSearch,
      getPhonePaymentSearch,
      addPhonePaymentSearch,
      delPhonePaymentSearch
    },
    dispatch
  );

PhonePaymentSearchTable.propTypes = {
  initPhonePaymentSearch: PropTypes.func,
  addPhonePaymentSearch: PropTypes.func,
  getPhonePaymentSearch: PropTypes.func,
  delPhonePaymentSearch: PropTypes.func,
  handleModeChange: PropTypes.func,
  className: PropTypes.string,
  sidebar: PropTypes.object,
  stats: PropTypes.bool,
  icon: PropTypes.bool,
  dialogdata: PropTypes.object
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(requireAuth(PhonePaymentSearchTable, "mainContent"));
