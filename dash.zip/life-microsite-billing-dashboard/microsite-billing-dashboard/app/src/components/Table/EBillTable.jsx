import React from "react";
import { withStyles } from "@material-ui/core/styles";
import { connect } from "react-redux";
import { bindActionCreators } from "redux";
import Icon from "react-icons-kit";
import { red, green } from "@material-ui/core/colors";

import PropTypes from "prop-types";

// Import React Table
import ReactTable from "react-table";
import { ReactTableDefaults } from "react-table";

import TextField from "@material-ui/core/TextField";
import Select from "@material-ui/core/Select";
import InputLabel from "@material-ui/core/InputLabel";
import FormControl from "@material-ui/core/FormControl";
import Button from "@material-ui/core/Button";
import Tooltip from "@material-ui/core/Tooltip";
import { arrowRightB } from "react-icons-kit/ionicons/arrowRightB";
import { arrowDownB } from "react-icons-kit/ionicons/arrowDownB";
import Typography from "@material-ui/core/Typography";
import Checkbox from "@material-ui/core/Checkbox";
import InfoOutlined from "@material-ui/icons/InfoOutlined";

// Import actions
import {
  initEBillSearch,
  getEBillSearch,
  addEBillSearch,
  delEBillSearch
} from "actions/EBillSearchAction.jsx";

import "react-table/react-table.css";
import "assets/css/bits-styles-override.css";

import Snackbar from "components/Snackbar/Snackbar.jsx";
import APIURIs from "properties/APIURIs.jsx";
import DatePickerInput from "components/DatePickerInput/DatePickerInput.jsx";
import paymentMethods from "properties/BillPaymentMethods.jsx";
import ebillIndTypes from "properties/EBillIndicatorTypes.jsx";
import LoadingSpinner from "components/CustomWidgets/LoadingSpinner.jsx";
import ExcelDownload from "components/CustomWidgets/ExcelDownload.jsx";
import Refresh from "components/CustomWidgets/Refresh.jsx";
import EBillDetailsTable from "components/Table/EBillDetailsTable.jsx";
import CustomConfirmation from "components/CustomWidgets/CustomConfirmation.jsx";

import {
  formatDate,
  formatStringToDate,
  putData,
  postTableDataWithSearchParams,
  commonExcelDownload,
  getFromLocalStorage,
  isUserAuthorized,
  addDays
} from "utils/CommonFunctions.jsx";
import requireAuth from "utils/AuthenticatedComponent.jsx";
import Overlay from "components/CustomWidgets/Overlay.jsx";
import RecordCount from "components/CustomWidgets/RecordCount.jsx";

//Set default values of React Table
Object.assign(ReactTableDefaults, {
  multiSort: false,
  LoadingComponent: LoadingSpinner
});

const classes = theme => ({
  button: {
    margin: theme.spacing.unit
  }
});

const RedCheckbox = withStyles({
  root: {
    color: red[400],
    "&$checked": {
      color: red[600]
    }
  },
  checked: {}
})(props => <Checkbox color="default" {...props} />);

const GreenCheckbox = withStyles({
  root: {
    color: green[400],
    "&$checked": {
      color: green[600]
    }
  },
  checked: {}
})(props => <Checkbox color="default" {...props} />);

function getEBillData(pageSize, page, sorted, filtered, eBillSearch) {
  return postTableDataWithSearchParams(
    APIURIs.EBILL_DATA_URI,
    APIURIs.EBILL_DATA_APIKEY,
    pageSize,
    page,
    sorted,
    filtered,
    eBillSearch
  );
}

function isAuthorized() {
  return isUserAuthorized("ebill", "activate_deactivate");
}

class EBillTable extends React.PureComponent {
  _isMounted = false;
  constructor(props) {
    super(props);

    this.state = {
      data: [],
      pages: null,
      loading: true,
      downloadExcelLoading: false,
      totalRecords: null,
      selectedPolCont: "",
      selectedFlagType: "",
      excelDownloadElt: false,
      openConfirmation: false,
      confirmationTitle: "Confirmation",
      confirmationDesc: "Are you sure you want to continue ?"
    };
    this.props.initEBillSearch();
  }

  componentDidMount() {
    this._isMounted = true;
  }

  componentWillUnmount() {
    this._isMounted = false;
    this.props.initEBillSearch();
  }

  showNotification(place) {
    var x = [];
    x[place] = true;
    if (this._isMounted) {
      this.setState(x);
    }
    this.alertTimeout = setTimeout(
      function() {
        x[place] = false;
        if (this._isMounted) {
          this.setState(x);
        }
      }.bind(this),
      6000
    );
  }

  submitConfirmation = () => {
    if (this._isMounted) {
      this.setState({
        openConfirmation: false
      });
    }
    putData(
      APIURIs.EBILL_ACTION_URI + this.state.selectedPolCont,
      APIURIs.EBILL_ACTION_APIKEY,
      {
        action: this.state.selectedFlagType,
        userName: getFromLocalStorage("userId")
      }
    )
      .then(() => {
        if (this._isMounted) {
          this.setState({
            selectedPolCont: "",
            loading: false
          });
        }
        this.handleRefresh(event);
      })
      .catch(error => {
        console.warn(error);
        if (this._isMounted) {
          this.setState({ loading: false });
        }
      });
  };

  closeConfirmation() {
    if (this._isMounted) {
      this.setState({
        openConfirmation: false,
        reactivate: false,
        deactivate: false,
        selectedPolCont: ""
      });
    }
  }

  handleRefresh = event => {
    this.handleSubmit(event);
  };

  handleSubmit = () => {
    this.selectTable.fireFetchData();
  };

  handleClear = () => {
    this.props.delEBillSearch();
  };

  handleChange = event => {
    let eBillSearchTmp = Object.assign({}, this.props.dialogdata);
    eBillSearchTmp[event.target.name] = event.target.value;
    this.props.addEBillSearch(eBillSearchTmp);
  };

  handleCheckboxChange = (polCont, flagType) => event => {
    if (event.target.checked == true) {
      if (this._isMounted) {
        this.setState({
          openConfirmation: true,
          selectedPolCont: polCont,
          selectedFlagType: flagType
        });
      }
    } else {
      if (this._isMounted) {
        this.setState({
          selectedPolCont: "",
          selectedFlagType: ""
        });
      }
    }
    let confirmationDescTmp = "";
    if (flagType == "reactivate") {
      confirmationDescTmp =
        "This action will reactivate the E-Bill. <br/>" +
        "Are you sure you want to continue ?";
    } else {
      confirmationDescTmp =
        "This action will deactivate the E-Bill. <br/>" +
        "Are you sure you want to continue ?";
    }
    this.setState({
      confirmationDesc: confirmationDescTmp
    });
  };

  handleDateChange = (dateName, dateValue) => {
    let eBillSearchTmp = Object.assign({}, this.props.dialogdata);
    eBillSearchTmp[dateName] = formatDate(dateValue);
    this.props.addEBillSearch(eBillSearchTmp);
  };

  handleExcelDownload = () => {
    commonExcelDownload(
      this,
      APIURIs.EBILL_XLSDATA_URI,
      APIURIs.EBILL_XLSDATA_APIKEY,
      { ...this.props.dialogdata },
      "EBillRecords.xlsx"
    ).then(response => {
      if (response.status == 200 && response.message == "email") {
        this.showNotification("excelDownloadElt");
      }
    });
  };

  fetchData = state => {
    if (this._isMounted) {
      this.setState({ loading: true });
    }
    getEBillData(
      state.pageSize,
      state.page,
      state.sorted,
      state.filtered,
      this.props.dialogdata
    )
      .then(res => {
        if (this._isMounted) {
          this.setState({
            data: res.rows,
            pages: res.pages == undefined ? 0 : res.pages,
            totalRecords: res.totalRecords,
            loading: false
          });
        }
      })
      .catch(error => {
        console.warn(error);
        if (this._isMounted) {
          this.setState({ loading: false });
        }
      });
  };

  render() {
    const { data, pages, loading } = this.state;
    return (
      <React.Fragment>
        <Overlay active={this.state.downloadExcelLoading} marginTop="150px">
          <table border="0px" cellPadding="0" cellSpacing="0">
            <tbody>
              <tr>
                <td className="VerticalAlignBottom">
                  <TextField
                    id="polCont"
                    name="polCont"
                    label="Policy Number"
                    type="search"
                    className={classes.textField}
                    onChange={this.handleChange}
                    value={this.props.dialogdata.polCont}
                    margin="none"
                  />
                </td>
                <td>&nbsp;</td>
                <td className="VerticalAlignBottom">
                  <FormControl>
                    <InputLabel htmlFor="status">Bill Indicator</InputLabel>
                    <Select
                      native
                      autoWidth={false}
                      style={{ width: 120 }}
                      value={this.props.dialogdata.ebillIndicator}
                      onChange={this.handleChange}
                      inputProps={{
                        name: "ebillIndicator",
                        id: "ebillIndicator"
                      }}
                    >
                      <option value="" />
                      {ebillIndTypes.map(option => (
                        <option key={option.value} value={option.value}>
                          {option.label}
                        </option>
                      ))}
                    </Select>
                  </FormControl>
                </td>
                <td>&nbsp;</td>
                <td className="VerticalAlignBottom">
                  <FormControl style={{ flexDirection: "row" }}>
                    <Typography variant="caption">
                      <br />
                      <DatePickerInput
                        id="fromBillIndChangeDate"
                        name="fromBillIndChangeDate"
                        onChangeRaw={this.handleDateChangeRaw}
                        placeholderText="From Bill Ind Change Date"
                        selected={
                          this.props.dialogdata.fromBillIndChangeDate != null
                            ? formatStringToDate(
                                this.props.dialogdata.fromBillIndChangeDate
                              )
                            : ""
                        }
                        onChange={dateValue => {
                          this.handleDateChange(
                            "fromBillIndChangeDate",
                            dateValue
                          );
                        }}
                      />
                    </Typography>
                  </FormControl>
                </td>
                <td>&nbsp;</td>
                <td className="VerticalAlignBottom">
                  <FormControl style={{ flexDirection: "row" }}>
                    <Typography variant="caption">
                      <br />
                      <DatePickerInput
                        id="toBillIndChangeDate"
                        name="toBillIndChangeDate"
                        onChangeRaw={this.handleDateChangeRaw}
                        placeholderText="To Bill Ind Change Date"
                        selected={
                          this.props.dialogdata.toBillIndChangeDate != null
                            ? formatStringToDate(
                                this.props.dialogdata.toBillIndChangeDate
                              )
                            : ""
                        }
                        minDate={
                          this.props.dialogdata.fromBillIndChangeDate != null
                            ? formatStringToDate(
                                this.props.dialogdata.fromBillIndChangeDate
                              )
                            : ""
                        }
                        maxDate={
                          this.props.dialogdata.fromBillIndChangeDate != null
                            ? addDays(
                                this.props.dialogdata.fromBillIndChangeDate,
                                30
                              )
                            : ""
                        }
                        onChange={dateValue => {
                          this.handleDateChange(
                            "toBillIndChangeDate",
                            dateValue
                          );
                        }}
                      />
                    </Typography>
                  </FormControl>
                </td>
              </tr>
            </tbody>
          </table>
          <table border="0px" cellPadding="0" cellSpacing="0">
            <tbody>
              <tr>
                <td className="VerticalAlignBottom">
                  <TextField
                    id="lockBoxNumber"
                    name="lockBoxNumber"
                    label="Lock Box Number"
                    type="search"
                    className={classes.textField}
                    onChange={this.handleChange}
                    value={this.props.dialogdata.lockBoxNumber}
                    margin="none"
                  />
                </td>
                <td>&nbsp;</td>
                <td className="VerticalAlignBottom">
                  <FormControl>
                    <InputLabel htmlFor="paymentMethod">
                      Payment Method
                    </InputLabel>
                    <Select
                      native
                      autoWidth={true}
                      value={this.props.dialogdata.paymentMethod}
                      onChange={this.handleChange}
                      inputProps={{
                        name: "paymentMethod",
                        id: "paymentMethod"
                      }}
                    >
                      <option value="" />
                      {paymentMethods.map(option => (
                        <option key={option.value} value={option.value}>
                          {option.label}
                        </option>
                      ))}
                    </Select>
                  </FormControl>
                </td>
              </tr>
            </tbody>
          </table>
          <div className="LeftActionBarStyle">
            <Button
              variant="contained"
              color="primary"
              className={classes.button}
              onClick={this.handleSubmit}
            >
              Search
            </Button>
            &nbsp;
            <Button
              variant="contained"
              color="primary"
              className={classes.button}
              onClick={this.handleClear}
            >
              Clear
            </Button>
            &nbsp;
            <span className="RightActionBarStyle">
              <ExcelDownload
                enabled="true"
                onClick={this.handleExcelDownload}
              />
            </span>
            <span className="RightActionBarStyle">
              <Refresh onClick={this.handleRefresh} />
            </span>
          </div>
          <ReactTable
            ref={reactEBillTable => (this.selectTable = reactEBillTable)}
            columns={[
              {
                expander: true,
                width: 65,
                Expander: ({ isExpanded }) => (
                  <div>
                    {isExpanded ? (
                      <span>
                        <Icon
                          style={{
                            cursor: "pointer",
                            color: "#3f51b5",
                            paddingTop: 10
                          }}
                          size={24}
                          icon={arrowDownB}
                        />
                      </span>
                    ) : (
                      <span>
                        <Tooltip title="Expand for more details">
                          <Icon
                            style={{
                              cursor: "pointer",
                              color: "#3f51b5",
                              paddingTop: 10
                            }}
                            size={24}
                            icon={arrowRightB}
                          />
                        </Tooltip>
                      </span>
                    )}
                  </div>
                ),
                style: {
                  cursor: "pointer",
                  fontSize: 25,
                  padding: "0",
                  textAlign: "center",
                  userSelect: "none",
                  color: "green"
                },
                Footer: () => <span>&nbsp;</span>
              },
              {
                Header: "Sequence Number",
                accessor: "sequenceNumber",
                headerClassName: "BoldText ColoredText"
              },
              {
                Header: "Policy Number",
                accessor: "polCont",
                headerClassName: "BoldText ColoredText"
              },
              {
                Header: "Company Code",
                accessor: "companyCode",
                headerClassName: "BoldText ColoredText"
              },
              {
                Header: "Bill Indicator",
                id: "ebillIndicator",
                Cell: ({ original }) => {
                  return (
                    <span>
                      {original.ebillIndicator == "X"
                        ? "Paper"
                        : original.ebillIndicator == "Y"
                          ? "E-Bill"
                          : original.ebillIndicator == "Z"
                            ? "Both"
                            : ""}
                    </span>
                  );
                },
                headerClassName: "BoldText ColoredText"
              },
              {
                Header: "Bill Ind Change Date",
                accessor: "billIndChangeDate",
                headerClassName: "BoldText ColoredText"
              },
              {
                Header: "Lock Box Number",
                accessor: "lockboxNumber",
                headerClassName: "BoldText ColoredText"
              },
              {
                Header: "Payment Method",
                accessor: "paymentMethod",
                headerClassName: "BoldText ColoredText"
              },
              {
                Header: "Updated Timestamp",
                accessor: "updateTmStamp",
                headerClassName: "BoldText ColoredText"
              },
              {
                Header: "Actions",
                id: "actions",
                accessor: "actions",
                width: 110,
                sortable: false,
                headerClassName: "BoldText ColoredText",
                className: "Centered",
                show: isAuthorized(),
                Cell: ({ row, original }) => {
                  return (
                    <span style={{ textAlign: "center" }}>
                      {original.paymentMethod == "Direct Billing" &&
                      original.ebillIndicator != "Y" &&
                      original.isEbillActivated ? (
                        <Tooltip title="Reactivate" placement="left">
                          <GreenCheckbox
                            size="small"
                            checked={
                              this.state.selectedPolCont == row.polCont
                                ? true
                                : false
                            }
                            onChange={this.handleCheckboxChange(
                              row.polCont,
                              "reactivate"
                            )}
                            style={{ height: 20 }}
                            color="primary"
                          />
                        </Tooltip>
                      ) : (
                        ""
                      )}
                      {original.paymentMethod == "Direct Billing" &&
                      original.ebillIndicator == "Y" ? (
                        <Tooltip title="Deactivate" placement="left">
                          <RedCheckbox
                            size="small"
                            checked={
                              this.state.selectedPolCont == row.polCont
                                ? true
                                : false
                            }
                            onChange={this.handleCheckboxChange(
                              row.polCont,
                              "deactivate"
                            )}
                            style={{ height: 20 }}
                            color="secondary"
                          />
                        </Tooltip>
                      ) : (
                        ""
                      )}
                    </span>
                  );
                }
              }
            ]}
            defaultSorted={[
              {
                id: "billIndChangeDate",
                desc: true
              }
            ]}
            manual // Forces table not to paginate or sort automatically, so we can handle it server-side
            data={data}
            pages={pages} // Display the total number of pages
            loading={loading} // Display the loading overlay when we need it
            onFetchData={this.fetchData} // Request new data when things change
            defaultPageSize={10}
            className="-striped -highlight"
            SubComponent={row => {
              return (
                <div style={{ padding: "10px" }}>
                  <EBillDetailsTable
                    polCont={row.original.polCont}
                    showNotification={() =>
                      this.showNotification("excelDownloadElt")
                    }
                  />
                </div>
              );
            }}
          >
            {(state, makeTable) => {
              return (
                <RecordCount
                  state={state}
                  makeTable={makeTable}
                  totalRecords={this.state.totalRecords}
                />
              );
            }}
          </ReactTable>
          <CustomConfirmation
            open={this.state.openConfirmation}
            title={this.state.confirmationTitle}
            button1Title="CONTINUE"
            button2Title="CANCEL"
            description={this.state.confirmationDesc}
            onSubmit={this.submitConfirmation}
            onClose={() => this.closeConfirmation()}
          />
          <Snackbar
            place="tr"
            color="success"
            icon={InfoOutlined}
            message="Since the number of records are more than 10K, Excel report will be emailed to your email address."
            open={this.state.excelDownloadElt}
            closeNotification={() =>
              this._isMounted
                ? this.setState({ excelDownloadElt: false })
                : null
            }
            close
          />
        </Overlay>
      </React.Fragment>
    );
  }
}

const mapStateToProps = state => ({
  dialogdata: state.sidebar.eBillSearch
});

const mapDispatchToProps = dispatch =>
  bindActionCreators(
    {
      initEBillSearch,
      getEBillSearch,
      addEBillSearch,
      delEBillSearch
    },
    dispatch
  );

EBillTable.propTypes = {
  initEBillSearch: PropTypes.func,
  addEBillSearch: PropTypes.func,
  getEBillSearch: PropTypes.func,
  delEBillSearch: PropTypes.func,
  className: PropTypes.string,
  sidebar: PropTypes.object,
  stats: PropTypes.bool,
  icon: PropTypes.bool,
  dialogdata: PropTypes.object
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(requireAuth(EBillTable, "mainContent"));
