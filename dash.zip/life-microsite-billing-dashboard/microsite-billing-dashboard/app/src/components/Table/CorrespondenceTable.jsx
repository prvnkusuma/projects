import React from "react";
import { connect } from "react-redux";
import { bindActionCreators } from "redux";

import PropTypes from "prop-types";

// Import React Table
import ReactTable from "react-table";
import { ReactTableDefaults } from "react-table";

import TextField from "@material-ui/core/TextField";
import Select from "@material-ui/core/Select";
import InputLabel from "@material-ui/core/InputLabel";
import FormControl from "@material-ui/core/FormControl";
import Button from "@material-ui/core/Button";
import Typography from "@material-ui/core/Typography";
import InfoOutlined from "@material-ui/icons/InfoOutlined";

// Import actions
import {
  initCorrespondenceSearch,
  getCorrespondenceSearch,
  addCorrespondenceSearch,
  delCorrespondenceSearch
} from "actions/CorrespondenceSearchAction.jsx";

import "react-table/react-table.css";
import "assets/css/bits-styles-override.css";

import Snackbar from "components/Snackbar/Snackbar.jsx";
import DatePickerInput from "components/DatePickerInput/DatePickerInput.jsx";
import CorrespondenceActionDialog from "components/Dialog/CorrespondenceActionDialog.jsx";
import APIURIs from "properties/APIURIs.jsx";
import ProcessFlowDialog from "components/Dialog/ProcessFlowDialog.jsx";
import {
  statusTypes,
  eventCodeTypes
} from "properties/CorrespondenceTypes.jsx";
import LoadingSpinner from "components/CustomWidgets/LoadingSpinner.jsx";
import ExcelDownload from "components/CustomWidgets/ExcelDownload.jsx";
import Refresh from "components/CustomWidgets/Refresh.jsx";
import BulkReProcessCorrespondenceDialog from "components/Dialog/BulkReProcessCorrespondenceDialog.jsx";
import {
  addDays,
  diffDays,
  formatDate,
  formatStringToDate,
  postTableDataWithSearchParams,
  commonExcelDownload
} from "utils/CommonFunctions.jsx";
import requireAuth from "utils/AuthenticatedComponent.jsx";
import Overlay from "components/CustomWidgets/Overlay.jsx";
import RecordCount from "components/CustomWidgets/RecordCount.jsx";

//Set default values of React Table
Object.assign(ReactTableDefaults, {
  multiSort: false,
  LoadingComponent: LoadingSpinner
});

const classes = theme => ({
  button: {
    margin: theme.spacing.unit
  }
});

function getCorrespondenceData(
  pageSize,
  page,
  sorted,
  filtered,
  correspondenceSearch
) {
  return postTableDataWithSearchParams(
    APIURIs.CORRESPONDENCE_DATA_URI,
    APIURIs.CORRESPONDENCE_DATA_APIKEY,
    pageSize,
    page,
    sorted,
    filtered,
    correspondenceSearch
  );
}

class CorrespondenceTable extends React.Component {
  _isMounted = false;
  constructor(props) {
    super(props);

    this.state = {
      data: [],
      pages: null,
      loading: true,
      successElt: false,
      errorElt: false,
      infoElt: false,
      excelDownloadElt: false,
      openBulkReprocessDialog: false,
      downloadExcelLoading: false,
      disableCycleDates: false,
      totalRecords: null
    };
    this.props.initCorrespondenceSearch();
  }

  componentDidMount() {
    this._isMounted = true;
  }

  componentWillUnmount() {
    this._isMounted = false;
    this.props.initCorrespondenceSearch();
  }

  showNotification(place) {
    var x = [];
    x[place] = true;
    if (this._isMounted) {
      this.setState(x);
    }
    this.alertTimeout = setTimeout(
      function() {
        x[place] = false;
        if (this._isMounted) {
          this.setState(x);
        }
      }.bind(this),
      6000
    );
  }
  setLoading(status) {
    if (this._isMounted) {
      this.setState({ downloadExcelLoading: status });
    }
  }

  handleRefresh = event => {
    this.handleSubmit(event);
  };

  handleSubmit = event => {
    event.preventDefault();
    this.selectTable.fireFetchData();
  };

  handleClear = () => {
    this.props.delCorrespondenceSearch();
    if (this._isMounted) {
      this.setState({ disableCycleDates: false });
    }
  };

  handleBulkReprocess = () => {
    if (this._isMounted) {
      this.setState({ openBulkReprocessDialog: true });
    }
  };

  handleClose = () => {
    if (this._isMounted) {
      this.setState({ openBulkReprocessDialog: false });
    }
  };

  handleChange = event => {
    let correspondenceSearchTmp = Object.assign({}, this.props.dialogdata);
    correspondenceSearchTmp[event.target.name] = event.target.value;
    this.props.addCorrespondenceSearch(correspondenceSearchTmp);
  };

  handleDateChange = (dateName, dateValue) => {
    if (dateName == "insertDate") {
      let correspondenceSearchTmp = Object.assign({}, this.props.dialogdata);
      correspondenceSearchTmp["insertDate"] = formatDate(dateValue);
      correspondenceSearchTmp["fromCycleDate"] = "";
      correspondenceSearchTmp["toCycleDate"] = "";
      this.props.addCorrespondenceSearch(correspondenceSearchTmp);
      if (this._isMounted) {
        this.setState({ disableCycleDates: true });
      }
      return;
    }

    let correspondenceSearchTmp = Object.assign({}, this.props.dialogdata);
    correspondenceSearchTmp[dateName] = formatDate(dateValue);

    if (diffDays(dateValue, this.props.dialogdata.toCycleDate) > 30) {
      correspondenceSearchTmp["toCycleDate"] = formatDate(dateValue);
    }

    this.props.addCorrespondenceSearch(correspondenceSearchTmp);
  };

  handleDateChangeRaw = e => {
    e.preventDefault();
  };

  handleExcelDownload = () => {
    commonExcelDownload(
      this,
      APIURIs.CORRESPONDENCE_XLSDATA_URI,
      APIURIs.CORRESPONDENCE_XLSDATA_APIKEY,
      { ...this.props.dialogdata },
      "CorrespondenceRecords.xlsx"
    ).then(response => {
      if (response.status == 200 && response.message == "email") {
        this.showNotification("excelDownloadElt");
      }
    });
  };

  addDateFieldsToStore = () => {
    if (this._isMounted) {
      this.setState({ loading: true });
    }

    let correspondenceSearchTmp = Object.assign({}, this.props.dialogdata);
    correspondenceSearchTmp.fromCycleDate = formatDate(
      this.props.dialogdata.fromCycleDate
    );
    correspondenceSearchTmp.toCycleDate = formatDate(
      this.props.dialogdata.toCycleDate
    );
    this.props.addCorrespondenceSearch(correspondenceSearchTmp);
  };

  fetchSearchData = () => {
    this.addDateFieldsToStore();
    getCorrespondenceData(10, 0, true, false, this.props.dialogdata)
      .then(res => {
        if (this._isMounted) {
          this.setState({
            data: res.rows,
            pages: res.pages == undefined ? 0 : res.pages,
            totalRecords: res.totalRecords,
            loading: false
          });
        }
      })
      .catch(error => {
        console.warn(error);
        if (this._isMounted) {
          this.setState({ loading: false });
        }
      });
  };

  fetchData = state => {
    this.addDateFieldsToStore();
    getCorrespondenceData(
      state.pageSize,
      state.page,
      state.sorted,
      state.filtered,
      this.props.dialogdata
    )
      .then(res => {
        if (this._isMounted) {
          this.setState({
            data: res.rows,
            pages: res.pages == undefined ? 0 : res.pages,
            totalRecords: res.totalRecords,
            loading: false
          });
        }
      })
      .catch(error => {
        console.warn(error);
        if (this._isMounted) {
          this.setState({ loading: false });
        }
      });
  };

  render() {
    const { data, pages, loading } = this.state;
    return (
      <React.Fragment>
        <Overlay active={this.state.downloadExcelLoading} marginTop="150px">
          <table border="0px" cellPadding="0" cellSpacing="0">
            <tbody>
              <tr>
                <td className="VerticalAlignBottom">
                  <TextField
                    id="controlNum"
                    name="controlNum"
                    label="Control Number"
                    type="search"
                    className={classes.textField}
                    onChange={this.handleChange}
                    value={this.props.dialogdata.controlNum}
                    margin="none"
                  />
                </td>
                <td>&nbsp;</td>
                <td className="VerticalAlignBottom">
                  <TextField
                    id="polCont"
                    name="polCont"
                    label="Policy Number"
                    type="search"
                    className={classes.textField}
                    onChange={this.handleChange}
                    value={this.props.dialogdata.polCont}
                    margin="none"
                  />
                </td>
                <td>&nbsp;</td>
                <td className="VerticalAlignBottom">
                  <TextField
                    id="transRefGUID"
                    name="transRefGUID"
                    label="Trans Ref GUID"
                    type="search"
                    className={classes.textField}
                    onChange={this.handleChange}
                    value={this.props.dialogdata.transRefGUID}
                    margin="none"
                  />
                </td>
                <td>&nbsp;</td>
                <td className="VerticalAlignBottom">
                  <TextField
                    id="trackingNumber"
                    name="trackingNumber"
                    label="Tracking Number"
                    type="search"
                    className={classes.textField}
                    onChange={this.handleChange}
                    value={this.props.dialogdata.trackingNumber}
                    margin="none"
                  />
                </td>
              </tr>
            </tbody>
          </table>
          <table border="0px" cellPadding="0" cellSpacing="0">
            <tbody>
              <tr>
                <td className="VerticalAlignBottom">
                  <FormControl style={{ flexDirection: "row" }}>
                    <Typography variant="caption">
                      <br />
                      <DatePickerInput
                        id="fromCycleDate"
                        name="fromCycleDate"
                        disabled={this.state.disableCycleDates}
                        onChangeRaw={this.handleDateChangeRaw}
                        placeholderText="From Cycle Date"
                        selected={formatStringToDate(
                          this.props.dialogdata.fromCycleDate
                        )}
                        onChange={dateValue => {
                          this.handleDateChange("fromCycleDate", dateValue);
                        }}
                      />
                    </Typography>
                  </FormControl>
                </td>
                <td>&nbsp;</td>
                <td className="VerticalAlignBottom">
                  <FormControl style={{ flexDirection: "row" }}>
                    <Typography variant="caption">
                      <br />
                      <DatePickerInput
                        id="toCycleDate"
                        name="toCycleDate"
                        disabled={this.state.disableCycleDates}
                        onChangeRaw={this.handleDateChangeRaw}
                        placeholderText="To Cycle Date"
                        selected={formatStringToDate(
                          this.props.dialogdata.toCycleDate
                        )}
                        minDate={
                          this.props.dialogdata.fromCycleDate != null
                            ? formatStringToDate(
                                this.props.dialogdata.fromCycleDate
                              )
                            : ""
                        }
                        maxDate={
                          this.props.dialogdata.fromCycleDate != null
                            ? addDays(this.props.dialogdata.fromCycleDate, 30)
                            : ""
                        }
                        onChange={dateValue => {
                          this.handleDateChange("toCycleDate", dateValue);
                        }}
                      />
                    </Typography>
                  </FormControl>
                </td>
                <td>&nbsp;</td>
                <td className="VerticalAlignBottom">
                  <FormControl>
                    <InputLabel htmlFor="status">Status</InputLabel>
                    <Select
                      native
                      autoWidth={false}
                      style={{ width: 120 }}
                      value={this.props.dialogdata.status}
                      onChange={this.handleChange}
                      inputProps={{
                        name: "status",
                        id: "status"
                      }}
                    >
                      <option value="" />
                      {statusTypes.map(option => (
                        <option key={option.value} value={option.value}>
                          {option.label}
                        </option>
                      ))}
                    </Select>
                  </FormControl>
                </td>
                <td>&nbsp;</td>
                <td className="VerticalAlignBottom">
                  <FormControl>
                    <InputLabel htmlFor="status">Letter Type</InputLabel>
                    <Select
                      native
                      autoWidth={false}
                      style={{ width: 140 }}
                      value={this.props.dialogdata.eventCode}
                      onChange={this.handleChange}
                      inputProps={{
                        name: "eventCode",
                        id: "eventCode"
                      }}
                    >
                      <option value="" />
                      {eventCodeTypes.map(option => (
                        <option key={option.value} value={option.value}>
                          {option.label}
                        </option>
                      ))}
                    </Select>
                  </FormControl>
                </td>
              </tr>
            </tbody>
          </table>
          <div className="LeftActionBarStyle">
            <Button
              variant="contained"
              color="primary"
              className={classes.button}
              onClick={this.handleSubmit}
            >
              Search
            </Button>
            &nbsp;
            <Button
              variant="contained"
              color="primary"
              className={classes.button}
              onClick={this.handleClear}
            >
              Clear
            </Button>
            &nbsp;
            <Button
              variant="contained"
              color="primary"
              className={classes.button}
              onClick={this.handleBulkReprocess}
            >
              Bulk Reprocess
            </Button>
            <span className="RightActionBarStyle">
              <ExcelDownload
                enabled="true"
                onClick={this.handleExcelDownload}
              />
            </span>
            <span className="RightActionBarStyle">
              <Refresh onClick={this.handleRefresh} />
            </span>
          </div>
          <ReactTable
            ref={reactCorrespondenceTable =>
              (this.selectTable = reactCorrespondenceTable)
            }
            columns={[
              {
                Header: "Control Number",
                accessor: "controlNum",
                headerClassName: "BoldText ColoredText"
              },
              {
                Header: "Policy Number",
                accessor: "polCont",
                headerClassName: "BoldText ColoredText"
              },
              {
                Header: "Trans Ref GUID",
                accessor: "transRefGUID",
                headerClassName: "BoldText ColoredText"
              },
              {
                Header: "Tracking Number",
                accessor: "trackingNumber",
                headerClassName: "BoldText ColoredText"
              },
              {
                Header: "Cycle Date",
                accessor: "cycleDate",
                headerClassName: "BoldText ColoredText"
              },
              {
                Header: "Effective Date",
                accessor: "effDate",
                headerClassName: "BoldText ColoredText"
              },
              {
                Header: "Event Code",
                accessor: "eventCode",
                headerClassName: "BoldText ColoredText"
              },
              {
                Header: "Reason",
                accessor: "reason",
                headerClassName: "BoldText ColoredText"
              },
              {
                Header: "Status",
                id: "status",
                accessor: "status",
                headerClassName: "BoldText ColoredText",
                Cell: ({ row, original }) => {
                  return (
                    <span>
                      <span
                        style={{
                          color:
                            row.status === "completed"
                              ? "#ff2e00"
                              : row.status === "failed"
                                ? "#ffbf00"
                                : "#57d500",
                          transition: "all .3s ease"
                        }}
                      >
                        {" "}
                        <ProcessFlowDialog
                          title="Process Flow"
                          status={row.status}
                          processType="correspondence"
                          isReprocess={original.isReprocess}
                          stepNumber={original.stepNumber}
                          selectedId={original.transRefGUID}
                          transRefGUID={original.transRefGUID}
                        />
                      </span>
                    </span>
                  );
                }
              },
              {
                Header: "Actions",
                id: "actions",
                accessor: "actions",
                width: 110,
                sortable: false,
                headerClassName: "BoldText ColoredText",
                className: "Centered",
                Cell: ({ original }) => {
                  return (
                    <span style={{ textAlign: "center" }}>
                      <CorrespondenceActionDialog
                        controlNum={original.controlNum}
                        status={original.status}
                        transRefGUID={original.transRefGUID}
                        policyCont={original.polCont}
                        showLoading={() => this.setLoading(true)}
                        hideLoading={() => this.setLoading(false)}
                        cycleDate={original.cycleDate}
                        payorName={original.payorName}
                        eventCodeType={
                          original.eventCode == "70001"
                            ? "Bank Draft Termination Letter"
                            : original.eventCode == "70002"
                              ? "Bank Draft Reversal Letter"
                              : original.eventCode == "70003"
                                ? "Bank Draft Confirmation Letter"
                                : original.eventCode == "70004"
                                  ? "Bank Draft Mode Change Letter"
                                  : original.eventCode == "70005"
                                    ? "EBill Payment Scheduled email returned letter"
                                    : "EBill Payment Confirmation email returned letter"
                        }
                      />
                    </span>
                  );
                }
              }
            ]}
            defaultSorted={[
              {
                id: "cycleDate",
                desc: true
              }
            ]}
            manual // Forces table not to paginate or sort automatically, so we can handle it server-side
            data={data}
            pages={pages} // Display the total number of pages
            loading={loading} // Display the loading overlay when we need it
            onFetchData={this.fetchData} // Request new data when things change
            defaultPageSize={10}
            className="-striped -highlight"
          >
            {(state, makeTable) => {
              return (
                <RecordCount
                  state={state}
                  makeTable={makeTable}
                  totalRecords={this.state.totalRecords}
                />
              );
            }}
          </ReactTable>
          <br />
          {/* Bulk ReProcess Dialog */}
          <BulkReProcessCorrespondenceDialog
            open={this.state.openBulkReprocessDialog}
            handleClose={this.handleClose}
            title="Bulk Reprocess"
            showSuccessNotification={() => this.showNotification("successElt")}
            showErrorNotification={() => this.showNotification("errorElt")}
            showInfoNotification={() => this.showNotification("infoElt")}
          />
          <Snackbar
            place="tr"
            color="success"
            icon={InfoOutlined}
            message="Reprocess successfully initiated!"
            open={this.state.successElt}
            closeNotification={() => this.setState({ successElt: false })}
            close
          />
          <Snackbar
            place="tr"
            color="danger"
            icon={InfoOutlined}
            message="Reprocess initiation failed!"
            open={this.state.errorElt}
            closeNotification={() => this.setState({ errorElt: false })}
            close
          />
          <Snackbar
            place="tr"
            color="info"
            icon={InfoOutlined}
            message="No declines found!"
            open={this.state.infoElt}
            closeNotification={() => this.setState({ infoElt: false })}
            close
          />
          <Snackbar
            place="tr"
            color="success"
            icon={InfoOutlined}
            message="Since the number of records are more than 10K, Excel report will be emailed to your email address."
            open={this.state.excelDownloadElt}
            closeNotification={() =>
              this._isMounted
                ? this.setState({ excelDownloadElt: false })
                : null
            }
            close
          />
        </Overlay>
      </React.Fragment>
    );
  }
}

const mapStateToProps = state => ({
  dialogdata: state.sidebar.correspondenceSearch
});

const mapDispatchToProps = dispatch =>
  bindActionCreators(
    {
      initCorrespondenceSearch,
      getCorrespondenceSearch,
      addCorrespondenceSearch,
      delCorrespondenceSearch
    },
    dispatch
  );

CorrespondenceTable.propTypes = {
  initCorrespondenceSearch: PropTypes.func,
  addCorrespondenceSearch: PropTypes.func,
  getCorrespondenceSearch: PropTypes.func,
  delCorrespondenceSearch: PropTypes.func,
  className: PropTypes.string,
  sidebar: PropTypes.object,
  stats: PropTypes.bool,
  icon: PropTypes.bool,
  dialogdata: PropTypes.object
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(requireAuth(CorrespondenceTable, "mainContent"));
