import React from "react";
import { connect } from "react-redux";
import { bindActionCreators } from "redux";

import PropTypes from "prop-types";

// Import React Table
import ReactTable from "react-table";
import { ReactTableDefaults } from "react-table";

import TextField from "@material-ui/core/TextField";
import Select from "@material-ui/core/Select";
import InputLabel from "@material-ui/core/InputLabel";
import FormControl from "@material-ui/core/FormControl";
import Button from "@material-ui/core/Button";
import Typography from "@material-ui/core/Typography";
import InfoOutlined from "@material-ui/icons/InfoOutlined";

//Import actions
import {
  initEFTReturnsSearch,
  getEFTReturnsSearch,
  addEFTReturnsSearch,
  delEFTReturnsSearch
} from "actions/EFTReturnsSearchAction.jsx";

import "react-table/react-table.css";
import "assets/css/bits-styles-override.css";

import Snackbar from "components/Snackbar/Snackbar.jsx";
import DatePickerInput from "components/DatePickerInput/DatePickerInput.jsx";
import EFTReturnsActionDialog from "components/Dialog/EFTReturnsActionDialog.jsx";
import ProcessFlowDialog from "components/Dialog/ProcessFlowDialog.jsx";
import APIURIs from "properties/APIURIs.jsx";
import LoadingSpinner from "components/CustomWidgets/LoadingSpinner.jsx";
import ExcelDownload from "components/CustomWidgets/ExcelDownload.jsx";
import Refresh from "components/CustomWidgets/Refresh.jsx";
import { statusTypes } from "properties/CorrespondenceTypes.jsx";
import { types, eftTypes, paymentTypes } from "properties/EFTReturnTypes.jsx";
import BulkReProcessEFTReturnsDialog from "components/Dialog/BulkReProcessEFTReturnsDialog.jsx";
import {
  addDays,
  diffDays,
  formatDate,
  formatStringToDate,
  postTableDataWithSearchParams,
  commonExcelDownload,
  isOnlyUserRole
} from "utils/CommonFunctions.jsx";
import requireAuth from "utils/AuthenticatedComponent.jsx";
import Overlay from "components/CustomWidgets/Overlay.jsx";
import RecordCount from "components/CustomWidgets/RecordCount.jsx";

//Set default values of React Table
Object.assign(ReactTableDefaults, {
  multiSort: false,
  LoadingComponent: LoadingSpinner
});

const classes = theme => ({
  formControl: {
    margin: theme.spacing.unit,
    minWidth: 120,
    display: "flex",
    wrap: "nowrap"
  },
  textField: {
    marginLeft: theme.spacing.unit,
    marginRight: theme.spacing.unit,
    width: 200
  },
  button: {
    margin: theme.spacing.unit
  }
});

function getEFTReturnsData(pageSize, page, sorted, filtered, eftReturnsSearch) {
  const { eftType, ...rest } = eftReturnsSearch;
  let params = {
    eftType: isOnlyUserRole("customercare") ? "5" : eftType,
    ...rest
  };
  return postTableDataWithSearchParams(
    APIURIs.EFTRETURNS_DATA_URI,
    APIURIs.EFTRETURNS_DATA_APIKEY,
    pageSize,
    page,
    sorted,
    filtered,
    params
  );
}

class EFTReturnsTable extends React.Component {
  _isMounted = false;
  constructor(props) {
    super(props);

    this.state = {
      data: [],
      pages: null,
      loading: true,
      successElt: false,
      errorElt: false,
      infoElt: false,
      excelDownloadElt: false,
      openBulkReprocessDialog: false,
      downloadExcelLoading: false,
      totalRecords: null
    };
    this.props.initEFTReturnsSearch();
  }

  componentDidMount() {
    this._isMounted = true;
  }

  componentWillUnmount() {
    this._isMounted = false;
    this.props.initEFTReturnsSearch();
  }

  showNotification(place) {
    var x = [];
    x[place] = true;
    if (this._isMounted) {
      this.setState(x);
    }
    this.alertTimeout = setTimeout(
      function() {
        x[place] = false;
        if (this._isMounted) {
          this.setState(x);
        }
      }.bind(this),
      6000
    );
  }

  setLoading(status) {
    if (this._isMounted) {
      this.setState({ downloadExcelLoading: status });
    }
  }

  handleRefresh = event => {
    this.handleSubmit(event);
  };

  handleClose = () => {
    if (this._isMounted) {
      this.setState({
        openBulkReprocessDialog: false
      });
    }
  };

  handleSubmit = event => {
    event.preventDefault();
    this.selectTable.fireFetchData();
  };

  handleClear = () => {
    this.props.delEFTReturnsSearch();
  };

  handleBulkReprocess = () => {
    if (this._isMounted) {
      this.setState({ openBulkReprocessDialog: true });
    }
  };

  handleChange = event => {
    let eftReturnsSearchTmp = Object.assign({}, this.props.searchdata);
    eftReturnsSearchTmp[event.target.name] = event.target.value;
    this.props.addEFTReturnsSearch(eftReturnsSearchTmp);
  };

  handleDateChange = (dateName, dateValue) => {
    let eftReturnsSearchTmp = Object.assign({}, this.props.searchdata);
    eftReturnsSearchTmp[dateName] = formatDate(dateValue);

    if (
      dateName === "fromCycleDate" &&
      diffDays(dateValue, this.props.searchdata.toCycleDate) > 30
    ) {
      eftReturnsSearchTmp["toCycleDate"] = formatDate(dateValue);
    }

    this.props.addEFTReturnsSearch(eftReturnsSearchTmp);
  };

  handleDateChangeRaw = e => {
    e.preventDefault();
  };

  handleExcelDownload = () => {
    commonExcelDownload(
      this,
      APIURIs.EFTRETURNS_XLSDATA_URI,
      APIURIs.EFTRETURNS_XLSDATA_APIKEY,
      { ...this.props.searchdata },
      "EFTReturnsRecords.xlsx"
    ).then(response => {
      if (response.status == 200 && response.message == "email") {
        this.showNotification("excelDownloadElt");
      }
    });
  };

  addDateFieldsToStore = () => {
    if (this._isMounted) {
      this.setState({ loading: true });
    }

    let eftReturnsSearchTmp = Object.assign({}, this.props.searchdata);

    eftReturnsSearchTmp.fromCycleDate = formatDate(
      this.props.searchdata.fromCycleDate
    );
    eftReturnsSearchTmp.toCycleDate = formatDate(
      this.props.searchdata.toCycleDate
    );
    this.props.addEFTReturnsSearch(eftReturnsSearchTmp);
  };

  fetchSearchData = () => {
    this.addDateFieldsToStore();
    getEFTReturnsData(10, 0, true, false, this.props.searchdata)
      .then(res => {
        if (this._isMounted) {
          this.setState({
            data: res.rows,
            pages: res.pages == undefined ? 0 : res.pages,
            totalRecords: res.totalRecords,
            loading: false
          });
        }
      })
      .catch(error => {
        console.warn(error);
        if (this._isMounted) {
          this.setState({ loading: false });
        }
      });
  };

  fetchData = state => {
    this.addDateFieldsToStore();
    getEFTReturnsData(
      state.pageSize,
      state.page,
      state.sorted,
      state.filtered,
      this.props.searchdata
    )
      .then(res => {
        if (this._isMounted) {
          this.setState({
            data: res.rows,
            pages: res.pages == undefined ? 0 : res.pages,
            totalRecords: res.totalRecords,
            loading: false
          });
        }
      })
      .catch(error => {
        console.warn(error);
        if (this._isMounted) {
          this.setState({ loading: false });
        }
      });
  };

  render() {
    const { data, pages, loading } = this.state;
    return (
      <React.Fragment>
        <Overlay active={this.state.downloadExcelLoading} marginTop="150px">
          <table border="0px" cellPadding="0" cellSpacing="0">
            <tbody>
              <tr>
                <td className="VerticalAlignBottom">
                  <TextField
                    id="polCont"
                    name="polCont"
                    label="Policy Number"
                    type="search"
                    className={classes.textField}
                    onChange={this.handleChange}
                    value={this.props.searchdata.polCont}
                    margin="none"
                  />
                </td>
                <td>&nbsp;</td>
                <td className="VerticalAlignBottom">
                  <TextField
                    id="controlNum"
                    name="controlNum"
                    label="Control Number"
                    type="search"
                    className={classes.textField}
                    onChange={this.handleChange}
                    value={this.props.searchdata.controlNum}
                    margin="none"
                  />
                </td>
                <td>&nbsp;</td>
                <td
                  className="VerticalAlignBottom"
                  style={{
                    display: isOnlyUserRole("customercare")
                      ? "none"
                      : "table-cell"
                  }}
                >
                  <FormControl>
                    <InputLabel htmlFor="eftType">EFT Type</InputLabel>
                    <Select
                      native
                      autoWidth={false}
                      style={{ width: 120 }}
                      value={this.props.searchdata.eftType}
                      onChange={this.handleChange}
                      inputProps={{
                        name: "eftType",
                        id: "eftType"
                      }}
                    >
                      <option value="" />
                      {eftTypes.map(option => (
                        <option key={option.value} value={option.value}>
                          {option.label}
                        </option>
                      ))}
                    </Select>
                  </FormControl>
                </td>
                <td>&nbsp;</td>
                <td className="VerticalAlignBottom">
                  <FormControl>
                    <InputLabel htmlFor="paymentType">Payment Type</InputLabel>
                    <Select
                      native
                      autoWidth={false}
                      style={{ width: 120 }}
                      value={this.props.searchdata.paymentType}
                      onChange={this.handleChange}
                      inputProps={{
                        name: "paymentType",
                        id: "paymentType"
                      }}
                    >
                      <option value="" />
                      {paymentTypes.map(option => (
                        <option key={option.value} value={option.value}>
                          {option.label}
                        </option>
                      ))}
                    </Select>
                  </FormControl>
                </td>
                <td>&nbsp;</td>
                <td className="VerticalAlignBottom">
                  <FormControl style={{ flexDirection: "row" }}>
                    <Typography variant="caption">
                      <br />
                      <DatePickerInput
                        id="effDate"
                        name="effDate"
                        placeholderText="Effective Date"
                        selected={formatStringToDate(
                          this.props.searchdata.effDate
                        )}
                        onChange={dateValue => {
                          this.handleDateChange("effDate", dateValue);
                        }}
                      />
                    </Typography>
                  </FormControl>
                </td>
              </tr>
            </tbody>
          </table>
          <table border="0px" cellPadding="0" cellSpacing="0">
            <tbody>
              <tr>
                <td>&nbsp;</td>
                <td className="VerticalAlignBottom">
                  <FormControl style={{ flexDirection: "row" }}>
                    <Typography variant="caption">
                      <br />
                      <DatePickerInput
                        id="fromCycleDate"
                        name="fromCycleDate"
                        onChangeRaw={this.handleDateChangeRaw}
                        placeholderText="From Cycle Date"
                        selected={formatStringToDate(
                          this.props.searchdata.fromCycleDate
                        )}
                        onChange={dateValue => {
                          this.handleDateChange("fromCycleDate", dateValue);
                        }}
                      />
                    </Typography>
                  </FormControl>
                </td>
                <td>&nbsp;</td>
                <td className="VerticalAlignBottom">
                  <FormControl style={{ flexDirection: "row" }}>
                    <Typography variant="caption">
                      <br />
                      <DatePickerInput
                        id="toCycleDate"
                        name="toCycleDate"
                        onChangeRaw={this.handleDateChangeRaw}
                        placeholderText="To Cycle Date"
                        selected={formatStringToDate(
                          this.props.searchdata.toCycleDate
                        )}
                        minDate={
                          this.props.searchdata.fromCycleDate != null
                            ? formatStringToDate(
                                this.props.searchdata.fromCycleDate
                              )
                            : ""
                        }
                        maxDate={
                          this.props.searchdata.fromCycleDate != null
                            ? addDays(this.props.searchdata.fromCycleDate, 30)
                            : ""
                        }
                        onChange={dateValue => {
                          this.handleDateChange("toCycleDate", dateValue);
                        }}
                      />
                    </Typography>
                  </FormControl>
                </td>
                <td>&nbsp;</td>
                <td className="VerticalAlignBottom">
                  <FormControl>
                    <TextField
                      id="transCode"
                      name="transCode"
                      label="Transaction Code"
                      type="search"
                      className={classes.textField}
                      onChange={this.handleChange}
                      value={this.props.searchdata.transCode}
                      margin="none"
                    />
                  </FormControl>
                </td>
                <td>&nbsp;</td>
                <td className="VerticalAlignBottom">
                  <FormControl>
                    <TextField
                      id="reasonCode"
                      name="reasonCode"
                      label="Reason Code"
                      type="search"
                      className={classes.textField}
                      onChange={this.handleChange}
                      value={this.props.searchdata.reasonCode}
                      margin="none"
                    />
                  </FormControl>
                </td>
              </tr>
            </tbody>
          </table>
          <table border="0px" cellPadding="0" cellSpacing="0">
            <tbody>
              <tr>
                <td>&nbsp;</td>
                <td className="VerticalAlignBottom">
                  <FormControl>
                    <InputLabel htmlFor="type">Type</InputLabel>
                    <Select
                      native
                      autoWidth={false}
                      style={{ width: 200 }}
                      value={this.props.searchdata.type}
                      onChange={this.handleChange}
                      inputProps={{
                        name: "type",
                        id: "type"
                      }}
                    >
                      <option value="" />
                      {types.map(option => (
                        <option key={option.value} value={option.value}>
                          {option.label}
                        </option>
                      ))}
                    </Select>
                  </FormControl>
                </td>
                <td>&nbsp;</td>
                <td className="VerticalAlignBottom">
                  <FormControl>
                    <InputLabel htmlFor="status">Status</InputLabel>
                    <Select
                      native
                      autoWidth={false}
                      style={{ width: 120 }}
                      value={this.props.searchdata.status}
                      onChange={this.handleChange}
                      inputProps={{
                        name: "status",
                        id: "status"
                      }}
                    >
                      <option value="" />
                      {statusTypes.map(option => (
                        <option key={option.value} value={option.value}>
                          {option.label}
                        </option>
                      ))}
                    </Select>
                  </FormControl>
                </td>
              </tr>
            </tbody>
          </table>
          <div className="LeftActionBarStyle">
            <Button
              variant="contained"
              color="primary"
              className={classes.button}
              onClick={this.handleSubmit}
            >
              Search
            </Button>
            &nbsp;
            <Button
              variant="contained"
              color="primary"
              className={classes.button}
              onClick={this.handleClear}
            >
              Clear
            </Button>
            &nbsp;
            <Button
              variant="contained"
              color="primary"
              className={classes.button}
              onClick={this.handleBulkReprocess}
            >
              Bulk Reprocess
            </Button>
            <span className="RightActionBarStyle">
              <ExcelDownload
                enabled="true"
                onClick={this.handleExcelDownload}
              />
            </span>
            <span className="RightActionBarStyle">
              <Refresh onClick={this.handleRefresh} />
            </span>
          </div>
          <ReactTable
            ref={reactEFTReturnsTable =>
              (this.selectTable = reactEFTReturnsTable)
            }
            columns={[
              {
                Header: "Policy Number",
                id: "polCont",
                accessor: d => d.polCont,
                headerClassName: "BoldText ColoredText"
              },
              {
                Header: "Control Number",
                accessor: "controlNum",
                headerClassName: "BoldText ColoredText"
              },
              {
                Header: "Amount",
                accessor: "premiumAmt",
                headerClassName: "BoldText ColoredText"
              },
              {
                Header: "EFT Type",
                accessor: "eftType",
                headerClassName: "BoldText ColoredText"
              },
              {
                Header: "Effective Date",
                accessor: "effDate",
                headerClassName: "BoldText ColoredText"
              },
              {
                Header: "Cycle Date",
                accessor: "cycleDate",
                headerClassName: "BoldText ColoredText"
              },
              {
                Header: "Transaction Code",
                accessor: "transCode",
                headerClassName: "BoldText ColoredText"
              },
              {
                Header: "Reason Code",
                accessor: "reasonCode",
                headerClassName: "BoldText ColoredText"
              },
              {
                Header: "Type",
                accessor: "type",
                headerClassName: "BoldText ColoredText"
              },
              {
                Header: "Reverse Text",
                accessor: "reverseTxt",
                sortable: false,
                headerClassName: "BoldText ColoredText"
              },
              {
                Header: "Status",
                id: "status",
                accessor: "status",
                sortable: false,
                headerClassName: "BoldText ColoredText",
                Cell: ({ row, original }) => {
                  return (
                    <span>
                      <span
                        style={{
                          color:
                            row.status === "completed"
                              ? "#ff2e00"
                              : row.status === "failed"
                                ? "#ffbf00"
                                : "#57d500",
                          transition: "all .3s ease"
                        }}
                      >
                        {" "}
                        <ProcessFlowDialog
                          title="Process Flow"
                          status={row.status}
                          processType="eftReturns"
                          eftType={original.type}
                          isReprocess={original.isReprocess}
                          stepNumber={original.stepNumber}
                          selectedId={original.transRefGUID}
                        />
                      </span>
                    </span>
                  );
                }
              },
              {
                Header: "Actions",
                id: "actions",
                accessor: "actions",
                width: 110,
                sortable: false,
                headerClassName: "BoldText ColoredText",
                className: "Centered",
                Cell: ({ original }) => {
                  return (
                    <span style={{ textAlign: "center" }}>
                      <EFTReturnsActionDialog
                        billId={original.billId}
                        status={original.status}
                        type={original.type}
                        transRefGUID={original.transRefGUID}
                        policyCont={original.polCont}
                        showLoading={() => this.setLoading(true)}
                        hideLoading={() => this.setLoading(false)}
                      />
                    </span>
                  );
                }
              }
            ]}
            defaultSorted={[
              {
                id: "polCont",
                desc: true
              }
            ]}
            manual // Forces table not to paginate or sort automatically, so we can handle it server-side
            data={data}
            pages={pages} // Display the total number of pages
            loading={loading} // Display the loading overlay when we need it
            onFetchData={this.fetchData} // Request new data when things change
            defaultPageSize={10}
            className="-striped -highlight"
          >
            {(state, makeTable) => {
              return (
                <RecordCount
                  state={state}
                  makeTable={makeTable}
                  totalRecords={this.state.totalRecords}
                />
              );
            }}
          </ReactTable>
          <br />
          {/* Bulk ReProcess Dialog */}
          <BulkReProcessEFTReturnsDialog
            open={this.state.openBulkReprocessDialog}
            handleClose={this.handleClose}
            title="Bulk Reprocess"
            showSuccessNotification={() => this.showNotification("successElt")}
            showErrorNotification={() => this.showNotification("errorElt")}
            showInfoNotification={() => this.showNotification("infoElt")}
          />
          <Snackbar
            place="tr"
            color="success"
            icon={InfoOutlined}
            message="Reprocess successfully initiated!"
            open={this.state.successElt}
            closeNotification={() =>
              this._isMounted ? this.setState({ successElt: false }) : null
            }
            close
          />
          <Snackbar
            place="tr"
            color="danger"
            icon={InfoOutlined}
            message="Reprocess initiation failed!"
            open={this.state.errorElt}
            closeNotification={() =>
              this._isMounted ? this.setState({ errorElt: false }) : null
            }
            close
          />
          <Snackbar
            place="tr"
            color="info"
            icon={InfoOutlined}
            message="No bills found!"
            open={this.state.infoElt}
            closeNotification={() =>
              this._isMounted ? this.setState({ infoElt: false }) : null
            }
            close
          />
          <Snackbar
            place="tr"
            color="success"
            icon={InfoOutlined}
            message="Since the number of records are more than 10K, Excel report will be emailed to your email address."
            open={this.state.excelDownloadElt}
            closeNotification={() =>
              this._isMounted
                ? this.setState({ excelDownloadElt: false })
                : null
            }
            close
          />
        </Overlay>
      </React.Fragment>
    );
  }
}

const mapStateToProps = state => ({
  searchdata: state.sidebar.eftReturnsSearch
});

const mapDispatchToProps = dispatch =>
  bindActionCreators(
    {
      initEFTReturnsSearch,
      getEFTReturnsSearch,
      addEFTReturnsSearch,
      delEFTReturnsSearch
    },
    dispatch
  );

EFTReturnsTable.propTypes = {
  initEFTReturnsSearch: PropTypes.func,
  getEFTReturnsSearch: PropTypes.func,
  addEFTReturnsSearch: PropTypes.func,
  delEFTReturnsSearch: PropTypes.func,
  className: PropTypes.string,
  sidebar: PropTypes.object,
  stats: PropTypes.bool,
  icon: PropTypes.bool,
  searchdata: PropTypes.object
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(requireAuth(EFTReturnsTable, "mainContent"));
