import React from "react";
import { connect } from "react-redux";
import { bindActionCreators } from "redux";

import PropTypes from "prop-types";

// Import React Table
import ReactTable from "react-table";
import { ReactTableDefaults } from "react-table";

import TextField from "@material-ui/core/TextField";
import Button from "@material-ui/core/Button";

//Import actions
import {
  initBankHeaderInquiry,
  getBankHeaderInquiry,
  addBankHeaderInquiry,
  delBankHeaderInquiry
} from "actions/EFTBankHeaderInquiryAction.jsx";

import "react-table/react-table.css";
import "assets/css/bits-styles-override.css";

import APIURIs from "properties/APIURIs.jsx";
import LoadingSpinner from "components/CustomWidgets/LoadingSpinner.jsx";
import Refresh from "components/CustomWidgets/Refresh.jsx";
import { postTableDataWithSearchParams } from "utils/CommonFunctions.jsx";
import requireAuth from "utils/AuthenticatedComponent.jsx";
import RecordCount from "components/CustomWidgets/RecordCount.jsx";

//Set default values of React Table
Object.assign(ReactTableDefaults, {
  multiSort: false,
  LoadingComponent: LoadingSpinner
});

const classes = theme => ({
  formControl: {
    margin: theme.spacing.unit,
    minWidth: 120,
    display: "flex",
    wrap: "nowrap"
  },
  textField: {
    marginLeft: theme.spacing.unit,
    marginRight: theme.spacing.unit,
    width: 200
  },
  button: {
    margin: theme.spacing.unit
  }
});

function getBankHeaderInquiryData(
  pageSize,
  page,
  sorted,
  filtered,
  eftBankHeaderInquiry
) {
  return postTableDataWithSearchParams(
    APIURIs.EFT_BANKHDR_INQUIRY_URI,
    APIURIs.EFT_BANKHDR_INQUIRY_APIKEY,
    pageSize,
    page,
    sorted,
    filtered,
    eftBankHeaderInquiry
  );
}

class EFTBankHeaderInquiryTable extends React.Component {
  _isMounted = false;
  constructor(props) {
    super(props);

    this.state = {
      data: [],
      pages: null,
      loading: true,
      editMode: false,
      selectedGuid: "",
      transitNum: "",
      bankName: "",
      totalRecords: null
    };
    this.props.initBankHeaderInquiry();
  }

  componentDidMount() {
    this._isMounted = true;
  }

  componentWillUnmount() {
    this._isMounted = false;
    this.props.initBankHeaderInquiry();
  }

  showNotification(place) {
    var x = [];
    x[place] = true;
    if (this._isMounted) {
      this.setState(x);
    }
    this.alertTimeout = setTimeout(
      function() {
        x[place] = false;
        if (this._isMounted) {
          this.setState(x);
        }
      }.bind(this),
      6000
    );
  }

  handleRefresh = event => {
    this.handleSubmit(event);
  };

  handleSubmit = event => {
    event.preventDefault();
    this.selectTable.fireFetchData();
  };

  handleClear = () => {
    this.props.delBankHeaderInquiry();
  };

  handleChange = event => {
    let accountInquiryTmp = Object.assign({}, this.props.eftBankHeaderInquiry);
    accountInquiryTmp[event.target.name] = event.target.value;
    this.props.addBankHeaderInquiry(accountInquiryTmp);
  };

  handleTextChange = name => event => {
    if (this._isMounted) {
      this.setState({ [name]: event.target.value });
    }
  };

  fetchData = state => {
    if (this._isMounted) {
      this.setState({ loading: true });
    }
    getBankHeaderInquiryData(
      state.pageSize,
      state.page,
      state.sorted,
      state.filtered,
      this.props.eftBankHeaderInquiry
    )
      .then(res => {
        if (this._isMounted) {
          this.setState({
            data: res.rows,
            pages: res.pages == undefined ? 0 : res.pages,
            totalRecords: res.totalRecords,
            loading: false
          });
        }
      })
      .catch(error => {
        console.warn(error);
        if (this._isMounted) {
          this.setState({ loading: false });
        }
      });
  };

  render() {
    const { data, pages, loading } = this.state;
    return (
      <React.Fragment>
        <p />
        <table border="0px" cellPadding="0" cellSpacing="0">
          <tbody>
            <tr>
              <td className="VerticalAlignBottom">
                <TextField
                  id="transitNum"
                  name="transitNum"
                  label="Transit Number"
                  type="search"
                  className={classes.textField}
                  onChange={this.handleChange}
                  value={this.props.eftBankHeaderInquiry.transitNum}
                  margin="none"
                />
              </td>
              <td>&nbsp;</td>
              <td className="VerticalAlignBottom">
                <TextField
                  id="bankName"
                  name="bankName"
                  label="Bank Name"
                  type="search"
                  className={classes.textField}
                  onChange={this.handleChange}
                  value={this.props.eftBankHeaderInquiry.bankName}
                  margin="none"
                />
              </td>
            </tr>
          </tbody>
        </table>
        <div className="LeftActionBarStyle">
          <Button
            variant="contained"
            color="primary"
            className={classes.button}
            onClick={this.handleSubmit}
          >
            Search
          </Button>
          &nbsp;
          <Button
            variant="contained"
            color="primary"
            className={classes.button}
            onClick={this.handleClear}
          >
            Clear
          </Button>
          &nbsp;
          <span className="RightActionBarStyle">
            <Refresh onClick={this.handleRefresh} />
          </span>
        </div>
        <ReactTable
          ref={reactEFTBankHeaderInquiry =>
            (this.selectTable = reactEFTBankHeaderInquiry)
          }
          columns={[
            {
              Header: "Transit Number",
              accessor: "transitNum",
              headerClassName: "BoldText ColoredText"
            },
            {
              Header: "Bank Name",
              accessor: "bankName",
              headerClassName: "BoldText ColoredText"
            }
          ]}
          defaultSorted={[
            {
              id: "bankName",
              desc: false
            }
          ]}
          manual // Forces table not to paginate or sort automatically, so we can handle it server-side
          data={data}
          pages={pages} // Display the total number of pages
          loading={loading} // Display the loading overlay when we need it
          onFetchData={this.fetchData} // Request new data when things change
          defaultPageSize={10}
          className="-striped -highlight"
        >
          {(state, makeTable) => {
            return (
              <RecordCount
                state={state}
                makeTable={makeTable}
                totalRecords={this.state.totalRecords}
              />
            );
          }}
        </ReactTable>
      </React.Fragment>
    );
  }
}

const mapStateToProps = state => ({
  eftBankHeaderInquiry: state.sidebar.eftBankHeaderInquiry
});

const mapDispatchToProps = dispatch =>
  bindActionCreators(
    {
      initBankHeaderInquiry,
      getBankHeaderInquiry,
      addBankHeaderInquiry,
      delBankHeaderInquiry
    },
    dispatch
  );

EFTBankHeaderInquiryTable.propTypes = {
  initBankHeaderInquiry: PropTypes.func,
  getBankHeaderInquiry: PropTypes.func,
  addBankHeaderInquiry: PropTypes.func,
  delBankHeaderInquiry: PropTypes.func,
  className: PropTypes.string,
  sidebar: PropTypes.object,
  stats: PropTypes.bool,
  icon: PropTypes.bool,
  eftBankHeaderInquiry: PropTypes.object
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(requireAuth(EFTBankHeaderInquiryTable, "mainContent"));
