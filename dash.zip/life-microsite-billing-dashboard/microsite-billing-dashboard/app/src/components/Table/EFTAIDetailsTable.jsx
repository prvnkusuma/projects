import React from "react";
import PropTypes from "prop-types";

// Import React Table
import ReactTable from "react-table";
import { ReactTableDefaults } from "react-table";

import "react-table/react-table.css";
import "assets/css/bits-styles-override.css";

import APIURIs from "properties/APIURIs.jsx";
import ExcelDownload from "components/CustomWidgets/ExcelDownload.jsx";
import LoadingSpinner from "components/CustomWidgets/LoadingSpinner.jsx";
import Overlay from "components/CustomWidgets/Overlay.jsx";
import { postTableData, commonExcelDownload } from "utils/CommonFunctions.jsx";
import requireAuth from "utils/AuthenticatedComponent.jsx";
import RecordCount from "components/CustomWidgets/RecordCount.jsx";

//Set default values of React Table
Object.assign(ReactTableDefaults, {
  multiSort: false,
  LoadingComponent: LoadingSpinner
});

function getAccountInquiryDetailsData(
  pageSize,
  page,
  sorted,
  filtered,
  controlNum
) {
  return postTableData(
    APIURIs.EFT_ACCOUNT_INQ_DETAILS_URI,
    APIURIs.EFT_ACCOUNT_INQ_DETAILS_APIKEY,
    pageSize,
    page,
    sorted,
    filtered,
    { controlNum: controlNum }
  );
}

class EFTAIDetailsTable extends React.Component {
  _isMounted = false;
  constructor(props) {
    super(props);

    this.state = {
      data: [],
      payorName: "",
      totalDraftAmt: "",
      pages: null,
      loading: true,
      downloadExcelLoading: false,
      totalRecords: null
    };
  }

  componentDidMount() {
    this._isMounted = true;
  }

  componentWillUnmount() {
    this._isMounted = false;
  }

  handleExcelDownload = () => {
    commonExcelDownload(
      this,
      APIURIs.EFT_ACCOUNT_INQ_DET_XLSDATA_URI,
      APIURIs.EFT_ACCOUNT_INQ_DET_XLSDATA_APIKEY,
      { controlNum: this.props.controlNum },
      "EFTAccountInquiryRecords.xlsx"
    ).then(response => {
      if (response.status == 200 && response.message == "email") {
        this.props.showNotification("excelDownloadElt");
      }
    });
  };

  fetchData = state => {
    getAccountInquiryDetailsData(
      state.pageSize,
      state.page,
      state.sorted,
      state.filtered,
      this.props.controlNum
    )
      .then(res => {
        if (this._isMounted) {
          this.setState({
            data: res.rows,
            payorName: res.payorName,
            totalDraftAmt: res.totalDraftAmt,
            pages: res.pages == undefined ? 0 : res.pages,
            totalRecords: res.totalRecords,
            loading: false
          });
        }
      })
      .catch(error => {
        console.warn(error);
        if (this._isMounted) {
          this.setState({ loading: false });
        }
      });
  };

  render() {
    const { data, pages, loading } = this.state;
    return (
      <React.Fragment>
        <span>
          <ExcelDownload enabled="true" onClick={this.handleExcelDownload} />
        </span>
        <p />
        <Overlay active={this.state.downloadExcelLoading} marginTop="150px">
          <ReactTable
            ref={reactAccInqDetTable =>
              (this.selectTable = reactAccInqDetTable)
            }
            columns={[
              {
                Header: "Co.ID",
                accessor: "companyCode",
                headerClassName: "BoldText ColoredText"
              },
              {
                Header: "Policy Number",
                accessor: "polCont",
                headerClassName: "BoldText ColoredText"
              },
              {
                Header: "Account Type",
                accessor: "bankAcctType",
                headerClassName: "BoldText ColoredText",
                sortable: false
              },
              {
                Header: "Transit Number",
                accessor: "transitNum",
                headerClassName: "BoldText ColoredText",
                sortable: false
              },
              {
                Header: "Bank Account No",
                accessor: "bankAcctNum",
                headerClassName: "BoldText ColoredText",
                sortable: false
              },
              {
                Header: "Withdraw Day",
                accessor: "withdrawDay",
                headerClassName: "BoldText ColoredText",
                sortable: false
              },
              {
                Header: "Premium Amount",
                accessor: "premiumAmt",
                headerClassName: "BoldText ColoredText"
              },
              {
                Header: "Loan Amount Outstanding",
                accessor: "loanAmt",
                headerClassName: "BoldText ColoredText"
              }
            ]}
            defaultSorted={[
              {
                id: "polCont",
                desc: false
              }
            ]}
            manual // Forces table not to paginate or sort automatically, so we can handle it server-side
            data={data}
            pages={pages} // Display the total number of pages
            loading={loading} // Display the loading overlay when we need it
            onFetchData={this.fetchData} // Request new data when things change
            defaultPageSize={5}
            className="-striped -highlight"
          >
            {(state, makeTable) => {
              return (
                <RecordCount
                  state={state}
                  makeTable={makeTable}
                  totalRecords={this.state.totalRecords}
                />
              );
            }}
          </ReactTable>
          <div className="LeftActionBarStyle">
            <span className="BoldText ColoredText">Signature</span>
            <span style={{ fontWeight: "bold", fontSize: 14 }}>
              &nbsp;&nbsp;
              {this.state.payorName}
            </span>
            &nbsp;
            <div className="RightActionBarStyle">
              <span className="BoldText ColoredText">Total Draft Amount</span>
              <span style={{ fontWeight: "bold", fontSize: 14 }}>
                &nbsp;&nbsp;
                {this.state.totalDraftAmt}
              </span>
            </div>
          </div>
        </Overlay>
      </React.Fragment>
    );
  }
}

EFTAIDetailsTable.propTypes = {
  dialogdata: PropTypes.object,
  controlNum: PropTypes.string,
  showNotification: PropTypes.func
};

export default requireAuth(EFTAIDetailsTable, "mainContent");
