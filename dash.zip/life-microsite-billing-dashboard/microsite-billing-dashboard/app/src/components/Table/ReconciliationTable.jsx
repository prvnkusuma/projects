import React from "react";
import { connect } from "react-redux";
import { bindActionCreators } from "redux";
import { withStyles } from "@material-ui/core/styles";

import PropTypes from "prop-types";

// Import React Table
import ReactTable from "react-table";
import { ReactTableDefaults } from "react-table";

import FormControl from "@material-ui/core/FormControl";
import Button from "@material-ui/core/Button";
import Typography from "@material-ui/core/Typography";
import Paper from "@material-ui/core/Paper";
import Tabs from "@material-ui/core/Tabs";
import Tab from "@material-ui/core/Tab";
import { grey } from "@material-ui/core/colors";

// Import actions
import {
  initReconciliationSearch,
  getReconciliationSearch,
  addReconciliationSearch,
  delReconciliationSearch
} from "actions/ReconciliationSearchAction.jsx";

import "react-table/react-table.css";
import "assets/css/bits-styles-override.css";

import DatePickerInput from "components/DatePickerInput/DatePickerInput.jsx";
import APIURIs from "properties/APIURIs.jsx";
import LoadingSpinner from "components/CustomWidgets/LoadingSpinner.jsx";
import Refresh from "components/CustomWidgets/Refresh.jsx";
import RecordCount from "components/CustomWidgets/RecordCount.jsx";
import {
  formatDate,
  formatStringToDate,
  getTableData
} from "utils/CommonFunctions.jsx";
import EFTReconTable from "components/Table/EFTReconTable.jsx";
import requireAuth from "utils/AuthenticatedComponent.jsx";

//Set default values of React Table
Object.assign(ReactTableDefaults, {
  multiSort: false,
  LoadingComponent: LoadingSpinner
});

const classes = theme => ({
  root: {
    flexGrow: 1,
    backgroundColor: theme.palette.background.paper
  },
  indicator: {
    backgroundColor: "#009688"
  },
  button: {
    margin: 0
  }
});

const paperStyle = {
  width: 645
};

function TabContainer(props) {
  return <div style={{ padding: 0 }}>{props.children}</div>;
}

TabContainer.propTypes = {
  children: PropTypes.node.isRequired
};

function getReconciliationData(
  pageSize,
  page,
  sorted,
  filtered,
  reconciliationSearch,
  type
) {
  let reconTypeCode = 0;
  if (type === "Bill") {
    reconTypeCode = 1801;
  } else if (type === "Remit") {
    reconTypeCode = 508;
  } else {
    reconTypeCode = 118;
  }

  return getTableData(
    APIURIs.HIST_BILLRECON_DATA_URI,
    APIURIs.HIST_BILLRECON_DATA_APIKEY,
    pageSize,
    page,
    sorted,
    filtered,
    { ...reconciliationSearch, reconType: reconTypeCode }
  );
}

class ReconciliationTable extends React.Component {
  _isMounted = false;
  constructor(props) {
    super(props);

    this.state = {
      data: [],
      pages: null,
      loading: true,
      tabIndex: 0,
      totalRecords: null
    };
    this.props.initReconciliationSearch();
  }

  componentDidMount() {
    this._isMounted = true;
  }

  componentWillUnmount() {
    this._isMounted = false;
    this.props.initReconciliationSearch();
  }

  handleTabChange = (event, tabIndex) => {
    if (this._isMounted) {
      this.setState({ tabIndex });
    }
  };

  handleRefresh = (event, type) => {
    this.handleSubmit(event, type);
  };

  handleSubmit = (event, type) => {
    event.preventDefault();
    if (type === "Bill") {
      this.selectBillTable.fireFetchData();
    } else if (type === "Remit") {
      this.selectRemitTable.fireFetchData();
    } else {
      this.selectInvoiceTable.fireFetchData();
    }
  };

  handleClear = () => {
    this.props.delReconciliationSearch();
  };

  handleChange = event => {
    let reconciliationSearchTmp = Object.assign({}, this.props.dialogdata);
    reconciliationSearchTmp[event.target.name] = event.target.value;
    this.props.addReconciliationSearch(reconciliationSearchTmp);
  };

  handleDateChange = (dateName, dateValue) => {
    let reconciliationSearchTmp = Object.assign({}, this.props.dialogdata);
    reconciliationSearchTmp[dateName] = formatDate(dateValue);
    this.props.addReconciliationSearch(reconciliationSearchTmp);
  };

  addDateFieldsToStore = () => {
    if (this._isMounted) {
      this.setState({ loading: true });
    }

    let reconciliationSearchTmp = Object.assign({}, this.props.dialogdata);
    reconciliationSearchTmp.cycleDate = formatDate(
      this.props.dialogdata.cycleDate
    );

    this.props.addReconciliationSearch(reconciliationSearchTmp);
  };

  fetchSearchData = type => {
    this.addDateFieldsToStore();
    getReconciliationData(10, 0, true, false, this.props.dialogdata, type)
      .then(res => {
        if (this._isMounted) {
          this.setState({
            data: res.historicCounts,
            pages: res.pages == undefined ? 0 : res.pages,
            totalRecords: res.totalRecords,
            loading: false
          });
        }
      })
      .catch(error => {
        console.warn(error);
        if (this._isMounted) {
          this.setState({ loading: false });
        }
      });
  };

  fetchData = (state, type) => {
    this.addDateFieldsToStore();
    getReconciliationData(
      state.pageSize,
      state.page,
      state.sorted,
      state.filtered,
      this.props.dialogdata,
      type
    )
      .then(res => {
        if (this._isMounted) {
          this.setState({
            data: res.historicCounts,
            pages: res.pages == undefined ? 0 : res.pages,
            totalRecords: res.totalRecords,
            loading: false
          });
        }
      })
      .catch(error => {
        console.warn(error);
        if (this._isMounted) {
          this.setState({ loading: false });
        }
      });
  };

  render() {
    const { classes } = this.props;
    const { data, pages, loading, tabIndex } = this.state;
    var styles = {
      default_tab: {
        backgroundColor: grey[50],
        fontWeight: 500
      }
    };
    styles.tab = [];
    for (var i = 0; i < 4; i++) {
      styles.tab[i] = styles.default_tab;
    }

    return (
      <React.Fragment>
        <p />
        <div className={classes.root}>
          <Paper style={paperStyle}>
            <Tabs
              value={tabIndex}
              indicatorColor="primary"
              textColor="primary"
              onChange={this.handleTabChange}
              classes={{
                indicator: classes.indicator
              }}
              style={styles.tab[0]}
            >
              <Tab label="Bill" />
              <Tab label="Remittance" />
              <Tab label="Invoice" />
              <Tab label="EFT" />
            </Tabs>
          </Paper>
          {tabIndex === 0 && (
            <div>
              <table border="0px" cellPadding="0" cellSpacing="0">
                <tbody>
                  <tr>
                    <td className="VerticalAlignBottom">
                      <FormControl style={{ flexDirection: "row" }}>
                        <Typography variant="caption">
                          <br />
                          <DatePickerInput
                            id="cycleDate"
                            name="cycleDate"
                            placeholderText="Cycle Date"
                            selected={formatStringToDate(
                              this.props.dialogdata.cycleDate
                            )}
                            onChange={dateValue => {
                              this.handleDateChange("cycleDate", dateValue);
                            }}
                          />
                        </Typography>
                      </FormControl>
                    </td>
                  </tr>
                </tbody>
              </table>
              <div className="LeftActionBarStyle">
                <Button
                  variant="contained"
                  color="primary"
                  className={classes.button}
                  onClick={event => this.handleSubmit(event, "Bill")}
                >
                  Search
                </Button>
                &nbsp;
                <Button
                  variant="contained"
                  color="primary"
                  className={classes.button}
                  onClick={() => this.handleClear("Bill")}
                >
                  Clear
                </Button>
                <span className="RightActionBarStyle">
                  <Refresh
                    onClick={event => this.handleRefresh(event, "Bill")}
                  />
                </span>
              </div>
              <TabContainer>
                <ReactTable
                  ref={reactReconBillTable =>
                    (this.selectBillTable = reactReconBillTable)
                  }
                  columns={[
                    {
                      Header: "Cycle Date",
                      accessor: "cycleDate",
                      headerClassName: "BoldText ColoredText"
                    },
                    {
                      Header: "Payment Method",
                      accessor: "paymentMethod",
                      headerClassName: "BoldText ColoredText"
                    },
                    {
                      Header: "ALIP",
                      accessor: "alipCount",
                      headerClassName: "BoldText ColoredText",
                      sortable: false
                    },
                    {
                      Header: "BITS",
                      accessor: "bitsCount",
                      headerClassName: "BoldText ColoredText",
                      sortable: false
                    },
                    {
                      Header: "AIH",
                      accessor: "aihCount",
                      headerClassName: "BoldText ColoredText",
                      sortable: false
                    },
                    {
                      Header: "SAP",
                      accessor: "sapCount",
                      headerClassName: "BoldText ColoredText",
                      sortable: false
                    }
                  ]}
                  defaultSorted={[
                    {
                      id: "cycleDate",
                      desc: true
                    }
                  ]}
                  manual // Forces table not to paginate or sort automatically, so we can handle it server-side
                  data={data}
                  pages={pages} // Display the total number of pages
                  loading={loading} // Display the loading overlay when we need it
                  onFetchData={state => this.fetchData(state, "Bill")} // Request new data when things change
                  defaultPageSize={10}
                  className="-striped -highlight"
                >
                  {(state, makeTable) => {
                    return (
                      <RecordCount
                        state={state}
                        makeTable={makeTable}
                        totalRecords={this.state.totalRecords}
                      />
                    );
                  }}
                </ReactTable>
              </TabContainer>
            </div>
          )}
          {tabIndex === 1 && (
            <div>
              <table border="0px" cellPadding="0" cellSpacing="0">
                <tbody>
                  <tr>
                    <td className="VerticalAlignBottom">
                      <FormControl style={{ flexDirection: "row" }}>
                        <Typography variant="caption">
                          <br />
                          <DatePickerInput
                            id="cycleDate"
                            name="cycleDate"
                            placeholderText="Cycle Date"
                            selected={formatStringToDate(
                              this.props.dialogdata.cycleDate
                            )}
                            onChange={dateValue => {
                              this.handleDateChange("cycleDate", dateValue);
                            }}
                          />
                        </Typography>
                      </FormControl>
                    </td>
                  </tr>
                </tbody>
              </table>
              <div className="LeftActionBarStyle">
                <Button
                  variant="contained"
                  color="primary"
                  className={classes.button}
                  onClick={event => this.handleSubmit(event, "Remit")}
                >
                  Search
                </Button>
                &nbsp;
                <Button
                  variant="contained"
                  color="primary"
                  className={classes.button}
                  onClick={() => this.handleClear("Remit")}
                >
                  Clear
                </Button>
                <span className="RightActionBarStyle">
                  <Refresh
                    onClick={event => this.handleRefresh(event, "Remit")}
                  />
                </span>
              </div>
              <TabContainer>
                <ReactTable
                  ref={reactReconRemitTable =>
                    (this.selectRemitTable = reactReconRemitTable)
                  }
                  columns={[
                    {
                      Header: "Cycle Date",
                      accessor: "cycleDate",
                      headerClassName: "BoldText ColoredText"
                    },
                    {
                      Header: "Payment Method",
                      accessor: "paymentMethod",
                      headerClassName: "BoldText ColoredText"
                    },
                    {
                      Header: "SAP",
                      accessor: "sapCount",
                      headerClassName: "BoldText ColoredText",
                      sortable: false
                    },
                    {
                      Header: "AIH",
                      accessor: "aihCount",
                      headerClassName: "BoldText ColoredText",
                      sortable: false
                    },
                    {
                      Header: "BITS",
                      accessor: "bitsCount",
                      headerClassName: "BoldText ColoredText",
                      sortable: false
                    },
                    {
                      Header: "ALIP",
                      accessor: "alipCount",
                      headerClassName: "BoldText ColoredText",
                      sortable: false
                    }
                  ]}
                  defaultSorted={[
                    {
                      id: "cycleDate",
                      desc: true
                    }
                  ]}
                  manual // Forces table not to paginate or sort automatically, so we can handle it server-side
                  data={data}
                  pages={pages} // Display the total number of pages
                  loading={loading} // Display the loading overlay when we need it
                  onFetchData={state => this.fetchData(state, "Remit")} // Request new data when things change
                  defaultPageSize={10}
                  className="-striped -highlight"
                >
                  {(state, makeTable) => {
                    return (
                      <RecordCount
                        state={state}
                        makeTable={makeTable}
                        totalRecords={this.state.totalRecords}
                      />
                    );
                  }}
                </ReactTable>
              </TabContainer>
            </div>
          )}
          {tabIndex === 2 && (
            <div>
              <table border="0px" cellPadding="0" cellSpacing="0">
                <tbody>
                  <tr>
                    <td className="VerticalAlignBottom">
                      <FormControl style={{ flexDirection: "row" }}>
                        <Typography variant="caption">
                          <br />
                          <DatePickerInput
                            id="cycleDate"
                            name="cycleDate"
                            placeholderText="Cycle Date"
                            selected={formatStringToDate(
                              this.props.dialogdata.cycleDate
                            )}
                            onChange={dateValue => {
                              this.handleDateChange("cycleDate", dateValue);
                            }}
                          />
                        </Typography>
                      </FormControl>
                    </td>
                  </tr>
                </tbody>
              </table>
              <div className="LeftActionBarStyle">
                <Button
                  variant="contained"
                  color="primary"
                  className={classes.button}
                  onClick={event => this.handleSubmit(event, "Invoice")}
                >
                  Search
                </Button>
                &nbsp;
                <Button
                  variant="contained"
                  color="primary"
                  className={classes.button}
                  onClick={() => this.handleClear("Invoice")}
                >
                  Clear
                </Button>
                <span className="RightActionBarStyle">
                  <Refresh
                    onClick={event => this.handleRefresh(event, "Invoice")}
                  />
                </span>
              </div>
              <TabContainer>
                <ReactTable
                  ref={reactReconInvoiceTable =>
                    (this.selectInvoiceTable = reactReconInvoiceTable)
                  }
                  columns={[
                    {
                      Header: "Cycle Date",
                      accessor: "cycleDate",
                      headerClassName: "BoldText ColoredText"
                    },
                    {
                      Header: "Payment Method",
                      accessor: "paymentMethod",
                      headerClassName: "BoldText ColoredText"
                    },
                    {
                      Header: "SAP",
                      accessor: "sapCount",
                      headerClassName: "BoldText ColoredText",
                      sortable: false
                    },
                    {
                      Header: "AIH",
                      accessor: "aihCount",
                      headerClassName: "BoldText ColoredText",
                      sortable: false
                    },
                    {
                      Header: "BITS",
                      accessor: "bitsCount",
                      headerClassName: "BoldText ColoredText",
                      sortable: false
                    },
                    {
                      Header: "XPRESSION",
                      accessor: "alipCount",
                      headerClassName: "BoldText ColoredText",
                      sortable: false
                    }
                  ]}
                  defaultSorted={[
                    {
                      id: "cycleDate",
                      desc: true
                    }
                  ]}
                  manual // Forces table not to paginate or sort automatically, so we can handle it server-side
                  data={data}
                  pages={pages} // Display the total number of pages
                  loading={loading} // Display the loading overlay when we need it
                  onFetchData={state => this.fetchData(state, "Invoice")} // Request new data when things change
                  defaultPageSize={10}
                  className="-striped -highlight"
                >
                  {(state, makeTable) => {
                    return (
                      <RecordCount
                        state={state}
                        makeTable={makeTable}
                        totalRecords={this.state.totalRecords}
                      />
                    );
                  }}
                </ReactTable>
              </TabContainer>
            </div>
          )}
          {tabIndex === 3 && <EFTReconTable />}
        </div>
        <br />
      </React.Fragment>
    );
  }
}

const mapStateToProps = state => ({
  dialogdata: state.sidebar.reconciliationSearch
});

const mapDispatchToProps = dispatch =>
  bindActionCreators(
    {
      initReconciliationSearch,
      getReconciliationSearch,
      addReconciliationSearch,
      delReconciliationSearch
    },
    dispatch
  );

ReconciliationTable.propTypes = {
  initReconciliationSearch: PropTypes.func,
  addReconciliationSearch: PropTypes.func,
  getReconciliationSearch: PropTypes.func,
  delReconciliationSearch: PropTypes.func,
  className: PropTypes.string,
  sidebar: PropTypes.object,
  stats: PropTypes.bool,
  icon: PropTypes.bool,
  dialogdata: PropTypes.object,
  classes: PropTypes.object.isRequired
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withStyles(classes)(requireAuth(ReconciliationTable, "mainContent")));
