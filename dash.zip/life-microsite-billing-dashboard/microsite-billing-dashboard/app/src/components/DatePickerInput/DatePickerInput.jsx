import React from "react";
import DatePicker from "react-datepicker";

import "react-datepicker/dist/react-datepicker.css";
import "assets/css/bits-react-datepicker-override.css";

const DatePickerInput = props => {
  return (
    <span>
      <span style={{ fontSize: "10px", fontWeight: "400" }}>
        {props.placeholderText}
      </span>
      <DatePicker
        peekNextMonth
        showMonthDropdown
        showYearDropdown
        dateFormat="yyyy-MM-dd"
        dropdownMode="select"
        tabIndex={1}
        className="SingleBorderBox CursorPointer"
        {...props}
      />
    </span>
  );
};

export default DatePickerInput;
