import React from "react";
import PropTypes from "prop-types";
// @material-ui/core components
import withStyles from "@material-ui/core/styles/withStyles";
// @material-ui/icons
import { Person, HelpOutline } from "@material-ui/icons";
//import Dashboard from "@material-ui/icons/Dashboard";

// core components
import Button from "components/CustomButtons/Button.jsx";

import headerLinksStyle from "assets/jss/material-dashboard-react/components/headerLinksStyle.jsx";
import { NavLink } from "react-router-dom";
import Icon from "react-icons-kit";
import { logout } from "react-icons-kit/ikons/logout";
import Tooltip from "@material-ui/core/Tooltip";

import "assets/css/bits-styles-override.css";

var helpWindow = "";

function openHelpWindow() {
  let height = 730;
  let width = 1025;
  let left = window.outerWidth / 2 + window.screenX - width / 2;
  let top = window.outerHeight / 4 + window.screenY - height / 4;
  helpWindow = window.open(
    "docs/BITS-EFT-Guidebook.htm",
    "help",
    "left=" +
      left +
      ",top=" +
      top +
      "height=" +
      height +
      ",width=" +
      width +
      ",toolbar=no,menubar=no,scrollbars=yes,resizable=yes,location=no,directories=no,status=no"
  );
  return helpWindow;
}

class HeaderLinks extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      openHelp: false
    };
  }

  handleLogout = () => {
    localStorage.removeItem("userProf");
    localStorage.removeItem("user");
    if (helpWindow && !helpWindow.closed) {
      helpWindow.close();
    }
  };

  handleHelp = () => {
    openHelpWindow();
  };

  render() {
    const { classes } = this.props;
    return (
      <div>
        <a
          role="button"
          style={{
            cursor: "pointer"
          }}
          className="BlackColorLink"
          id="help"
          name="help"
          rel="noopener noreferrer"
          onClick={this.handleHelp}
        >
          <Tooltip title="Help">
            <Button
              color={window.innerWidth > 959 ? "transparent" : "white"}
              justIcon={window.innerWidth > 959}
              simple={!(window.innerWidth > 959)}
              aria-label="Help"
              className={classes.buttonLink}
            >
              <HelpOutline className={classes.icons} />
            </Button>
          </Tooltip>
        </a>
        <NavLink
          exact
          to="/user"
          className="BlackColorLink"
          activeClassName="BlackColorLink"
        >
          <Tooltip title="User Profile">
            <Button
              color={window.innerWidth > 959 ? "transparent" : "white"}
              justIcon={window.innerWidth > 959}
              simple={!(window.innerWidth > 959)}
              aria-label="Person"
              className={classes.buttonLink}
            >
              <Person className={classes.icons} />
            </Button>
          </Tooltip>
        </NavLink>

        <NavLink
          exact
          to="/login"
          className="BlackColorLink"
          activeClassName="BlackColorLink"
        >
          <Tooltip title="Logout">
            <Button
              color={window.innerWidth > 959 ? "transparent" : "white"}
              justIcon={window.innerWidth > 959}
              simple={!(window.innerWidth > 959)}
              aria-label="Logout"
              className={classes.buttonLink}
              style={{ fontSize: "0px" }}
              onClick={this.handleLogout}
            >
              <Icon
                style={{
                  cursor: "pointer"
                }}
                icon={logout}
              />
            </Button>
          </Tooltip>
        </NavLink>
      </div>
    );
  }
}

HeaderLinks.propTypes = {
  classes: PropTypes.object
};

export default withStyles(headerLinksStyle)(HeaderLinks);
