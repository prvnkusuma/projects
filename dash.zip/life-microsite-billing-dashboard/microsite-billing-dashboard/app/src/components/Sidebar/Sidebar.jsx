import React from "react";
import classNames from "classnames";
import PropTypes from "prop-types";
import { withRouter } from "react-router";
import { NavLink } from "react-router-dom";
// @material-ui/core components
import withStyles from "@material-ui/core/styles/withStyles";
import Drawer from "@material-ui/core/Drawer";
import Hidden from "@material-ui/core/Hidden";
import List from "@material-ui/core/List";
import ListItem from "@material-ui/core/ListItem";
import ListItemIcon from "@material-ui/core/ListItemIcon";
import ListItemText from "@material-ui/core/ListItemText";
import Collapse from "@material-ui/core/Collapse";
import Icon from "@material-ui/core/Icon";
import ExpandLess from "@material-ui/icons/ExpandLess";
import ExpandMore from "@material-ui/icons/ExpandMore";

import "simplebar";
import "simplebar/dist/simplebar.css";

// core components
import HeaderLinks from "components/Header/HeaderLinks.jsx";

import sidebarStyle from "assets/jss/material-dashboard-react/components/sidebarStyle.jsx";
import { isUserRole } from "utils/CommonFunctions.jsx";

import dashboardSubRoutes from "routes/dashboardSubLinks.jsx";
import "assets/css/bits-styles-override.css";

const Sidebar = ({ ...props }) => {
  // verifies if routeName is the one active (in browser input)
  function activeRoute(routeName) {
    return props.location.pathname == routeName ? true : false;
  }
  function handleClick(sidebarName) {
    if (sidebarName == "User") {
      setOpenUser(!openUser);
    }
    if (sidebarName == "Decline") {
      setOpenDecline(!openDecline);
    }
  }
  const { classes, color, logo, image, logoText, routes } = props;
  const [openUser, setOpenUser] = React.useState(false);
  const [openDecline, setOpenDecline] = React.useState(false);
  var links = (
    <List className={classes.list}>
      {routes.map((prop, key) => {
        if (prop.redirect) return null;
        var activePro = " ";
        var listItemClasses;
        listItemClasses = classNames({
          [" " + classes[color]]: activeRoute(prop.path)
        });
        const whiteFontClasses = classNames({
          [" " + classes.whiteFont]: activeRoute(prop.path)
        });
        return (
          <div key={prop.path}>
            {prop.path !== "/login" && prop.path !== "/error" ? (
              // For the primary menu link access that has sub menu add the access
              // level condition before div, currently none exists
              prop.isExpandable === true ? (
                <div>
                  <ListItem
                    button
                    className={classes.itemLink + listItemClasses}
                    onClick={() => handleClick(prop.sidebarName)}
                  >
                    <ListItemIcon
                      className={classes.itemIcon + whiteFontClasses}
                    >
                      {typeof prop.icon === "string" ? (
                        <Icon>{prop.icon}</Icon>
                      ) : (
                        <prop.icon />
                      )}
                    </ListItemIcon>
                    <ListItemText
                      primary={prop.sidebarName}
                      className={classes.itemText + whiteFontClasses}
                      disableTypography={true}
                    />
                    {eval("open" + prop.sidebarName) ? (
                      <ExpandLess
                        className={classes.itemIcon + whiteFontClasses}
                      />
                    ) : (
                      <ExpandMore
                        className={classes.itemIcon + whiteFontClasses}
                      />
                    )}
                  </ListItem>
                  <Collapse in={eval("open" + prop.sidebarName)} timeout="auto">
                    <List component="div" disablePadding>
                      {dashboardSubRoutes.map((subprop, subkey) => {
                        var subListItemClasses;
                        subListItemClasses = classNames({
                          [" " + classes[color]]: activeRoute(subprop.path)
                        });
                        const subListwhiteFontClasses = classNames({
                          [" " + classes.whiteFont]: activeRoute(subprop.path)
                        });
                        return (
                          <div key={subprop.path}>
                            {subprop.path !== "/admin" ||
                            (subprop.path === "/admin" &&
                              // For submenu level access
                              isUserRole("admin")) ? (
                              subprop.parent == prop.sidebarName ? (
                                <ListItem
                                  button
                                  className={
                                    classes.itemLink + subListItemClasses
                                  }
                                  component={NavLink}
                                  to={subprop.path}
                                  key={subkey}
                                >
                                  <ListItemIcon
                                    className={
                                      classes.itemIcon + subListwhiteFontClasses
                                    }
                                  >
                                    {typeof subprop.icon === "string" ? (
                                      <Icon>{subprop.icon}</Icon>
                                    ) : (
                                      <subprop.icon />
                                    )}
                                  </ListItemIcon>
                                  <ListItemText
                                    primary={subprop.sidebarName}
                                    className={
                                      classes.itemText + subListwhiteFontClasses
                                    }
                                    disableTypography={true}
                                  />
                                </ListItem>
                              ) : (
                                ""
                              )
                            ) : (
                              ""
                            )}
                          </div>
                        );
                      })}
                    </List>
                  </Collapse>
                </div>
              ) : (
                <div key={prop.path}>
                  {((isUserRole("support") ||
                    isUserRole("business") ||
                    isUserRole("admin")) &&
                    prop.path !== "/manualBill") || // For the primary menu link access that has no sub menu
                  (prop.path === "/manualBill" && isUserRole("business")) ||
                  ((prop.path === "/phonePayment" ||
                    prop.path === "/invoice" ||
                    prop.path === "/correspondence" ||
                    prop.path === "/decline") &&
                    isUserRole("customercare")) ? (
                    <NavLink
                      to={{
                        pathname: prop.path,
                        origin: "sidebar"
                      }}
                      replace={true}
                      className={activePro + classes.item}
                      activeClassName="active"
                      key={key}
                    >
                      <ListItem
                        button
                        className={classes.itemLink + listItemClasses}
                      >
                        <ListItemIcon
                          className={classes.itemIcon + whiteFontClasses}
                        >
                          {typeof prop.icon === "string" ? (
                            <Icon>{prop.icon}</Icon>
                          ) : (
                            <prop.icon />
                          )}
                        </ListItemIcon>
                        <ListItemText
                          primary={prop.sidebarName}
                          className={classes.itemText + whiteFontClasses}
                          disableTypography={true}
                        />
                      </ListItem>
                    </NavLink>
                  ) : (
                    ""
                  )}
                </div>
              )
            ) : (
              <div style={{ display: "none" }} />
            )}
          </div>
        );
      })}
    </List>
  );
  var brand = (
    <div className={classes.logo}>
      <a
        href="https://www.aig.com"
        target="_blank"
        rel="noopener noreferrer"
        className={classes.logoLink}
      >
        <div className={classes.logoImage}>
          <img src={logo} alt="logo" className={classes.img} />
        </div>
        &nbsp;
        {logoText}
      </a>
    </div>
  );
  return (
    <div>
      <Hidden mdUp implementation="css">
        <Drawer
          variant="temporary"
          anchor="right"
          open={props.open}
          classes={{
            paper: classes.drawerPaper
          }}
          onClose={props.handleDrawerToggle}
          ModalProps={{
            keepMounted: true // Better open performance on mobile.
          }}
        >
          {brand}
          <div
            id="leftPanel"
            name="leftPanel"
            className={classes.sidebarWrapper}
            data-simplebar
          >
            <HeaderLinks />
            {links}
          </div>
          {image !== undefined ? (
            <div
              className={classes.background}
              style={{ backgroundImage: "url(" + image + ")" }}
            />
          ) : null}
        </Drawer>
      </Hidden>
      <Hidden smDown implementation="css">
        <Drawer
          anchor="left"
          variant="permanent"
          open={props.sidebarOpen}
          className={classNames(classes.drawerPaper, {
            [classes.drawerOpen]: !props.sidebarOpen,
            [classes.drawerClose]: props.sidebarOpen
          })}
          classes={{
            paper: classNames({
              [classes.drawerOpen]: !props.sidebarOpen,
              [classes.drawerClose]: props.sidebarOpen
            })
          }}
        >
          {brand}
          <div
            id="leftPanel"
            name="leftPanel"
            className={classes.sidebarWrapper}
            data-simplebar
          >
            {links}
          </div>
          {image !== undefined ? (
            <div
              className={classes.background}
              style={{ backgroundImage: "url(" + image + ")" }}
            />
          ) : null}
        </Drawer>
      </Hidden>
    </div>
  );
};

Sidebar.propTypes = {
  classes: PropTypes.object.isRequired,
  location: PropTypes.object,
  color: PropTypes.string,
  image: PropTypes.string,
  logo: PropTypes.string,
  logoText: PropTypes.string,
  routes: PropTypes.array,
  open: PropTypes.any,
  sidebarOpen: PropTypes.any,
  handleDrawerToggle: PropTypes.func,
  handleSidebarToggle: PropTypes.func
};

export default withRouter(withStyles(sidebarStyle)(Sidebar));
