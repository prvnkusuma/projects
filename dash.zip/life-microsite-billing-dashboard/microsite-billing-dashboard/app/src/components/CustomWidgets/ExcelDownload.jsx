import React from "react";
import Icon from "react-icons-kit";

import Tooltip from "@material-ui/core/Tooltip";
import { fileExcel } from "react-icons-kit/icomoon/fileExcel";

class ExcelDownload extends React.Component {
  constructor(props) {
    super(props);
  }

  render() {
    return (
      <React.Fragment>
        <div style={{ textAlign: "right" }}>
          <Tooltip title="Download as Excel">
            <Icon
              {...this.props}
              style={{
                cursor: "pointer",
                color: this.props.enabled == "true" ? "#08743b" : "#CCCCCC",
                paddingTop: 10
              }}
              size={24}
              icon={fileExcel}
            />
          </Tooltip>
        </div>
      </React.Fragment>
    );
  }
}

export default ExcelDownload;
