import React from "react";
import PropTypes from "prop-types";
import { withStyles } from "@material-ui/core/styles";
import Popper from "@material-ui/core/Popper";
import Typography from "@material-ui/core/Typography";
import Fade from "@material-ui/core/Fade";
import Paper from "@material-ui/core/Paper";

const styles = theme => ({
  paper: {
    backgroundColor: "#ffffff"
  },
  typography: {
    padding: theme.spacing.unit * 2
  }
});

class CustomPopper extends React.Component {
  render() {
    const { classes, open, anchorEl, data, headers } = this.props;
    const id = open ? "simple-popper" : null;
    return (
      <React.Fragment>
        <Popper
          id={id}
          open={open}
          anchorEl={anchorEl}
          transition
          modifiers={{
            flip: {
              enabled: true
            },
            arrow: {
              enabled: true,
              element: id
            }
          }}
        >
          {({ TransitionProps }) => (
            <Fade {...TransitionProps} timeout={150}>
              <Paper className={classes.paper} elevation={1}>
                <Typography className={classes.typography}>
                  {Object.entries(headers).map(([key, value]) => {
                    return (
                      <React.Fragment key={key}>
                        <span style={{ color: "#303f9f" }}>
                          <b>
                            {value.toString()}
                            {key != Object.keys(headers).length - 1
                              ? " : "
                              : ""}
                          </b>
                        </span>
                      </React.Fragment>
                    );
                  })}
                  <br />
                  {Object.entries(data).map(([key, value]) => {
                    return (
                      <React.Fragment key={key}>
                        <span>
                          {key} : {value.toString()}
                        </span>
                        <br />
                      </React.Fragment>
                    );
                  })}
                </Typography>
              </Paper>
            </Fade>
          )}
        </Popper>
      </React.Fragment>
    );
  }
}

CustomPopper.propTypes = {
  classes: PropTypes.object.isRequired,
  open: PropTypes.bool,
  anchorEl: PropTypes.object,
  data: PropTypes.oneOfType([PropTypes.object, PropTypes.string])
};

export default withStyles(styles)(CustomPopper);
