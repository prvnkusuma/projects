import React from "react";
import Icon from "react-icons-kit";
import PropTypes from "prop-types";

import Tooltip from "@material-ui/core/Tooltip";

class CustomIcon extends React.PureComponent {
  constructor(props) {
    super(props);
  }

  render() {
    const { textAlign, toolTip, color, size, icon, onClick } = this.props;
    return (
      <React.Fragment>
        <div style={{ textAlign: textAlign }}>
          {this.props.toolTip != null ? (
            <Tooltip title={toolTip}>
              <Icon
                style={{
                  cursor: "pointer",
                  color: color,
                  paddingTop: 10
                }}
                size={size}
                icon={icon}
                onClick={onClick}
              />
            </Tooltip>
          ) : (
            <Icon
              style={{
                cursor: "pointer",
                color: color,
                paddingTop: 10
              }}
              size={size}
              icon={icon}
              onClick={onClick}
            />
          )}
        </div>
      </React.Fragment>
    );
  }
}

CustomIcon.propTypes = {
  textAlign: PropTypes.string,
  toolTip: PropTypes.string,
  color: PropTypes.string,
  size: PropTypes.string,
  icon: PropTypes.object,
  onClick: PropTypes.func
};

export default CustomIcon;
