import React from "react";
import classNames from "classnames";
import PropTypes from "prop-types";

import { withStyles } from "@material-ui/core/styles";

import "font-awesome/css/font-awesome.min.css";
import "assets/css/bits-styles-override.css";

const styles = theme => ({
  progress: {
    margin: theme.spacing.unit * 2
  }
});

const LoadingSpinner = props => (
  <div className={classNames("-loading", { "active -active": props.loading })}>
    <div id="spinner" style={{ top: "50%", left: "50%" }}>
      <i
        className="fa fa-spinner fa-pulse fa-3x fa-fw"
        style={{ fontSize: 36, color: "#00acc1" }}
      />
    </div>
  </div>
);

LoadingSpinner.propTypes = {
  loading: PropTypes.bool
};

export default withStyles(styles)(LoadingSpinner);
