import React from "react";
import PropTypes from "prop-types";
//import { Link } from "react-router-dom";

import { withStyles } from "@material-ui/core/styles";
import Paper from "@material-ui/core/Paper";
import CustomPopper from "components/CustomWidgets/CustomPopper.jsx";
import "assets/css/bits-styles-override.css";

const classes = theme => ({
  root: {
    ...theme.mixins.gutters(),
    paddingTop: theme.spacing.unit * 1,
    paddingBottom: theme.spacing.unit * 2,
    paddingLeft: 0,
    paddingRight: 0,
    color: "#FFFFFF",
    boxShadow: "none",
    borderRadius: ".25rem",
    minHeight: "70px",
    minWidth: "120px",
    flexShrink: 0,
    border: 1,
    borderStyle: "solid",
    borderColor: "rgba(24,125,160,0.67)"
  },
  card: {
    display: "flex"
  }
});

class MetricsBox extends React.Component {
  state = {
    anchorEl: null
  };

  handlePopoverOpen = event => {
    this.setState({ anchorEl: event.currentTarget });
  };

  handlePopoverClose = () => {
    this.setState({ anchorEl: null });
  };

  render() {
    //const { classes, header, headerLink, data, popperData } = this.props;
    const { classes, header, data, popperData, popperHeaders } = this.props;
    const open = Boolean(this.state.anchorEl);
    const style = {
      background: this.props.bgcolor
    };
    return (
      <React.Fragment>
        <Paper className={classes.root} style={style} border={0}>
          <div
            style={{
              textAlign: "left",
              fontSize: "1.0125rem",
              fontWeight: "600"
            }}
          >
            {header}
            {/*
            {headerLink.match(/\b(http:|https:)/) ? (
              <a
                id="reconMetrics"
                name="reconMetrics"
                rel="noopener noreferrer"
                href={headerLink}
                target="_blank"
              >
                {header}
              </a>
            ) : (
              <Link id="reconMetrics" name="reconMetrics" to={headerLink}>
                {header}
              </Link>
            )}
          */}
          </div>
          <hr
            style={{
              border: "0",
              height: "0",
              borderTop: "1px solid rgba(0, 0, 0, 0.1)",
              borderBottom: "1px solid rgba(255, 255, 255, 0.3)"
            }}
          />
          <div
            style={{ textAlign: "center", fontSize: "30px" }}
            onMouseEnter={this.handlePopoverOpen}
            onMouseLeave={this.handlePopoverClose}
          >
            {data}
          </div>
        </Paper>
        <CustomPopper
          open={open}
          anchorEl={popperData != "" ? this.state.anchorEl : null}
          data={popperData}
          headers={popperHeaders}
        />
      </React.Fragment>
    );
  }
}

MetricsBox.propTypes = {
  classes: PropTypes.object.isRequired,
  header: PropTypes.string,
  headerLink: PropTypes.string,
  data: PropTypes.oneOfType([PropTypes.number, PropTypes.string]),
  popperData: PropTypes.oneOfType([PropTypes.object, PropTypes.string]),
  popperHeaders: PropTypes.array,
  bgcolor: PropTypes.string
};

export default withStyles(classes)(MetricsBox);
