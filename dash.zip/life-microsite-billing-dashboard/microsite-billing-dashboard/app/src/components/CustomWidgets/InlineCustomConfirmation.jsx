import React from "react";
import { render } from "react-dom";
import PropTypes from "prop-types";
import {
  Button,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions
} from "@material-ui/core";

let resolve;

class InlineCustomConfirmation extends React.Component {
  static create(props = {}) {
    const containerElement = document.createElement("div");
    document.body.appendChild(containerElement);
    return render(
      <InlineCustomConfirmation inlineProps={props} />,
      containerElement
    );
  }

  constructor() {
    super();
    this.state = {
      isOpen: false,
      otherProps: {}
    };
  }

  componentDidMount() {
    this._isMounted = true;
  }

  componentWillUnmount() {
    this._isMounted = false;
  }

  handleSubmit = () => {
    this.setState({ isOpen: false });
    resolve(true);
  };

  handleClose = () => {
    this.setState({ isOpen: false });
    resolve(false);
  };

  show(props = {}) {
    const allProps = { ...this.props.inlineProps, ...props };
    this.setState({ isOpen: true, ...allProps });
    return new Promise(res => {
      resolve = res;
    });
  }

  render() {
    const {
      isOpen,
      title,
      button1Title,
      button2Title,
      description
    } = this.state;
    return (
      <Dialog aria-labelledby="customized-dialog-title" open={isOpen}>
        <DialogTitle id="customized-dialog-title">{title}</DialogTitle>
        <DialogContent>
          <div
            dangerouslySetInnerHTML={{
              __html: description
            }}
          />
        </DialogContent>
        <DialogActions>
          <Button color="primary" onClick={this.handleSubmit}>
            {button1Title}
          </Button>
          {button2Title && button2Title !== "" ? (
            <Button color="primary" onClick={this.handleClose} autoFocus>
              {button2Title}
            </Button>
          ) : (
            ""
          )}
        </DialogActions>
      </Dialog>
    );
  }
}

InlineCustomConfirmation.propTypes = {
  inlineProps: PropTypes.object
};

export default InlineCustomConfirmation.create({});
