import React from "react";
import PropTypes from "prop-types";
import Dropzone from "react-dropzone";

import { upload } from "react-icons-kit/icomoon/upload";
import CustomIcon from "components/CustomWidgets/CustomIcon.jsx";

class CustomFileUpload extends React.Component {
  constructor(props) {
    super(props);
  }

  render() {
    const { style, iconMargin, accept, maxSize, onDrop } = this.props;
    return (
      <Dropzone onDrop={onDrop} accept={accept} minSize={0} maxSize={maxSize}>
        {({ getRootProps, getInputProps, rejectedFiles, acceptedFiles }) => (
          <div
            id="fileUploadDiv"
            {...getRootProps()}
            style={style}
            align="center"
          >
            <div style={{ marginTop: iconMargin, cursor: "pointer" }}>
              <input {...getInputProps()} />
              Drag a file into this box, or click anywhere to upload a file!
              <CustomIcon icon={upload} size="48" color="#00838f" />
              {((rejectedFiles.length > 0 && rejectedFiles[0].size < maxSize) ||
                (rejectedFiles.length > 0 &&
                  rejectedFiles[0].name.toLowerCase().indexOf(accept) == -1)) &&
                this.props.getMessage("fileTypeReject")}
              {rejectedFiles.length > 0 &&
                rejectedFiles[0].size > maxSize &&
                this.props.getMessage("sizeReject")}
              {/* This is for IE11 which allows excel even when .csv is present */}
              {acceptedFiles.length > 0 &&
                acceptedFiles[0].name.toLowerCase().indexOf(accept) == -1 &&
                this.props.getMessage("fileTypeReject")}
              {acceptedFiles.length > 0 &&
                acceptedFiles[0].name.toLowerCase().indexOf(accept) > 0 &&
                this.props.getMessage("accept")}
            </div>
          </div>
        )}
      </Dropzone>
    );
  }
}

CustomFileUpload.propTypes = {
  toolTip: PropTypes.string
};

CustomFileUpload.defaultProps = {
  maxSize: 5242880
};

export default CustomFileUpload;
