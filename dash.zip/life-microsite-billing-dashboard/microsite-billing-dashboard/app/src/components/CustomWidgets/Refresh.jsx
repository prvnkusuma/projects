import React from "react";
import Icon from "react-icons-kit";

import Tooltip from "@material-ui/core/Tooltip";
import { refresh } from "react-icons-kit/ionicons/refresh";

class Refresh extends React.Component {
  constructor(props) {
    super(props);
  }

  render() {
    return (
      <React.Fragment>
        <div style={{ textAlign: "right" }}>
          <Tooltip title="Refresh">
            <Icon
              {...this.props}
              style={{
                cursor: "pointer",
                color: "#3f51b5",
                paddingTop: 10
              }}
              size={24}
              icon={refresh}
            />
          </Tooltip>
        </div>
      </React.Fragment>
    );
  }
}

export default Refresh;
