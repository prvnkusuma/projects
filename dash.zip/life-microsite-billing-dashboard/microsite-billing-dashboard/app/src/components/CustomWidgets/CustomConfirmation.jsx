import React from "react";
import PropTypes from "prop-types";
import {
  Button,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions
} from "@material-ui/core";

const CustomConfirmation = ({
  open,
  title,
  button1Title,
  button2Title,
  description,
  onSubmit,
  onClose
}) => {
  return (
    <Dialog aria-labelledby="customized-dialog-title" open={open}>
      <DialogTitle id="customized-dialog-title">{title}</DialogTitle>
      <DialogContent>
        <div
          dangerouslySetInnerHTML={{
            __html: description
          }}
        />
      </DialogContent>
      <DialogActions>
        <Button color="primary" onClick={onSubmit}>
          {button1Title}
        </Button>
        {button2Title ? (
          <Button color="primary" onClick={onClose} autoFocus>
            {button2Title}
          </Button>
        ) : (
          ""
        )}
      </DialogActions>
    </Dialog>
  );
};

CustomConfirmation.propTypes = {
  open: PropTypes.bool,
  title: PropTypes.string,
  button1Title: PropTypes.string,
  button2Title: PropTypes.string,
  description: PropTypes.string,
  onSubmit: PropTypes.func,
  onClose: PropTypes.func
};

export default CustomConfirmation;
