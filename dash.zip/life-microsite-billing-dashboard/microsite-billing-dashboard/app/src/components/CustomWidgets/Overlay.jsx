import React from "react";
import PropTypes from "prop-types";
import LoadingOverlay from "react-loading-overlay";

import LoadingSpinner from "components/CustomWidgets/LoadingSpinner.jsx";
import { withStyles } from "@material-ui/core/styles";

import "assets/css/bits-styles-override.css";

const styles = theme => ({
  progress: {
    margin: theme.spacing.unit * 2
  }
});

const Overlay = props => (
  <LoadingOverlay
    {...props}
    spinner={<LoadingSpinner />}
    classNamePrefix="OverlaySpinner_"
    styles={{
      overlay: base => ({
        ...base,
        background: "rgba(255, 255, 255, 0.7)"
      }),
      content: base => ({
        ...base,
        marginTop: props.marginTop
      })
    }}
  >
    {props.children}
  </LoadingOverlay>
);

Overlay.propTypes = {
  loading: PropTypes.bool
};

export default withStyles(styles)(Overlay);
