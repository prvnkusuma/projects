# Life Billing Dashboard
 
This is a user interface for dash board of life application. There are several screens to analyze the usage counts, monitor the bill process, remittance process, recon process, reprocess the bills, remittances etc.


**Prerequisites:** [Node.js 10+](https://nodejs.org/), and [npm](https://www.npmjs.com/).

* [Getting Started](#getting-started)
* [Development Environment Setup](#dev-env-setup)
* [Links](#links)
* [Help](#help)
* [Learning](#learning)

## Getting Started

Before installing the application, Install nodejs and set the node home folder to the 'path' environment variable.

To install the application, run the following commands:

```bash
git clone https://github.aig.net/Consumer/life-billing-dashboard.git life-billing-dashboard 
cd life-billing-dashboard
```

This will get a copy of the project installed locally. To install all of its dependencies and start each app, follow the instructions below.

To run the client, cd into the `billing-dashboard\app` folder and run the following commands:

For the first time run,

```bash
npm install
```

Note: Ignore any audit errors after npm install command. These are related to webpack-dev-server which is used only on DEV

For all subsequent runs,
 
```bash
npm start
```

Use below command to check for lint errors:

```bash
npm run lint:check
```

## Development Environment Setup

We are using Sublime Text 3 with Sublime Merge. Install the following plugins to Sublime for syntax highlighting, code completion,
lint etc:

* A File Icon
* Babel
* Babel Snippets
* Emmet
* SublimeLinter-contrib-eslint_d
* SublimeLinter-eslint

Complete article is listed under Help links below.
Apart from these plugins, We are using Sublime Merge. Its a great GitHub client from Sublime.
To configure Sublime Merge, 

Run this in Sublime command line to add sublime merge to Sublime Text 3: 

window.settings().set("sublime_merge_path", "C:\\Tools\\sublime_merge_build_1107_x64\\sublime_merge.exe")

or 

Add below line to the user settings: 

"sublime_merge_path": "C:\\Tools\\sublime_merge_build_1107_x64\\sublime_merge.exe"

## Links

This project uses the following open source libraries:

* [React](https://reactjs.org/)
* [Material UI](https://material-ui.com/)

## Help

Here are some other components used in the application:
* [React-Table](https://react-table.js.org)
* [Chart.js 2](https://www.chartjs.org/samples/latest/)
* [React-DatePicker](https://reactdatepicker.com/)
* [Redux](https://redux.js.org/)
* [Redux Thunk](https://github.com/reduxjs/redux-thunk)
* [Simple React Validation](https://www.npmjs.com/package/simple-react-validator)
* [Spinner](https://fontawesome.com/?from=io)
* [Material UI Icons](https://material.io/tools/icons/?icon=line_weight&style=baseline)
* [Material UI Colors](https://material-ui.com/style/color/)
* [React Icons Kit](http://wmira.github.io/react-icons-kit/index.html)
* [Redux Dev Tools](https://github.com/zalmoxisus/redux-devtools-extension#usage)
* [JS File Download](https://www.npmjs.com/package/js-file-download)
* [Sublime Plugin Setup](https://medium.com/@adrianmcli/setting-up-sublime-text-3-for-reactjs-3bf6baceb73a)
* [React Loading Overlay](https://github.com/derrickpelletier/react-loading-overlay)

## Learning

* [ReactJS Concepts](https://scotch.io/tutorials/learning-react-getting-started-and-concepts)
* [ReactJS Basics](https://medium.freecodecamp.org/everything-you-need-to-know-about-react-eaedf53238c4)
* [ReactJS Examples](https://reacttraining.com/react-router/web/example/basic)
* [React Router](https://blog.pshrmn.com/entry/simple-react-router-v4-tutorial/)
* [Redux](https://www.valentinog.com/blog/redux/)